#include <stdio.h> 
#include <assert.h>
#include <math.h>
#include <stdlib.h>

void __VERIFIER_error(int i) {
    fprintf(stderr, "error_%d ", i);
    assert(0);
}

	// inputs
	int inputs[] = {13,16,2,8,9,20,10,17,6,5,15,18,11,12,4,1,19,14,7,3};

	void errorCheck();
	void calculate_output(int);
	void calculate_outputm1(int);
	void calculate_outputm2(int);
	void calculate_outputm3(int);
	void calculate_outputm4(int);
	void calculate_outputm5(int);
	void calculate_outputm6(int);
	void calculate_outputm7(int);
	void calculate_outputm8(int);
	void calculate_outputm9(int);
	void calculate_outputm10(int);
	void calculate_outputm11(int);
	void calculate_outputm12(int);
	void calculate_outputm13(int);
	void calculate_outputm14(int);
	void calculate_outputm15(int);
	void calculate_outputm16(int);
	void calculate_outputm17(int);
	void calculate_outputm18(int);
	void calculate_outputm19(int);
	void calculate_outputm20(int);
	void calculate_outputm21(int);
	void calculate_outputm22(int);
	void calculate_outputm23(int);
	void calculate_outputm24(int);
	void calculate_outputm25(int);
	void calculate_outputm26(int);
	void calculate_outputm27(int);
	void calculate_outputm28(int);
	void calculate_outputm29(int);
	void calculate_outputm30(int);
	void calculate_outputm31(int);
	void calculate_outputm32(int);
	void calculate_outputm33(int);
	void calculate_outputm34(int);
	void calculate_outputm35(int);
	void calculate_outputm36(int);
	void calculate_outputm37(int);
	void calculate_outputm38(int);
	void calculate_outputm39(int);
	void calculate_outputm40(int);
	void calculate_outputm41(int);
	void calculate_outputm42(int);
	void calculate_outputm43(int);
	void calculate_outputm44(int);
	void calculate_outputm45(int);
	void calculate_outputm46(int);
	void calculate_outputm47(int);
	void calculate_outputm48(int);
	void calculate_outputm49(int);
	void calculate_outputm50(int);
	void calculate_outputm51(int);
	void calculate_outputm52(int);
	void calculate_outputm53(int);
	void calculate_outputm54(int);
	void calculate_outputm55(int);
	void calculate_outputm56(int);
	void calculate_outputm57(int);
	void calculate_outputm58(int);
	void calculate_outputm59(int);
	void calculate_outputm60(int);
	void calculate_outputm61(int);
	void calculate_outputm62(int);
	void calculate_outputm63(int);
	void calculate_outputm64(int);
	void calculate_outputm65(int);
	void calculate_outputm66(int);
	void calculate_outputm67(int);
	void calculate_outputm68(int);
	void calculate_outputm69(int);
	void calculate_outputm70(int);
	void calculate_outputm71(int);
	void calculate_outputm72(int);
	void calculate_outputm73(int);
	void calculate_outputm74(int);
	void calculate_outputm75(int);
	void calculate_outputm76(int);
	void calculate_outputm77(int);
	void calculate_outputm78(int);
	void calculate_outputm79(int);
	void calculate_outputm80(int);
	void calculate_outputm81(int);
	void calculate_outputm82(int);
	void calculate_outputm83(int);
	void calculate_outputm84(int);
	void calculate_outputm85(int);
	void calculate_outputm86(int);
	void calculate_outputm87(int);
	void calculate_outputm88(int);
	void calculate_outputm89(int);
	void calculate_outputm90(int);
	void calculate_outputm91(int);
	void calculate_outputm92(int);
	void calculate_outputm93(int);
	void calculate_outputm94(int);
	void calculate_outputm95(int);
	void calculate_outputm96(int);
	void calculate_outputm97(int);
	void calculate_outputm98(int);
	void calculate_outputm99(int);
	void calculate_outputm100(int);
	void calculate_outputm101(int);
	void calculate_outputm102(int);
	void calculate_outputm103(int);
	void calculate_outputm104(int);
	void calculate_outputm105(int);
	void calculate_outputm106(int);
	void calculate_outputm107(int);
	void calculate_outputm108(int);
	void calculate_outputm109(int);
	void calculate_outputm110(int);
	void calculate_outputm111(int);
	void calculate_outputm112(int);
	void calculate_outputm113(int);
	void calculate_outputm114(int);
	void calculate_outputm115(int);
	void calculate_outputm116(int);
	void calculate_outputm117(int);
	void calculate_outputm118(int);
	void calculate_outputm119(int);
	void calculate_outputm120(int);
	void calculate_outputm121(int);
	void calculate_outputm122(int);
	void calculate_outputm123(int);
	void calculate_outputm124(int);
	void calculate_outputm125(int);
	void calculate_outputm126(int);
	void calculate_outputm127(int);
	void calculate_outputm128(int);
	void calculate_outputm129(int);
	void calculate_outputm130(int);
	void calculate_outputm131(int);
	void calculate_outputm132(int);
	void calculate_outputm133(int);
	void calculate_outputm134(int);
	void calculate_outputm135(int);
	void calculate_outputm136(int);
	void calculate_outputm137(int);
	void calculate_outputm138(int);
	void calculate_outputm139(int);
	void calculate_outputm140(int);
	void calculate_outputm141(int);
	void calculate_outputm142(int);
	void calculate_outputm143(int);
	void calculate_outputm144(int);
	void calculate_outputm145(int);
	void calculate_outputm146(int);
	void calculate_outputm147(int);
	void calculate_outputm148(int);
	void calculate_outputm149(int);
	void calculate_outputm150(int);
	void calculate_outputm151(int);
	void calculate_outputm152(int);
	void calculate_outputm153(int);
	void calculate_outputm154(int);
	void calculate_outputm155(int);
	void calculate_outputm156(int);
	void calculate_outputm157(int);
	void calculate_outputm158(int);
	void calculate_outputm159(int);
	void calculate_outputm160(int);
	void calculate_outputm161(int);
	void calculate_outputm162(int);
	void calculate_outputm163(int);
	void calculate_outputm164(int);
	void calculate_outputm165(int);
	void calculate_outputm166(int);
	void calculate_outputm167(int);
	void calculate_outputm168(int);
	void calculate_outputm169(int);
	void calculate_outputm170(int);
	void calculate_outputm171(int);
	void calculate_outputm172(int);
	void calculate_outputm173(int);
	void calculate_outputm174(int);
	void calculate_outputm175(int);
	void calculate_outputm176(int);
	void calculate_outputm177(int);
	void calculate_outputm178(int);
	void calculate_outputm179(int);
	void calculate_outputm180(int);
	void calculate_outputm181(int);
	void calculate_outputm182(int);
	void calculate_outputm183(int);
	void calculate_outputm184(int);
	void calculate_outputm185(int);
	void calculate_outputm186(int);
	void calculate_outputm187(int);
	void calculate_outputm188(int);
	void calculate_outputm189(int);
	void calculate_outputm190(int);
	void calculate_outputm191(int);
	void calculate_outputm192(int);
	void calculate_outputm193(int);
	void calculate_outputm194(int);
	void calculate_outputm195(int);
	void calculate_outputm196(int);
	void calculate_outputm197(int);
	void calculate_outputm198(int);
	void calculate_outputm199(int);
	void calculate_outputm200(int);
	void calculate_outputm201(int);
	void calculate_outputm202(int);
	void calculate_outputm203(int);
	void calculate_outputm204(int);
	void calculate_outputm205(int);
	void calculate_outputm206(int);
	void calculate_outputm207(int);
	void calculate_outputm208(int);
	void calculate_outputm209(int);
	void calculate_outputm210(int);
	void calculate_outputm211(int);
	void calculate_outputm212(int);
	void calculate_outputm213(int);
	void calculate_outputm214(int);
	void calculate_outputm215(int);
	void calculate_outputm216(int);
	void calculate_outputm217(int);
	void calculate_outputm218(int);
	void calculate_outputm219(int);
	void calculate_outputm220(int);
	void calculate_outputm221(int);
	void calculate_outputm222(int);
	void calculate_outputm223(int);
	void calculate_outputm224(int);
	void calculate_outputm225(int);
	void calculate_outputm226(int);
	void calculate_outputm227(int);
	void calculate_outputm228(int);
	void calculate_outputm229(int);
	void calculate_outputm230(int);
	void calculate_outputm231(int);
	void calculate_outputm232(int);
	void calculate_outputm233(int);
	void calculate_outputm234(int);
	void calculate_outputm235(int);
	void calculate_outputm236(int);
	void calculate_outputm237(int);
	void calculate_outputm238(int);
	void calculate_outputm239(int);
	void calculate_outputm240(int);
	void calculate_outputm241(int);
	void calculate_outputm242(int);
	void calculate_outputm243(int);
	void calculate_outputm244(int);
	void calculate_outputm245(int);
	void calculate_outputm246(int);
	void calculate_outputm247(int);
	void calculate_outputm248(int);
	void calculate_outputm249(int);
	void calculate_outputm250(int);
	void calculate_outputm251(int);
	void calculate_outputm252(int);
	void calculate_outputm253(int);
	void calculate_outputm254(int);
	void calculate_outputm255(int);
	void calculate_outputm256(int);
	void calculate_outputm257(int);
	void calculate_outputm258(int);
	void calculate_outputm259(int);
	void calculate_outputm260(int);
	void calculate_outputm261(int);
	void calculate_outputm262(int);
	void calculate_outputm263(int);
	void calculate_outputm264(int);
	void calculate_outputm265(int);
	void calculate_outputm266(int);
	void calculate_outputm267(int);
	void calculate_outputm268(int);
	void calculate_outputm269(int);
	void calculate_outputm270(int);
	void calculate_outputm271(int);
	void calculate_outputm272(int);
	void calculate_outputm273(int);
	void calculate_outputm274(int);
	void calculate_outputm275(int);
	void calculate_outputm276(int);
	void calculate_outputm277(int);
	void calculate_outputm278(int);
	void calculate_outputm279(int);
	void calculate_outputm280(int);
	void calculate_outputm281(int);
	void calculate_outputm282(int);
	void calculate_outputm283(int);
	void calculate_outputm284(int);
	void calculate_outputm285(int);
	void calculate_outputm286(int);
	void calculate_outputm287(int);
	void calculate_outputm288(int);
	void calculate_outputm289(int);
	void calculate_outputm290(int);
	void calculate_outputm291(int);
	void calculate_outputm292(int);
	void calculate_outputm293(int);
	void calculate_outputm294(int);
	void calculate_outputm295(int);
	void calculate_outputm296(int);
	void calculate_outputm297(int);
	void calculate_outputm298(int);
	void calculate_outputm299(int);
	void calculate_outputm300(int);
	void calculate_outputm301(int);
	void calculate_outputm302(int);
	void calculate_outputm303(int);
	void calculate_outputm304(int);
	void calculate_outputm305(int);
	void calculate_outputm306(int);
	void calculate_outputm307(int);
	void calculate_outputm308(int);
	void calculate_outputm309(int);
	void calculate_outputm310(int);
	void calculate_outputm311(int);
	void calculate_outputm312(int);
	void calculate_outputm313(int);
	void calculate_outputm314(int);
	void calculate_outputm315(int);
	void calculate_outputm316(int);
	void calculate_outputm317(int);
	void calculate_outputm318(int);
	void calculate_outputm319(int);
	void calculate_outputm320(int);
	void calculate_outputm321(int);
	void calculate_outputm322(int);
	void calculate_outputm323(int);
	void calculate_outputm324(int);
	void calculate_outputm325(int);
	void calculate_outputm326(int);
	void calculate_outputm327(int);
	void calculate_outputm328(int);
	void calculate_outputm329(int);
	void calculate_outputm330(int);
	void calculate_outputm331(int);
	void calculate_outputm332(int);
	void calculate_outputm333(int);
	void calculate_outputm334(int);
	void calculate_outputm335(int);
	void calculate_outputm336(int);
	void calculate_outputm337(int);
	void calculate_outputm338(int);
	void calculate_outputm339(int);
	void calculate_outputm340(int);
	void calculate_outputm341(int);
	void calculate_outputm342(int);
	void calculate_outputm343(int);
	void calculate_outputm344(int);
	void calculate_outputm345(int);
	void calculate_outputm346(int);
	void calculate_outputm347(int);
	void calculate_outputm348(int);
	void calculate_outputm349(int);
	void calculate_outputm350(int);
	void calculate_outputm351(int);
	void calculate_outputm352(int);
	void calculate_outputm353(int);
	void calculate_outputm354(int);
	void calculate_outputm355(int);
	void calculate_outputm356(int);
	void calculate_outputm357(int);
	void calculate_outputm358(int);
	void calculate_outputm359(int);
	void calculate_outputm360(int);
	void calculate_outputm361(int);
	void calculate_outputm362(int);
	void calculate_outputm363(int);
	void calculate_outputm364(int);
	void calculate_outputm365(int);
	void calculate_outputm366(int);
	void calculate_outputm367(int);
	void calculate_outputm368(int);
	void calculate_outputm369(int);
	void calculate_outputm370(int);
	void calculate_outputm371(int);
	void calculate_outputm372(int);
	void calculate_outputm373(int);
	void calculate_outputm374(int);
	void calculate_outputm375(int);
	void calculate_outputm376(int);
	void calculate_outputm377(int);
	void calculate_outputm378(int);
	void calculate_outputm379(int);
	void calculate_outputm380(int);
	void calculate_outputm381(int);
	void calculate_outputm382(int);
	void calculate_outputm383(int);
	void calculate_outputm384(int);
	void calculate_outputm385(int);
	void calculate_outputm386(int);
	void calculate_outputm387(int);
	void calculate_outputm388(int);
	void calculate_outputm389(int);
	void calculate_outputm390(int);
	void calculate_outputm391(int);
	void calculate_outputm392(int);
	void calculate_outputm393(int);
	void calculate_outputm394(int);
	void calculate_outputm395(int);
	void calculate_outputm396(int);
	void calculate_outputm397(int);
	void calculate_outputm398(int);
	void calculate_outputm399(int);
	void calculate_outputm400(int);
	void calculate_outputm401(int);
	void calculate_outputm402(int);
	void calculate_outputm403(int);
	void calculate_outputm404(int);
	void calculate_outputm405(int);
	void calculate_outputm406(int);
	void calculate_outputm407(int);
	void calculate_outputm408(int);
	void calculate_outputm409(int);
	void calculate_outputm410(int);
	void calculate_outputm411(int);
	void calculate_outputm412(int);
	void calculate_outputm413(int);
	void calculate_outputm414(int);
	void calculate_outputm415(int);
	void calculate_outputm416(int);
	void calculate_outputm417(int);
	void calculate_outputm418(int);
	void calculate_outputm419(int);
	void calculate_outputm420(int);
	void calculate_outputm421(int);
	void calculate_outputm422(int);
	void calculate_outputm423(int);
	void calculate_outputm424(int);
	void calculate_outputm425(int);
	void calculate_outputm426(int);
	void calculate_outputm427(int);
	void calculate_outputm428(int);
	void calculate_outputm429(int);
	void calculate_outputm430(int);
	void calculate_outputm431(int);
	void calculate_outputm432(int);
	void calculate_outputm433(int);
	void calculate_outputm434(int);
	void calculate_outputm435(int);
	void calculate_outputm436(int);
	void calculate_outputm437(int);
	void calculate_outputm438(int);
	void calculate_outputm439(int);
	void calculate_outputm440(int);
	void calculate_outputm441(int);
	void calculate_outputm442(int);
	void calculate_outputm443(int);
	void calculate_outputm444(int);
	void calculate_outputm445(int);
	void calculate_outputm446(int);
	void calculate_outputm447(int);
	void calculate_outputm448(int);
	void calculate_outputm449(int);
	void calculate_outputm450(int);
	void calculate_outputm451(int);
	void calculate_outputm452(int);
	void calculate_outputm453(int);
	void calculate_outputm454(int);
	void calculate_outputm455(int);
	void calculate_outputm456(int);
	void calculate_outputm457(int);
	void calculate_outputm458(int);
	void calculate_outputm459(int);
	void calculate_outputm460(int);
	void calculate_outputm461(int);
	void calculate_outputm462(int);
	void calculate_outputm463(int);
	void calculate_outputm464(int);
	void calculate_outputm465(int);
	void calculate_outputm466(int);
	void calculate_outputm467(int);
	void calculate_outputm468(int);
	void calculate_outputm469(int);
	void calculate_outputm470(int);
	void calculate_outputm471(int);
	void calculate_outputm472(int);
	void calculate_outputm473(int);
	void calculate_outputm474(int);
	void calculate_outputm475(int);
	void calculate_outputm476(int);
	void calculate_outputm477(int);
	void calculate_outputm478(int);
	void calculate_outputm479(int);
	void calculate_outputm480(int);
	void calculate_outputm481(int);
	void calculate_outputm482(int);
	void calculate_outputm483(int);
	void calculate_outputm484(int);
	void calculate_outputm485(int);
	void calculate_outputm486(int);
	void calculate_outputm487(int);
	void calculate_outputm488(int);
	void calculate_outputm489(int);
	void calculate_outputm490(int);
	void calculate_outputm491(int);
	void calculate_outputm492(int);
	void calculate_outputm493(int);
	void calculate_outputm494(int);
	void calculate_outputm495(int);
	void calculate_outputm496(int);
	void calculate_outputm497(int);
	void calculate_outputm498(int);
	void calculate_outputm499(int);
	void calculate_outputm500(int);
	void calculate_outputm501(int);
	void calculate_outputm502(int);
	void calculate_outputm503(int);
	void calculate_outputm504(int);
	void calculate_outputm505(int);
	void calculate_outputm506(int);
	void calculate_outputm507(int);
	void calculate_outputm508(int);
	void calculate_outputm509(int);
	void calculate_outputm510(int);
	void calculate_outputm511(int);
	void calculate_outputm512(int);
	void calculate_outputm513(int);
	void calculate_outputm514(int);
	void calculate_outputm515(int);
	void calculate_outputm516(int);
	void calculate_outputm517(int);
	void calculate_outputm518(int);
	void calculate_outputm519(int);
	void calculate_outputm520(int);
	void calculate_outputm521(int);
	void calculate_outputm522(int);
	void calculate_outputm523(int);
	void calculate_outputm524(int);
	void calculate_outputm525(int);
	void calculate_outputm526(int);
	void calculate_outputm527(int);
	void calculate_outputm528(int);
	void calculate_outputm529(int);
	void calculate_outputm530(int);
	void calculate_outputm531(int);
	void calculate_outputm532(int);
	void calculate_outputm533(int);
	void calculate_outputm534(int);
	void calculate_outputm535(int);
	void calculate_outputm536(int);
	void calculate_outputm537(int);
	void calculate_outputm538(int);
	void calculate_outputm539(int);
	void calculate_outputm540(int);
	void calculate_outputm541(int);
	void calculate_outputm542(int);
	void calculate_outputm543(int);
	void calculate_outputm544(int);
	void calculate_outputm545(int);
	void calculate_outputm546(int);
	void calculate_outputm547(int);
	void calculate_outputm548(int);
	void calculate_outputm549(int);
	void calculate_outputm550(int);
	void calculate_outputm551(int);
	void calculate_outputm552(int);
	void calculate_outputm553(int);
	void calculate_outputm554(int);
	void calculate_outputm555(int);
	void calculate_outputm556(int);
	void calculate_outputm557(int);
	void calculate_outputm558(int);
	void calculate_outputm559(int);
	void calculate_outputm560(int);
	void calculate_outputm561(int);
	void calculate_outputm562(int);
	void calculate_outputm563(int);
	void calculate_outputm564(int);
	void calculate_outputm565(int);
	void calculate_outputm566(int);
	void calculate_outputm567(int);
	void calculate_outputm568(int);
	void calculate_outputm569(int);
	void calculate_outputm570(int);
	void calculate_outputm571(int);
	void calculate_outputm572(int);
	void calculate_outputm573(int);
	void calculate_outputm574(int);
	void calculate_outputm575(int);
	void calculate_outputm576(int);
	void calculate_outputm577(int);
	void calculate_outputm578(int);
	void calculate_outputm579(int);
	void calculate_outputm580(int);
	void calculate_outputm581(int);
	void calculate_outputm582(int);
	void calculate_outputm583(int);
	void calculate_outputm584(int);
	void calculate_outputm585(int);
	void calculate_outputm586(int);
	void calculate_outputm587(int);
	void calculate_outputm588(int);
	void calculate_outputm589(int);
	void calculate_outputm590(int);
	void calculate_outputm591(int);
	void calculate_outputm592(int);
	void calculate_outputm593(int);
	void calculate_outputm594(int);
	void calculate_outputm595(int);
	void calculate_outputm596(int);
	void calculate_outputm597(int);
	void calculate_outputm598(int);
	void calculate_outputm599(int);
	void calculate_outputm600(int);
	void calculate_outputm601(int);
	void calculate_outputm602(int);
	void calculate_outputm603(int);
	void calculate_outputm604(int);
	void calculate_outputm605(int);
	void calculate_outputm606(int);
	void calculate_outputm607(int);
	void calculate_outputm608(int);
	void calculate_outputm609(int);
	void calculate_outputm610(int);
	void calculate_outputm611(int);
	void calculate_outputm612(int);
	void calculate_outputm613(int);
	void calculate_outputm614(int);
	void calculate_outputm615(int);
	void calculate_outputm616(int);
	void calculate_outputm617(int);
	void calculate_outputm618(int);
	void calculate_outputm619(int);
	void calculate_outputm620(int);
	void calculate_outputm621(int);
	void calculate_outputm622(int);
	void calculate_outputm623(int);
	void calculate_outputm624(int);
	void calculate_outputm625(int);
	void calculate_outputm626(int);
	void calculate_outputm627(int);
	void calculate_outputm628(int);
	void calculate_outputm629(int);
	void calculate_outputm630(int);
	void calculate_outputm631(int);
	void calculate_outputm632(int);
	void calculate_outputm633(int);
	void calculate_outputm634(int);
	void calculate_outputm635(int);
	void calculate_outputm636(int);
	void calculate_outputm637(int);
	void calculate_outputm638(int);
	void calculate_outputm639(int);
	void calculate_outputm640(int);
	void calculate_outputm641(int);
	void calculate_outputm642(int);
	void calculate_outputm643(int);
	void calculate_outputm644(int);
	void calculate_outputm645(int);
	void calculate_outputm646(int);
	void calculate_outputm647(int);
	void calculate_outputm648(int);
	void calculate_outputm649(int);
	void calculate_outputm650(int);
	void calculate_outputm651(int);
	void calculate_outputm652(int);
	void calculate_outputm653(int);
	void calculate_outputm654(int);
	void calculate_outputm655(int);
	void calculate_outputm656(int);
	void calculate_outputm657(int);
	void calculate_outputm658(int);
	void calculate_outputm659(int);
	void calculate_outputm660(int);
	void calculate_outputm661(int);
	void calculate_outputm662(int);
	void calculate_outputm663(int);
	void calculate_outputm664(int);
	void calculate_outputm665(int);
	void calculate_outputm666(int);
	void calculate_outputm667(int);
	void calculate_outputm668(int);
	void calculate_outputm669(int);
	void calculate_outputm670(int);
	void calculate_outputm671(int);
	void calculate_outputm672(int);
	void calculate_outputm673(int);
	void calculate_outputm674(int);
	void calculate_outputm675(int);
	void calculate_outputm676(int);
	void calculate_outputm677(int);
	void calculate_outputm678(int);
	void calculate_outputm679(int);
	void calculate_outputm680(int);
	void calculate_outputm681(int);
	void calculate_outputm682(int);
	void calculate_outputm683(int);
	void calculate_outputm684(int);
	void calculate_outputm685(int);
	void calculate_outputm686(int);
	void calculate_outputm687(int);
	void calculate_outputm688(int);
	void calculate_outputm689(int);
	void calculate_outputm690(int);
	void calculate_outputm691(int);
	void calculate_outputm692(int);
	void calculate_outputm693(int);
	void calculate_outputm694(int);
	void calculate_outputm695(int);
	void calculate_outputm696(int);
	void calculate_outputm697(int);
	void calculate_outputm698(int);
	void calculate_outputm699(int);
	void calculate_outputm700(int);
	void calculate_outputm701(int);
	void calculate_outputm702(int);
	void calculate_outputm703(int);
	void calculate_outputm704(int);
	void calculate_outputm705(int);
	void calculate_outputm706(int);
	void calculate_outputm707(int);
	void calculate_outputm708(int);
	void calculate_outputm709(int);
	void calculate_outputm710(int);
	void calculate_outputm711(int);
	void calculate_outputm712(int);
	void calculate_outputm713(int);
	void calculate_outputm714(int);
	void calculate_outputm715(int);
	void calculate_outputm716(int);
	void calculate_outputm717(int);
	void calculate_outputm718(int);
	void calculate_outputm719(int);
	void calculate_outputm720(int);
	void calculate_outputm721(int);
	void calculate_outputm722(int);
	void calculate_outputm723(int);
	void calculate_outputm724(int);
	void calculate_outputm725(int);
	void calculate_outputm726(int);
	void calculate_outputm727(int);
	void calculate_outputm728(int);
	void calculate_outputm729(int);
	void calculate_outputm730(int);
	void calculate_outputm731(int);
	void calculate_outputm732(int);
	void calculate_outputm733(int);
	void calculate_outputm734(int);
	void calculate_outputm735(int);
	void calculate_outputm736(int);
	void calculate_outputm737(int);
	void calculate_outputm738(int);
	void calculate_outputm739(int);
	void calculate_outputm740(int);
	void calculate_outputm741(int);
	void calculate_outputm742(int);
	void calculate_outputm743(int);
	void calculate_outputm744(int);
	void calculate_outputm745(int);
	void calculate_outputm746(int);
	void calculate_outputm747(int);
	void calculate_outputm748(int);
	void calculate_outputm749(int);
	void calculate_outputm750(int);
	void calculate_outputm751(int);
	void calculate_outputm752(int);
	void calculate_outputm753(int);
	void calculate_outputm754(int);
	void calculate_outputm755(int);
	void calculate_outputm756(int);
	void calculate_outputm757(int);
	void calculate_outputm758(int);
	void calculate_outputm759(int);
	void calculate_outputm760(int);
	void calculate_outputm761(int);
	void calculate_outputm762(int);
	void calculate_outputm763(int);
	void calculate_outputm764(int);
	void calculate_outputm765(int);
	void calculate_outputm766(int);
	void calculate_outputm767(int);
	void calculate_outputm768(int);
	void calculate_outputm769(int);
	void calculate_outputm770(int);
	void calculate_outputm771(int);
	void calculate_outputm772(int);
	void calculate_outputm773(int);
	void calculate_outputm774(int);
	void calculate_outputm775(int);
	void calculate_outputm776(int);
	void calculate_outputm777(int);
	void calculate_outputm778(int);
	void calculate_outputm779(int);
	void calculate_outputm780(int);
	void calculate_outputm781(int);
	void calculate_outputm782(int);
	void calculate_outputm783(int);
	void calculate_outputm784(int);
	void calculate_outputm785(int);
	void calculate_outputm786(int);
	void calculate_outputm787(int);
	void calculate_outputm788(int);
	void calculate_outputm789(int);
	void calculate_outputm790(int);
	void calculate_outputm791(int);
	void calculate_outputm792(int);
	void calculate_outputm793(int);
	void calculate_outputm794(int);
	void calculate_outputm795(int);
	void calculate_outputm796(int);
	void calculate_outputm797(int);
	void calculate_outputm798(int);
	void calculate_outputm799(int);
	void calculate_outputm800(int);
	void calculate_outputm801(int);
	void calculate_outputm802(int);
	void calculate_outputm803(int);
	void calculate_outputm804(int);
	void calculate_outputm805(int);
	void calculate_outputm806(int);

	 int a1009240021 = 10;
	 int a207863872 = 8;
	 int a2135613870  = 34;
	 int a1085908735  = 32;
	 int a534598694 = 10;
	 int a1172911487  = 35;
	 int a1519100789 = 4;
	 int a1166586546 = 13;
	 int a1505404504 = 4;
	 int a465336174  = 35;
	 int a662123779 = 6;
	 int a1690193643  = 34;
	 int a363404159 = 3;
	 int a1506379905  = 34;
	 int a2005069365  = 36;
	 int a221974990 = 11;
	 int a1235481610 = 10;
	 int a71813398 = 5;
	 int a1307756142  = 34;
	 int a1739072993  = 36;
	 int a805812408 = 11;
	 int a349181387 = 5;
	 int a679327000  = 34;
	 int a933478840  = 36;
	 int a1561044360  = 32;
	 int a798343693 = 10;
	 int a397915314 = 7;
	 int a990124478  = 32;
	 int a747683138  = 35;
	 int a48792734  = 36;
	 int a1682504076 = 6;
	 int a529769874 = 8;
	 int a525429632  = 33;
	 int a1795880353  = 33;
	 int a1904774218  = 33;
	 int a1838812917  = 32;
	 int a1388584441  = 32;
	 int a1883016343 = 11;
	 int a1089968358 = 7;
	 int a954368445 = 3;
	 int a991719280  = 34;
	 int a1116999236 = 11;
	 int a1093326457  = 36;
	 int a1754726785 = 14;
	 int a132648993 = 13;
	 int a1684687706 = 10;
	 int a650110038  = 32;
	 int a1243394452 = 3;
	 int a666963702 = 13;
	 int a1428914468 = 12;
	 int a1204193075  = 33;
	 int a892217980 = 12;
	 int a604409338  = 32;
	 int a1239184736  = 35;
	 int a1086754137 = 11;
	 int a998584754 = 10;
	 int a1271566896 = 8;
	 int a169540124  = 34;
	 int a1146785657  = 32;
	 int a1610737594  = 35;
	 int a132552289 = 12;
	 int a749536178 = 5;
	 int a602507557  = 34;
	 int a275125637 = 8;
	 int a759122969 = 8;
	 int a928570136  = 35;
	 int a2077351330 = 3;
	 int a1186984341  = 33;
	 int a1015737466 = 9;
	 int a451941968  = 34;
	 int cf = 1;
	 int a603781876 = 7;
	 int a1052150692 = 13;
	 int a1639827725  = 34;
	 int a1815432985  = 34;
	 int a1325377146  = 35;
	 int a353267992  = 33;
	 int a792575314 = 9;
	 int a925870636 = 10;
	 int a1039723590  = 36;
	 int a986008840 = 15;
	 int a524102808 = 10;
	 int a1275896582  = 32;
	 int a727645622  = 36;
	 int a844311967  = 33;
	 int a1957279511 = 2;
	 int a1857807887  = 32;
	 int a836757480  = 36;
	 int a1194623510  = 33;
	 int a920118831 = 11;
	 int a868028614  = 32;
	 int a1958000800 = 12;
	 int a829511935  = 33;
	 int a1843210244  = 35;
	 int a745730534  = 32;
	 int a200393381 = 3;
	 int a201083786 = 11;
	 int a596573336 = 12;
	 int a740799408  = 33;
	 int a245033430 = 15;
	 int a738616794  = 32;
	 int a1549928701 = 8;
	 int a369539608  = 36;
	 int a1894975097 = 7;
	 int a714559100 = 5;
	 int a1710271440 = 8;
	 int a1127376297  = 33;
	 int a706302795 = 8;
	 int a772592654 = 4;
	 int a1756771009  = 36;
	 int a1960724031  = 32;
	 int a304497462 = 11;
	 int a2059681452  = 33;
	 int a1735753243 = 7;
	 int a1571676929  = 32;
	 int a110820676  = 34;
	 int a18979981 = 8;
	 int a2125137407 = 10;
	 int a685344195 = 7;
	 int a107446547 = 12;
	 int a367284938  = 36;
	 int a744476156  = 32;
	 int a806083420  = 36;
	 int a1350444666  = 32;
	 int a1655731851 = 5;
	 int a1153134505  = 33;
	 int a2124036967  = 34;
	 int a205734433 = 8;
	 int a2002331280  = 34;
	 int a264802066  = 32;
	 int a687007811  = 32;
	 int a347749795 = 10;
	 int a1184734075 = 14;
	 int a1096033747  = 33;
	 int a1699038459 = 8;
	 int a461439918 = 7;
	 int a240738299  = 36;
	 int a569036257 = 9;
	 int a137564664 = 13;
	 int a685667843 = 15;
	 int a206599328  = 35;
	 int a1944506598  = 34;
	 int a2016510333  = 34;
	 int a1109056640 = 1;
	 int a1492184786  = 35;
	 int a1872268177  = 33;
	 int a1380627758 = 10;
	 int a927953139  = 32;
	 int a1688003115 = 11;
	 int a1684674520  = 35;
	 int a1124714117 = 1;
	 int a815941786  = 36;
	 int a88077474  = 34;
	 int a1942309322  = 34;
	 int a2065134388 = 17;
	 int a976704484 = 5;
	 int a969893172  = 35;
	 int a1129866701 = 9;
	 int a1144659688 = 5;
	 int a113788596  = 33;
	 int a2138261183 = 5;
	 int a691578539 = 6;
	 int a1950243878  = 35;
	 int a317927282 = 10;
	 int a1498704550  = 34;
	 int a1468138070  = 34;
	 int a2110599067 = 13;
	 int a27741386  = 35;
	 int a1775644016 = 10;
	 int a67466277  = 32;
	 int a103910758  = 34;
	 int a1577567933  = 36;
	 int a593874874 = 15;
	 int a834910632  = 33;
	 int a1079106761 = 12;
	 int a1566584718 = 14;
	 int a491478835  = 36;
	 int a246458106  = 36;
	 int a904637882 = 9;


	void errorCheck() {
	    if((((a1307756142 == 36 && a369539608 == 35) && a1519100789 == 5) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(0);
	    }
	    if((((a1872268177 == 33 && a1958000800 == 6) && a1519100789 == 9) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(1);
	    }
	    if((((a525429632 == 35 && a1775644016 == 13) && a1838812917 == 36) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(2);
	    }
	    if((((a1089968358 == 7 && a714559100 == 5) && a1838812917 == 35) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(3);
	    }
	    if((((a132648993 == 14 && a107446547 == 13) && a2059681452 == 36) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(4);
	    }
	    if((((a2135613870 == 33 && a1428914468 == 11) && a969893172 == 33) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(5);
	    }
	    if((((a245033430 == 12 && a2124036967 == 33) && a969893172 == 36) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(6);
	    }
	    if((((a2059681452 == 32 && a107446547 == 13) && a1838812917 == 34) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(7);
	    }
	    if((((a1815432985 == 34 && a569036257 == 5) && a1838812917 == 33) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(8);
	    }
	    if((((a1109056640 == 5 && a240738299 == 34) && a1519100789 == 4) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(9);
	    }
	    if((((a928570136 == 32 && a27741386 == 32) && a1904774218 == 32) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(10);
	    }
	    if((((a1124714117 == 8 && a369539608 == 32) && a1904774218 == 35) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(11);
	    }
	    if((((a933478840 == 32 && a604409338 == 34) && a1519100789 == 6) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(12);
	    }
	    if((((a1815432985 == 35 && a569036257 == 5) && a1838812917 == 33) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(13);
	    }
	    if((((a806083420 == 34 && a928570136 == 33) && a1904774218 == 36) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(14);
	    }
	    if((((a1754726785 == 9 && a369539608 == 34) && a1904774218 == 35) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(15);
	    }
	    if((((a986008840 == 13 && a107446547 == 14) && a2059681452 == 36) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(16);
	    }
	    if((((a1904774218 == 35 && a88077474 == 32) && a1519100789 == 3) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(17);
	    }
	    if((((a465336174 == 33 && a569036257 == 7) && a1838812917 == 33) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(18);
	    }
	    if((((a1307756142 == 34 && a369539608 == 35) && a1519100789 == 5) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(19);
	    }
	    if((((a1754726785 == 12 && a369539608 == 34) && a1904774218 == 35) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(20);
	    }
	    if((((a245033430 == 15 && a2124036967 == 33) && a969893172 == 36) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(21);
	    }
	    if((((a954368445 == 8 && a604409338 == 33) && a1519100789 == 6) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(22);
	    }
	    if((((a1639827725 == 34 && a685667843 == 11) && a969893172 == 35) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(23);
	    }
	    if((((a1894975097 == 9 && a369539608 == 33) && a1519100789 == 5) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(24);
	    }
	    if((((a798343693 == 11 && a1958000800 == 12) && a1519100789 == 9) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(25);
	    }
	    if((((a71813398 == 5 && a1052150692 == 7) && a1519100789 == 2) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(26);
	    }
	    if((((a666963702 == 10 && a925870636 == 10) && a1904774218 == 34) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(27);
	    }
	    if((((a2135613870 == 33 && a107446547 == 14) && a1838812917 == 34) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(28);
	    }
	    if((((a18979981 == 6 && a1684687706 == 11) && a2059681452 == 34) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(29);
	    }
	    if((((a1109056640 == 2 && a240738299 == 34) && a1519100789 == 4) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(30);
	    }
	    if((((a363404159 == 3 && a369539608 == 35) && a1904774218 == 35) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(31);
	    }
	    if((((a666963702 == 13 && a928570136 == 35) && a1904774218 == 36) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(32);
	    }
	    if((((a1688003115 == 7 && a604409338 == 36) && a1519100789 == 6) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(33);
	    }
	    if((((a685344195 == 11 && a1243394452 == 4) && a1519100789 == 7) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(34);
	    }
	    if((((a2077351330 == 8 && a369539608 == 33) && a1904774218 == 35) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(35);
	    }
	    if((((a1096033747 == 35 && a927953139 == 32) && a1838812917 == 32) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(36);
	    }
	    if((((a603781876 == 12 && a679327000 == 34) && a2059681452 == 32) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(37);
	    }
	    if((((a1166586546 == 11 && a1775644016 == 8) && a1838812917 == 36) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(38);
	    }
	    if((((a1166586546 == 9 && a1775644016 == 8) && a1838812917 == 36) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(39);
	    }
	    if((((a904637882 == 8 && a925870636 == 9) && a1904774218 == 34) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(40);
	    }
	    if((((a1146785657 == 33 && a1129866701 == 6) && a2059681452 == 35) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(41);
	    }
	    if((((a1009240021 == 10 && a27741386 == 34) && a1904774218 == 32) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(42);
	    }
	    if((((a525429632 == 33 && a1775644016 == 13) && a1838812917 == 36) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(43);
	    }
	    if((((a1124714117 == 5 && a679327000 == 36) && a2059681452 == 32) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(44);
	    }
	    if((((a397915314 == 7 && a927953139 == 35) && a1838812917 == 32) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(45);
	    }
	    if((((a836757480 == 36 && a928570136 == 32) && a1904774218 == 36) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(46);
	    }
	    if((((a1872268177 == 32 && a1428914468 == 14) && a969893172 == 33) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(47);
	    }
	    if((((a1710271440 == 12 && a1684687706 == 12) && a2059681452 == 34) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(48);
	    }
	    if((((a200393381 == 5 && a1775644016 == 6) && a1838812917 == 36) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(49);
	    }
	    if((((a1079106761 == 9 && a714559100 == 5) && a969893172 == 34) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(50);
	    }
	    if((((a662123779 == 10 && a1052150692 == 10) && a1519100789 == 2) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(51);
	    }
	    if((((a205734433 == 12 && a844311967 == 35) && a1904774218 == 33) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(52);
	    }
	    if((((a603781876 == 11 && a679327000 == 34) && a2059681452 == 32) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(53);
	    }
	    if((((a1186984341 == 35 && a1684687706 == 7) && a2059681452 == 34) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(54);
	    }
	    if((((a1684674520 == 32 && a369539608 == 34) && a1519100789 == 5) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(55);
	    }
	    if((((a169540124 == 33 && a927953139 == 36) && a1838812917 == 32) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(56);
	    }
	    if((((a2125137407 == 6 && a714559100 == 10) && a1838812917 == 35) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(57);
	    }
	    if((((a1904774218 == 34 && a569036257 == 9) && a1838812917 == 33) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(58);
	    }
	    if((((a245033430 == 17 && a2124036967 == 33) && a969893172 == 36) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(59);
	    }
	    if((((a205734433 == 9 && a844311967 == 35) && a1904774218 == 33) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(60);
	    }
	    if((((a772592654 == 10 && a113788596 == 36) && a1519100789 == 8) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(61);
	    }
	    if((((a1795880353 == 36 && a107446547 == 8) && a2059681452 == 36) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(62);
	    }
	    if((((a1735753243 == 4 && a1243394452 == 2) && a1519100789 == 7) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(63);
	    }
	    if((((a1894975097 == 12 && a369539608 == 33) && a1519100789 == 5) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(64);
	    }
	    if((((a792575314 == 12 && a27741386 == 36) && a1904774218 == 32) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(65);
	    }
	    if((((a834910632 == 35 && a685667843 == 10) && a969893172 == 35) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(66);
	    }
	    if((((a1009240021 == 6 && a27741386 == 34) && a1904774218 == 32) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(67);
	    }
	    if((((a805812408 == 9 && a714559100 == 11) && a1838812917 == 35) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(68);
	    }
	    if((((a928570136 == 33 && a27741386 == 32) && a1904774218 == 32) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(69);
	    }
	    if((((a1350444666 == 34 && a1775644016 == 7) && a1838812917 == 36) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(70);
	    }
	    if((((a1039723590 == 35 && a747683138 == 35) && a2059681452 == 33) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(71);
	    }
	    if((((a691578539 == 9 && a1129866701 == 11) && a2059681452 == 35) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(72);
	    }
	    if((((a524102808 == 10 && a2124036967 == 36) && a969893172 == 36) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(73);
	    }
	    if((((a687007811 == 32 && a714559100 == 11) && a969893172 == 34) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(74);
	    }
	    if((((a1815432985 == 33 && a1243394452 == 3) && a1519100789 == 7) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(75);
	    }
	    if((((a1124714117 == 2 && a369539608 == 32) && a1904774218 == 35) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(76);
	    }
	    if((((a221974990 == 8 && a650110038 == 36) && a969893172 == 32) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(77);
	    }
	    if((((a317927282 == 12 && a844311967 == 34) && a1904774218 == 33) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(78);
	    }
	    if((((a48792734 == 34 && a925870636 == 12) && a1904774218 == 34) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(79);
	    }
	    if((((a759122969 == 6 && a925870636 == 13) && a1904774218 == 34) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(80);
	    }
	    if((((a805812408 == 10 && a714559100 == 11) && a1838812917 == 35) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(81);
	    }
	    if((((a1172911487 == 33 && a747683138 == 36) && a2059681452 == 33) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(82);
	    }
	    if((((a792575314 == 8 && a27741386 == 36) && a1904774218 == 32) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(83);
	    }
	    if((((a1039723590 == 34 && a747683138 == 35) && a2059681452 == 33) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(84);
	    }
	    if((((a246458106 == 35 && a1243394452 == 5) && a1519100789 == 7) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(85);
	    }
	    if((((a2135613870 == 34 && a1428914468 == 11) && a969893172 == 33) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(86);
	    }
	    if((((a1235481610 == 6 && a844311967 == 36) && a1904774218 == 33) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(87);
	    }
	    if((((a1124714117 == 6 && a369539608 == 32) && a1904774218 == 35) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(88);
	    }
	    if((((a1795880353 == 35 && a107446547 == 8) && a2059681452 == 36) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(89);
	    }
	    if((((a1566584718 == 14 && a1775644016 == 11) && a1838812917 == 36) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(90);
	    }
	    if((((a1079106761 == 13 && a714559100 == 5) && a969893172 == 34) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(91);
	    }
	    if((((a1271566896 == 9 && a1129866701 == 13) && a2059681452 == 35) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(92);
	    }
	    if((((a461439918 == 8 && a1129866701 == 12) && a2059681452 == 35) && a2005069365 == 33)){
	    cf = 0;
	    __VERIFIER_error(93);
	    }
	    if((((a1015737466 == 8 && a650110038 == 33) && a969893172 == 32) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(94);
	    }
	    if((((a798343693 == 4 && a1958000800 == 12) && a1519100789 == 9) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(95);
	    }
	    if((((a1815432985 == 34 && a1243394452 == 3) && a1519100789 == 7) && a2005069365 == 35)){
	    cf = 0;
	    __VERIFIER_error(96);
	    }
	    if((((a205734433 == 8 && a569036257 == 6) && a1838812917 == 33) && a2005069365 == 36)){
	    cf = 0;
	    __VERIFIER_error(97);
	    }
	    if((((a928570136 == 36 && a27741386 == 32) && a1904774218 == 32) && a2005069365 == 32)){
	    cf = 0;
	    __VERIFIER_error(98);
	    }
	    if((((a245033430 == 10 && a2124036967 == 33) && a969893172 == 36) && a2005069365 == 34)){
	    cf = 0;
	    __VERIFIER_error(99);
	    }
	}
 void calculate_outputm31(int input) {
    if(((a928570136 == 34 && (a2005069365 == 32 && ((input == 12) && ( cf==1  && a1904774218 == 32)))) && a27741386 == 32)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a2135613870 = 35 ;
    	a1428914468 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 13) && (a1904774218 == 32 && (a2005069365 == 32 && (a27741386 == 32 && ( cf==1  && a928570136 == 34)))))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a569036257 = 6;
    	a2005069365 = 36 ;
    	a205734433 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1904774218 == 32 && (a27741386 == 32 && (( cf==1  && a2005069365 == 32) && a928570136 == 34))) && (input == 14))) {
    	cf = 0;
    	a2135613870 = 35 ;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 32 && ((a1904774218 == 32 && ( cf==1  && (input == 19))) && a27741386 == 32)) && a928570136 == 34)) {
    	cf = 0;
    	a925870636 = 10;
    	a1904774218 = 34 ;
    	a666963702 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm33(int input) {
    if(((input == 16) && ((a27741386 == 33 && (( cf==1  && a2005069365 == 32) && a706302795 == 10)) && a1904774218 == 32))) {
    	cf = 0;
    	a1519100789 = 7;
    	a246458106 = 36 ;
    	a2005069365 = 35 ;
    	a1243394452 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm34(int input) {
    if(((input == 6) && ((a1904774218 == 32 && (( cf==1  && a27741386 == 33) && a2005069365 == 32)) && a706302795 == 12))) {
    	cf = 0;
    	a1958000800 = 7;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a207863872 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a706302795 == 12 && ((((a2005069365 == 32 &&  cf==1 ) && a27741386 == 33) && a1904774218 == 32) && (input == 10)))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1492184786 = 33 ;
    	a1838812917 = 36 ;
    	a1775644016 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1904774218 == 32 && ((input == 16) && (a2005069365 == 32 && (( cf==1  && a706302795 == 12) && a27741386 == 33))))) {
    	cf = 0;
    	a88077474 = 36 ;
    	a744476156 = 32 ;
    	a2005069365 = 35 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a27741386 == 33 && (a1904774218 == 32 && ((input == 19) && (( cf==1  && a2005069365 == 32) && a706302795 == 12))))) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a369539608 = 34 ;
    	a1754726785 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a706302795 == 12 && (((a2005069365 == 32 &&  cf==1 ) && a27741386 == 33) && a1904774218 == 32)) && (input == 8))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a525429632 = 33 ;
    	a1775644016 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm35(int input) {
    if((a27741386 == 33 && ((a706302795 == 13 && ((a2005069365 == 32 &&  cf==1 ) && (input == 1))) && a1904774218 == 32))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1186984341 = 33 ;
    	a1684687706 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1904774218 == 32 && ((a706302795 == 13 && ( cf==1  && a2005069365 == 32)) && a27741386 == 33)) && (input == 4))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 13;
    	a1271566896 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a2005069365 == 32 && (( cf==1  && (input == 5)) && a1904774218 == 32)) && a706302795 == 13) && a27741386 == 33)) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a844311967 = 34 ;
    	a317927282 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm36(int input) {
    if(((((a1904774218 == 32 && (a706302795 == 14 &&  cf==1 )) && a27741386 == 33) && a2005069365 == 32) && (input == 8))) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a747683138 = 34 ;
    	a2005069365 = 33 ;
    	a1428914468 = 13; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 10) && ((((a27741386 == 33 &&  cf==1 ) && a2005069365 == 32) && a1904774218 == 32) && a706302795 == 14))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a206599328 = 33 ;
    	a714559100 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a706302795 == 14 && ((a1904774218 == 32 && (( cf==1  && (input == 20)) && a27741386 == 33)) && a2005069365 == 32))) {
    	cf = 0;
    	a1129866701 = 10;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a596573336 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm37(int input) {
    if((((((a27741386 == 33 &&  cf==1 ) && a1904774218 == 32) && (input == 1)) && a706302795 == 15) && a2005069365 == 32)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1775644016 = 6;
    	a200393381 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a706302795 == 15 && (a1904774218 == 32 && ((input == 10) && (a2005069365 == 32 && ( cf==1  && a27741386 == 33)))))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a2135613870 = 32 ;
    	a1428914468 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a27741386 == 33 && ((a1904774218 == 32 && (( cf==1  && a2005069365 == 32) && a706302795 == 15)) && (input == 13)))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a844311967 = 32 ;
    	a749536178 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm38(int input) {
    if((a1009240021 == 3 && (a2005069365 == 32 && ((((input == 7) &&  cf==1 ) && a1904774218 == 32) && a27741386 == 34)))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a1872268177 = 33 ;
    	a969893172 = 33 ;
    	a1428914468 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1009240021 == 3 && ((input == 14) && (a27741386 == 34 && (a1904774218 == 32 && ( cf==1  && a2005069365 == 32)))))) {
    	cf = 0;
    	a844311967 = 36 ;
    	a1904774218 = 33 ;
    	a1235481610 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 32 && ((((a1009240021 == 3 &&  cf==1 ) && (input == 15)) && a1904774218 == 32) && a27741386 == 34))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a1325377146 = 33 ;
    	a569036257 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((((input == 20) &&  cf==1 ) && a1904774218 == 32) && a1009240021 == 3) && a2005069365 == 32) && a27741386 == 34)) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a2059681452 = 33 ;
    	a107446547 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm39(int input) {
    if((((a27741386 == 34 && (a1009240021 == 4 && (a2005069365 == 32 &&  cf==1 ))) && a1904774218 == 32) && (input == 1))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a744476156 = 33 ;
    	a88077474 = 36 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((((a1009240021 == 4 &&  cf==1 ) && a27741386 == 34) && a2005069365 == 32) && (input == 13)) && a1904774218 == 32)) {
    	cf = 0;
    	a927953139 = 34 ;
    	a1838812917 = 32 ;
    	a2005069365 = 36 ;
    	a1857807887 = 34 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 19) && ((a27741386 == 34 && (a1009240021 == 4 && ( cf==1  && a1904774218 == 32))) && a2005069365 == 32))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a491478835 = 32 ;
    	a714559100 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((( cf==1  && (input == 20)) && a2005069365 == 32) && a1904774218 == 32) && a27741386 == 34) && a1009240021 == 4)) {
    	cf = 0;
    	a1756771009 = 32 ;
    	a2005069365 = 35 ;
    	a240738299 = 32 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm40(int input) {
    if(((a1009240021 == 5 && (a2005069365 == 32 && (a1904774218 == 32 && ( cf==1  && (input == 2))))) && a27741386 == 34)) {
    	cf = 0;
    	a1009240021 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1009240021 == 5 && (((a1904774218 == 32 && ( cf==1  && a27741386 == 34)) && (input == 10)) && a2005069365 == 32))) {
    	cf = 0;
    	a491478835 = 36 ;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1009240021 == 5 && (a1904774218 == 32 && ((a27741386 == 34 && (a2005069365 == 32 &&  cf==1 )) && (input == 11))))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a525429632 = 36 ;
    	a969893172 = 33 ;
    	a1428914468 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm42(int input) {
    if((a1904774218 == 32 && (((((input == 13) &&  cf==1 ) && a1009240021 == 9) && a2005069365 == 32) && a27741386 == 34))) {
    	cf = 0;
    	a525429632 = 34 ;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1775644016 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm44(int input) {
    if((a1904774218 == 32 && (a27741386 == 35 && ((( cf==1  && a829511935 == 33) && a2005069365 == 32) && (input == 15))))) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a1960724031 = 36 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm45(int input) {
    if((((a27741386 == 35 && (((input == 1) &&  cf==1 ) && a1904774218 == 32)) && a2005069365 == 32) && a829511935 == 35)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1146785657 = 34 ;
    	a1129866701 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 32 && ((input == 5) && (a1904774218 == 32 && (( cf==1  && a27741386 == 35) && a829511935 == 35))))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a679327000 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a27741386 == 35 && ((a829511935 == 35 && ((a2005069365 == 32 &&  cf==1 ) && a1904774218 == 32)) && (input == 6)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1153134505 = 33 ;
    	a240738299 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((a1904774218 == 32 && ( cf==1  && a2005069365 == 32)) && a27741386 == 35) && (input == 7)) && a829511935 == 35)) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm46(int input) {
    if((a1904774218 == 32 && ((input == 1) && (a2005069365 == 32 && (a27741386 == 35 && (a829511935 == 36 &&  cf==1 )))))) {
    	cf = 0;
    	a687007811 = 35 ;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a714559100 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 32 && ((((input == 11) && ( cf==1  && a829511935 == 36)) && a1904774218 == 32) && a27741386 == 35))) {
    	cf = 0;
    	a927953139 = 33 ;
    	a2005069365 = 36 ;
    	a1838812917 = 32 ;
    	a1944506598 = 33 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1904774218 == 32 && ((input == 17) && (((a27741386 == 35 &&  cf==1 ) && a829511935 == 36) && a2005069365 == 32)))) {
    	cf = 0;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1958000800 = 12;
    	a798343693 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a829511935 == 36 && (a2005069365 == 32 && (a27741386 == 35 && (((input == 19) &&  cf==1 ) && a1904774218 == 32))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1739072993 = 32 ;
    	a113788596 = 35 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm48(int input) {
    if(((a27741386 == 36 && ((a1904774218 == 32 && ( cf==1  && a2005069365 == 32)) && a792575314 == 9)) && (input == 2))) {
    	cf = 0;
    	a1129866701 = 8;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1505404504 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a792575314 == 9 && (a2005069365 == 32 && (((a27741386 == 36 &&  cf==1 ) && (input == 15)) && a1904774218 == 32)))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 32 && (a1904774218 == 32 && (( cf==1  && a27741386 == 36) && (input == 17)))) && a792575314 == 9)) {
    	cf = 0;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 6;
    	a132552289 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a27741386 == 36 && (((( cf==1  && a792575314 == 9) && a2005069365 == 32) && (input == 20)) && a1904774218 == 32))) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm49(int input) {
    if((((a1904774218 == 32 && (( cf==1  && a792575314 == 10) && a27741386 == 36)) && (input == 1)) && a2005069365 == 32)) {
    	cf = 0;
    	a1838812917 = 32 ;
    	a2005069365 = 36 ;
    	a927953139 = 33 ;
    	a1944506598 = 33 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a27741386 == 36 && (a2005069365 == 32 && (( cf==1  && (input == 4)) && a792575314 == 10))) && a1904774218 == 32)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1243394452 = 4;
    	a685344195 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1904774218 == 32 && ((a2005069365 == 32 && ( cf==1  && a27741386 == 36)) && (input == 17))) && a792575314 == 10)) {
    	cf = 0;
    	a369539608 = 34 ;
    	a1684674520 = 34 ;
    	a2005069365 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a27741386 == 36 && (a2005069365 == 32 && ((input == 20) && (a1904774218 == 32 && (a792575314 == 10 &&  cf==1 )))))) {
    	cf = 0;
    	a1519100789 = 9;
    	a369539608 = 36 ;
    	a2005069365 = 35 ;
    	a1958000800 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm50(int input) {
    if((((((a792575314 == 11 &&  cf==1 ) && (input == 5)) && a27741386 == 36) && a1904774218 == 32) && a2005069365 == 32)) {
    	cf = 0;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 14;
    	a2138261183 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm52(int input) {
    if((a2005069365 == 32 && ((a27741386 == 36 && ((input == 15) && (a792575314 == 14 &&  cf==1 ))) && a1904774218 == 32))) {
    	cf = 0;
    	a27741386 = 35 ;
    	a829511935 = 33 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1904774218 == 32 && ((((a27741386 == 36 &&  cf==1 ) && a792575314 == 14) && (input == 17)) && a2005069365 == 32))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 5;
    	a2005069365 = 36 ;
    	a1089968358 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2005069365 == 32 && (a792575314 == 14 && (a1904774218 == 32 && ( cf==1  && (input == 20))))) && a27741386 == 36)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1243394452 = 6;
    	a1519100789 = 7;
    	a132552289 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm1(int input) {
    if((a27741386 == 32 &&  cf==1 )) {
    	if(( cf==1  && a928570136 == 34)) {
    		calculate_outputm31(input);
    	} 
    } 
    if((a27741386 == 33 &&  cf==1 )) {
    	if((a706302795 == 10 &&  cf==1 )) {
    		calculate_outputm33(input);
    	} 
    	if((a706302795 == 12 &&  cf==1 )) {
    		calculate_outputm34(input);
    	} 
    	if((a706302795 == 13 &&  cf==1 )) {
    		calculate_outputm35(input);
    	} 
    	if((a706302795 == 14 &&  cf==1 )) {
    		calculate_outputm36(input);
    	} 
    	if((a706302795 == 15 &&  cf==1 )) {
    		calculate_outputm37(input);
    	} 
    } 
    if((a27741386 == 34 &&  cf==1 )) {
    	if(( cf==1  && a1009240021 == 3)) {
    		calculate_outputm38(input);
    	} 
    	if(( cf==1  && a1009240021 == 4)) {
    		calculate_outputm39(input);
    	} 
    	if(( cf==1  && a1009240021 == 5)) {
    		calculate_outputm40(input);
    	} 
    	if((a1009240021 == 9 &&  cf==1 )) {
    		calculate_outputm42(input);
    	} 
    } 
    if(( cf==1  && a27741386 == 35)) {
    	if((a829511935 == 33 &&  cf==1 )) {
    		calculate_outputm44(input);
    	} 
    	if((a829511935 == 35 &&  cf==1 )) {
    		calculate_outputm45(input);
    	} 
    	if(( cf==1  && a829511935 == 36)) {
    		calculate_outputm46(input);
    	} 
    } 
    if(( cf==1  && a27741386 == 36)) {
    	if((a792575314 == 9 &&  cf==1 )) {
    		calculate_outputm48(input);
    	} 
    	if((a792575314 == 10 &&  cf==1 )) {
    		calculate_outputm49(input);
    	} 
    	if(( cf==1  && a792575314 == 11)) {
    		calculate_outputm50(input);
    	} 
    	if((a792575314 == 14 &&  cf==1 )) {
    		calculate_outputm52(input);
    	} 
    } 
}
 void calculate_outputm53(int input) {
    if(((((( cf==1  && a749536178 == 5) && a1904774218 == 33) && (input == 1)) && a2005069365 == 32) && a844311967 == 32)) {
    	cf = 0;
    	a714559100 = 7;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1166586546 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 4) && (((a844311967 == 32 && ( cf==1  && a749536178 == 5)) && a1904774218 == 33) && a2005069365 == 32))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 12;
    	a2005069365 = 36 ;
    	a1655731851 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a844311967 == 32 && (( cf==1  && a1904774218 == 33) && a2005069365 == 32)) && (input == 10)) && a749536178 == 5)) {
    	cf = 0;
    	a1561044360 = 35 ;
    	a2005069365 = 35 ;
    	a113788596 = 32 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a844311967 == 32 && ((input == 14) && (a1904774218 == 33 && (a749536178 == 5 &&  cf==1 )))) && a2005069365 == 32)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a491478835 = 35 ;
    	a714559100 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm54(int input) {
    if(((a749536178 == 6 && (a1904774218 == 33 && ((a844311967 == 32 &&  cf==1 ) && a2005069365 == 32))) && (input == 7))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a88077474 = 35 ;
    	a1519100789 = 3;
    	a534598694 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 32 && ((a844311967 == 32 && ( cf==1  && a749536178 == 6)) && a1904774218 == 33)) && (input == 9))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a650110038 = 32 ;
    	a969893172 = 32 ;
    	a200393381 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a844311967 == 32 && (((( cf==1  && (input == 12)) && a2005069365 == 32) && a749536178 == 6) && a1904774218 == 33))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a1428914468 = 8;
    	a1699038459 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 32 && (a844311967 == 32 && ((((input == 13) &&  cf==1 ) && a749536178 == 6) && a1904774218 == 33)))) {
    	cf = 0;
    	a1186984341 = 35 ;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm55(int input) {
    if(((input == 20) && (((a1904774218 == 33 && ( cf==1  && a749536178 == 7)) && a2005069365 == 32) && a844311967 == 32))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a107446547 = 12;
    	a1682504076 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm56(int input) {
    if(((input == 8) && (((a2005069365 == 32 && (a844311967 == 32 &&  cf==1 )) && a1904774218 == 33) && a749536178 == 8))) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a369539608 = 36 ;
    	a1577567933 = 36 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((a1904774218 == 33 &&  cf==1 ) && a749536178 == 8) && (input == 20)) && a844311967 == 32) && a2005069365 == 32)) {
    	cf = 0;
    	a1958000800 = 13;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a593874874 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm57(int input) {
    if(((a1904774218 == 33 && (a749536178 == 9 && ((input == 13) && (a2005069365 == 32 &&  cf==1 )))) && a844311967 == 32)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1610737594 = 35 ;
    	a1428914468 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm58(int input) {
    if((a1904774218 == 33 && ((input == 4) && ((a749536178 == 10 && (a2005069365 == 32 &&  cf==1 )) && a844311967 == 32)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a246458106 = 36 ;
    	a1519100789 = 7;
    	a1243394452 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a749536178 == 10 && ((input == 12) && (a844311967 == 32 && ( cf==1  && a2005069365 == 32)))) && a1904774218 == 33)) {
    	cf = 0;
    	a679327000 = 32 ;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a103910758 = 33 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 32 && (a844311967 == 32 && (a1904774218 == 33 && ((a749536178 == 10 &&  cf==1 ) && (input == 17)))))) {
    	cf = 0;
    	a525429632 = 34 ;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1775644016 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm59(int input) {
    if((a844311967 == 32 && (((a1904774218 == 33 && ( cf==1  && a2005069365 == 32)) && (input == 8)) && a749536178 == 12))) {
    	cf = 0;
    	a714559100 = 12;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a1116999236 = 16; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 32 && (a1904774218 == 33 && (a844311967 == 32 && ((a749536178 == 12 &&  cf==1 ) && (input == 13)))))) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 7;
    	a2005069365 = 35 ;
    	a71813398 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1904774218 == 33 && (a844311967 == 32 && (((input == 16) &&  cf==1 ) && a749536178 == 12))) && a2005069365 == 32)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1052150692 = 10;
    	a1519100789 = 2;
    	a662123779 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1904774218 == 33 && (((a844311967 == 32 && ( cf==1  && (input == 17))) && a749536178 == 12) && a2005069365 == 32))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a2002331280 = 33 ;
    	a1519100789 = 9;
    	a1958000800 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm60(int input) {
    if((a844311967 == 33 && (a1904774218 == 33 && ((a2005069365 == 32 && ( cf==1  && (input == 3))) && a1380627758 == 4)))) {
    	cf = 0;
    	a369539608 = 36 ;
    	a1904774218 = 35 ;
    	a1577567933 = 35 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 32 && (a1904774218 == 33 && ((a1380627758 == 4 && (a844311967 == 33 &&  cf==1 )) && (input == 14))))) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a369539608 = 36 ;
    	a1577567933 = 35 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a2005069365 == 32 && ((((input == 17) &&  cf==1 ) && a844311967 == 33) && a1380627758 == 4)) && a1904774218 == 33)) {
    	cf = 0;
    	a1052150692 = 8;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1144659688 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm61(int input) {
    if((((a2005069365 == 32 && (a1904774218 == 33 && ((input == 16) &&  cf==1 ))) && a844311967 == 33) && a1380627758 == 7)) {
    	cf = 0;
    	a844311967 = 32 ;
    	a749536178 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a844311967 == 33 && (a1380627758 == 7 && ( cf==1  && a1904774218 == 33))) && (input == 19)) && a2005069365 == 32)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 8;
    	a1505404504 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm62(int input) {
    if((a844311967 == 33 && ((a2005069365 == 32 && (( cf==1  && a1904774218 == 33) && (input == 1))) && a1380627758 == 9))) {
    	cf = 0;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1958000800 = 13;
    	a593874874 = 16; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm63(int input) {
    if((a844311967 == 33 && (a2005069365 == 32 && (a1904774218 == 33 && ((input == 7) && (a1380627758 == 10 &&  cf==1 )))))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a1428914468 = 10;
    	a969893172 = 33 ;
    	a954368445 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1904774218 == 33 && (a2005069365 == 32 && (a1380627758 == 10 &&  cf==1 ))) && a844311967 == 33) && (input == 11))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a525429632 = 34 ;
    	a1775644016 = 13; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1904774218 == 33 && (((a2005069365 == 32 &&  cf==1 ) && (input == 20)) && a1380627758 == 10)) && a844311967 == 33)) {
    	cf = 0;
    	a369539608 = 34 ;
    	a2005069365 = 35 ;
    	a1684674520 = 36 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm64(int input) {
    if((a844311967 == 34 && ((a317927282 == 7 && (a1904774218 == 33 && (a2005069365 == 32 &&  cf==1 ))) && (input == 14)))) {
    	cf = 0;
    	a1428914468 = 13;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a2125137407 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a317927282 == 7 && (a1904774218 == 33 && ((input == 15) && (a2005069365 == 32 && ( cf==1  && a844311967 == 34)))))) {
    	cf = 0;
    	a1958000800 = 8;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1184734075 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm65(int input) {
    if((a844311967 == 34 && (a317927282 == 10 && ((input == 1) && (a2005069365 == 32 && ( cf==1  && a1904774218 == 33)))))) {
    	cf = 0;
    	a1243394452 = 4;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a685344195 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 32 && (((input == 4) && ( cf==1  && a844311967 == 34)) && a1904774218 == 33)) && a317927282 == 10)) {
    	cf = 0;
    	a27741386 = 36 ;
    	a1904774218 = 32 ;
    	a792575314 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a317927282 == 10 && (a2005069365 == 32 && (a1904774218 == 33 && (((input == 11) &&  cf==1 ) && a844311967 == 34))))) {
    	cf = 0;
    	a714559100 = 7;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1166586546 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 32 && (((input == 14) && (a317927282 == 10 && (a1904774218 == 33 &&  cf==1 ))) && a844311967 == 34))) {
    	cf = 0;
    	a1958000800 = 12;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a798343693 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm67(int input) {
    if(((a1904774218 == 33 && ((a317927282 == 13 && (a844311967 == 34 &&  cf==1 )) && a2005069365 == 32)) && (input == 14))) {
    	cf = 0;
    	a1153134505 = 32 ;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1904774218 == 33 && ((a2005069365 == 32 && (( cf==1  && a844311967 == 34) && a317927282 == 13)) && (input == 15)))) {
    	cf = 0;
    	a1958000800 = 9;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1754726785 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm68(int input) {
    if(((input == 3) && (a844311967 == 35 && ((a2005069365 == 32 && (a1904774218 == 33 &&  cf==1 )) && a205734433 == 8)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 4;
    	a240738299 = 33 ;
    	a201083786 = 15; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a205734433 == 8 && ((a844311967 == 35 &&  cf==1 ) && a2005069365 == 32)) && a1904774218 == 33) && (input == 11))) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a925870636 = 9;
    	a904637882 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a844311967 == 35 && (((a205734433 == 8 &&  cf==1 ) && a2005069365 == 32) && a1904774218 == 33)) && (input == 15))) {
    	cf = 0;
    	a1519100789 = 5;
    	a2005069365 = 35 ;
    	a369539608 = 36 ;
    	a347749795 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 32 && (a844311967 == 35 && ((((input == 20) &&  cf==1 ) && a1904774218 == 33) && a205734433 == 8)))) {
    	cf = 0;
    	a1243394452 = 6;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a132552289 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm70(int input) {
    if((a205734433 == 10 && ((input == 4) && ((( cf==1  && a2005069365 == 32) && a844311967 == 35) && a1904774218 == 33)))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a2005069365 = 36 ;
    	a740799408 = 34 ;
    	a1775644016 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm71(int input) {
    if(((a2005069365 == 32 && (a205734433 == 11 && (a1904774218 == 33 && ( cf==1  && (input == 1))))) && a844311967 == 35)) {
    	cf = 0;
    	a928570136 = 33 ;
    	a1904774218 = 36 ;
    	a806083420 = 36 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a844311967 == 35 && (( cf==1  && (input == 5)) && a1904774218 == 33)) && a2005069365 == 32) && a205734433 == 11)) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm73(int input) {
    if(((a2005069365 == 32 && ((input == 7) && (( cf==1  && a1904774218 == 33) && a205734433 == 13))) && a844311967 == 35)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a2124036967 = 35 ;
    	a1942309322 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a844311967 == 35 && (a205734433 == 13 && (a2005069365 == 32 && (((input == 10) &&  cf==1 ) && a1904774218 == 33))))) {
    	cf = 0;
    	a2124036967 = 35 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a1942309322 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm74(int input) {
    if(((a2005069365 == 32 && (a205734433 == 14 && ((input == 5) && (a1904774218 == 33 &&  cf==1 )))) && a844311967 == 35)) {
    	cf = 0;
    	a2124036967 = 32 ;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a1194623510 = 36 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 19) && ((a844311967 == 35 && ((a1904774218 == 33 &&  cf==1 ) && a205734433 == 14)) && a2005069365 == 32))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a525429632 = 32 ;
    	a1838812917 = 36 ;
    	a1775644016 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm75(int input) {
    if((a2005069365 == 32 && (a1904774218 == 33 && (a844311967 == 36 && (( cf==1  && (input == 6)) && a1235481610 == 5))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1153134505 = 33 ;
    	a1519100789 = 7;
    	a1243394452 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 32 && ((( cf==1  && a844311967 == 36) && (input == 15)) && a1235481610 == 5)) && a1904774218 == 33)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a679327000 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm77(int input) {
    if(((a1235481610 == 8 && ((( cf==1  && a844311967 == 36) && (input == 1)) && a2005069365 == 32)) && a1904774218 == 33)) {
    	cf = 0;
    	a928570136 = 34 ;
    	a1904774218 = 36 ;
    	a868028614 = 32 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1904774218 == 33 && (( cf==1  && a844311967 == 36) && (input == 5))) && a1235481610 == 8) && a2005069365 == 32)) {
    	cf = 0;
    	a369539608 = 34 ;
    	a1904774218 = 35 ;
    	a1754726785 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1904774218 == 33 && (( cf==1  && a2005069365 == 32) && (input == 13))) && a1235481610 == 8) && a844311967 == 36)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a88077474 = 32 ;
    	a1904774218 = 32 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1235481610 == 8 && (((input == 19) &&  cf==1 ) && a844311967 == 36)) && a2005069365 == 32) && a1904774218 == 33)) {
    	cf = 0;
    	a604409338 = 36 ;
    	a1519100789 = 6;
    	a2005069365 = 35 ;
    	a1688003115 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm78(int input) {
    if((a844311967 == 36 && (a1235481610 == 12 && (a2005069365 == 32 && (a1904774218 == 33 && ( cf==1  && (input == 15))))))) {
    	cf = 0;
    	a844311967 = 33 ;
    	a1380627758 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((a2005069365 == 32 &&  cf==1 ) && a1235481610 == 12) && (input == 20)) && a1904774218 == 33) && a844311967 == 36)) {
    	cf = 0;
    	a1815432985 = 36 ;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm2(int input) {
    if((a844311967 == 32 &&  cf==1 )) {
    	if((a749536178 == 5 &&  cf==1 )) {
    		calculate_outputm53(input);
    	} 
    	if(( cf==1  && a749536178 == 6)) {
    		calculate_outputm54(input);
    	} 
    	if((a749536178 == 7 &&  cf==1 )) {
    		calculate_outputm55(input);
    	} 
    	if((a749536178 == 8 &&  cf==1 )) {
    		calculate_outputm56(input);
    	} 
    	if((a749536178 == 9 &&  cf==1 )) {
    		calculate_outputm57(input);
    	} 
    	if((a749536178 == 10 &&  cf==1 )) {
    		calculate_outputm58(input);
    	} 
    	if((a749536178 == 12 &&  cf==1 )) {
    		calculate_outputm59(input);
    	} 
    } 
    if(( cf==1  && a844311967 == 33)) {
    	if((a1380627758 == 4 &&  cf==1 )) {
    		calculate_outputm60(input);
    	} 
    	if(( cf==1  && a1380627758 == 7)) {
    		calculate_outputm61(input);
    	} 
    	if(( cf==1  && a1380627758 == 9)) {
    		calculate_outputm62(input);
    	} 
    	if(( cf==1  && a1380627758 == 10)) {
    		calculate_outputm63(input);
    	} 
    } 
    if(( cf==1  && a844311967 == 34)) {
    	if((a317927282 == 7 &&  cf==1 )) {
    		calculate_outputm64(input);
    	} 
    	if(( cf==1  && a317927282 == 10)) {
    		calculate_outputm65(input);
    	} 
    	if((a317927282 == 13 &&  cf==1 )) {
    		calculate_outputm67(input);
    	} 
    } 
    if(( cf==1  && a844311967 == 35)) {
    	if(( cf==1  && a205734433 == 8)) {
    		calculate_outputm68(input);
    	} 
    	if(( cf==1  && a205734433 == 10)) {
    		calculate_outputm70(input);
    	} 
    	if((a205734433 == 11 &&  cf==1 )) {
    		calculate_outputm71(input);
    	} 
    	if((a205734433 == 13 &&  cf==1 )) {
    		calculate_outputm73(input);
    	} 
    	if((a205734433 == 14 &&  cf==1 )) {
    		calculate_outputm74(input);
    	} 
    } 
    if((a844311967 == 36 &&  cf==1 )) {
    	if(( cf==1  && a1235481610 == 5)) {
    		calculate_outputm75(input);
    	} 
    	if(( cf==1  && a1235481610 == 8)) {
    		calculate_outputm77(input);
    	} 
    	if((a1235481610 == 12 &&  cf==1 )) {
    		calculate_outputm78(input);
    	} 
    } 
}
 void calculate_outputm79(int input) {
    if(((a2005069365 == 32 && (a1904774218 == 34 && ((a925870636 == 8 &&  cf==1 ) && a1883016343 == 7))) && (input == 1))) {
    	cf = 0;
    	a1684687706 = 12;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1710271440 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 32 && ((input == 8) && (a1904774218 == 34 && ( cf==1  && a1883016343 == 7)))) && a925870636 == 8)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a714559100 = 12;
    	a1116999236 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm80(int input) {
    if(((input == 7) && (((a1904774218 == 34 && ( cf==1  && a925870636 == 8)) && a1883016343 == 8) && a2005069365 == 32))) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1883016343 == 8 && ((a925870636 == 8 && ((a1904774218 == 34 &&  cf==1 ) && (input == 13))) && a2005069365 == 32))) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 32 && (a1883016343 == 8 && (a925870636 == 8 && ((a1904774218 == 34 &&  cf==1 ) && (input == 15)))))) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a679327000 = 33 ;
    	a2065134388 = 17; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm81(int input) {
    if(((a1883016343 == 10 && (((a2005069365 == 32 &&  cf==1 ) && a1904774218 == 34) && a925870636 == 8)) && (input == 3))) {
    	cf = 0;
    	a465336174 = 34 ;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1883016343 == 10 && (((a2005069365 == 32 && (a925870636 == 8 &&  cf==1 )) && (input == 8)) && a1904774218 == 34))) {
    	cf = 0;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 2;
    	a1735753243 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1883016343 == 10 && (a925870636 == 8 && (a2005069365 == 32 && ((input == 12) && (a1904774218 == 34 &&  cf==1 )))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 8;
    	a1184734075 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm82(int input) {
    if((a925870636 == 8 && (((a1883016343 == 11 && ( cf==1  && (input == 13))) && a1904774218 == 34) && a2005069365 == 32))) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a2005069365 = 33 ;
    	a747683138 = 34 ;
    	a1428914468 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 32 && ((((input == 15) && (a925870636 == 8 &&  cf==1 )) && a1883016343 == 11) && a1904774218 == 34))) {
    	cf = 0;
    	a1519100789 = 8;
    	a2005069365 = 35 ;
    	a113788596 = 36 ;
    	a772592654 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1883016343 == 11 && ((input == 16) && ((a2005069365 == 32 && (a925870636 == 8 &&  cf==1 )) && a1904774218 == 34)))) {
    	cf = 0;
    	a829511935 = 34 ;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm83(int input) {
    if((a2005069365 == 32 && (a1883016343 == 12 && ((a925870636 == 8 && (a1904774218 == 34 &&  cf==1 )) && (input == 5))))) {
    	cf = 0;
    	a1904774218 = 36 ;
    	a928570136 = 32 ;
    	a836757480 = 33 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm84(int input) {
    if((a1904774218 == 34 && (((a925870636 == 9 && (a2005069365 == 32 &&  cf==1 )) && (input == 12)) && a904637882 == 6))) {
    	cf = 0;
    	a1739072993 = 34 ;
    	a113788596 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm85(int input) {
    if(((((a2005069365 == 32 && (a1904774218 == 34 &&  cf==1 )) && a925870636 == 9) && a904637882 == 7) && (input == 7))) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm87(int input) {
    if((a2005069365 == 32 && ((((a925870636 == 9 &&  cf==1 ) && (input == 1)) && a904637882 == 10) && a1904774218 == 34))) {
    	cf = 0;
    	a714559100 = 5;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a1089968358 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a2005069365 == 32 && ((a925870636 == 9 &&  cf==1 ) && a1904774218 == 34)) && (input == 6)) && a904637882 == 10)) {
    	cf = 0;
    	a679327000 = 32 ;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a103910758 = 33 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a904637882 == 10 && (a2005069365 == 32 && ((a1904774218 == 34 &&  cf==1 ) && (input == 7)))) && a925870636 == 9)) {
    	cf = 0;
    	a740799408 = 32 ;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1775644016 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 16) && ((a904637882 == 10 && (a925870636 == 9 && (a1904774218 == 34 &&  cf==1 ))) && a2005069365 == 32))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a369539608 = 35 ;
    	a1958000800 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm88(int input) {
    if(((input == 7) && ((a2005069365 == 32 && (( cf==1  && a904637882 == 11) && a1904774218 == 34)) && a925870636 == 9))) {
    	cf = 0;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a451941968 = 32 ;
    	a1052150692 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1904774218 == 34 && (a904637882 == 11 && ((( cf==1  && a2005069365 == 32) && (input == 12)) && a925870636 == 9)))) {
    	cf = 0;
    	a451941968 = 32 ;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 32 && (((((input == 13) &&  cf==1 ) && a925870636 == 9) && a904637882 == 11) && a1904774218 == 34))) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a904637882 == 11 && ( cf==1  && a925870636 == 9)) && (input == 19)) && a1904774218 == 34) && a2005069365 == 32)) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm89(int input) {
    if(((input == 2) && ((a925870636 == 10 && (a1904774218 == 34 && (a666963702 == 9 &&  cf==1 ))) && a2005069365 == 32))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 32 ;
    	a927953139 = 34 ;
    	a1857807887 = 34 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 32 && ((((input == 10) && ( cf==1  && a925870636 == 10)) && a666963702 == 9) && a1904774218 == 34))) {
    	cf = 0;
    	a369539608 = 32 ;
    	a2005069365 = 35 ;
    	a604409338 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 32 && (a925870636 == 10 && (((input == 12) &&  cf==1 ) && a1904774218 == 34))) && a666963702 == 9)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a2124036967 = 35 ;
    	a969893172 = 36 ;
    	a1942309322 = 36 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 15) && (((( cf==1  && a925870636 == 10) && a2005069365 == 32) && a666963702 == 9) && a1904774218 == 34))) {
    	cf = 0;
    	a113788596 = 36 ;
    	a1519100789 = 8;
    	a2005069365 = 35 ;
    	a772592654 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm91(int input) {
    if((a666963702 == 13 && (((a925870636 == 10 && (a1904774218 == 34 &&  cf==1 )) && a2005069365 == 32) && (input == 3)))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a569036257 = 6;
    	a2005069365 = 36 ;
    	a205734433 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1904774218 == 34 && ((a2005069365 == 32 && (a925870636 == 10 && (a666963702 == 13 &&  cf==1 ))) && (input == 7)))) {
    	cf = 0;
    	a1904774218 = 36 ;
    	a928570136 = 33 ;
    	a806083420 = 36 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((a666963702 == 13 &&  cf==1 ) && a1904774218 == 34) && (input == 10)) && a2005069365 == 32) && a925870636 == 10)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 8;
    	a113788596 = 33 ;
    	a137564664 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 4) && (((a2005069365 == 32 && (a1904774218 == 34 &&  cf==1 )) && a925870636 == 10) && a666963702 == 13))) {
    	cf = 0;
    	a747683138 = 36 ;
    	a2059681452 = 33 ;
    	a2005069365 = 33 ;
    	a1172911487 = 33 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm92(int input) {
    if((a2005069365 == 32 && (a925870636 == 10 && (((input == 5) && ( cf==1  && a666963702 == 14)) && a1904774218 == 34)))) {
    	cf = 0;
    	a67466277 = 36 ;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a2005069365 == 32 && ((a925870636 == 10 && (a666963702 == 14 &&  cf==1 )) && (input == 10))) && a1904774218 == 34)) {
    	cf = 0;
    	a666963702 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1904774218 == 34 && (((a2005069365 == 32 && (a925870636 == 10 &&  cf==1 )) && a666963702 == 14) && (input == 20)))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 11;
    	a2005069365 = 36 ;
    	a805812408 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm93(int input) {
    if(((input == 1) && (((a2005069365 == 32 && (a1904774218 == 34 &&  cf==1 )) && a925870636 == 10) && a666963702 == 16))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1388584441 = 34 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1904774218 == 34 && (((( cf==1  && a666963702 == 16) && (input == 6)) && a925870636 == 10) && a2005069365 == 32))) {
    	cf = 0;
    	a369539608 = 34 ;
    	a1904774218 = 35 ;
    	a1754726785 = 15; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1904774218 == 34 && (a2005069365 == 32 && (a666963702 == 16 && (a925870636 == 10 && ( cf==1  && (input == 11))))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1388584441 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm94(int input) {
    if(((((( cf==1  && a925870636 == 11) && (input == 1)) && a2005069365 == 32) && a1904774218 == 34) && a1506379905 == 36)) {
    	cf = 0;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1872268177 = 34 ;
    	a1958000800 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 15) && (a1506379905 == 36 && ((a1904774218 == 34 &&  cf==1 ) && a2005069365 == 32))) && a925870636 == 11)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a240738299 = 32 ;
    	a1756771009 = 36 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm95(int input) {
    if(((((( cf==1  && a2005069365 == 32) && (input == 5)) && a925870636 == 12) && a1904774218 == 34) && a48792734 == 33)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1684674520 = 35 ;
    	a369539608 = 34 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 8) && ((a1904774218 == 34 && (a48792734 == 33 &&  cf==1 )) && a925870636 == 12)) && a2005069365 == 32)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1684674520 = 35 ;
    	a369539608 = 34 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a48792734 == 33 && (a925870636 == 12 && ((( cf==1  && a2005069365 == 32) && a1904774218 == 34) && (input == 17))))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 8;
    	a1699038459 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm97(int input) {
    if(((a48792734 == 35 && ((a2005069365 == 32 && (a925870636 == 12 &&  cf==1 )) && (input == 10))) && a1904774218 == 34)) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1904774218 == 34 && (a2005069365 == 32 && (( cf==1  && (input == 11)) && a925870636 == 12))) && a48792734 == 35)) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm98(int input) {
    if(((input == 4) && (a925870636 == 13 && ((a1904774218 == 34 && ( cf==1  && a2005069365 == 32)) && a759122969 == 3)))) {
    	cf = 0;
    	a747683138 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 33 ;
    	a1682504076 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1904774218 == 34 && (a925870636 == 13 && ((a759122969 == 3 && ((input == 8) &&  cf==1 )) && a2005069365 == 32)))) {
    	cf = 0;
    	a569036257 = 6;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a205734433 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a925870636 == 13 && (a2005069365 == 32 && (( cf==1  && (input == 13)) && a759122969 == 3))) && a1904774218 == 34)) {
    	cf = 0;
    	a1519100789 = 7;
    	a1815432985 = 32 ;
    	a2005069365 = 35 ;
    	a1243394452 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a2005069365 == 32 && ((input == 17) && (a1904774218 == 34 &&  cf==1 ))) && a759122969 == 3) && a925870636 == 13)) {
    	cf = 0;
    	a759122969 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm99(int input) {
    if((a925870636 == 13 && ((input == 1) && ((a1904774218 == 34 && (a2005069365 == 32 &&  cf==1 )) && a759122969 == 5)))) {
    	cf = 0;
    	a927953139 = 34 ;
    	a1838812917 = 32 ;
    	a2005069365 = 36 ;
    	a1857807887 = 34 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((( cf==1  && a925870636 == 13) && a759122969 == 5) && (input == 3)) && a2005069365 == 32) && a1904774218 == 34)) {
    	cf = 0;
    	a714559100 = 10;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a2125137407 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 14) && ((a759122969 == 5 && (a1904774218 == 34 && (a925870636 == 13 &&  cf==1 ))) && a2005069365 == 32))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 10;
    	a2125137407 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((a1904774218 == 34 &&  cf==1 ) && a759122969 == 5) && (input == 19)) && a925870636 == 13) && a2005069365 == 32)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1052150692 = 12;
    	a1519100789 = 2;
    	a1957279511 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm101(int input) {
    if(((a1904774218 == 34 && ((input == 2) && (a759122969 == 8 && ( cf==1  && a2005069365 == 32)))) && a925870636 == 13)) {
    	cf = 0;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1153134505 = 32 ;
    	a1243394452 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a925870636 == 13 && ((input == 5) && (a759122969 == 8 && ( cf==1  && a1904774218 == 34)))) && a2005069365 == 32)) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 36 ;
    	a2005069365 = 34 ;
    	a221974990 = 13; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm102(int input) {
    if(((a925870636 == 13 && ((a2005069365 == 32 && ( cf==1  && a1904774218 == 34)) && a759122969 == 9)) && (input == 19))) {
    	cf = 0;
    	a1684674520 = 34 ;
    	a2005069365 = 35 ;
    	a369539608 = 34 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm103(int input) {
    if(((((( cf==1  && a925870636 == 14) && a1904774218 == 34) && a1571676929 == 34) && (input == 3)) && a2005069365 == 32)) {
    	cf = 0;
    	a1428914468 = 10;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a954368445 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((( cf==1  && a2005069365 == 32) && a1571676929 == 34) && a925870636 == 14) && (input == 4)) && a1904774218 == 34)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a2124036967 = 36 ;
    	a524102808 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 8) && (((( cf==1  && a2005069365 == 32) && a925870636 == 14) && a1571676929 == 34) && a1904774218 == 34))) {
    	cf = 0;
    	a369539608 = 35 ;
    	a1307756142 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a925870636 == 14 && (a2005069365 == 32 && ( cf==1  && a1571676929 == 34))) && (input == 10)) && a1904774218 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a2002331280 = 35 ;
    	a1958000800 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm104(int input) {
    if(((a2005069365 == 32 && ((a1571676929 == 36 && (a925870636 == 14 &&  cf==1 )) && a1904774218 == 34)) && (input == 1))) {
    	cf = 0;
    	a1325377146 = 33 ;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a569036257 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 32 && (a1571676929 == 36 && ((input == 15) && (( cf==1  && a925870636 == 14) && a1904774218 == 34))))) {
    	cf = 0;
    	a1325377146 = 33 ;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a569036257 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm105(int input) {
    if((a1904774218 == 34 && ((a2005069365 == 32 && (a925870636 == 15 && ( cf==1  && a1127376297 == 34))) && (input == 8)))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1739072993 = 32 ;
    	a2005069365 = 36 ;
    	a1775644016 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1904774218 == 34 && (((( cf==1  && a2005069365 == 32) && a1127376297 == 34) && (input == 12)) && a925870636 == 15))) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a27741386 = 34 ;
    	a1009240021 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a2005069365 == 32 && (((input == 13) && ( cf==1  && a925870636 == 15)) && a1904774218 == 34)) && a1127376297 == 34)) {
    	cf = 0;
    	a67466277 = 32 ;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a1904774218 == 34 && ( cf==1  && a1127376297 == 34)) && a925870636 == 15) && (input == 17)) && a2005069365 == 32)) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a747683138 = 32 ;
    	a2005069365 = 33 ;
    	a2110599067 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 19) && (a1904774218 == 34 && ((a925870636 == 15 && (a2005069365 == 32 &&  cf==1 )) && a1127376297 == 34)))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a569036257 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm106(int input) {
    if(((input == 2) && (((a2005069365 == 32 && (a1127376297 == 35 &&  cf==1 )) && a1904774218 == 34) && a925870636 == 15))) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a2005069365 = 33 ;
    	a747683138 = 33 ;
    	a1682504076 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 32 && (a925870636 == 15 && ((( cf==1  && a1127376297 == 35) && (input == 17)) && a1904774218 == 34)))) {
    	cf = 0;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a2005069365 = 35 ;
    	a347749795 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm107(int input) {
    if(((((a1904774218 == 34 && ((input == 4) &&  cf==1 )) && a1127376297 == 36) && a925870636 == 15) && a2005069365 == 32)) {
    	cf = 0;
    	a714559100 = 6;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1086754137 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 32 && (((input == 6) && ((a1904774218 == 34 &&  cf==1 ) && a925870636 == 15)) && a1127376297 == 36))) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 10;
    	a2005069365 = 35 ;
    	a662123779 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1904774218 == 34 && (a925870636 == 15 && (a2005069365 == 32 && ((a1127376297 == 36 &&  cf==1 ) && (input == 19)))))) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a27741386 = 35 ;
    	a829511935 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm3(int input) {
    if(( cf==1  && a925870636 == 8)) {
    	if((a1883016343 == 7 &&  cf==1 )) {
    		calculate_outputm79(input);
    	} 
    	if((a1883016343 == 8 &&  cf==1 )) {
    		calculate_outputm80(input);
    	} 
    	if(( cf==1  && a1883016343 == 10)) {
    		calculate_outputm81(input);
    	} 
    	if((a1883016343 == 11 &&  cf==1 )) {
    		calculate_outputm82(input);
    	} 
    	if(( cf==1  && a1883016343 == 12)) {
    		calculate_outputm83(input);
    	} 
    } 
    if(( cf==1  && a925870636 == 9)) {
    	if(( cf==1  && a904637882 == 6)) {
    		calculate_outputm84(input);
    	} 
    	if(( cf==1  && a904637882 == 7)) {
    		calculate_outputm85(input);
    	} 
    	if(( cf==1  && a904637882 == 10)) {
    		calculate_outputm87(input);
    	} 
    	if(( cf==1  && a904637882 == 11)) {
    		calculate_outputm88(input);
    	} 
    } 
    if((a925870636 == 10 &&  cf==1 )) {
    	if((a666963702 == 9 &&  cf==1 )) {
    		calculate_outputm89(input);
    	} 
    	if(( cf==1  && a666963702 == 13)) {
    		calculate_outputm91(input);
    	} 
    	if(( cf==1  && a666963702 == 14)) {
    		calculate_outputm92(input);
    	} 
    	if((a666963702 == 16 &&  cf==1 )) {
    		calculate_outputm93(input);
    	} 
    } 
    if((a925870636 == 11 &&  cf==1 )) {
    	if(( cf==1  && a1506379905 == 36)) {
    		calculate_outputm94(input);
    	} 
    } 
    if((a925870636 == 12 &&  cf==1 )) {
    	if((a48792734 == 33 &&  cf==1 )) {
    		calculate_outputm95(input);
    	} 
    	if(( cf==1  && a48792734 == 35)) {
    		calculate_outputm97(input);
    	} 
    } 
    if(( cf==1  && a925870636 == 13)) {
    	if(( cf==1  && a759122969 == 3)) {
    		calculate_outputm98(input);
    	} 
    	if(( cf==1  && a759122969 == 5)) {
    		calculate_outputm99(input);
    	} 
    	if((a759122969 == 8 &&  cf==1 )) {
    		calculate_outputm101(input);
    	} 
    	if((a759122969 == 9 &&  cf==1 )) {
    		calculate_outputm102(input);
    	} 
    } 
    if((a925870636 == 14 &&  cf==1 )) {
    	if((a1571676929 == 34 &&  cf==1 )) {
    		calculate_outputm103(input);
    	} 
    	if((a1571676929 == 36 &&  cf==1 )) {
    		calculate_outputm104(input);
    	} 
    } 
    if((a925870636 == 15 &&  cf==1 )) {
    	if((a1127376297 == 34 &&  cf==1 )) {
    		calculate_outputm105(input);
    	} 
    	if((a1127376297 == 35 &&  cf==1 )) {
    		calculate_outputm106(input);
    	} 
    	if((a1127376297 == 36 &&  cf==1 )) {
    		calculate_outputm107(input);
    	} 
    } 
}
 void calculate_outputm108(int input) {
    if((((a2005069365 == 32 && ((a1124714117 == 1 &&  cf==1 ) && a1904774218 == 35)) && (input == 8)) && a369539608 == 32)) {
    	cf = 0;
    	a1129866701 = 11;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm110(int input) {
    if(((a369539608 == 32 && ((( cf==1  && (input == 1)) && a1124714117 == 3) && a2005069365 == 32)) && a1904774218 == 35)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 12;
    	a1655731851 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1124714117 == 3 && (a369539608 == 32 && (((input == 3) && (a1904774218 == 35 &&  cf==1 )) && a2005069365 == 32)))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a569036257 = 4;
    	a1838812917 = 33 ;
    	a1549928701 = 15; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a369539608 == 32 && ((input == 13) && (a1124714117 == 3 && (a1904774218 == 35 && (a2005069365 == 32 &&  cf==1 )))))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a353267992 = 36 ;
    	a107446547 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a369539608 == 32 && (((a1124714117 == 3 && ( cf==1  && a1904774218 == 35)) && (input == 17)) && a2005069365 == 32))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a747683138 = 32 ;
    	a2059681452 = 33 ;
    	a2110599067 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm111(int input) {
    if(((a1904774218 == 35 && (a1124714117 == 5 && (a2005069365 == 32 && ((input == 14) &&  cf==1 )))) && a369539608 == 32)) {
    	cf = 0;
    	a1428914468 = 10;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a954368445 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm113(int input) {
    if(((((( cf==1  && a2005069365 == 32) && a1124714117 == 7) && (input == 20)) && a1904774218 == 35) && a369539608 == 32)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1146785657 = 34 ;
    	a1129866701 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm115(int input) {
    if((((((a1904774218 == 35 &&  cf==1 ) && a369539608 == 33) && a2077351330 == 3) && a2005069365 == 32) && (input == 2))) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((a369539608 == 33 && ( cf==1  && a2005069365 == 32)) && a1904774218 == 35) && (input == 5)) && a2077351330 == 3)) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a369539608 == 33 && ((((input == 7) && (a1904774218 == 35 &&  cf==1 )) && a2005069365 == 32) && a2077351330 == 3))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 34 ;
    	a2059681452 = 32 ;
    	a603781876 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm116(int input) {
    if(((((a1904774218 == 35 && ( cf==1  && a369539608 == 33)) && (input == 1)) && a2077351330 == 4) && a2005069365 == 32)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 10;
    	a954368445 = 4; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1904774218 == 35 && (((input == 16) && ((a369539608 == 33 &&  cf==1 ) && a2077351330 == 4)) && a2005069365 == 32))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 12;
    	a1957279511 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm117(int input) {
    if(((a1904774218 == 35 && ((input == 7) && (a369539608 == 33 && (a2005069365 == 32 &&  cf==1 )))) && a2077351330 == 6)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a369539608 = 36 ;
    	a1519100789 = 9;
    	a1958000800 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((((input == 15) && ( cf==1  && a1904774218 == 35)) && a2077351330 == 6) && a2005069365 == 32) && a369539608 == 33)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 10;
    	a954368445 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm119(int input) {
    if(((a1754726785 == 8 && ((a369539608 == 34 && ( cf==1  && (input == 4))) && a1904774218 == 35)) && a2005069365 == 32)) {
    	cf = 0;
    	a714559100 = 7;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a1166586546 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((((input == 7) &&  cf==1 ) && a1754726785 == 8) && a1904774218 == 35) && a2005069365 == 32) && a369539608 == 34)) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a928570136 = 33 ;
    	a107446547 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a369539608 == 34 && ((a1754726785 == 8 && (( cf==1  && a2005069365 == 32) && (input == 12))) && a1904774218 == 35))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a347749795 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a369539608 == 34 && ((a1754726785 == 8 && ( cf==1  && (input == 19))) && a2005069365 == 32)) && a1904774218 == 35)) {
    	cf = 0;
    	a744476156 = 33 ;
    	a88077474 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm121(int input) {
    if(((a2005069365 == 32 && (a1904774218 == 35 && (((input == 1) &&  cf==1 ) && a1754726785 == 11))) && a369539608 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1243394452 = 8;
    	a529769874 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a369539608 == 34 && ((a1754726785 == 11 && (a2005069365 == 32 && ((input == 5) &&  cf==1 ))) && a1904774218 == 35))) {
    	cf = 0;
    	a650110038 = 33 ;
    	a2005069365 = 34 ;
    	a969893172 = 32 ;
    	a1015737466 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a369539608 == 34 && ((input == 11) && (((a1754726785 == 11 &&  cf==1 ) && a1904774218 == 35) && a2005069365 == 32)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a2002331280 = 33 ;
    	a1958000800 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1754726785 == 11 && (a1904774218 == 35 && (((input == 13) && ( cf==1  && a2005069365 == 32)) && a369539608 == 34)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 12;
    	a1957279511 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm123(int input) {
    if((((((input == 3) && ( cf==1  && a2005069365 == 32)) && a369539608 == 34) && a1754726785 == 13) && a1904774218 == 35)) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((( cf==1  && a1904774218 == 35) && a1754726785 == 13) && (input == 6)) && a2005069365 == 32) && a369539608 == 34)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1239184736 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1904774218 == 35 && (a369539608 == 34 && ((( cf==1  && a1754726785 == 13) && (input == 20)) && a2005069365 == 32)))) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm124(int input) {
    if((((input == 6) && (a369539608 == 34 && (a1754726785 == 14 && ( cf==1  && a2005069365 == 32)))) && a1904774218 == 35)) {
    	cf = 0;
    	a569036257 = 10;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a920118831 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1754726785 == 14 && (((a2005069365 == 32 && (a1904774218 == 35 &&  cf==1 )) && a369539608 == 34) && (input == 10)))) {
    	cf = 0;
    	a27741386 = 34 ;
    	a1904774218 = 32 ;
    	a1009240021 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1754726785 == 14 && (((input == 17) && (a369539608 == 34 && ( cf==1  && a1904774218 == 35))) && a2005069365 == 32))) {
    	cf = 0;
    	a928570136 = 34 ;
    	a1904774218 = 36 ;
    	a868028614 = 33 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm125(int input) {
    if(((a2005069365 == 32 && ((input == 2) && ((a1754726785 == 15 &&  cf==1 ) && a369539608 == 34))) && a1904774218 == 35)) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((input == 6) && ( cf==1  && a1904774218 == 35)) && a1754726785 == 15) && a2005069365 == 32) && a369539608 == 34)) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a369539608 == 34 && ((input == 7) && (a2005069365 == 32 && (a1904774218 == 35 &&  cf==1 )))) && a1754726785 == 15)) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a2005069365 == 32 && ((input == 11) && (a369539608 == 34 &&  cf==1 ))) && a1904774218 == 35) && a1754726785 == 15)) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a844311967 = 35 ;
    	a205734433 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm127(int input) {
    if(((((a363404159 == 4 && ( cf==1  && a369539608 == 35)) && (input == 3)) && a1904774218 == 35) && a2005069365 == 32)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a465336174 = 35 ;
    	a2005069365 = 36 ;
    	a569036257 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1904774218 == 35 && (((( cf==1  && a2005069365 == 32) && a369539608 == 35) && (input == 13)) && a363404159 == 4))) {
    	cf = 0;
    	a569036257 = 10;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a920118831 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 32 && ((a369539608 == 35 && ((input == 20) &&  cf==1 )) && a1904774218 == 35)) && a363404159 == 4)) {
    	cf = 0;
    	a925870636 = 8;
    	a1904774218 = 34 ;
    	a1883016343 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm128(int input) {
    if((a369539608 == 35 && (((a363404159 == 6 && ( cf==1  && (input == 5))) && a1904774218 == 35) && a2005069365 == 32))) {
    	cf = 0;
    	a107446547 = 15;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a275125637 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 7) && (((a1904774218 == 35 &&  cf==1 ) && a363404159 == 6) && a2005069365 == 32)) && a369539608 == 35)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a714559100 = 5;
    	a1838812917 = 35 ;
    	a1089968358 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a363404159 == 6 && (((input == 12) && ( cf==1  && a2005069365 == 32)) && a1904774218 == 35)) && a369539608 == 35)) {
    	cf = 0;
    	a369539608 = 33 ;
    	a2005069365 = 35 ;
    	a1519100789 = 5;
    	a1894975097 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm129(int input) {
    if((((a369539608 == 35 && (((input == 7) &&  cf==1 ) && a2005069365 == 32)) && a363404159 == 9) && a1904774218 == 35)) {
    	cf = 0;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a246458106 = 36 ;
    	a1243394452 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 32 && ((((a369539608 == 35 &&  cf==1 ) && a363404159 == 9) && (input == 12)) && a1904774218 == 35))) {
    	cf = 0;
    	a1684687706 = 9;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a892217980 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1904774218 == 35 && (((a369539608 == 35 &&  cf==1 ) && a2005069365 == 32) && (input == 14))) && a363404159 == 9)) {
    	cf = 0;
    	a1388584441 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 32 && (a1904774218 == 35 && (( cf==1  && a369539608 == 35) && (input == 17)))) && a363404159 == 9)) {
    	cf = 0;
    	a1428914468 = 10;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a954368445 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm130(int input) {
    if(((input == 8) && ((a1904774218 == 35 && ((a1577567933 == 32 &&  cf==1 ) && a369539608 == 36)) && a2005069365 == 32))) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a925870636 = 10;
    	a666963702 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1577567933 == 32 && ((input == 16) && ((a369539608 == 36 && ( cf==1  && a2005069365 == 32)) && a1904774218 == 35)))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a569036257 = 6;
    	a205734433 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a369539608 == 36 && (a1904774218 == 35 && (a1577567933 == 32 && ((input == 17) && ( cf==1  && a2005069365 == 32)))))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 6;
    	a205734433 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm131(int input) {
    if((((a1577567933 == 35 && (((input == 2) &&  cf==1 ) && a369539608 == 36)) && a1904774218 == 35) && a2005069365 == 32)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a1325377146 = 36 ;
    	a2005069365 = 36 ;
    	a569036257 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 32 && (a1904774218 == 35 && ((input == 11) && (a1577567933 == 35 && ( cf==1  && a369539608 == 36)))))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a650110038 = 35 ;
    	a264802066 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((input == 12) && (a369539608 == 36 && ( cf==1  && a2005069365 == 32))) && a1577567933 == 35) && a1904774218 == 35)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 8;
    	a1505404504 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((((a1904774218 == 35 &&  cf==1 ) && a1577567933 == 35) && (input == 19)) && a2005069365 == 32) && a369539608 == 36)) {
    	cf = 0;
    	a844311967 = 33 ;
    	a1904774218 = 33 ;
    	a1380627758 = 4; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm132(int input) {
    if((a1577567933 == 36 && (a2005069365 == 32 && (((input == 2) && ( cf==1  && a369539608 == 36)) && a1904774218 == 35)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a604409338 = 36 ;
    	a1519100789 = 6;
    	a1688003115 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1904774218 == 35 && ((input == 16) && (a1577567933 == 36 && (( cf==1  && a2005069365 == 32) && a369539608 == 36))))) {
    	cf = 0;
    	a604409338 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 6;
    	a1688003115 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm4(int input) {
    if((a369539608 == 32 &&  cf==1 )) {
    	if(( cf==1  && a1124714117 == 1)) {
    		calculate_outputm108(input);
    	} 
    	if((a1124714117 == 3 &&  cf==1 )) {
    		calculate_outputm110(input);
    	} 
    	if(( cf==1  && a1124714117 == 5)) {
    		calculate_outputm111(input);
    	} 
    	if(( cf==1  && a1124714117 == 7)) {
    		calculate_outputm113(input);
    	} 
    } 
    if((a369539608 == 33 &&  cf==1 )) {
    	if((a2077351330 == 3 &&  cf==1 )) {
    		calculate_outputm115(input);
    	} 
    	if((a2077351330 == 4 &&  cf==1 )) {
    		calculate_outputm116(input);
    	} 
    	if(( cf==1  && a2077351330 == 6)) {
    		calculate_outputm117(input);
    	} 
    } 
    if(( cf==1  && a369539608 == 34)) {
    	if(( cf==1  && a1754726785 == 8)) {
    		calculate_outputm119(input);
    	} 
    	if(( cf==1  && a1754726785 == 11)) {
    		calculate_outputm121(input);
    	} 
    	if(( cf==1  && a1754726785 == 13)) {
    		calculate_outputm123(input);
    	} 
    	if((a1754726785 == 14 &&  cf==1 )) {
    		calculate_outputm124(input);
    	} 
    	if(( cf==1  && a1754726785 == 15)) {
    		calculate_outputm125(input);
    	} 
    } 
    if((a369539608 == 35 &&  cf==1 )) {
    	if((a363404159 == 4 &&  cf==1 )) {
    		calculate_outputm127(input);
    	} 
    	if((a363404159 == 6 &&  cf==1 )) {
    		calculate_outputm128(input);
    	} 
    	if(( cf==1  && a363404159 == 9)) {
    		calculate_outputm129(input);
    	} 
    } 
    if(( cf==1  && a369539608 == 36)) {
    	if((a1577567933 == 32 &&  cf==1 )) {
    		calculate_outputm130(input);
    	} 
    	if((a1577567933 == 35 &&  cf==1 )) {
    		calculate_outputm131(input);
    	} 
    	if((a1577567933 == 36 &&  cf==1 )) {
    		calculate_outputm132(input);
    	} 
    } 
}
 void calculate_outputm133(int input) {
    if(((input == 19) && (((( cf==1  && a1904774218 == 36) && a928570136 == 32) && a836757480 == 32) && a2005069365 == 32))) {
    	cf = 0;
    	a1243394452 = 2;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1735753243 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm134(int input) {
    if(((input == 3) && (((a1904774218 == 36 && ( cf==1  && a2005069365 == 32)) && a836757480 == 33) && a928570136 == 32))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a844311967 = 34 ;
    	a317927282 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((a2005069365 == 32 &&  cf==1 ) && (input == 11)) && a1904774218 == 36) && a928570136 == 32) && a836757480 == 33)) {
    	cf = 0;
    	a604409338 = 32 ;
    	a1756771009 = 32 ;
    	a2005069365 = 35 ;
    	a1519100789 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a836757480 == 33 && (a1904774218 == 36 && (((input == 16) &&  cf==1 ) && a928570136 == 32))) && a2005069365 == 32)) {
    	cf = 0;
    	a925870636 = 9;
    	a1904774218 = 34 ;
    	a904637882 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm135(int input) {
    if(((((input == 14) && (( cf==1  && a1904774218 == 36) && a928570136 == 32)) && a2005069365 == 32) && a836757480 == 34)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a747683138 = 32 ;
    	a2059681452 = 33 ;
    	a2110599067 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm137(int input) {
    if((((input == 5) && ((a928570136 == 33 && (a2005069365 == 32 &&  cf==1 )) && a806083420 == 32)) && a1904774218 == 36)) {
    	cf = 0;
    	a1052150692 = 12;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1957279511 = 4; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 32 && (((((input == 17) &&  cf==1 ) && a1904774218 == 36) && a806083420 == 32) && a928570136 == 33))) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a925870636 = 13;
    	a759122969 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a806083420 == 32 && (a928570136 == 33 && (a2005069365 == 32 && ((input == 19) &&  cf==1 )))) && a1904774218 == 36)) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a369539608 = 33 ;
    	a2077351330 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 20) && ((a2005069365 == 32 && (( cf==1  && a1904774218 == 36) && a928570136 == 33)) && a806083420 == 32))) {
    	cf = 0;
    	a714559100 = 5;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a1079106761 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm138(int input) {
    if((a2005069365 == 32 && ((a1904774218 == 36 && ((input == 10) && ( cf==1  && a928570136 == 33))) && a806083420 == 33))) {
    	cf = 0;
    	a925870636 = 9;
    	a1904774218 = 34 ;
    	a904637882 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a806083420 == 33 && (a928570136 == 33 && ( cf==1  && (input == 13)))) && a1904774218 == 36) && a2005069365 == 32)) {
    	cf = 0;
    	a2135613870 = 34 ;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a107446547 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1904774218 == 36 && ((input == 19) && (a2005069365 == 32 &&  cf==1 ))) && a806083420 == 33) && a928570136 == 33)) {
    	cf = 0;
    	a1052150692 = 12;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1957279511 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm140(int input) {
    if((a1904774218 == 36 && (((input == 15) && (a2005069365 == 32 && (a806083420 == 36 &&  cf==1 ))) && a928570136 == 33))) {
    	cf = 0;
    	a88077474 = 34 ;
    	a2016510333 = 33 ;
    	a2005069365 = 35 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 19) && (a2005069365 == 32 && (a806083420 == 36 && (a928570136 == 33 && (a1904774218 == 36 &&  cf==1 )))))) {
    	cf = 0;
    	a1958000800 = 7;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a207863872 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm141(int input) {
    if((a868028614 == 32 && (((input == 17) && (a2005069365 == 32 && (a928570136 == 34 &&  cf==1 ))) && a1904774218 == 36))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1684674520 = 34 ;
    	a369539608 = 34 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm142(int input) {
    if(((((( cf==1  && a868028614 == 33) && (input == 7)) && a1904774218 == 36) && a2005069365 == 32) && a928570136 == 34)) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2124036967 = 32 ;
    	a2005069365 = 34 ;
    	a1194623510 = 34 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((input == 10) && (a868028614 == 33 && ( cf==1  && a2005069365 == 32))) && a928570136 == 34) && a1904774218 == 36)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1325377146 = 32 ;
    	a1838812917 = 33 ;
    	a569036257 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((input == 17) && (( cf==1  && a928570136 == 34) && a868028614 == 33)) && a1904774218 == 36) && a2005069365 == 32)) {
    	cf = 0;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1958000800 = 7;
    	a207863872 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm143(int input) {
    if(((((a868028614 == 35 && ((input == 12) &&  cf==1 )) && a2005069365 == 32) && a1904774218 == 36) && a928570136 == 34)) {
    	cf = 0;
    	a714559100 = 6;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a1086754137 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 32 && ((( cf==1  && a1904774218 == 36) && (input == 17)) && a868028614 == 35)) && a928570136 == 34)) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2059681452 = 35 ;
    	a2005069365 = 36 ;
    	a107446547 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm144(int input) {
    if(((((input == 12) && (( cf==1  && a928570136 == 35) && a666963702 == 9)) && a1904774218 == 36) && a2005069365 == 32)) {
    	cf = 0;
    	a27741386 = 34 ;
    	a1904774218 = 32 ;
    	a1009240021 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a666963702 == 9 && (( cf==1  && a1904774218 == 36) && (input == 19))) && a2005069365 == 32) && a928570136 == 35)) {
    	cf = 0;
    	a1519100789 = 7;
    	a1243394452 = 8;
    	a2005069365 = 35 ;
    	a529769874 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 32 && ((input == 17) && ((a666963702 == 9 && (a928570136 == 35 &&  cf==1 )) && a1904774218 == 36)))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a465336174 = 33 ;
    	a2005069365 = 36 ;
    	a569036257 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm145(int input) {
    if(((a1904774218 == 36 && ((input == 7) && ((a666963702 == 10 &&  cf==1 ) && a2005069365 == 32))) && a928570136 == 35)) {
    	cf = 0;
    	a1519100789 = 7;
    	a1153134505 = 32 ;
    	a2005069365 = 35 ;
    	a1243394452 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm146(int input) {
    if(((a1904774218 == 36 && ((a2005069365 == 32 && (a928570136 == 35 &&  cf==1 )) && a666963702 == 12)) && (input == 2))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1775644016 = 8;
    	a2005069365 = 36 ;
    	a1166586546 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a666963702 == 12 && (a928570136 == 35 && (((input == 12) && (a1904774218 == 36 &&  cf==1 )) && a2005069365 == 32)))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a714559100 = 12;
    	a1655731851 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm148(int input) {
    if(((((a1904774218 == 36 && ( cf==1  && a666963702 == 14)) && a2005069365 == 32) && a928570136 == 35) && (input == 13))) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 10;
    	a2005069365 = 35 ;
    	a662123779 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm149(int input) {
    if((a1904774218 == 36 && ((((input == 4) && ( cf==1  && a928570136 == 35)) && a2005069365 == 32) && a666963702 == 15))) {
    	cf = 0;
    	a928570136 = 33 ;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a107446547 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a666963702 == 15 && (((( cf==1  && a2005069365 == 32) && a1904774218 == 36) && a928570136 == 35) && (input == 13)))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a465336174 = 35 ;
    	a2005069365 = 36 ;
    	a569036257 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm150(int input) {
    if((a2005069365 == 32 && (a998584754 == 10 && ((input == 1) && (a928570136 == 36 && ( cf==1  && a1904774218 == 36)))))) {
    	cf = 0;
    	a107446547 = 12;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a1682504076 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 7) && ((a2005069365 == 32 && (a998584754 == 10 &&  cf==1 )) && a928570136 == 36)) && a1904774218 == 36)) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2124036967 = 33 ;
    	a2005069365 = 34 ;
    	a245033430 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((input == 12) && (a928570136 == 36 &&  cf==1 )) && a1904774218 == 36) && a998584754 == 10) && a2005069365 == 32)) {
    	cf = 0;
    	a1561044360 = 35 ;
    	a2005069365 = 35 ;
    	a113788596 = 32 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm151(int input) {
    if((a998584754 == 11 && ((a1904774218 == 36 && (a2005069365 == 32 && (a928570136 == 36 &&  cf==1 ))) && (input == 17)))) {
    	cf = 0;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 8;
    	a529769874 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm5(int input) {
    if((a928570136 == 32 &&  cf==1 )) {
    	if(( cf==1  && a836757480 == 32)) {
    		calculate_outputm133(input);
    	} 
    	if((a836757480 == 33 &&  cf==1 )) {
    		calculate_outputm134(input);
    	} 
    	if((a836757480 == 34 &&  cf==1 )) {
    		calculate_outputm135(input);
    	} 
    } 
    if((a928570136 == 33 &&  cf==1 )) {
    	if((a806083420 == 32 &&  cf==1 )) {
    		calculate_outputm137(input);
    	} 
    	if(( cf==1  && a806083420 == 33)) {
    		calculate_outputm138(input);
    	} 
    	if((a806083420 == 36 &&  cf==1 )) {
    		calculate_outputm140(input);
    	} 
    } 
    if(( cf==1  && a928570136 == 34)) {
    	if((a868028614 == 32 &&  cf==1 )) {
    		calculate_outputm141(input);
    	} 
    	if((a868028614 == 33 &&  cf==1 )) {
    		calculate_outputm142(input);
    	} 
    	if((a868028614 == 35 &&  cf==1 )) {
    		calculate_outputm143(input);
    	} 
    } 
    if((a928570136 == 35 &&  cf==1 )) {
    	if((a666963702 == 9 &&  cf==1 )) {
    		calculate_outputm144(input);
    	} 
    	if(( cf==1  && a666963702 == 10)) {
    		calculate_outputm145(input);
    	} 
    	if((a666963702 == 12 &&  cf==1 )) {
    		calculate_outputm146(input);
    	} 
    	if((a666963702 == 14 &&  cf==1 )) {
    		calculate_outputm148(input);
    	} 
    	if((a666963702 == 15 &&  cf==1 )) {
    		calculate_outputm149(input);
    	} 
    } 
    if(( cf==1  && a928570136 == 36)) {
    	if((a998584754 == 10 &&  cf==1 )) {
    		calculate_outputm150(input);
    	} 
    	if((a998584754 == 11 &&  cf==1 )) {
    		calculate_outputm151(input);
    	} 
    } 
}
 void calculate_outputm152(int input) {
    if(((input == 4) && (a2059681452 == 32 && (((a2005069365 == 33 &&  cf==1 ) && a679327000 == 32) && a103910758 == 32)))) {
    	cf = 0;
    	a1498704550 = 35 ;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2059681452 == 32 && (a103910758 == 32 && (a679327000 == 32 && (((input == 12) &&  cf==1 ) && a2005069365 == 33))))) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a747683138 = 33 ;
    	a1682504076 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm153(int input) {
    if(((a679327000 == 32 && (a2059681452 == 32 && ((input == 1) && ( cf==1  && a2005069365 == 33)))) && a103910758 == 33)) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2059681452 == 32 && (a2005069365 == 33 && ((input == 2) && (a679327000 == 32 && (a103910758 == 33 &&  cf==1 )))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 33 && (((input == 5) && (( cf==1  && a679327000 == 32) && a2059681452 == 32)) && a103910758 == 33))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a1690193643 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 12) && ((a2005069365 == 33 && (( cf==1  && a2059681452 == 32) && a103910758 == 33)) && a679327000 == 32))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a925870636 = 9;
    	a1904774218 = 34 ;
    	a904637882 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm154(int input) {
    if((((input == 12) && ((( cf==1  && a2005069365 == 33) && a679327000 == 33) && a2065134388 == 12)) && a2059681452 == 32)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1775644016 = 8;
    	a1166586546 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 33 && (((input == 13) && ( cf==1  && a2059681452 == 32)) && a2065134388 == 12)) && a679327000 == 33)) {
    	cf = 0;
    	a1519100789 = 9;
    	a1958000800 = 8;
    	a2005069365 = 35 ;
    	a1184734075 = 13; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2059681452 == 32 && ((a679327000 == 33 && (a2005069365 == 33 &&  cf==1 )) && a2065134388 == 12)) && (input == 6))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1872268177 = 32 ;
    	a1428914468 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm155(int input) {
    if(((input == 1) && (a679327000 == 33 && ((( cf==1  && a2065134388 == 15) && a2005069365 == 33) && a2059681452 == 32)))) {
    	cf = 0;
    	a246458106 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1243394452 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2065134388 == 15 && (a2005069365 == 33 && ((((input == 5) &&  cf==1 ) && a2059681452 == 32) && a679327000 == 33)))) {
    	cf = 0;
    	a714559100 = 6;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1086754137 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2059681452 == 32 && (a2005069365 == 33 && ((input == 10) && (( cf==1  && a2065134388 == 15) && a679327000 == 33))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a844311967 = 36 ;
    	a1235481610 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm156(int input) {
    if(((((input == 3) && ((a2059681452 == 32 &&  cf==1 ) && a2065134388 == 16)) && a2005069365 == 33) && a679327000 == 33)) {
    	cf = 0;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a650110038 = 35 ;
    	a264802066 = 34 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 33 && ((a679327000 == 33 && ((a2065134388 == 16 &&  cf==1 ) && a2059681452 == 32)) && (input == 6)))) {
    	cf = 0;
    	a679327000 = 34 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a2065134388 == 16 && (( cf==1  && a2005069365 == 33) && (input == 14))) && a2059681452 == 32) && a679327000 == 33)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a569036257 = 10;
    	a2005069365 = 36 ;
    	a920118831 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm157(int input) {
    if(((((a2059681452 == 32 && (a679327000 == 33 &&  cf==1 )) && a2005069365 == 33) && a2065134388 == 17) && (input == 4))) {
    	cf = 0;
    	a604409338 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 6;
    	a1688003115 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2065134388 == 17 && (((( cf==1  && a2059681452 == 32) && a2005069365 == 33) && (input == 8)) && a679327000 == 33))) {
    	cf = 0;
    	a1519100789 = 7;
    	a1153134505 = 33 ;
    	a2005069365 = 35 ;
    	a1243394452 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((((input == 10) && ( cf==1  && a2065134388 == 17)) && a679327000 == 33) && a2005069365 == 33) && a2059681452 == 32)) {
    	cf = 0;
    	a88077474 = 34 ;
    	a2005069365 = 35 ;
    	a2016510333 = 32 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a679327000 == 33 && (a2065134388 == 17 && (((a2059681452 == 32 &&  cf==1 ) && a2005069365 == 33) && (input == 17))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a369539608 = 32 ;
    	a1904774218 = 35 ;
    	a1124714117 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm158(int input) {
    if((((a2005069365 == 33 && (( cf==1  && (input == 12)) && a679327000 == 34)) && a603781876 == 5) && a2059681452 == 32)) {
    	cf = 0;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1093326457 = 35 ;
    	a714559100 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a2005069365 == 33 && ((a2059681452 == 32 &&  cf==1 ) && (input == 17))) && a603781876 == 5) && a679327000 == 34)) {
    	cf = 0;
    	a928570136 = 33 ;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a107446547 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm159(int input) {
    if(((((input == 12) && (( cf==1  && a2059681452 == 32) && a679327000 == 34)) && a2005069365 == 33) && a603781876 == 6)) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a2005069365 = 32 ;
    	a369539608 = 33 ;
    	a2077351330 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a679327000 == 34 && ((input == 16) && ((a603781876 == 6 &&  cf==1 ) && a2005069365 == 33))) && a2059681452 == 32)) {
    	cf = 0;
    	a1153134505 = 36 ;
    	a240738299 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm160(int input) {
    if(((input == 15) && ((a2005069365 == 33 && (( cf==1  && a2059681452 == 32) && a679327000 == 34)) && a603781876 == 7))) {
    	cf = 0;
    	a679327000 = 35 ;
    	a1960724031 = 35 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm161(int input) {
    if((a603781876 == 8 && (a679327000 == 34 && ((((input == 11) &&  cf==1 ) && a2005069365 == 33) && a2059681452 == 32)))) {
    	cf = 0;
    	a1204193075 = 34 ;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1243394452 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((input == 16) && (a603781876 == 8 && ( cf==1  && a2005069365 == 33))) && a2059681452 == 32) && a679327000 == 34)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a925870636 = 8;
    	a1904774218 = 34 ;
    	a1883016343 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm162(int input) {
    if((a2005069365 == 33 && (((( cf==1  && a2059681452 == 32) && a603781876 == 9) && a679327000 == 34) && (input == 2)))) {
    	cf = 0;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a367284938 = 33 ;
    	a685667843 = 16; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a679327000 == 34 && (a603781876 == 9 && (a2005069365 == 33 &&  cf==1 ))) && (input == 15)) && a2059681452 == 32)) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm163(int input) {
    if(((a2005069365 == 33 && ((a2059681452 == 32 && ((input == 11) &&  cf==1 )) && a603781876 == 10)) && a679327000 == 34)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a491478835 = 32 ;
    	a714559100 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a603781876 == 10 && (a2059681452 == 32 && (((input == 17) && (a679327000 == 34 &&  cf==1 )) && a2005069365 == 33)))) {
    	cf = 0;
    	a1684687706 = 9;
    	a2059681452 = 34 ;
    	a892217980 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm166(int input) {
    if(((input == 12) && (a2059681452 == 32 && (a2005069365 == 33 && (( cf==1  && a1960724031 == 32) && a679327000 == 35))))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 12;
    	a461439918 = 3; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1960724031 == 32 && ((input == 17) && (( cf==1  && a679327000 == 35) && a2059681452 == 32))) && a2005069365 == 33)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1243394452 = 8;
    	a1519100789 = 7;
    	a529769874 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm167(int input) {
    if(((a1960724031 == 34 && (((input == 8) && ( cf==1  && a2059681452 == 32)) && a2005069365 == 33)) && a679327000 == 35)) {
    	cf = 0;
    	a925870636 = 10;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a666963702 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a2005069365 == 33 && ((input == 17) && (a679327000 == 35 &&  cf==1 ))) && a2059681452 == 32) && a1960724031 == 34)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 14;
    	a2138261183 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm168(int input) {
    if((a2059681452 == 32 && (a2005069365 == 33 && ((input == 1) && (( cf==1  && a1960724031 == 35) && a679327000 == 35))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a2002331280 = 35 ;
    	a1958000800 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((( cf==1  && (input == 2)) && a679327000 == 35) && a2059681452 == 32) && a1960724031 == 35) && a2005069365 == 33)) {
    	cf = 0;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a650110038 = 34 ;
    	a349181387 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 20) && (((a2059681452 == 32 && (a2005069365 == 33 &&  cf==1 )) && a1960724031 == 35) && a679327000 == 35))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1052150692 = 12;
    	a1519100789 = 2;
    	a1957279511 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm169(int input) {
    if((a1960724031 == 36 && (a2005069365 == 33 && (a679327000 == 35 && (a2059681452 == 32 && ((input == 10) &&  cf==1 )))))) {
    	cf = 0;
    	a1843210244 = 34 ;
    	a2059681452 = 34 ;
    	a1684687706 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm170(int input) {
    if((a2005069365 == 33 && (((( cf==1  && a1124714117 == 1) && a2059681452 == 32) && (input == 2)) && a679327000 == 36))) {
    	cf = 0;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 2;
    	a1735753243 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm172(int input) {
    if(((a679327000 == 36 && ((( cf==1  && (input == 11)) && a2059681452 == 32) && a2005069365 == 33)) && a1124714117 == 7)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1775644016 = 11;
    	a1566584718 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a679327000 == 36 && (a1124714117 == 7 && ((input == 16) && (( cf==1  && a2059681452 == 32) && a2005069365 == 33))))) {
    	cf = 0;
    	a604409338 = 34 ;
    	a2005069365 = 35 ;
    	a933478840 = 34 ;
    	a1519100789 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm6(int input) {
    if((a679327000 == 32 &&  cf==1 )) {
    	if(( cf==1  && a103910758 == 32)) {
    		calculate_outputm152(input);
    	} 
    	if((a103910758 == 33 &&  cf==1 )) {
    		calculate_outputm153(input);
    	} 
    } 
    if((a679327000 == 33 &&  cf==1 )) {
    	if(( cf==1  && a2065134388 == 12)) {
    		calculate_outputm154(input);
    	} 
    	if((a2065134388 == 15 &&  cf==1 )) {
    		calculate_outputm155(input);
    	} 
    	if(( cf==1  && a2065134388 == 16)) {
    		calculate_outputm156(input);
    	} 
    	if(( cf==1  && a2065134388 == 17)) {
    		calculate_outputm157(input);
    	} 
    } 
    if(( cf==1  && a679327000 == 34)) {
    	if(( cf==1  && a603781876 == 5)) {
    		calculate_outputm158(input);
    	} 
    	if((a603781876 == 6 &&  cf==1 )) {
    		calculate_outputm159(input);
    	} 
    	if(( cf==1  && a603781876 == 7)) {
    		calculate_outputm160(input);
    	} 
    	if(( cf==1  && a603781876 == 8)) {
    		calculate_outputm161(input);
    	} 
    	if(( cf==1  && a603781876 == 9)) {
    		calculate_outputm162(input);
    	} 
    	if((a603781876 == 10 &&  cf==1 )) {
    		calculate_outputm163(input);
    	} 
    } 
    if(( cf==1  && a679327000 == 35)) {
    	if((a1960724031 == 32 &&  cf==1 )) {
    		calculate_outputm166(input);
    	} 
    	if(( cf==1  && a1960724031 == 34)) {
    		calculate_outputm167(input);
    	} 
    	if(( cf==1  && a1960724031 == 35)) {
    		calculate_outputm168(input);
    	} 
    	if((a1960724031 == 36 &&  cf==1 )) {
    		calculate_outputm169(input);
    	} 
    } 
    if((a679327000 == 36 &&  cf==1 )) {
    	if(( cf==1  && a1124714117 == 1)) {
    		calculate_outputm170(input);
    	} 
    	if((a1124714117 == 7 &&  cf==1 )) {
    		calculate_outputm172(input);
    	} 
    } 
}
 void calculate_outputm173(int input) {
    if(((a2059681452 == 33 && (a747683138 == 32 && ((input == 11) && (a2005069365 == 33 &&  cf==1 )))) && a2110599067 == 11)) {
    	cf = 0;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a246458106 = 36 ;
    	a1243394452 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((( cf==1  && a2005069365 == 33) && a2110599067 == 11) && a2059681452 == 33) && a747683138 == 32) && (input == 12))) {
    	cf = 0;
    	a88077474 = 34 ;
    	a2016510333 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((input == 14) && (a2059681452 == 33 && (( cf==1  && a2110599067 == 11) && a2005069365 == 33))) && a747683138 == 32)) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a925870636 = 9;
    	a2005069365 = 32 ;
    	a904637882 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm174(int input) {
    if(((input == 4) && (((a747683138 == 32 && (a2110599067 == 12 &&  cf==1 )) && a2059681452 == 33) && a2005069365 == 33))) {
    	cf = 0;
    	a88077474 = 34 ;
    	a2016510333 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2059681452 == 33 && (a747683138 == 32 && ((( cf==1  && a2005069365 == 33) && (input == 10)) && a2110599067 == 12)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1243394452 = 4;
    	a1519100789 = 7;
    	a685344195 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2110599067 == 12 && ((((a2005069365 == 33 &&  cf==1 ) && a2059681452 == 33) && (input == 11)) && a747683138 == 32))) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a27741386 = 36 ;
    	a2005069365 = 32 ;
    	a792575314 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm175(int input) {
    if(((a747683138 == 32 && ((a2110599067 == 13 && ( cf==1  && a2059681452 == 33)) && a2005069365 == 33)) && (input == 3))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a1093326457 = 32 ;
    	a2005069365 = 34 ;
    	a714559100 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a2110599067 == 13 && ((a747683138 == 32 && ( cf==1  && (input == 6))) && a2005069365 == 33)) && a2059681452 == 33)) {
    	cf = 0;
    	a714559100 = 11;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a805812408 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 33 && (a2059681452 == 33 && ((a747683138 == 32 && ((input == 13) &&  cf==1 )) && a2110599067 == 13)))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a107446547 = 15;
    	a275125637 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2110599067 == 13 && (a2059681452 == 33 && (a2005069365 == 33 && ((input == 16) && ( cf==1  && a747683138 == 32)))))) {
    	cf = 0;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1958000800 = 9;
    	a1754726785 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm176(int input) {
    if(((a2059681452 == 33 && ((( cf==1  && (input == 16)) && a747683138 == 32) && a2110599067 == 14)) && a2005069365 == 33)) {
    	cf = 0;
    	a679327000 = 33 ;
    	a2059681452 = 32 ;
    	a2065134388 = 17; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm177(int input) {
    if((((input == 12) && ((( cf==1  && a2005069365 == 33) && a2059681452 == 33) && a747683138 == 32)) && a2110599067 == 15)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a1093326457 = 35 ;
    	a714559100 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm178(int input) {
    if((a2059681452 == 33 && (a2005069365 == 33 && (a747683138 == 33 && (a1682504076 == 6 && ((input == 7) &&  cf==1 )))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 10;
    	a662123779 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 15) && ((a747683138 == 33 && ( cf==1  && a2059681452 == 33)) && a1682504076 == 6)) && a2005069365 == 33)) {
    	cf = 0;
    	a113788596 = 32 ;
    	a2005069365 = 35 ;
    	a1561044360 = 35 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm179(int input) {
    if(((input == 2) && ((a2005069365 == 33 && (( cf==1  && a1682504076 == 7) && a747683138 == 33)) && a2059681452 == 33))) {
    	cf = 0;
    	a844311967 = 34 ;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a317927282 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 33 && ((a747683138 == 33 && (( cf==1  && (input == 6)) && a2059681452 == 33)) && a1682504076 == 7))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a107446547 = 14;
    	a986008840 = 15; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm180(int input) {
    if((a2005069365 == 33 && (a1682504076 == 9 && ((input == 13) && (a2059681452 == 33 && (a747683138 == 33 &&  cf==1 )))))) {
    	cf = 0;
    	a369539608 = 32 ;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a1124714117 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a747683138 == 33 && (a2059681452 == 33 && ((input == 17) && (a1682504076 == 9 && (a2005069365 == 33 &&  cf==1 )))))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a714559100 = 11;
    	a805812408 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm181(int input) {
    if((a747683138 == 33 && (a2059681452 == 33 && (((input == 3) && ( cf==1  && a1682504076 == 10)) && a2005069365 == 33)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1052150692 = 8;
    	a1519100789 = 2;
    	a1144659688 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2059681452 == 33 && (((( cf==1  && (input == 7)) && a1682504076 == 10) && a2005069365 == 33) && a747683138 == 33))) {
    	cf = 0;
    	a928570136 = 32 ;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a836757480 = 32 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm182(int input) {
    if((a1682504076 == 13 && (((( cf==1  && a2005069365 == 33) && (input == 3)) && a2059681452 == 33) && a747683138 == 33))) {
    	cf = 0;
    	a1684687706 = 9;
    	a2059681452 = 34 ;
    	a892217980 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm183(int input) {
    if(((((a747683138 == 34 && ( cf==1  && a1428914468 == 7)) && (input == 2)) && a2059681452 == 33) && a2005069365 == 33)) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 7;
    	a2005069365 = 35 ;
    	a71813398 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 3) && (a747683138 == 34 && (a2005069365 == 33 && (a2059681452 == 33 && ( cf==1  && a1428914468 == 7)))))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a491478835 = 35 ;
    	a714559100 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1428914468 == 7 && ((a2059681452 == 33 && (( cf==1  && a747683138 == 34) && a2005069365 == 33)) && (input == 5)))) {
    	cf = 0;
    	a569036257 = 6;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a205734433 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((((a2005069365 == 33 &&  cf==1 ) && a747683138 == 34) && a2059681452 == 33) && a1428914468 == 7) && (input == 20))) {
    	cf = 0;
    	a928570136 = 32 ;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a836757480 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm184(int input) {
    if((((((input == 4) && (a747683138 == 34 &&  cf==1 )) && a1428914468 == 8) && a2059681452 == 33) && a2005069365 == 33)) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((a747683138 == 34 &&  cf==1 ) && a2059681452 == 33) && a1428914468 == 8) && (input == 6)) && a2005069365 == 33)) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a2005069365 == 33 && ( cf==1  && a2059681452 == 33)) && a747683138 == 34) && a1428914468 == 8) && (input == 17))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a925870636 = 10;
    	a666963702 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm185(int input) {
    if((((a747683138 == 34 && (a2005069365 == 33 && ( cf==1  && (input == 2)))) && a2059681452 == 33) && a1428914468 == 11)) {
    	cf = 0;
    	a1129866701 = 8;
    	a2059681452 = 35 ;
    	a1505404504 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 16) && (a2059681452 == 33 && (((a747683138 == 34 &&  cf==1 ) && a1428914468 == 11) && a2005069365 == 33)))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a2005069365 = 36 ;
    	a740799408 = 35 ;
    	a1775644016 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1428914468 == 11 && (a2005069365 == 33 && (a2059681452 == 33 && ((input == 17) &&  cf==1 )))) && a747683138 == 34)) {
    	cf = 0;
    	a928570136 = 32 ;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a836757480 = 33 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1428914468 == 11 && ((a2059681452 == 33 && ((a747683138 == 34 &&  cf==1 ) && a2005069365 == 33)) && (input == 9)))) {
    	cf = 0;
    	a1146785657 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm186(int input) {
    if((a1428914468 == 12 && ((input == 2) && (a747683138 == 34 && (a2005069365 == 33 && (a2059681452 == 33 &&  cf==1 )))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1243394452 = 8;
    	a529769874 = 4; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a747683138 == 34 && ((( cf==1  && a2059681452 == 33) && a2005069365 == 33) && a1428914468 == 12)) && (input == 13))) {
    	cf = 0;
    	a113788596 = 33 ;
    	a2005069365 = 35 ;
    	a1519100789 = 8;
    	a137564664 = 15; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 16) && ((a1428914468 == 12 && (a2005069365 == 33 && ( cf==1  && a747683138 == 34))) && a2059681452 == 33))) {
    	cf = 0;
    	a747683138 = 32 ;
    	a2110599067 = 15; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 19) && (a2005069365 == 33 && ((( cf==1  && a1428914468 == 12) && a2059681452 == 33) && a747683138 == 34)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1958000800 = 13;
    	a1519100789 = 9;
    	a593874874 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm187(int input) {
    if((((a2005069365 == 33 && (( cf==1  && a2059681452 == 33) && a1428914468 == 13)) && (input == 3)) && a747683138 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 12;
    	a1957279511 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2059681452 == 33 && ((((input == 4) && ( cf==1  && a747683138 == 34)) && a1428914468 == 13) && a2005069365 == 33))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 32 ;
    	a650110038 = 36 ;
    	a221974990 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 8) && ((a747683138 == 34 && (a1428914468 == 13 && ( cf==1  && a2005069365 == 33))) && a2059681452 == 33))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a569036257 = 10;
    	a1838812917 = 33 ;
    	a920118831 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((( cf==1  && (input == 17)) && a2059681452 == 33) && a2005069365 == 33) && a1428914468 == 13) && a747683138 == 34)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a990124478 = 36 ;
    	a107446547 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm188(int input) {
    if((a2005069365 == 33 && (a1428914468 == 14 && (((input == 5) && ( cf==1  && a2059681452 == 33)) && a747683138 == 34)))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a2124036967 = 36 ;
    	a524102808 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm189(int input) {
    if(((((a747683138 == 35 && ((input == 20) &&  cf==1 )) && a2059681452 == 33) && a2005069365 == 33) && a1039723590 == 32)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a569036257 = 4;
    	a1838812917 = 33 ;
    	a1549928701 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm192(int input) {
    if((a1039723590 == 36 && (((input == 7) && (a747683138 == 35 && ( cf==1  && a2059681452 == 33))) && a2005069365 == 33))) {
    	cf = 0;
    	a1958000800 = 12;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a798343693 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a2059681452 == 33 && (a2005069365 == 33 && ( cf==1  && a747683138 == 35))) && (input == 12)) && a1039723590 == 36)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 12;
    	a1655731851 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a747683138 == 35 && (a1039723590 == 36 && (a2005069365 == 33 && ((input == 15) && (a2059681452 == 33 &&  cf==1 )))))) {
    	cf = 0;
    	a27741386 = 32 ;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a928570136 = 34 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1039723590 == 36 && (((( cf==1  && (input == 19)) && a747683138 == 35) && a2005069365 == 33) && a2059681452 == 33))) {
    	cf = 0;
    	a604409338 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 6;
    	a1688003115 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm193(int input) {
    if((((a2059681452 == 33 && (a747683138 == 36 && ( cf==1  && a2005069365 == 33))) && a1172911487 == 32) && (input == 3))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a569036257 = 6;
    	a2005069365 = 36 ;
    	a205734433 = 15; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a2005069365 == 33 && (a747683138 == 36 && ((input == 19) && (a1172911487 == 32 &&  cf==1 )))) && a2059681452 == 33)) {
    	cf = 0;
    	a604409338 = 32 ;
    	a2005069365 = 35 ;
    	a1756771009 = 33 ;
    	a1519100789 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2059681452 == 33 && (a1172911487 == 32 && (((input == 20) && (a747683138 == 36 &&  cf==1 )) && a2005069365 == 33)))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a1684687706 = 12;
    	a1710271440 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2059681452 == 33 && ((( cf==1  && a1172911487 == 32) && a2005069365 == 33) && (input == 16))) && a747683138 == 36)) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a27741386 = 32 ;
    	a2005069365 = 32 ;
    	a928570136 = 36 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm195(int input) {
    if(((a2059681452 == 33 && ((input == 4) && ((a2005069365 == 33 &&  cf==1 ) && a1172911487 == 34))) && a747683138 == 36)) {
    	cf = 0;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1872268177 = 32 ;
    	a1958000800 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 33 && ((input == 10) && ((a1172911487 == 34 &&  cf==1 ) && a2059681452 == 33))) && a747683138 == 36)) {
    	cf = 0;
    	a714559100 = 10;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a2125137407 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1172911487 == 34 && ((a2005069365 == 33 && ((input == 13) &&  cf==1 )) && a2059681452 == 33)) && a747683138 == 36)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a844311967 = 35 ;
    	a205734433 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2059681452 == 33 && ((input == 17) && (a1172911487 == 34 && ((a2005069365 == 33 &&  cf==1 ) && a747683138 == 36))))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a525429632 = 34 ;
    	a2005069365 = 36 ;
    	a1775644016 = 13; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm7(int input) {
    if((a747683138 == 32 &&  cf==1 )) {
    	if((a2110599067 == 11 &&  cf==1 )) {
    		calculate_outputm173(input);
    	} 
    	if((a2110599067 == 12 &&  cf==1 )) {
    		calculate_outputm174(input);
    	} 
    	if((a2110599067 == 13 &&  cf==1 )) {
    		calculate_outputm175(input);
    	} 
    	if(( cf==1  && a2110599067 == 14)) {
    		calculate_outputm176(input);
    	} 
    	if(( cf==1  && a2110599067 == 15)) {
    		calculate_outputm177(input);
    	} 
    } 
    if((a747683138 == 33 &&  cf==1 )) {
    	if((a1682504076 == 6 &&  cf==1 )) {
    		calculate_outputm178(input);
    	} 
    	if((a1682504076 == 7 &&  cf==1 )) {
    		calculate_outputm179(input);
    	} 
    	if(( cf==1  && a1682504076 == 9)) {
    		calculate_outputm180(input);
    	} 
    	if((a1682504076 == 10 &&  cf==1 )) {
    		calculate_outputm181(input);
    	} 
    	if(( cf==1  && a1682504076 == 13)) {
    		calculate_outputm182(input);
    	} 
    } 
    if((a747683138 == 34 &&  cf==1 )) {
    	if((a1428914468 == 7 &&  cf==1 )) {
    		calculate_outputm183(input);
    	} 
    	if((a1428914468 == 8 &&  cf==1 )) {
    		calculate_outputm184(input);
    	} 
    	if((a1428914468 == 11 &&  cf==1 )) {
    		calculate_outputm185(input);
    	} 
    	if((a1428914468 == 12 &&  cf==1 )) {
    		calculate_outputm186(input);
    	} 
    	if(( cf==1  && a1428914468 == 13)) {
    		calculate_outputm187(input);
    	} 
    	if(( cf==1  && a1428914468 == 14)) {
    		calculate_outputm188(input);
    	} 
    } 
    if((a747683138 == 35 &&  cf==1 )) {
    	if((a1039723590 == 32 &&  cf==1 )) {
    		calculate_outputm189(input);
    	} 
    	if((a1039723590 == 36 &&  cf==1 )) {
    		calculate_outputm192(input);
    	} 
    } 
    if((a747683138 == 36 &&  cf==1 )) {
    	if(( cf==1  && a1172911487 == 32)) {
    		calculate_outputm193(input);
    	} 
    	if(( cf==1  && a1172911487 == 34)) {
    		calculate_outputm195(input);
    	} 
    } 
}
 void calculate_outputm196(int input) {
    if((((input == 8) && (a1388584441 == 32 && (( cf==1  && a2005069365 == 33) && a1684687706 == 5))) && a2059681452 == 34)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a928570136 = 34 ;
    	a1838812917 = 34 ;
    	a107446547 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 12) && ((a2005069365 == 33 && (a2059681452 == 34 && (a1388584441 == 32 &&  cf==1 ))) && a1684687706 == 5))) {
    	cf = 0;
    	a1958000800 = 8;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1184734075 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm197(int input) {
    if((a1388584441 == 33 && (((input == 4) && (( cf==1  && a1684687706 == 5) && a2005069365 == 33)) && a2059681452 == 34))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a1690193643 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2059681452 == 34 && (((a1684687706 == 5 && ( cf==1  && a2005069365 == 33)) && (input == 10)) && a1388584441 == 33))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a1690193643 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm198(int input) {
    if((a1684687706 == 5 && ((input == 5) && (a2059681452 == 34 && (( cf==1  && a1388584441 == 34) && a2005069365 == 33))))) {
    	cf = 0;
    	a240738299 = 35 ;
    	a2005069365 = 35 ;
    	a1153134505 = 33 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm199(int input) {
    if((((((input == 1) && ( cf==1  && a1684687706 == 5)) && a1388584441 == 36) && a2005069365 == 33) && a2059681452 == 34)) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a925870636 = 9;
    	a904637882 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm200(int input) {
    if((((input == 3) && (a2059681452 == 34 && (a602507557 == 32 && (a1684687706 == 6 &&  cf==1 )))) && a2005069365 == 33)) {
    	cf = 0;
    	a747683138 = 35 ;
    	a2059681452 = 33 ;
    	a1039723590 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a2005069365 == 33 && (a1684687706 == 6 && (( cf==1  && a2059681452 == 34) && (input == 7)))) && a602507557 == 32)) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 12;
    	a2005069365 = 36 ;
    	a1655731851 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2059681452 == 34 && (a1684687706 == 6 && (((a2005069365 == 33 &&  cf==1 ) && (input == 13)) && a602507557 == 32)))) {
    	cf = 0;
    	a1052150692 = 10;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a662123779 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm201(int input) {
    if((a602507557 == 34 && ((a1684687706 == 6 && ((input == 3) && ( cf==1  && a2059681452 == 34))) && a2005069365 == 33))) {
    	cf = 0;
    	a107446547 = 12;
    	a2059681452 = 36 ;
    	a1682504076 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm202(int input) {
    if((a1186984341 == 32 && (a2059681452 == 34 && ((input == 17) && (( cf==1  && a1684687706 == 7) && a2005069365 == 33))))) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a747683138 = 32 ;
    	a2110599067 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm203(int input) {
    if((a1186984341 == 33 && ((input == 2) && ((( cf==1  && a2005069365 == 33) && a2059681452 == 34) && a1684687706 == 7)))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a1428914468 = 7;
    	a976704484 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 33 && (((( cf==1  && a1186984341 == 33) && (input == 7)) && a1684687706 == 7) && a2059681452 == 34))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a2059681452 = 35 ;
    	a1838812917 = 34 ;
    	a107446547 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1186984341 == 33 && ((input == 8) && ((a2059681452 == 34 && ( cf==1  && a1684687706 == 7)) && a2005069365 == 33)))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a925870636 = 9;
    	a904637882 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2059681452 == 34 && ((a1186984341 == 33 && (( cf==1  && (input == 11)) && a2005069365 == 33)) && a1684687706 == 7))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a240738299 = 36 ;
    	a727645622 = 34 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm205(int input) {
    if((a2005069365 == 33 && (a2059681452 == 34 && ((( cf==1  && (input == 1)) && a1684687706 == 8) && a1239184736 == 33)))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a369539608 = 34 ;
    	a1904774218 = 35 ;
    	a1754726785 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1239184736 == 33 && ((( cf==1  && a2059681452 == 34) && a1684687706 == 8) && (input == 6))) && a2005069365 == 33)) {
    	cf = 0;
    	a1684687706 = 9;
    	a892217980 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a1684687706 == 8 && (a1239184736 == 33 && ((input == 13) &&  cf==1 ))) && a2059681452 == 34) && a2005069365 == 33)) {
    	cf = 0;
    	a1519100789 = 7;
    	a1153134505 = 32 ;
    	a2005069365 = 35 ;
    	a1243394452 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm206(int input) {
    if(((a2005069365 == 33 && ((( cf==1  && a1239184736 == 35) && a1684687706 == 8) && a2059681452 == 34)) && (input == 10))) {
    	cf = 0;
    	a2124036967 = 35 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a1942309322 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1239184736 == 35 && (a2059681452 == 34 && ((a2005069365 == 33 && ( cf==1  && a1684687706 == 8)) && (input == 15))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1958000800 = 12;
    	a1519100789 = 9;
    	a798343693 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 33 && (a1239184736 == 35 && (a2059681452 == 34 && ((input == 16) && ( cf==1  && a1684687706 == 8)))))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a844311967 = 36 ;
    	a2005069365 = 32 ;
    	a1235481610 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm207(int input) {
    if(((((( cf==1  && a2005069365 == 33) && a892217980 == 5) && (input == 3)) && a1684687706 == 9) && a2059681452 == 34)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 13;
    	a1271566896 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1684687706 == 9 && ((a892217980 == 5 && (( cf==1  && a2005069365 == 33) && a2059681452 == 34)) && (input == 7)))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a2124036967 = 35 ;
    	a1942309322 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm208(int input) {
    if((a892217980 == 6 && (((a2059681452 == 34 && ( cf==1  && a2005069365 == 33)) && a1684687706 == 9) && (input == 10)))) {
    	cf = 0;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a928570136 = 32 ;
    	a836757480 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((input == 13) && (a892217980 == 6 && ( cf==1  && a2005069365 == 33))) && a2059681452 == 34) && a1684687706 == 9)) {
    	cf = 0;
    	a844311967 = 36 ;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a1235481610 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm209(int input) {
    if((a1684687706 == 9 && ((input == 13) && (((a2005069365 == 33 &&  cf==1 ) && a892217980 == 7) && a2059681452 == 34)))) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm210(int input) {
    if((a2005069365 == 33 && (a1684687706 == 9 && ((a2059681452 == 34 && ( cf==1  && a892217980 == 8)) && (input == 8))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 12;
    	a1957279511 = 1; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 33 && ((a1684687706 == 9 && (( cf==1  && (input == 16)) && a2059681452 == 34)) && a892217980 == 8))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a714559100 = 12;
    	a969893172 = 34 ;
    	a1116999236 = 16; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a892217980 == 8 && ((input == 6) && (((a2059681452 == 34 &&  cf==1 ) && a2005069365 == 33) && a1684687706 == 9)))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a2124036967 = 33 ;
    	a245033430 = 15; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm211(int input) {
    if(((a892217980 == 9 && (((a2059681452 == 34 &&  cf==1 ) && (input == 1)) && a1684687706 == 9)) && a2005069365 == 33)) {
    	cf = 0;
    	a1239184736 = 33 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((input == 6) && (((a1684687706 == 9 &&  cf==1 ) && a892217980 == 9) && a2005069365 == 33)) && a2059681452 == 34)) {
    	cf = 0;
    	a367284938 = 32 ;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 16; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1684687706 == 9 && (a2005069365 == 33 && (a892217980 == 9 && ( cf==1  && (input == 20))))) && a2059681452 == 34)) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm212(int input) {
    if(((a892217980 == 11 && (a2059681452 == 34 && (a1684687706 == 9 && ( cf==1  && a2005069365 == 33)))) && (input == 10))) {
    	cf = 0;
    	a1639827725 = 33 ;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm213(int input) {
    if((a1684687706 == 9 && (((( cf==1  && a892217980 == 12) && a2059681452 == 34) && (input == 14)) && a2005069365 == 33))) {
    	cf = 0;
    	a1561044360 = 35 ;
    	a113788596 = 32 ;
    	a2005069365 = 35 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm214(int input) {
    if(((a1843210244 == 33 && (((a2059681452 == 34 &&  cf==1 ) && a1684687706 == 10) && (input == 12))) && a2005069365 == 33)) {
    	cf = 0;
    	a747683138 = 34 ;
    	a2059681452 = 33 ;
    	a1428914468 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 14) && ((a2059681452 == 34 && (a1684687706 == 10 && ( cf==1  && a2005069365 == 33))) && a1843210244 == 33))) {
    	cf = 0;
    	a928570136 = 32 ;
    	a2005069365 = 35 ;
    	a88077474 = 33 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((input == 9) && ((a2059681452 == 34 && (a1843210244 == 33 &&  cf==1 )) && a2005069365 == 33)) && a1684687706 == 10)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a369539608 = 34 ;
    	a1684674520 = 32 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm215(int input) {
    if(((a1684687706 == 10 && ((( cf==1  && (input == 1)) && a2005069365 == 33) && a2059681452 == 34)) && a1843210244 == 34)) {
    	cf = 0;
    	a1243394452 = 8;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a529769874 = 3; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a2005069365 == 33 && (a1843210244 == 34 && ( cf==1  && a2059681452 == 34))) && (input == 4)) && a1684687706 == 10)) {
    	cf = 0;
    	a844311967 = 35 ;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a205734433 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((( cf==1  && a2059681452 == 34) && a2005069365 == 33) && a1843210244 == 34) && (input == 7)) && a1684687706 == 10)) {
    	cf = 0;
    	a685667843 = 14;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a2138261183 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((( cf==1  && a2005069365 == 33) && a1843210244 == 34) && (input == 11)) && a1684687706 == 10) && a2059681452 == 34)) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a679327000 = 35 ;
    	a1960724031 = 36 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm216(int input) {
    if(((input == 20) && (a2059681452 == 34 && (((a1843210244 == 35 &&  cf==1 ) && a1684687706 == 10) && a2005069365 == 33)))) {
    	cf = 0;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1958000800 = 7;
    	a207863872 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm217(int input) {
    if((((input == 15) && ((a1684687706 == 10 && (a2005069365 == 33 &&  cf==1 )) && a1843210244 == 36)) && a2059681452 == 34)) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm219(int input) {
    if(((a2005069365 == 33 && ((a18979981 == 7 && (a2059681452 == 34 &&  cf==1 )) && (input == 7))) && a1684687706 == 11)) {
    	cf = 0;
    	a1519100789 = 9;
    	a1958000800 = 13;
    	a2005069365 = 35 ;
    	a593874874 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a18979981 == 7 && (((input == 11) && (a2059681452 == 34 && ( cf==1  && a2005069365 == 33))) && a1684687706 == 11))) {
    	cf = 0;
    	a1428914468 = 13;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a2125137407 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm220(int input) {
    if((a18979981 == 9 && ((a2059681452 == 34 && (a1684687706 == 11 && (a2005069365 == 33 &&  cf==1 ))) && (input == 13)))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a169540124 = 36 ;
    	a969893172 = 35 ;
    	a685667843 = 13; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2059681452 == 34 && (a18979981 == 9 && (((input == 19) && (a2005069365 == 33 &&  cf==1 )) && a1684687706 == 11)))) {
    	cf = 0;
    	a569036257 = 10;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a920118831 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm221(int input) {
    if((a1684687706 == 11 && (a18979981 == 10 && ((a2059681452 == 34 && ( cf==1  && a2005069365 == 33)) && (input == 1))))) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a27741386 = 36 ;
    	a2005069365 = 32 ;
    	a792575314 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((a2005069365 == 33 &&  cf==1 ) && a2059681452 == 34) && (input == 6)) && a1684687706 == 11) && a18979981 == 10)) {
    	cf = 0;
    	a928570136 = 35 ;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a666963702 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm222(int input) {
    if(((a2005069365 == 33 && ((input == 8) && (a2059681452 == 34 && (a1684687706 == 11 &&  cf==1 )))) && a18979981 == 12)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a1093326457 = 35 ;
    	a969893172 = 34 ;
    	a714559100 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm223(int input) {
    if(((a1684687706 == 11 && ((a18979981 == 13 && (a2005069365 == 33 &&  cf==1 )) && a2059681452 == 34)) && (input == 7))) {
    	cf = 0;
    	a928570136 = 35 ;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a666963702 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((( cf==1  && a1684687706 == 11) && (input == 16)) && a18979981 == 13) && a2059681452 == 34) && a2005069365 == 33)) {
    	cf = 0;
    	a2135613870 = 36 ;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a107446547 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 33 && (((a1684687706 == 11 && ( cf==1  && a2059681452 == 34)) && a18979981 == 13) && (input == 17)))) {
    	cf = 0;
    	a88077474 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 3;
    	a534598694 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2059681452 == 34 && (a1684687706 == 11 && (a2005069365 == 33 && (((input == 12) &&  cf==1 ) && a18979981 == 13))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a928570136 = 35 ;
    	a1904774218 = 36 ;
    	a666963702 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm224(int input) {
    if(((input == 2) && (a2005069365 == 33 && (a1710271440 == 8 && (a1684687706 == 12 && ( cf==1  && a2059681452 == 34)))))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a714559100 = 12;
    	a2005069365 = 34 ;
    	a1116999236 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm225(int input) {
    if(((input == 7) && (a2059681452 == 34 && (a2005069365 == 33 && (( cf==1  && a1710271440 == 9) && a1684687706 == 12))))) {
    	cf = 0;
    	a27741386 = 33 ;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a706302795 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1710271440 == 9 && (a2005069365 == 33 && (a2059681452 == 34 && (a1684687706 == 12 &&  cf==1 )))) && (input == 11))) {
    	cf = 0;
    	a714559100 = 12;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1116999236 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 33 && (a2059681452 == 34 && (a1710271440 == 9 && ((input == 15) && (a1684687706 == 12 &&  cf==1 )))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a88077474 = 36 ;
    	a744476156 = 34 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2059681452 == 34 && ((a1684687706 == 12 && (( cf==1  && (input == 20)) && a1710271440 == 9)) && a2005069365 == 33))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a107446547 = 14;
    	a986008840 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((a1684687706 == 12 && ( cf==1  && a2059681452 == 34)) && (input == 5)) && a1710271440 == 9) && a2005069365 == 33)) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 33 ;
    	a2005069365 = 34 ;
    	a1015737466 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm226(int input) {
    if((a2059681452 == 34 && ((a1684687706 == 12 && (( cf==1  && a1710271440 == 10) && a2005069365 == 33)) && (input == 8)))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a925870636 = 9;
    	a1904774218 = 34 ;
    	a904637882 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1710271440 == 10 && (a2059681452 == 34 && ( cf==1  && a2005069365 == 33))) && a1684687706 == 12) && (input == 10))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a740799408 = 32 ;
    	a2005069365 = 36 ;
    	a1775644016 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 11) && (((a1684687706 == 12 && (a2005069365 == 33 &&  cf==1 )) && a1710271440 == 10) && a2059681452 == 34))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a2016510333 = 36 ;
    	a88077474 = 34 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a2005069365 == 33 && ((a1710271440 == 10 &&  cf==1 ) && (input == 15))) && a1684687706 == 12) && a2059681452 == 34)) {
    	cf = 0;
    	a27741386 = 32 ;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a928570136 = 34 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm8(int input) {
    if(( cf==1  && a1684687706 == 5)) {
    	if((a1388584441 == 32 &&  cf==1 )) {
    		calculate_outputm196(input);
    	} 
    	if((a1388584441 == 33 &&  cf==1 )) {
    		calculate_outputm197(input);
    	} 
    	if(( cf==1  && a1388584441 == 34)) {
    		calculate_outputm198(input);
    	} 
    	if((a1388584441 == 36 &&  cf==1 )) {
    		calculate_outputm199(input);
    	} 
    } 
    if(( cf==1  && a1684687706 == 6)) {
    	if(( cf==1  && a602507557 == 32)) {
    		calculate_outputm200(input);
    	} 
    	if((a602507557 == 34 &&  cf==1 )) {
    		calculate_outputm201(input);
    	} 
    } 
    if(( cf==1  && a1684687706 == 7)) {
    	if((a1186984341 == 32 &&  cf==1 )) {
    		calculate_outputm202(input);
    	} 
    	if((a1186984341 == 33 &&  cf==1 )) {
    		calculate_outputm203(input);
    	} 
    } 
    if(( cf==1  && a1684687706 == 8)) {
    	if((a1239184736 == 33 &&  cf==1 )) {
    		calculate_outputm205(input);
    	} 
    	if((a1239184736 == 35 &&  cf==1 )) {
    		calculate_outputm206(input);
    	} 
    } 
    if(( cf==1  && a1684687706 == 9)) {
    	if(( cf==1  && a892217980 == 5)) {
    		calculate_outputm207(input);
    	} 
    	if((a892217980 == 6 &&  cf==1 )) {
    		calculate_outputm208(input);
    	} 
    	if((a892217980 == 7 &&  cf==1 )) {
    		calculate_outputm209(input);
    	} 
    	if((a892217980 == 8 &&  cf==1 )) {
    		calculate_outputm210(input);
    	} 
    	if((a892217980 == 9 &&  cf==1 )) {
    		calculate_outputm211(input);
    	} 
    	if(( cf==1  && a892217980 == 11)) {
    		calculate_outputm212(input);
    	} 
    	if(( cf==1  && a892217980 == 12)) {
    		calculate_outputm213(input);
    	} 
    } 
    if(( cf==1  && a1684687706 == 10)) {
    	if(( cf==1  && a1843210244 == 33)) {
    		calculate_outputm214(input);
    	} 
    	if(( cf==1  && a1843210244 == 34)) {
    		calculate_outputm215(input);
    	} 
    	if(( cf==1  && a1843210244 == 35)) {
    		calculate_outputm216(input);
    	} 
    	if((a1843210244 == 36 &&  cf==1 )) {
    		calculate_outputm217(input);
    	} 
    } 
    if(( cf==1  && a1684687706 == 11)) {
    	if((a18979981 == 7 &&  cf==1 )) {
    		calculate_outputm219(input);
    	} 
    	if(( cf==1  && a18979981 == 9)) {
    		calculate_outputm220(input);
    	} 
    	if(( cf==1  && a18979981 == 10)) {
    		calculate_outputm221(input);
    	} 
    	if((a18979981 == 12 &&  cf==1 )) {
    		calculate_outputm222(input);
    	} 
    	if((a18979981 == 13 &&  cf==1 )) {
    		calculate_outputm223(input);
    	} 
    } 
    if((a1684687706 == 12 &&  cf==1 )) {
    	if((a1710271440 == 8 &&  cf==1 )) {
    		calculate_outputm224(input);
    	} 
    	if((a1710271440 == 9 &&  cf==1 )) {
    		calculate_outputm225(input);
    	} 
    	if((a1710271440 == 10 &&  cf==1 )) {
    		calculate_outputm226(input);
    	} 
    } 
}
 void calculate_outputm228(int input) {
    if((a1129866701 == 6 && ((a1146785657 == 32 && (( cf==1  && (input == 12)) && a2005069365 == 33)) && a2059681452 == 35))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 8;
    	a1144659688 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a2005069365 == 33 && (a1146785657 == 32 && ( cf==1  && a1129866701 == 6))) && (input == 15)) && a2059681452 == 35)) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a925870636 = 8;
    	a2005069365 = 32 ;
    	a1883016343 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm230(int input) {
    if((a2059681452 == 35 && (a1129866701 == 6 && ((( cf==1  && a1146785657 == 34) && (input == 5)) && a2005069365 == 33)))) {
    	cf = 0;
    	a2135613870 = 34 ;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a107446547 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1129866701 == 6 && (((input == 16) && (( cf==1  && a2059681452 == 35) && a2005069365 == 33)) && a1146785657 == 34))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a369539608 = 32 ;
    	a1124714117 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((a1146785657 == 34 &&  cf==1 ) && a1129866701 == 6) && a2005069365 == 33) && (input == 17)) && a2059681452 == 35)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a246458106 = 36 ;
    	a1243394452 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((( cf==1  && a2005069365 == 33) && a1146785657 == 34) && a2059681452 == 35) && (input == 19)) && a1129866701 == 6)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a27741386 = 35 ;
    	a1904774218 = 32 ;
    	a829511935 = 35 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm231(int input) {
    if(((a1129866701 == 7 && (((a2005069365 == 33 &&  cf==1 ) && a829511935 == 32) && (input == 12))) && a2059681452 == 35)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a2124036967 = 33 ;
    	a245033430 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm232(int input) {
    if(((((a2005069365 == 33 && (a829511935 == 34 &&  cf==1 )) && (input == 1)) && a1129866701 == 7) && a2059681452 == 35)) {
    	cf = 0;
    	a1129866701 = 8;
    	a1505404504 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2059681452 == 35 && ((input == 11) && (a1129866701 == 7 && ((a829511935 == 34 &&  cf==1 ) && a2005069365 == 33))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm233(int input) {
    if(((a829511935 == 35 && ((a1129866701 == 7 && (a2005069365 == 33 &&  cf==1 )) && (input == 20))) && a2059681452 == 35)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 4;
    	a240738299 = 33 ;
    	a201083786 = 16; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm234(int input) {
    if((a1129866701 == 7 && (((input == 3) && (a2005069365 == 33 && (a2059681452 == 35 &&  cf==1 ))) && a829511935 == 36))) {
    	cf = 0;
    	a1243394452 = 8;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a529769874 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1129866701 == 7 && (a2059681452 == 35 && (((input == 13) && ( cf==1  && a829511935 == 36)) && a2005069365 == 33)))) {
    	cf = 0;
    	a1519100789 = 5;
    	a369539608 = 36 ;
    	a2005069365 = 35 ;
    	a347749795 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm235(int input) {
    if(((((input == 16) && ((a1505404504 == 4 &&  cf==1 ) && a2005069365 == 33)) && a2059681452 == 35) && a1129866701 == 8)) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm236(int input) {
    if(((input == 17) && (a1129866701 == 8 && (a2059681452 == 35 && (a2005069365 == 33 && ( cf==1  && a1505404504 == 5)))))) {
    	cf = 0;
    	a844311967 = 35 ;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a205734433 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((a2059681452 == 35 && ( cf==1  && a1129866701 == 8)) && a2005069365 == 33) && (input == 9)) && a1505404504 == 5)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a2124036967 = 33 ;
    	a969893172 = 36 ;
    	a245033430 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm237(int input) {
    if((((a2059681452 == 35 && (a1129866701 == 8 && ( cf==1  && a1505404504 == 6))) && a2005069365 == 33) && (input == 1))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 12;
    	a1655731851 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2059681452 == 35 && (a1129866701 == 8 && ((a1505404504 == 6 && ( cf==1  && (input == 13))) && a2005069365 == 33)))) {
    	cf = 0;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 4;
    	a685344195 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm238(int input) {
    if(((a2059681452 == 35 && (((a1129866701 == 8 &&  cf==1 ) && (input == 8)) && a2005069365 == 33)) && a1505404504 == 7)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1492184786 = 32 ;
    	a1838812917 = 36 ;
    	a1775644016 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm239(int input) {
    if((a1505404504 == 9 && (((input == 7) && (a1129866701 == 8 && ( cf==1  && a2005069365 == 33))) && a2059681452 == 35))) {
    	cf = 0;
    	a650110038 = 32 ;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a200393381 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1129866701 == 8 && ((input == 11) && ((a1505404504 == 9 &&  cf==1 ) && a2005069365 == 33))) && a2059681452 == 35)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a991719280 = 35 ;
    	a569036257 = 3; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1505404504 == 9 && (((input == 17) && (a1129866701 == 8 &&  cf==1 )) && a2059681452 == 35)) && a2005069365 == 33)) {
    	cf = 0;
    	a1129866701 = 13;
    	a1271566896 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm240(int input) {
    if(((((a1505404504 == 10 && ( cf==1  && a2059681452 == 35)) && a2005069365 == 33) && a1129866701 == 8) && (input == 8))) {
    	cf = 0;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 6;
    	a132552289 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1505404504 == 10 && ((((input == 10) && (a2005069365 == 33 &&  cf==1 )) && a2059681452 == 35) && a1129866701 == 8))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a604409338 = 35 ;
    	a1519100789 = 6;
    	a1688003115 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm241(int input) {
    if(((a1129866701 == 9 && ((a2059681452 == 35 && ( cf==1  && a679327000 == 32)) && a2005069365 == 33)) && (input == 20))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a1428914468 = 13;
    	a2005069365 = 34 ;
    	a2125137407 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm242(int input) {
    if((a679327000 == 34 && ((a1129866701 == 9 && ((input == 3) && ( cf==1  && a2059681452 == 35))) && a2005069365 == 33))) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2059681452 == 35 && ((input == 8) && (((a679327000 == 34 &&  cf==1 ) && a1129866701 == 9) && a2005069365 == 33)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1052150692 = 8;
    	a1519100789 = 2;
    	a1144659688 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a679327000 == 34 && (a2005069365 == 33 && ((a2059681452 == 35 && (a1129866701 == 9 &&  cf==1 )) && (input == 11))))) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a679327000 = 33 ;
    	a2065134388 = 16; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a679327000 == 34 && ((a2005069365 == 33 && ((input == 13) &&  cf==1 )) && a1129866701 == 9)) && a2059681452 == 35)) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm243(int input) {
    if((((a679327000 == 35 && ((input == 2) && ( cf==1  && a1129866701 == 9))) && a2005069365 == 33) && a2059681452 == 35)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a1815432985 = 36 ;
    	a2005069365 = 36 ;
    	a569036257 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 3) && (a2005069365 == 33 && (a1129866701 == 9 && (a2059681452 == 35 && (a679327000 == 35 &&  cf==1 )))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1153134505 = 33 ;
    	a240738299 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((input == 7) && ((a679327000 == 35 && (a1129866701 == 9 &&  cf==1 )) && a2059681452 == 35)) && a2005069365 == 33)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a369539608 = 34 ;
    	a1684674520 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 33 && (((input == 1) && ((a2059681452 == 35 &&  cf==1 ) && a679327000 == 35)) && a1129866701 == 9))) {
    	cf = 0;
    	a1872268177 = 33 ;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1958000800 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm244(int input) {
    if((a679327000 == 36 && (((a2005069365 == 33 && ( cf==1  && a1129866701 == 9)) && a2059681452 == 35) && (input == 8)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1243394452 = 4;
    	a1519100789 = 7;
    	a685344195 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1129866701 == 9 && ((((input == 13) && ( cf==1  && a2059681452 == 35)) && a679327000 == 36) && a2005069365 == 33))) {
    	cf = 0;
    	a844311967 = 36 ;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a1235481610 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm245(int input) {
    if(((((input == 1) && (a2059681452 == 35 && (a1129866701 == 10 &&  cf==1 ))) && a596573336 == 8) && a2005069365 == 33)) {
    	cf = 0;
    	a1388584441 = 34 ;
    	a2059681452 = 34 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm246(int input) {
    if((a596573336 == 9 && ((a2005069365 == 33 && (( cf==1  && (input == 7)) && a1129866701 == 10)) && a2059681452 == 35))) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((input == 17) && (a596573336 == 9 && (a1129866701 == 10 && ( cf==1  && a2059681452 == 35)))) && a2005069365 == 33)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a844311967 = 35 ;
    	a1904774218 = 33 ;
    	a205734433 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm247(int input) {
    if((((a2059681452 == 35 && ((a596573336 == 10 &&  cf==1 ) && a1129866701 == 10)) && a2005069365 == 33) && (input == 4))) {
    	cf = 0;
    	a685667843 = 14;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a2138261183 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 33 && (a1129866701 == 10 && ((a2059681452 == 35 && ( cf==1  && a596573336 == 10)) && (input == 10))))) {
    	cf = 0;
    	a829511935 = 34 ;
    	a1129866701 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a596573336 == 10 && (a2005069365 == 33 && ((input == 19) && (( cf==1  && a1129866701 == 10) && a2059681452 == 35))))) {
    	cf = 0;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a2005069365 = 35 ;
    	a347749795 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm248(int input) {
    if(((input == 15) && ((a2059681452 == 35 && ((a1129866701 == 10 &&  cf==1 ) && a596573336 == 11)) && a2005069365 == 33))) {
    	cf = 0;
    	a1519100789 = 9;
    	a1958000800 = 8;
    	a2005069365 = 35 ;
    	a1184734075 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm249(int input) {
    if((((input == 7) && (a2005069365 == 33 && ((a1129866701 == 10 &&  cf==1 ) && a596573336 == 12))) && a2059681452 == 35)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 6;
    	a205734433 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((( cf==1  && (input == 16)) && a2059681452 == 35) && a2005069365 == 33) && a596573336 == 12) && a1129866701 == 10)) {
    	cf = 0;
    	a1052150692 = 8;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1144659688 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm250(int input) {
    if(((a1129866701 == 10 && (a596573336 == 13 && (a2005069365 == 33 && ((input == 10) &&  cf==1 )))) && a2059681452 == 35)) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 12) && ((a1129866701 == 10 && ((a2005069365 == 33 &&  cf==1 ) && a596573336 == 13)) && a2059681452 == 35))) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a596573336 == 13 && (a2005069365 == 33 && (a1129866701 == 10 && ((input == 15) && ( cf==1  && a2059681452 == 35)))))) {
    	cf = 0;
    	a569036257 = 4;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a1549928701 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm251(int input) {
    if((a691578539 == 5 && (a2059681452 == 35 && (a1129866701 == 11 && ((input == 4) && ( cf==1  && a2005069365 == 33)))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1052150692 = 11;
    	a1519100789 = 2;
    	a1089968358 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 10) && ((a2059681452 == 35 && (( cf==1  && a691578539 == 5) && a1129866701 == 11)) && a2005069365 == 33))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a1843210244 = 34 ;
    	a107446547 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a2005069365 == 33 && ( cf==1  && a2059681452 == 35)) && a691578539 == 5) && a1129866701 == 11) && (input == 19))) {
    	cf = 0;
    	a1428914468 = 10;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a954368445 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a1129866701 == 11 && (a691578539 == 5 && (a2005069365 == 33 &&  cf==1 ))) && (input == 20)) && a2059681452 == 35)) {
    	cf = 0;
    	a1950243878 = 35 ;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 15; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm253(int input) {
    if(((a2005069365 == 33 && (a2059681452 == 35 && (a1129866701 == 11 && (a691578539 == 11 &&  cf==1 )))) && (input == 1))) {
    	cf = 0;
    	a1239184736 = 35 ;
    	a2059681452 = 34 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a691578539 == 11 && ((a2005069365 == 33 && (a1129866701 == 11 && (a2059681452 == 35 &&  cf==1 ))) && (input == 7)))) {
    	cf = 0;
    	a1243394452 = 2;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1735753243 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1129866701 == 11 && (((( cf==1  && (input == 11)) && a2059681452 == 35) && a691578539 == 11) && a2005069365 == 33))) {
    	cf = 0;
    	a206599328 = 34 ;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a714559100 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a691578539 == 11 && ( cf==1  && a2005069365 == 33)) && (input == 5)) && a1129866701 == 11) && a2059681452 == 35)) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a844311967 = 34 ;
    	a317927282 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm254(int input) {
    if((((a691578539 == 12 && (a1129866701 == 11 && (a2005069365 == 33 &&  cf==1 ))) && (input == 10)) && a2059681452 == 35)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a650110038 = 36 ;
    	a969893172 = 32 ;
    	a221974990 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2059681452 == 35 && ((((a1129866701 == 11 &&  cf==1 ) && a691578539 == 12) && a2005069365 == 33) && (input == 14)))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a107446547 = 12;
    	a1682504076 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm255(int input) {
    if((((a2005069365 == 33 && (( cf==1  && a2059681452 == 35) && a461439918 == 3)) && a1129866701 == 12) && (input == 2))) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a27741386 = 36 ;
    	a792575314 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a461439918 == 3 && (a2005069365 == 33 && ((input == 4) &&  cf==1 ))) && a1129866701 == 12) && a2059681452 == 35)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a569036257 = 6;
    	a1838812917 = 33 ;
    	a205734433 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 33 && (a1129866701 == 12 && (a2059681452 == 35 && ((a461439918 == 3 &&  cf==1 ) && (input == 12)))))) {
    	cf = 0;
    	a747683138 = 32 ;
    	a2059681452 = 33 ;
    	a2110599067 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm256(int input) {
    if((a2059681452 == 35 && (a461439918 == 5 && ((a2005069365 == 33 && (a1129866701 == 12 &&  cf==1 )) && (input == 2))))) {
    	cf = 0;
    	a1052150692 = 8;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1144659688 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1129866701 == 12 && ((input == 3) && (a2059681452 == 35 && ((a461439918 == 5 &&  cf==1 ) && a2005069365 == 33))))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 10;
    	a954368445 = 1; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 33 && (((input == 11) && (a2059681452 == 35 && ( cf==1  && a461439918 == 5))) && a1129866701 == 12))) {
    	cf = 0;
    	a1519100789 = 6;
    	a604409338 = 36 ;
    	a2005069365 = 35 ;
    	a1688003115 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1129866701 == 12 && ((input == 13) && (( cf==1  && a2005069365 == 33) && a461439918 == 5))) && a2059681452 == 35)) {
    	cf = 0;
    	a1690193643 = 32 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm257(int input) {
    if((((a1129866701 == 12 && (( cf==1  && a461439918 == 6) && (input == 2))) && a2059681452 == 35) && a2005069365 == 33)) {
    	cf = 0;
    	a88077474 = 33 ;
    	a2005069365 = 35 ;
    	a928570136 = 34 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a2059681452 == 35 && (a461439918 == 6 &&  cf==1 )) && a1129866701 == 12) && a2005069365 == 33) && (input == 8))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 11;
    	a2005069365 = 36 ;
    	a805812408 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((a461439918 == 6 && (a2005069365 == 33 &&  cf==1 )) && a2059681452 == 35) && a1129866701 == 12) && (input == 10))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a927953139 = 33 ;
    	a1838812917 = 32 ;
    	a1944506598 = 35 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a461439918 == 6 && ( cf==1  && a1129866701 == 12)) && (input == 16)) && a2059681452 == 35) && a2005069365 == 33)) {
    	cf = 0;
    	a927953139 = 35 ;
    	a1838812917 = 32 ;
    	a2005069365 = 36 ;
    	a397915314 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm258(int input) {
    if((a2005069365 == 33 && (a1129866701 == 12 && (((input == 16) && ( cf==1  && a2059681452 == 35)) && a461439918 == 7)))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a27741386 = 32 ;
    	a928570136 = 34 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a461439918 == 7 && ((a1129866701 == 12 && ( cf==1  && a2005069365 == 33)) && a2059681452 == 35)) && (input == 17))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a48792734 = 35 ;
    	a1904774218 = 34 ;
    	a925870636 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a2005069365 == 33 && (a2059681452 == 35 && ( cf==1  && a1129866701 == 12))) && a461439918 == 7) && (input == 19))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a650110038 = 35 ;
    	a264802066 = 32 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm260(int input) {
    if((((a2005069365 == 33 && ((input == 3) && ( cf==1  && a1129866701 == 13))) && a2059681452 == 35) && a1271566896 == 7)) {
    	cf = 0;
    	a991719280 = 33 ;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 3; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1129866701 == 13 && (( cf==1  && a2005069365 == 33) && a2059681452 == 35)) && (input == 12)) && a1271566896 == 7)) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a679327000 = 34 ;
    	a603781876 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm262(int input) {
    if((a1271566896 == 10 && ((a2059681452 == 35 && (a2005069365 == 33 && ( cf==1  && a1129866701 == 13))) && (input == 3)))) {
    	cf = 0;
    	a353267992 = 36 ;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a107446547 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1271566896 == 10 && (a2005069365 == 33 && (a1129866701 == 13 && (a2059681452 == 35 && ( cf==1  && (input == 16))))))) {
    	cf = 0;
    	a1519100789 = 6;
    	a2005069365 = 35 ;
    	a604409338 = 35 ;
    	a1688003115 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 33 && ((input == 20) && ((( cf==1  && a1129866701 == 13) && a2059681452 == 35) && a1271566896 == 10)))) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a48792734 = 33 ;
    	a2005069365 = 32 ;
    	a925870636 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm263(int input) {
    if((((a2005069365 == 33 && (( cf==1  && a1271566896 == 11) && (input == 4))) && a1129866701 == 13) && a2059681452 == 35)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 32 ;
    	a650110038 = 34 ;
    	a349181387 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm264(int input) {
    if(((a2059681452 == 35 && ((( cf==1  && (input == 1)) && a1271566896 == 12) && a2005069365 == 33)) && a1129866701 == 13)) {
    	cf = 0;
    	a844311967 = 35 ;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a205734433 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 7) && (a1271566896 == 12 && (((a2059681452 == 35 &&  cf==1 ) && a2005069365 == 33) && a1129866701 == 13)))) {
    	cf = 0;
    	a1129866701 = 8;
    	a1505404504 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((input == 17) && ((a2059681452 == 35 && ( cf==1  && a2005069365 == 33)) && a1271566896 == 12)) && a1129866701 == 13)) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm265(int input) {
    if(((a1271566896 == 13 && (((input == 1) && (a2005069365 == 33 &&  cf==1 )) && a1129866701 == 13)) && a2059681452 == 35)) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a107446547 = 12;
    	a1682504076 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm9(int input) {
    if(( cf==1  && a1129866701 == 6)) {
    	if(( cf==1  && a1146785657 == 32)) {
    		calculate_outputm228(input);
    	} 
    	if((a1146785657 == 34 &&  cf==1 )) {
    		calculate_outputm230(input);
    	} 
    } 
    if((a1129866701 == 7 &&  cf==1 )) {
    	if((a829511935 == 32 &&  cf==1 )) {
    		calculate_outputm231(input);
    	} 
    	if((a829511935 == 34 &&  cf==1 )) {
    		calculate_outputm232(input);
    	} 
    	if((a829511935 == 35 &&  cf==1 )) {
    		calculate_outputm233(input);
    	} 
    	if((a829511935 == 36 &&  cf==1 )) {
    		calculate_outputm234(input);
    	} 
    } 
    if((a1129866701 == 8 &&  cf==1 )) {
    	if((a1505404504 == 4 &&  cf==1 )) {
    		calculate_outputm235(input);
    	} 
    	if((a1505404504 == 5 &&  cf==1 )) {
    		calculate_outputm236(input);
    	} 
    	if((a1505404504 == 6 &&  cf==1 )) {
    		calculate_outputm237(input);
    	} 
    	if((a1505404504 == 7 &&  cf==1 )) {
    		calculate_outputm238(input);
    	} 
    	if(( cf==1  && a1505404504 == 9)) {
    		calculate_outputm239(input);
    	} 
    	if(( cf==1  && a1505404504 == 10)) {
    		calculate_outputm240(input);
    	} 
    } 
    if((a1129866701 == 9 &&  cf==1 )) {
    	if((a679327000 == 32 &&  cf==1 )) {
    		calculate_outputm241(input);
    	} 
    	if((a679327000 == 34 &&  cf==1 )) {
    		calculate_outputm242(input);
    	} 
    	if(( cf==1  && a679327000 == 35)) {
    		calculate_outputm243(input);
    	} 
    	if(( cf==1  && a679327000 == 36)) {
    		calculate_outputm244(input);
    	} 
    } 
    if((a1129866701 == 10 &&  cf==1 )) {
    	if(( cf==1  && a596573336 == 8)) {
    		calculate_outputm245(input);
    	} 
    	if(( cf==1  && a596573336 == 9)) {
    		calculate_outputm246(input);
    	} 
    	if((a596573336 == 10 &&  cf==1 )) {
    		calculate_outputm247(input);
    	} 
    	if((a596573336 == 11 &&  cf==1 )) {
    		calculate_outputm248(input);
    	} 
    	if((a596573336 == 12 &&  cf==1 )) {
    		calculate_outputm249(input);
    	} 
    	if(( cf==1  && a596573336 == 13)) {
    		calculate_outputm250(input);
    	} 
    } 
    if((a1129866701 == 11 &&  cf==1 )) {
    	if(( cf==1  && a691578539 == 5)) {
    		calculate_outputm251(input);
    	} 
    	if((a691578539 == 11 &&  cf==1 )) {
    		calculate_outputm253(input);
    	} 
    	if(( cf==1  && a691578539 == 12)) {
    		calculate_outputm254(input);
    	} 
    } 
    if(( cf==1  && a1129866701 == 12)) {
    	if(( cf==1  && a461439918 == 3)) {
    		calculate_outputm255(input);
    	} 
    	if((a461439918 == 5 &&  cf==1 )) {
    		calculate_outputm256(input);
    	} 
    	if(( cf==1  && a461439918 == 6)) {
    		calculate_outputm257(input);
    	} 
    	if((a461439918 == 7 &&  cf==1 )) {
    		calculate_outputm258(input);
    	} 
    } 
    if((a1129866701 == 13 &&  cf==1 )) {
    	if(( cf==1  && a1271566896 == 7)) {
    		calculate_outputm260(input);
    	} 
    	if((a1271566896 == 10 &&  cf==1 )) {
    		calculate_outputm262(input);
    	} 
    	if((a1271566896 == 11 &&  cf==1 )) {
    		calculate_outputm263(input);
    	} 
    	if(( cf==1  && a1271566896 == 12)) {
    		calculate_outputm264(input);
    	} 
    	if(( cf==1  && a1271566896 == 13)) {
    		calculate_outputm265(input);
    	} 
    } 
}
 void calculate_outputm266(int input) {
    if(((a2059681452 == 36 && (a2005069365 == 33 && (a1795880353 == 32 && ((input == 20) &&  cf==1 )))) && a107446547 == 8)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1506379905 = 36 ;
    	a1904774218 = 34 ;
    	a925870636 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm267(int input) {
    if(((a2005069365 == 33 && ((a107446547 == 8 && ( cf==1  && a2059681452 == 36)) && (input == 4))) && a1795880353 == 33)) {
    	cf = 0;
    	a1519100789 = 7;
    	a1243394452 = 4;
    	a2005069365 = 35 ;
    	a685344195 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a107446547 == 8 && (a2005069365 == 33 && ((( cf==1  && a2059681452 == 36) && (input == 11)) && a1795880353 == 33)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a347749795 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a2059681452 == 36 && (a2005069365 == 33 &&  cf==1 )) && a1795880353 == 33) && a107446547 == 8) && (input == 12))) {
    	cf = 0;
    	a27741386 = 32 ;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a928570136 = 34 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2059681452 == 36 && (a2005069365 == 33 && (a107446547 == 8 && (a1795880353 == 33 && ((input == 17) &&  cf==1 )))))) {
    	cf = 0;
    	a1428914468 = 10;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a954368445 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm270(int input) {
    if(((((( cf==1  && a2005069365 == 33) && a107446547 == 9) && a2059681452 == 36) && (input == 3)) && a1690193643 == 32)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1243394452 = 8;
    	a1519100789 = 7;
    	a529769874 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1690193643 == 32 && (a107446547 == 9 && ((a2059681452 == 36 &&  cf==1 ) && a2005069365 == 33))) && (input == 6))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a687007811 = 35 ;
    	a714559100 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2059681452 == 36 && ((((input == 14) && (a2005069365 == 33 &&  cf==1 )) && a1690193643 == 32) && a107446547 == 9))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1153134505 = 32 ;
    	a1243394452 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm271(int input) {
    if((a2005069365 == 33 && ((a1690193643 == 33 && ((a2059681452 == 36 &&  cf==1 ) && (input == 3))) && a107446547 == 9))) {
    	cf = 0;
    	a925870636 = 10;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a666963702 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a2005069365 == 33 && ((a1690193643 == 33 && (a2059681452 == 36 &&  cf==1 )) && (input == 6))) && a107446547 == 9)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a569036257 = 4;
    	a2005069365 = 36 ;
    	a1549928701 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1690193643 == 33 && ((((a2005069365 == 33 &&  cf==1 ) && a2059681452 == 36) && (input == 13)) && a107446547 == 9))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 8;
    	a1505404504 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((input == 20) && (( cf==1  && a2005069365 == 33) && a2059681452 == 36)) && a107446547 == 9) && a1690193643 == 33)) {
    	cf = 0;
    	a27741386 = 33 ;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a706302795 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 33 && (a2059681452 == 36 && ((input == 8) && (( cf==1  && a107446547 == 9) && a1690193643 == 33))))) {
    	cf = 0;
    	a1958000800 = 12;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a798343693 = 4; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm272(int input) {
    if(((a1690193643 == 35 && (a107446547 == 9 && (((input == 4) &&  cf==1 ) && a2005069365 == 33))) && a2059681452 == 36)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a113788596 = 36 ;
    	a1519100789 = 8;
    	a772592654 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a2059681452 == 36 && (a107446547 == 9 && (a2005069365 == 33 &&  cf==1 ))) && a1690193643 == 35) && (input == 7))) {
    	cf = 0;
    	a1519100789 = 6;
    	a2005069365 = 35 ;
    	a604409338 = 33 ;
    	a954368445 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 16) && ((a1690193643 == 35 && (a2005069365 == 33 &&  cf==1 )) && a2059681452 == 36)) && a107446547 == 9)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 10;
    	a920118831 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm273(int input) {
    if(((a2059681452 == 36 && ((a1843210244 == 32 && ( cf==1  && a2005069365 == 33)) && a107446547 == 10)) && (input == 3))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 4;
    	a1549928701 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 33 && (a1843210244 == 32 && ((input == 19) && (a107446547 == 10 && (a2059681452 == 36 &&  cf==1 )))))) {
    	cf = 0;
    	a1684687706 = 11;
    	a2059681452 = 34 ;
    	a18979981 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm274(int input) {
    if((((((input == 3) && (a2059681452 == 36 &&  cf==1 )) && a2005069365 == 33) && a1843210244 == 34) && a107446547 == 10)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 5;
    	a369539608 = 36 ;
    	a347749795 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a107446547 == 10 && (a2059681452 == 36 && ((input == 11) && (( cf==1  && a2005069365 == 33) && a1843210244 == 34))))) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a27741386 = 36 ;
    	a792575314 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a1843210244 == 34 && ( cf==1  && a2005069365 == 33)) && a2059681452 == 36) && a107446547 == 10) && (input == 19))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a525429632 = 35 ;
    	a2005069365 = 34 ;
    	a1428914468 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 33 && (a107446547 == 10 && (((input == 20) &&  cf==1 ) && a2059681452 == 36))) && a1843210244 == 34)) {
    	cf = 0;
    	a113788596 = 36 ;
    	a1519100789 = 8;
    	a2005069365 = 35 ;
    	a772592654 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm275(int input) {
    if(((input == 14) && (a107446547 == 11 && ((a1275896582 == 32 && (a2059681452 == 36 &&  cf==1 )) && a2005069365 == 33)))) {
    	cf = 0;
    	a714559100 = 6;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a1086754137 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((a107446547 == 11 && ( cf==1  && a2005069365 == 33)) && a1275896582 == 32) && (input == 15)) && a2059681452 == 36)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 13;
    	a593874874 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm276(int input) {
    if(((input == 4) && (a1275896582 == 34 && ((a107446547 == 11 && ( cf==1  && a2005069365 == 33)) && a2059681452 == 36)))) {
    	cf = 0;
    	a1307756142 = 35 ;
    	a2005069365 = 35 ;
    	a369539608 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm277(int input) {
    if((a107446547 == 12 && (a1682504076 == 6 && (a2005069365 == 33 && (a2059681452 == 36 && ( cf==1  && (input == 11))))))) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 10;
    	a2005069365 = 35 ;
    	a662123779 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm278(int input) {
    if((((input == 5) && ((a2005069365 == 33 && ( cf==1  && a107446547 == 12)) && a1682504076 == 7)) && a2059681452 == 36)) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a1843210244 = 36 ;
    	a1684687706 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a107446547 == 12 && ((((a2059681452 == 36 &&  cf==1 ) && (input == 15)) && a1682504076 == 7) && a2005069365 == 33))) {
    	cf = 0;
    	a1682504076 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm279(int input) {
    if((a2005069365 == 33 && (a107446547 == 12 && (((input == 6) && (a1682504076 == 10 &&  cf==1 )) && a2059681452 == 36)))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm280(int input) {
    if((a107446547 == 12 && (a1682504076 == 11 && (a2059681452 == 36 && (( cf==1  && (input == 1)) && a2005069365 == 33))))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a928570136 = 32 ;
    	a107446547 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 33 && (((input == 4) && ((a2059681452 == 36 &&  cf==1 ) && a1682504076 == 11)) && a107446547 == 12))) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a1127376297 = 35 ;
    	a2005069365 = 32 ;
    	a925870636 = 15; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a107446547 == 12 && ((input == 20) && (a1682504076 == 11 && ((a2059681452 == 36 &&  cf==1 ) && a2005069365 == 33))))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a353267992 = 35 ;
    	a1838812917 = 34 ;
    	a107446547 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm281(int input) {
    if(((input == 10) && (((a2059681452 == 36 && ( cf==1  && a107446547 == 12)) && a2005069365 == 33) && a1682504076 == 12))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a844311967 = 33 ;
    	a1380627758 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm282(int input) {
    if((((a107446547 == 12 && ((a1682504076 == 13 &&  cf==1 ) && a2059681452 == 36)) && a2005069365 == 33) && (input == 1))) {
    	cf = 0;
    	a1388584441 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1682504076 == 13 && ((input == 2) && ((( cf==1  && a107446547 == 12) && a2005069365 == 33) && a2059681452 == 36)))) {
    	cf = 0;
    	a1756771009 = 36 ;
    	a240738299 = 32 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 33 && (((( cf==1  && (input == 19)) && a1682504076 == 13) && a2059681452 == 36) && a107446547 == 12))) {
    	cf = 0;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1872268177 = 32 ;
    	a1958000800 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1682504076 == 13 && ((a2059681452 == 36 && ( cf==1  && a107446547 == 12)) && (input == 20))) && a2005069365 == 33)) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a679327000 = 34 ;
    	a603781876 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm283(int input) {
    if((a107446547 == 13 && (a132648993 == 8 && (a2059681452 == 36 && ((input == 8) && ( cf==1  && a2005069365 == 33)))))) {
    	cf = 0;
    	a1519100789 = 6;
    	a2005069365 = 35 ;
    	a604409338 = 33 ;
    	a954368445 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 33 && ((a107446547 == 13 && (a2059681452 == 36 && (a132648993 == 8 &&  cf==1 ))) && (input == 15)))) {
    	cf = 0;
    	a569036257 = 4;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a1549928701 = 15; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a132648993 == 8 && (((input == 16) && ( cf==1  && a2005069365 == 33)) && a107446547 == 13)) && a2059681452 == 36)) {
    	cf = 0;
    	a465336174 = 35 ;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2059681452 == 36 && ((input == 19) && (a132648993 == 8 && (a2005069365 == 33 && ( cf==1  && a107446547 == 13)))))) {
    	cf = 0;
    	a604409338 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 6;
    	a1688003115 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm285(int input) {
    if((a986008840 == 9 && (a2005069365 == 33 && ((( cf==1  && (input == 4)) && a2059681452 == 36) && a107446547 == 14)))) {
    	cf = 0;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1085908735 = 36 ;
    	a1052150692 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((a986008840 == 9 &&  cf==1 ) && a2005069365 == 33) && a107446547 == 14) && (input == 6)) && a2059681452 == 36)) {
    	cf = 0;
    	a928570136 = 34 ;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a868028614 = 35 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a107446547 == 14 && ((input == 14) && ((a2059681452 == 36 &&  cf==1 ) && a2005069365 == 33))) && a986008840 == 9)) {
    	cf = 0;
    	a1838812917 = 32 ;
    	a927953139 = 36 ;
    	a2005069365 = 36 ;
    	a169540124 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm286(int input) {
    if(((a2005069365 == 33 && (a986008840 == 10 && ((a2059681452 == 36 &&  cf==1 ) && (input == 5)))) && a107446547 == 14)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a107446547 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 10) && (a986008840 == 10 && (a2005069365 == 33 && (( cf==1  && a2059681452 == 36) && a107446547 == 14))))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 33 ;
    	a2005069365 = 34 ;
    	a1015737466 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 12) && (a107446547 == 14 && (a2059681452 == 36 && (a2005069365 == 33 && ( cf==1  && a986008840 == 10)))))) {
    	cf = 0;
    	a369539608 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a2005069365 == 33 && ((a107446547 == 14 &&  cf==1 ) && a2059681452 == 36)) && (input == 13)) && a986008840 == 10)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a369539608 = 33 ;
    	a1519100789 = 5;
    	a1894975097 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm287(int input) {
    if((((a986008840 == 11 && (( cf==1  && a2005069365 == 33) && a2059681452 == 36)) && a107446547 == 14) && (input == 1))) {
    	cf = 0;
    	a927953139 = 34 ;
    	a1838812917 = 32 ;
    	a2005069365 = 36 ;
    	a1857807887 = 33 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a986008840 == 11 && (a107446547 == 14 && ((((input == 5) &&  cf==1 ) && a2059681452 == 36) && a2005069365 == 33)))) {
    	cf = 0;
    	a1428914468 = 10;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a954368445 = 2; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a2059681452 == 36 && (a986008840 == 11 && ( cf==1  && (input == 11)))) && a2005069365 == 33) && a107446547 == 14)) {
    	cf = 0;
    	a67466277 = 33 ;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 33 && (((( cf==1  && a2059681452 == 36) && a986008840 == 11) && a107446547 == 14) && (input == 20)))) {
    	cf = 0;
    	a604409338 = 34 ;
    	a2005069365 = 35 ;
    	a933478840 = 36 ;
    	a1519100789 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm289(int input) {
    if(((((( cf==1  && (input == 11)) && a986008840 == 14) && a2059681452 == 36) && a107446547 == 14) && a2005069365 == 33)) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a747683138 = 32 ;
    	a2110599067 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm290(int input) {
    if((a107446547 == 14 && ((input == 4) && ((a2005069365 == 33 && ( cf==1  && a986008840 == 15)) && a2059681452 == 36)))) {
    	cf = 0;
    	a369539608 = 35 ;
    	a2005069365 = 35 ;
    	a1307756142 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a2059681452 == 36 && ((a2005069365 == 33 &&  cf==1 ) && a986008840 == 15)) && (input == 5)) && a107446547 == 14)) {
    	cf = 0;
    	a927953139 = 33 ;
    	a1838812917 = 32 ;
    	a2005069365 = 36 ;
    	a1944506598 = 33 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 8) && (a107446547 == 14 && ((a2059681452 == 36 && (a986008840 == 15 &&  cf==1 )) && a2005069365 == 33)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a369539608 = 35 ;
    	a1958000800 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 19) && (a986008840 == 15 && ((a107446547 == 14 && ( cf==1  && a2059681452 == 36)) && a2005069365 == 33)))) {
    	cf = 0;
    	a240738299 = 35 ;
    	a1153134505 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm291(int input) {
    if(((a2059681452 == 36 && ((a1566584718 == 9 && ( cf==1  && (input == 1))) && a2005069365 == 33)) && a107446547 == 15)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a27741386 = 35 ;
    	a1904774218 = 32 ;
    	a829511935 = 36 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a2005069365 == 33 && ( cf==1  && a1566584718 == 9)) && (input == 5)) && a107446547 == 15) && a2059681452 == 36)) {
    	cf = 0;
    	a1519100789 = 5;
    	a369539608 = 33 ;
    	a2005069365 = 35 ;
    	a1894975097 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2005069365 == 33 && ((a1566584718 == 9 && (a2059681452 == 36 &&  cf==1 )) && a107446547 == 15)) && (input == 11))) {
    	cf = 0;
    	a451941968 = 34 ;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1052150692 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2059681452 == 36 && ((input == 19) && ((( cf==1  && a1566584718 == 9) && a107446547 == 15) && a2005069365 == 33)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1052150692 = 11;
    	a1519100789 = 2;
    	a1089968358 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm292(int input) {
    if((((a2005069365 == 33 && ((a107446547 == 15 &&  cf==1 ) && (input == 1))) && a2059681452 == 36) && a1566584718 == 14)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1958000800 = 7;
    	a1519100789 = 9;
    	a207863872 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a107446547 == 15 && (a1566584718 == 14 && (((input == 5) &&  cf==1 ) && a2005069365 == 33))) && a2059681452 == 36)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1243394452 = 8;
    	a529769874 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2059681452 == 36 && (a107446547 == 15 && (( cf==1  && a2005069365 == 33) && a1566584718 == 14))) && (input == 11))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1872268177 = 32 ;
    	a1958000800 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a2005069365 == 33 && ( cf==1  && a2059681452 == 36)) && a107446547 == 15) && (input == 17)) && a1566584718 == 14)) {
    	cf = 0;
    	a969893172 = 33 ;
    	a1428914468 = 10;
    	a2005069365 = 34 ;
    	a954368445 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm10(int input) {
    if((a107446547 == 8 &&  cf==1 )) {
    	if(( cf==1  && a1795880353 == 32)) {
    		calculate_outputm266(input);
    	} 
    	if((a1795880353 == 33 &&  cf==1 )) {
    		calculate_outputm267(input);
    	} 
    } 
    if(( cf==1  && a107446547 == 9)) {
    	if(( cf==1  && a1690193643 == 32)) {
    		calculate_outputm270(input);
    	} 
    	if((a1690193643 == 33 &&  cf==1 )) {
    		calculate_outputm271(input);
    	} 
    	if((a1690193643 == 35 &&  cf==1 )) {
    		calculate_outputm272(input);
    	} 
    } 
    if((a107446547 == 10 &&  cf==1 )) {
    	if((a1843210244 == 32 &&  cf==1 )) {
    		calculate_outputm273(input);
    	} 
    	if((a1843210244 == 34 &&  cf==1 )) {
    		calculate_outputm274(input);
    	} 
    } 
    if(( cf==1  && a107446547 == 11)) {
    	if(( cf==1  && a1275896582 == 32)) {
    		calculate_outputm275(input);
    	} 
    	if((a1275896582 == 34 &&  cf==1 )) {
    		calculate_outputm276(input);
    	} 
    } 
    if(( cf==1  && a107446547 == 12)) {
    	if(( cf==1  && a1682504076 == 6)) {
    		calculate_outputm277(input);
    	} 
    	if((a1682504076 == 7 &&  cf==1 )) {
    		calculate_outputm278(input);
    	} 
    	if((a1682504076 == 10 &&  cf==1 )) {
    		calculate_outputm279(input);
    	} 
    	if(( cf==1  && a1682504076 == 11)) {
    		calculate_outputm280(input);
    	} 
    	if(( cf==1  && a1682504076 == 12)) {
    		calculate_outputm281(input);
    	} 
    	if(( cf==1  && a1682504076 == 13)) {
    		calculate_outputm282(input);
    	} 
    } 
    if((a107446547 == 13 &&  cf==1 )) {
    	if(( cf==1  && a132648993 == 8)) {
    		calculate_outputm283(input);
    	} 
    } 
    if(( cf==1  && a107446547 == 14)) {
    	if(( cf==1  && a986008840 == 9)) {
    		calculate_outputm285(input);
    	} 
    	if((a986008840 == 10 &&  cf==1 )) {
    		calculate_outputm286(input);
    	} 
    	if((a986008840 == 11 &&  cf==1 )) {
    		calculate_outputm287(input);
    	} 
    	if((a986008840 == 14 &&  cf==1 )) {
    		calculate_outputm289(input);
    	} 
    	if((a986008840 == 15 &&  cf==1 )) {
    		calculate_outputm290(input);
    	} 
    } 
    if(( cf==1  && a107446547 == 15)) {
    	if((a1566584718 == 9 &&  cf==1 )) {
    		calculate_outputm291(input);
    	} 
    	if((a1566584718 == 14 &&  cf==1 )) {
    		calculate_outputm292(input);
    	} 
    } 
}
 void calculate_outputm293(int input) {
    if((a969893172 == 32 && (a650110038 == 32 && ((input == 3) && ((a2005069365 == 34 &&  cf==1 ) && a200393381 == 3))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1684687706 = 11;
    	a2059681452 = 34 ;
    	a18979981 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 34 && (a969893172 == 32 && ((a200393381 == 3 && ((input == 10) &&  cf==1 )) && a650110038 == 32)))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1739072993 = 36 ;
    	a2005069365 = 36 ;
    	a1775644016 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a969893172 == 32 && ((input == 12) && (a650110038 == 32 && (( cf==1  && a200393381 == 3) && a2005069365 == 34))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1843210244 = 33 ;
    	a1684687706 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a969893172 == 32 && ( cf==1  && a2005069365 == 34)) && a650110038 == 32) && a200393381 == 3) && (input == 19))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a1498704550 = 36 ;
    	a2005069365 = 36 ;
    	a714559100 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a969893172 == 32 && (a2005069365 == 34 && (a200393381 == 3 && (((input == 13) &&  cf==1 ) && a650110038 == 32))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1307756142 = 36 ;
    	a369539608 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm294(int input) {
    if(((a650110038 == 32 && (a969893172 == 32 && (( cf==1  && (input == 3)) && a200393381 == 4))) && a2005069365 == 34)) {
    	cf = 0;
    	a113788596 = 36 ;
    	a1519100789 = 8;
    	a2005069365 = 35 ;
    	a772592654 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 34 && (((input == 14) && (a200393381 == 4 && ( cf==1  && a650110038 == 32))) && a969893172 == 32))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 10;
    	a662123779 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm295(int input) {
    if((((a2005069365 == 34 && (a650110038 == 32 && ((input == 6) &&  cf==1 ))) && a200393381 == 6) && a969893172 == 32)) {
    	cf = 0;
    	a969893172 = 35 ;
    	a685667843 = 14;
    	a2138261183 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 12) && (((( cf==1  && a200393381 == 6) && a969893172 == 32) && a2005069365 == 34) && a650110038 == 32))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a107446547 = 12;
    	a2005069365 = 33 ;
    	a1682504076 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a650110038 == 32 && ((input == 14) && (a200393381 == 6 && (( cf==1  && a969893172 == 32) && a2005069365 == 34))))) {
    	cf = 0;
    	a1838812917 = 32 ;
    	a927953139 = 35 ;
    	a2005069365 = 36 ;
    	a397915314 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm296(int input) {
    if(((a2005069365 == 34 && ((input == 3) && (a1015737466 == 4 && (a969893172 == 32 &&  cf==1 )))) && a650110038 == 33)) {
    	cf = 0;
    	a969893172 = 35 ;
    	a685667843 = 14;
    	a2138261183 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1015737466 == 4 && (a2005069365 == 34 && (a969893172 == 32 && (a650110038 == 33 && ( cf==1  && (input == 5))))))) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a925870636 = 8;
    	a2005069365 = 32 ;
    	a1883016343 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a650110038 == 33 && ((a1015737466 == 4 && ( cf==1  && a2005069365 == 34)) && a969893172 == 32)) && (input == 16))) {
    	cf = 0;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a2005069365 = 35 ;
    	a347749795 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm297(int input) {
    if(((a969893172 == 32 && (((input == 3) && (a650110038 == 33 &&  cf==1 )) && a1015737466 == 5)) && a2005069365 == 34)) {
    	cf = 0;
    	a928570136 = 32 ;
    	a2005069365 = 32 ;
    	a1904774218 = 36 ;
    	a836757480 = 32 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1015737466 == 5 && (( cf==1  && a650110038 == 33) && a2005069365 == 34)) && a969893172 == 32) && (input == 16))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 33 ;
    	a747683138 = 32 ;
    	a2110599067 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a650110038 == 33 && (((a2005069365 == 34 && (a969893172 == 32 &&  cf==1 )) && (input == 20)) && a1015737466 == 5))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 12;
    	a2005069365 = 36 ;
    	a1655731851 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm298(int input) {
    if((a1015737466 == 6 && (((input == 14) && ((a650110038 == 33 &&  cf==1 ) && a2005069365 == 34)) && a969893172 == 32))) {
    	cf = 0;
    	a928570136 = 33 ;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a806083420 = 33 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 19) && ((a1015737466 == 6 && ((a2005069365 == 34 &&  cf==1 ) && a969893172 == 32)) && a650110038 == 33))) {
    	cf = 0;
    	a1129866701 = 11;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a691578539 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm299(int input) {
    if(((input == 6) && (a969893172 == 32 && (a2005069365 == 34 && (a650110038 == 33 && ( cf==1  && a1015737466 == 7)))))) {
    	cf = 0;
    	a747683138 = 35 ;
    	a2059681452 = 33 ;
    	a2005069365 = 33 ;
    	a1039723590 = 32 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a650110038 == 33 && (a969893172 == 32 && ((input == 10) && (( cf==1  && a1015737466 == 7) && a2005069365 == 34))))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a844311967 = 33 ;
    	a1380627758 = 4; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a650110038 == 33 && ((a969893172 == 32 && (( cf==1  && a2005069365 == 34) && a1015737466 == 7)) && (input == 13)))) {
    	cf = 0;
    	a714559100 = 7;
    	a969893172 = 34 ;
    	a1166586546 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 16) && ((a2005069365 == 34 && ( cf==1  && a650110038 == 33)) && a969893172 == 32)) && a1015737466 == 7)) {
    	cf = 0;
    	a969893172 = 33 ;
    	a1428914468 = 13;
    	a2125137407 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm301(int input) {
    if((a1015737466 == 9 && (a969893172 == 32 && (a2005069365 == 34 && ((input == 3) && (a650110038 == 33 &&  cf==1 )))))) {
    	cf = 0;
    	a1153134505 = 33 ;
    	a240738299 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1015737466 == 9 && (((a650110038 == 33 &&  cf==1 ) && a969893172 == 32) && (input == 12))) && a2005069365 == 34)) {
    	cf = 0;
    	a1052150692 = 8;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1144659688 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1015737466 == 9 && (((a969893172 == 32 && ((input == 13) &&  cf==1 )) && a650110038 == 33) && a2005069365 == 34))) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 8;
    	a2005069365 = 35 ;
    	a1144659688 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1015737466 == 9 && ((a969893172 == 32 && ((input == 19) && (a650110038 == 33 &&  cf==1 ))) && a2005069365 == 34))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm302(int input) {
    if((a969893172 == 32 && (a650110038 == 34 && ((( cf==1  && a349181387 == 1) && (input == 3)) && a2005069365 == 34)))) {
    	cf = 0;
    	a1684687706 = 9;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a892217980 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a650110038 == 34 && ((( cf==1  && a2005069365 == 34) && a969893172 == 32) && (input == 4))) && a349181387 == 1)) {
    	cf = 0;
    	a1775644016 = 8;
    	a1838812917 = 36 ;
    	a2005069365 = 36 ;
    	a1166586546 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 5) && (a349181387 == 1 && (((a2005069365 == 34 &&  cf==1 ) && a969893172 == 32) && a650110038 == 34)))) {
    	cf = 0;
    	a1085908735 = 32 ;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a969893172 == 32 && ((input == 13) && (((a349181387 == 1 &&  cf==1 ) && a650110038 == 34) && a2005069365 == 34)))) {
    	cf = 0;
    	a604409338 = 33 ;
    	a2005069365 = 35 ;
    	a1519100789 = 6;
    	a954368445 = 1; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm303(int input) {
    if((a969893172 == 32 && (a349181387 == 2 && ((((input == 11) &&  cf==1 ) && a2005069365 == 34) && a650110038 == 34)))) {
    	cf = 0;
    	a1129866701 = 10;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a596573336 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a969893172 == 32 && (((( cf==1  && a2005069365 == 34) && (input == 12)) && a650110038 == 34) && a349181387 == 2))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a569036257 = 10;
    	a1838812917 = 33 ;
    	a920118831 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a650110038 == 34 && ((a969893172 == 32 && (a349181387 == 2 &&  cf==1 )) && (input == 16))) && a2005069365 == 34)) {
    	cf = 0;
    	a107446547 = 14;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a986008840 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm304(int input) {
    if((a650110038 == 34 && ((input == 12) && (a2005069365 == 34 && (a349181387 == 4 && (a969893172 == 32 &&  cf==1 )))))) {
    	cf = 0;
    	a969893172 = 35 ;
    	a1498704550 = 36 ;
    	a685667843 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a969893172 == 32 && (( cf==1  && (input == 13)) && a650110038 == 34)) && a2005069365 == 34) && a349181387 == 4)) {
    	cf = 0;
    	a1775644016 = 11;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1566584718 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm305(int input) {
    if((a969893172 == 32 && (((input == 10) && (( cf==1  && a2005069365 == 34) && a349181387 == 6)) && a650110038 == 34))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a569036257 = 4;
    	a2005069365 = 36 ;
    	a1549928701 = 15; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm306(int input) {
    if(((a349181387 == 7 && ((( cf==1  && a969893172 == 32) && (input == 4)) && a650110038 == 34)) && a2005069365 == 34)) {
    	cf = 0;
    	a113788596 = 34 ;
    	a2005069365 = 35 ;
    	a1519100789 = 8;
    	a1688003115 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a650110038 == 34 && (a2005069365 == 34 && (a969893172 == 32 && (( cf==1  && a349181387 == 7) && (input == 11)))))) {
    	cf = 0;
    	a2124036967 = 33 ;
    	a969893172 = 36 ;
    	a245033430 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm307(int input) {
    if((a349181387 == 8 && (a969893172 == 32 && (a2005069365 == 34 && ((a650110038 == 34 &&  cf==1 ) && (input == 14)))))) {
    	cf = 0;
    	a1428914468 = 13;
    	a969893172 = 33 ;
    	a2125137407 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a650110038 == 34 && (a349181387 == 8 && ((( cf==1  && a2005069365 == 34) && a969893172 == 32) && (input == 15))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a650110038 == 34 && (a2005069365 == 34 && (((input == 19) &&  cf==1 ) && a349181387 == 8))) && a969893172 == 32)) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm308(int input) {
    if((a264802066 == 32 && (a969893172 == 32 && ((input == 7) && (a2005069365 == 34 && (a650110038 == 35 &&  cf==1 )))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a369539608 = 36 ;
    	a1577567933 = 35 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a264802066 == 32 && ( cf==1  && a2005069365 == 34)) && a650110038 == 35) && (input == 14)) && a969893172 == 32)) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a2005069365 = 32 ;
    	a369539608 = 36 ;
    	a1577567933 = 35 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm309(int input) {
    if(((a2005069365 == 34 && ((( cf==1  && a650110038 == 35) && a969893172 == 32) && (input == 15))) && a264802066 == 34)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a679327000 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm310(int input) {
    if((a650110038 == 35 && (a264802066 == 35 && (a969893172 == 32 && (a2005069365 == 34 && ( cf==1  && (input == 2))))))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2124036967 = 35 ;
    	a1942309322 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 34 && ((a969893172 == 32 && ( cf==1  && a264802066 == 35)) && (input == 5))) && a650110038 == 35)) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a1239184736 = 35 ;
    	a2005069365 = 33 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((input == 10) && (a264802066 == 35 &&  cf==1 )) && a969893172 == 32) && a650110038 == 35) && a2005069365 == 34)) {
    	cf = 0;
    	a650110038 = 36 ;
    	a221974990 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm311(int input) {
    if((a650110038 == 35 && ((input == 16) && (((a969893172 == 32 &&  cf==1 ) && a264802066 == 36) && a2005069365 == 34)))) {
    	cf = 0;
    	a1843210244 = 36 ;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm312(int input) {
    if((a969893172 == 32 && (a221974990 == 7 && ((( cf==1  && (input == 4)) && a2005069365 == 34) && a650110038 == 36)))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2124036967 = 35 ;
    	a1942309322 = 36 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 11) && (((( cf==1  && a969893172 == 32) && a2005069365 == 34) && a221974990 == 7) && a650110038 == 36))) {
    	cf = 0;
    	a650110038 = 35 ;
    	a264802066 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm314(int input) {
    if((((a650110038 == 36 && (( cf==1  && a221974990 == 9) && a969893172 == 32)) && (input == 13)) && a2005069365 == 34)) {
    	cf = 0;
    	a2124036967 = 34 ;
    	a969893172 = 36 ;
    	a745730534 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 34 && ((input == 15) && (a650110038 == 36 && ((a969893172 == 32 &&  cf==1 ) && a221974990 == 9))))) {
    	cf = 0;
    	a2124036967 = 36 ;
    	a969893172 = 36 ;
    	a524102808 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a650110038 == 36 && (a2005069365 == 34 && ((a221974990 == 9 &&  cf==1 ) && (input == 19)))) && a969893172 == 32)) {
    	cf = 0;
    	a1519100789 = 8;
    	a2005069365 = 35 ;
    	a113788596 = 36 ;
    	a772592654 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm315(int input) {
    if(((a650110038 == 36 && (((a969893172 == 32 &&  cf==1 ) && a2005069365 == 34) && a221974990 == 12)) && (input == 6))) {
    	cf = 0;
    	a687007811 = 35 ;
    	a969893172 = 34 ;
    	a714559100 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 34 && (((a969893172 == 32 && (a221974990 == 12 &&  cf==1 )) && (input == 7)) && a650110038 == 36))) {
    	cf = 0;
    	a1204193075 = 34 ;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm316(int input) {
    if(((input == 5) && (a650110038 == 36 && (((a2005069365 == 34 &&  cf==1 ) && a969893172 == 32) && a221974990 == 13)))) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a969893172 == 32 && ( cf==1  && a221974990 == 13)) && a650110038 == 36) && a2005069365 == 34) && (input == 8))) {
    	cf = 0;
    	a451941968 = 32 ;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm11(int input) {
    if(( cf==1  && a650110038 == 32)) {
    	if((a200393381 == 3 &&  cf==1 )) {
    		calculate_outputm293(input);
    	} 
    	if((a200393381 == 4 &&  cf==1 )) {
    		calculate_outputm294(input);
    	} 
    	if((a200393381 == 6 &&  cf==1 )) {
    		calculate_outputm295(input);
    	} 
    } 
    if((a650110038 == 33 &&  cf==1 )) {
    	if(( cf==1  && a1015737466 == 4)) {
    		calculate_outputm296(input);
    	} 
    	if(( cf==1  && a1015737466 == 5)) {
    		calculate_outputm297(input);
    	} 
    	if(( cf==1  && a1015737466 == 6)) {
    		calculate_outputm298(input);
    	} 
    	if(( cf==1  && a1015737466 == 7)) {
    		calculate_outputm299(input);
    	} 
    	if(( cf==1  && a1015737466 == 9)) {
    		calculate_outputm301(input);
    	} 
    } 
    if((a650110038 == 34 &&  cf==1 )) {
    	if(( cf==1  && a349181387 == 1)) {
    		calculate_outputm302(input);
    	} 
    	if(( cf==1  && a349181387 == 2)) {
    		calculate_outputm303(input);
    	} 
    	if(( cf==1  && a349181387 == 4)) {
    		calculate_outputm304(input);
    	} 
    	if((a349181387 == 6 &&  cf==1 )) {
    		calculate_outputm305(input);
    	} 
    	if(( cf==1  && a349181387 == 7)) {
    		calculate_outputm306(input);
    	} 
    	if(( cf==1  && a349181387 == 8)) {
    		calculate_outputm307(input);
    	} 
    } 
    if((a650110038 == 35 &&  cf==1 )) {
    	if((a264802066 == 32 &&  cf==1 )) {
    		calculate_outputm308(input);
    	} 
    	if(( cf==1  && a264802066 == 34)) {
    		calculate_outputm309(input);
    	} 
    	if(( cf==1  && a264802066 == 35)) {
    		calculate_outputm310(input);
    	} 
    	if((a264802066 == 36 &&  cf==1 )) {
    		calculate_outputm311(input);
    	} 
    } 
    if((a650110038 == 36 &&  cf==1 )) {
    	if(( cf==1  && a221974990 == 7)) {
    		calculate_outputm312(input);
    	} 
    	if((a221974990 == 9 &&  cf==1 )) {
    		calculate_outputm314(input);
    	} 
    	if((a221974990 == 12 &&  cf==1 )) {
    		calculate_outputm315(input);
    	} 
    	if(( cf==1  && a221974990 == 13)) {
    		calculate_outputm316(input);
    	} 
    } 
}
 void calculate_outputm317(int input) {
    if(((((a2005069365 == 34 && ( cf==1  && a969893172 == 33)) && a1428914468 == 7) && (input == 12)) && a976704484 == 4)) {
    	cf = 0;
    	a714559100 = 5;
    	a969893172 = 34 ;
    	a1079106761 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm318(int input) {
    if((((((a2005069365 == 34 &&  cf==1 ) && a969893172 == 33) && a1428914468 == 7) && (input == 7)) && a976704484 == 5)) {
    	cf = 0;
    	a1129866701 = 11;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm319(int input) {
    if((a2005069365 == 34 && ((((a976704484 == 8 &&  cf==1 ) && a969893172 == 33) && (input == 6)) && a1428914468 == 7))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 3;
    	a88077474 = 35 ;
    	a534598694 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a976704484 == 8 && ((input == 10) && (a2005069365 == 34 && (a1428914468 == 7 && ( cf==1  && a969893172 == 33)))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1204193075 = 34 ;
    	a1519100789 = 7;
    	a1243394452 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a976704484 == 8 && (((input == 15) && (a2005069365 == 34 && (a1428914468 == 7 &&  cf==1 ))) && a969893172 == 33))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1243394452 = 4;
    	a685344195 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm320(int input) {
    if((a1428914468 == 7 && (a2005069365 == 34 && ((input == 14) && (( cf==1  && a969893172 == 33) && a976704484 == 10))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a48792734 = 35 ;
    	a1904774218 = 34 ;
    	a925870636 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm321(int input) {
    if(((a2005069365 == 34 && (a969893172 == 33 && (( cf==1  && a1428914468 == 8) && (input == 1)))) && a1699038459 == 3)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a48792734 = 33 ;
    	a1904774218 = 34 ;
    	a925870636 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1428914468 == 8 && (a969893172 == 33 && ((input == 7) && (a2005069365 == 34 && ( cf==1  && a1699038459 == 3)))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a240738299 = 36 ;
    	a727645622 = 34 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1428914468 == 8 && (a1699038459 == 3 && (( cf==1  && a2005069365 == 34) && (input == 14)))) && a969893172 == 33)) {
    	cf = 0;
    	a714559100 = 7;
    	a969893172 = 34 ;
    	a1166586546 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm322(int input) {
    if((a2005069365 == 34 && (((( cf==1  && a1428914468 == 8) && (input == 2)) && a969893172 == 33) && a1699038459 == 7))) {
    	cf = 0;
    	a650110038 = 35 ;
    	a969893172 = 32 ;
    	a264802066 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((( cf==1  && (input == 3)) && a2005069365 == 34) && a1428914468 == 8) && a969893172 == 33) && a1699038459 == 7)) {
    	cf = 0;
    	a844311967 = 33 ;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a1380627758 = 4; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 19) && (a969893172 == 33 && ((a1428914468 == 8 &&  cf==1 ) && a1699038459 == 7))) && a2005069365 == 34)) {
    	cf = 0;
    	a1428914468 = 7;
    	a976704484 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm323(int input) {
    if((((a1428914468 == 8 && ((input == 11) && (a969893172 == 33 &&  cf==1 ))) && a1699038459 == 10) && a2005069365 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a2002331280 = 36 ;
    	a1958000800 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 5) && (a2005069365 == 34 && ((a1428914468 == 8 && ( cf==1  && a1699038459 == 10)) && a969893172 == 33)))) {
    	cf = 0;
    	a525429632 = 35 ;
    	a1838812917 = 36 ;
    	a2005069365 = 36 ;
    	a1775644016 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm324(int input) {
    if((a2005069365 == 34 && ((a1610737594 == 35 && ((a969893172 == 33 &&  cf==1 ) && (input == 16))) && a1428914468 == 9))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a844311967 = 32 ;
    	a1904774218 = 33 ;
    	a749536178 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a969893172 == 33 && ((a2005069365 == 34 && ((input == 20) && (a1610737594 == 35 &&  cf==1 ))) && a1428914468 == 9))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1243394452 = 2;
    	a1735753243 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm325(int input) {
    if((a2005069365 == 34 && (a969893172 == 33 && (((input == 2) && (a1428914468 == 9 &&  cf==1 )) && a1610737594 == 36)))) {
    	cf = 0;
    	a1775644016 = 11;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1566584718 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1610737594 == 36 && ((a1428914468 == 9 && (a969893172 == 33 && ((input == 15) &&  cf==1 ))) && a2005069365 == 34))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a2135613870 = 34 ;
    	a107446547 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm326(int input) {
    if((a2005069365 == 34 && (a954368445 == 1 && (a969893172 == 33 && (((input == 20) &&  cf==1 ) && a1428914468 == 10))))) {
    	cf = 0;
    	a2124036967 = 35 ;
    	a969893172 = 36 ;
    	a1942309322 = 34 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm327(int input) {
    if(((a1428914468 == 10 && ((input == 1) && (a969893172 == 33 && (a954368445 == 2 &&  cf==1 )))) && a2005069365 == 34)) {
    	cf = 0;
    	a1153134505 = 36 ;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a1428914468 == 10 && (( cf==1  && a2005069365 == 34) && a969893172 == 33)) && (input == 4)) && a954368445 == 2)) {
    	cf = 0;
    	a27741386 = 33 ;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a706302795 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a1428914468 == 10 && (( cf==1  && a2005069365 == 34) && a969893172 == 33)) && (input == 10)) && a954368445 == 2)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a113788596 = 36 ;
    	a1519100789 = 8;
    	a772592654 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm328(int input) {
    if((a2005069365 == 34 && (a969893172 == 33 && (a1428914468 == 10 && ((input == 16) && ( cf==1  && a954368445 == 3)))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 12;
    	a798343693 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 34 && (((a954368445 == 3 && ( cf==1  && (input == 19))) && a969893172 == 33) && a1428914468 == 10))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a714559100 = 6;
    	a1086754137 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm329(int input) {
    if(((input == 2) && (a954368445 == 4 && ((a2005069365 == 34 && ( cf==1  && a969893172 == 33)) && a1428914468 == 10)))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a1815432985 = 36 ;
    	a2005069365 = 36 ;
    	a569036257 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm330(int input) {
    if((a969893172 == 33 && (a1428914468 == 10 && ((((input == 15) &&  cf==1 ) && a954368445 == 5) && a2005069365 == 34)))) {
    	cf = 0;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1085908735 = 36 ;
    	a1052150692 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm331(int input) {
    if(((((a1428914468 == 10 && (a969893172 == 33 &&  cf==1 )) && a2005069365 == 34) && (input == 6)) && a954368445 == 6)) {
    	cf = 0;
    	a714559100 = 7;
    	a969893172 = 34 ;
    	a1166586546 = 15; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a954368445 == 6 && (((( cf==1  && a2005069365 == 34) && (input == 15)) && a1428914468 == 10) && a969893172 == 33))) {
    	cf = 0;
    	a2124036967 = 33 ;
    	a969893172 = 36 ;
    	a245033430 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 34 && ((a954368445 == 6 && ((input == 20) && (a1428914468 == 10 &&  cf==1 ))) && a969893172 == 33))) {
    	cf = 0;
    	a744476156 = 33 ;
    	a88077474 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm332(int input) {
    if((a954368445 == 7 && (a969893172 == 33 && (a2005069365 == 34 && ((a1428914468 == 10 &&  cf==1 ) && (input == 1)))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 36 ;
    	a928570136 = 33 ;
    	a806083420 = 36 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 7) && (a2005069365 == 34 && ((a1428914468 == 10 &&  cf==1 ) && a969893172 == 33))) && a954368445 == 7)) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a969893172 == 33 && (a1428914468 == 10 && (a954368445 == 7 && ( cf==1  && a2005069365 == 34)))) && (input == 15))) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm333(int input) {
    if(((a969893172 == 33 && (a2005069365 == 34 && (( cf==1  && a954368445 == 8) && a1428914468 == 10))) && (input == 3))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a844311967 = 35 ;
    	a2005069365 = 32 ;
    	a205734433 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 5) && (a1428914468 == 10 && (((a954368445 == 8 &&  cf==1 ) && a2005069365 == 34) && a969893172 == 33)))) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a925870636 = 9;
    	a904637882 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a969893172 == 33 && (a2005069365 == 34 && (a1428914468 == 10 &&  cf==1 ))) && (input == 17)) && a954368445 == 8)) {
    	cf = 0;
    	a2016510333 = 36 ;
    	a88077474 = 34 ;
    	a2005069365 = 35 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm334(int input) {
    if((a2135613870 == 32 && ((a2005069365 == 34 && (( cf==1  && a1428914468 == 11) && (input == 2))) && a969893172 == 33))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a465336174 = 35 ;
    	a569036257 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1428914468 == 11 && (a2135613870 == 32 && ((input == 14) && ( cf==1  && a969893172 == 33)))) && a2005069365 == 34)) {
    	cf = 0;
    	a2016510333 = 36 ;
    	a2005069365 = 35 ;
    	a88077474 = 34 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm337(int input) {
    if((a2005069365 == 34 && ((a2135613870 == 35 && (a1428914468 == 11 && ( cf==1  && (input == 1)))) && a969893172 == 33))) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a27741386 = 32 ;
    	a928570136 = 34 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((a969893172 == 33 && (a1428914468 == 11 &&  cf==1 )) && a2135613870 == 35) && a2005069365 == 34) && (input == 11))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a747683138 = 34 ;
    	a2059681452 = 33 ;
    	a1428914468 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((input == 15) && ((a2135613870 == 35 &&  cf==1 ) && a2005069365 == 34)) && a969893172 == 33) && a1428914468 == 11)) {
    	cf = 0;
    	a969893172 = 34 ;
    	a714559100 = 6;
    	a1086754137 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm338(int input) {
    if(((input == 15) && ((a969893172 == 33 && (a2135613870 == 36 && ( cf==1  && a2005069365 == 34))) && a1428914468 == 11))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2135613870 == 36 && (((a969893172 == 33 && ((input == 19) &&  cf==1 )) && a1428914468 == 11) && a2005069365 == 34))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm339(int input) {
    if((a525429632 == 32 && (((((input == 8) &&  cf==1 ) && a2005069365 == 34) && a969893172 == 33) && a1428914468 == 12))) {
    	cf = 0;
    	a844311967 = 32 ;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a749536178 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm340(int input) {
    if((a969893172 == 33 && (a525429632 == 33 && ((a2005069365 == 34 && ( cf==1  && a1428914468 == 12)) && (input == 3))))) {
    	cf = 0;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a451941968 = 32 ;
    	a1052150692 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a969893172 == 33 && (((a1428914468 == 12 &&  cf==1 ) && a2005069365 == 34) && a525429632 == 33)) && (input == 6))) {
    	cf = 0;
    	a240738299 = 36 ;
    	a727645622 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 34 && (a1428914468 == 12 && (((input == 7) && ( cf==1  && a525429632 == 33)) && a969893172 == 33)))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a107446547 = 12;
    	a1682504076 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm341(int input) {
    if(((a2005069365 == 34 && ((( cf==1  && a525429632 == 34) && (input == 11)) && a969893172 == 33)) && a1428914468 == 12)) {
    	cf = 0;
    	a1775644016 = 11;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1566584718 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a1428914468 == 12 && ( cf==1  && a969893172 == 33)) && a525429632 == 34) && a2005069365 == 34) && (input == 16))) {
    	cf = 0;
    	a27741386 = 35 ;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a829511935 = 35 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm342(int input) {
    if((a969893172 == 33 && (a525429632 == 35 && (a2005069365 == 34 && (( cf==1  && a1428914468 == 12) && (input == 15)))))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 4;
    	a1549928701 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm343(int input) {
    if(((a2005069365 == 34 && (a969893172 == 33 && (( cf==1  && a525429632 == 36) && (input == 5)))) && a1428914468 == 12)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a347749795 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm344(int input) {
    if((((((a1428914468 == 13 &&  cf==1 ) && a2125137407 == 5) && (input == 2)) && a2005069365 == 34) && a969893172 == 33)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a844311967 = 34 ;
    	a1904774218 = 33 ;
    	a317927282 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2125137407 == 5 && ((a2005069365 == 34 && ((input == 13) &&  cf==1 )) && a969893172 == 33)) && a1428914468 == 13)) {
    	cf = 0;
    	a844311967 = 34 ;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a317927282 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a2125137407 == 5 && (( cf==1  && a969893172 == 33) && a2005069365 == 34)) && a1428914468 == 13) && (input == 15))) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a1960724031 = 36 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a2005069365 == 34 && ((a2125137407 == 5 &&  cf==1 ) && a1428914468 == 13)) && a969893172 == 33) && (input == 19))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 12;
    	a2005069365 = 36 ;
    	a1655731851 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm345(int input) {
    if((a969893172 == 33 && (a1428914468 == 13 && (((input == 2) && (a2125137407 == 6 &&  cf==1 )) && a2005069365 == 34)))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 34 ;
    	a349181387 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm346(int input) {
    if((a2125137407 == 7 && (a2005069365 == 34 && (((input == 5) && ( cf==1  && a1428914468 == 13)) && a969893172 == 33)))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 8;
    	a1505404504 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 34 && (a969893172 == 33 && ((input == 6) && (( cf==1  && a2125137407 == 7) && a1428914468 == 13))))) {
    	cf = 0;
    	a844311967 = 35 ;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a205734433 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 8) && (a969893172 == 33 && (( cf==1  && a1428914468 == 13) && a2005069365 == 34))) && a2125137407 == 7)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1129866701 = 8;
    	a2059681452 = 35 ;
    	a1505404504 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 11) && ((a2125137407 == 7 && (( cf==1  && a2005069365 == 34) && a1428914468 == 13)) && a969893172 == 33))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a1690193643 = 33 ;
    	a2005069365 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm347(int input) {
    if((((a2005069365 == 34 && (( cf==1  && a1428914468 == 13) && (input == 3))) && a969893172 == 33) && a2125137407 == 10)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1684674520 = 36 ;
    	a369539608 = 34 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm348(int input) {
    if(((a2125137407 == 11 && ((input == 7) && (a2005069365 == 34 && (a1428914468 == 13 &&  cf==1 )))) && a969893172 == 33)) {
    	cf = 0;
    	a240738299 = 33 ;
    	a1519100789 = 4;
    	a2005069365 = 35 ;
    	a201083786 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 13) && ((a2125137407 == 11 && ( cf==1  && a2005069365 == 34)) && a969893172 == 33)) && a1428914468 == 13)) {
    	cf = 0;
    	a650110038 = 33 ;
    	a969893172 = 32 ;
    	a1015737466 = 4; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm350(int input) {
    if(((a2005069365 == 34 && (a969893172 == 33 && (( cf==1  && a1428914468 == 14) && a1872268177 == 33))) && (input == 1))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a1498704550 = 35 ;
    	a2005069365 = 36 ;
    	a714559100 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((input == 6) && (a2005069365 == 34 &&  cf==1 )) && a1872268177 == 33) && a969893172 == 33) && a1428914468 == 14)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a369539608 = 34 ;
    	a1519100789 = 9;
    	a1958000800 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm351(int input) {
    if((a969893172 == 33 && ((input == 2) && (((a1872268177 == 34 &&  cf==1 ) && a1428914468 == 14) && a2005069365 == 34)))) {
    	cf = 0;
    	a1093326457 = 35 ;
    	a969893172 = 34 ;
    	a714559100 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 7) && (((a969893172 == 33 && (a2005069365 == 34 &&  cf==1 )) && a1872268177 == 34) && a1428914468 == 14))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 33 ;
    	a1015737466 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 14) && (a1428914468 == 14 && (a1872268177 == 34 && (( cf==1  && a2005069365 == 34) && a969893172 == 33))))) {
    	cf = 0;
    	a714559100 = 10;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a2125137407 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 15) && ((((a1872268177 == 34 &&  cf==1 ) && a1428914468 == 14) && a969893172 == 33) && a2005069365 == 34))) {
    	cf = 0;
    	a1243394452 = 8;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a529769874 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm352(int input) {
    if(((((a969893172 == 33 && ( cf==1  && a1872268177 == 35)) && (input == 4)) && a2005069365 == 34) && a1428914468 == 14)) {
    	cf = 0;
    	a714559100 = 10;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a2125137407 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 34 && ((a969893172 == 33 && ((input == 10) && (a1872268177 == 35 &&  cf==1 ))) && a1428914468 == 14))) {
    	cf = 0;
    	a569036257 = 4;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a1549928701 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1428914468 == 14 && ((( cf==1  && a969893172 == 33) && a1872268177 == 35) && (input == 15))) && a2005069365 == 34)) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a27741386 = 33 ;
    	a2005069365 = 32 ;
    	a706302795 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1428914468 == 14 && (a969893172 == 33 && (a1872268177 == 35 && ((input == 17) && ( cf==1  && a2005069365 == 34)))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a829511935 = 35 ;
    	a2059681452 = 35 ;
    	a1129866701 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm353(int input) {
    if(((input == 12) && ((a1872268177 == 36 && ((a969893172 == 33 &&  cf==1 ) && a2005069365 == 34)) && a1428914468 == 14))) {
    	cf = 0;
    	a747683138 = 32 ;
    	a2005069365 = 33 ;
    	a2059681452 = 33 ;
    	a2110599067 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm12(int input) {
    if((a1428914468 == 7 &&  cf==1 )) {
    	if((a976704484 == 4 &&  cf==1 )) {
    		calculate_outputm317(input);
    	} 
    	if((a976704484 == 5 &&  cf==1 )) {
    		calculate_outputm318(input);
    	} 
    	if((a976704484 == 8 &&  cf==1 )) {
    		calculate_outputm319(input);
    	} 
    	if(( cf==1  && a976704484 == 10)) {
    		calculate_outputm320(input);
    	} 
    } 
    if((a1428914468 == 8 &&  cf==1 )) {
    	if(( cf==1  && a1699038459 == 3)) {
    		calculate_outputm321(input);
    	} 
    	if((a1699038459 == 7 &&  cf==1 )) {
    		calculate_outputm322(input);
    	} 
    	if(( cf==1  && a1699038459 == 10)) {
    		calculate_outputm323(input);
    	} 
    } 
    if((a1428914468 == 9 &&  cf==1 )) {
    	if((a1610737594 == 35 &&  cf==1 )) {
    		calculate_outputm324(input);
    	} 
    	if(( cf==1  && a1610737594 == 36)) {
    		calculate_outputm325(input);
    	} 
    } 
    if((a1428914468 == 10 &&  cf==1 )) {
    	if((a954368445 == 1 &&  cf==1 )) {
    		calculate_outputm326(input);
    	} 
    	if(( cf==1  && a954368445 == 2)) {
    		calculate_outputm327(input);
    	} 
    	if(( cf==1  && a954368445 == 3)) {
    		calculate_outputm328(input);
    	} 
    	if((a954368445 == 4 &&  cf==1 )) {
    		calculate_outputm329(input);
    	} 
    	if(( cf==1  && a954368445 == 5)) {
    		calculate_outputm330(input);
    	} 
    	if(( cf==1  && a954368445 == 6)) {
    		calculate_outputm331(input);
    	} 
    	if((a954368445 == 7 &&  cf==1 )) {
    		calculate_outputm332(input);
    	} 
    	if((a954368445 == 8 &&  cf==1 )) {
    		calculate_outputm333(input);
    	} 
    } 
    if((a1428914468 == 11 &&  cf==1 )) {
    	if((a2135613870 == 32 &&  cf==1 )) {
    		calculate_outputm334(input);
    	} 
    	if(( cf==1  && a2135613870 == 35)) {
    		calculate_outputm337(input);
    	} 
    	if((a2135613870 == 36 &&  cf==1 )) {
    		calculate_outputm338(input);
    	} 
    } 
    if((a1428914468 == 12 &&  cf==1 )) {
    	if((a525429632 == 32 &&  cf==1 )) {
    		calculate_outputm339(input);
    	} 
    	if(( cf==1  && a525429632 == 33)) {
    		calculate_outputm340(input);
    	} 
    	if(( cf==1  && a525429632 == 34)) {
    		calculate_outputm341(input);
    	} 
    	if(( cf==1  && a525429632 == 35)) {
    		calculate_outputm342(input);
    	} 
    	if(( cf==1  && a525429632 == 36)) {
    		calculate_outputm343(input);
    	} 
    } 
    if(( cf==1  && a1428914468 == 13)) {
    	if(( cf==1  && a2125137407 == 5)) {
    		calculate_outputm344(input);
    	} 
    	if((a2125137407 == 6 &&  cf==1 )) {
    		calculate_outputm345(input);
    	} 
    	if((a2125137407 == 7 &&  cf==1 )) {
    		calculate_outputm346(input);
    	} 
    	if((a2125137407 == 10 &&  cf==1 )) {
    		calculate_outputm347(input);
    	} 
    	if((a2125137407 == 11 &&  cf==1 )) {
    		calculate_outputm348(input);
    	} 
    } 
    if((a1428914468 == 14 &&  cf==1 )) {
    	if((a1872268177 == 33 &&  cf==1 )) {
    		calculate_outputm350(input);
    	} 
    	if(( cf==1  && a1872268177 == 34)) {
    		calculate_outputm351(input);
    	} 
    	if((a1872268177 == 35 &&  cf==1 )) {
    		calculate_outputm352(input);
    	} 
    	if((a1872268177 == 36 &&  cf==1 )) {
    		calculate_outputm353(input);
    	} 
    } 
}
 void calculate_outputm354(int input) {
    if((a1079106761 == 8 && (a714559100 == 5 && (((a2005069365 == 34 &&  cf==1 ) && a969893172 == 34) && (input == 8))))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a206599328 = 34 ;
    	a714559100 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a714559100 == 5 && (( cf==1  && a969893172 == 34) && (input == 13))) && a2005069365 == 34) && a1079106761 == 8)) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a969893172 == 34 && (a1079106761 == 8 && ( cf==1  && a2005069365 == 34))) && (input == 14)) && a714559100 == 5)) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm356(int input) {
    if(((a1079106761 == 10 && ((( cf==1  && a714559100 == 5) && a969893172 == 34) && (input == 7))) && a2005069365 == 34)) {
    	cf = 0;
    	a1519100789 = 7;
    	a1243394452 = 4;
    	a2005069365 = 35 ;
    	a685344195 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((( cf==1  && a1079106761 == 10) && a969893172 == 34) && a2005069365 == 34) && a714559100 == 5) && (input == 10))) {
    	cf = 0;
    	a27741386 = 32 ;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a928570136 = 34 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a714559100 == 5 && (((a2005069365 == 34 && (a969893172 == 34 &&  cf==1 )) && a1079106761 == 10) && (input == 12)))) {
    	cf = 0;
    	a1519100789 = 5;
    	a2005069365 = 35 ;
    	a369539608 = 36 ;
    	a347749795 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((input == 13) && (a714559100 == 5 && (a969893172 == 34 && (a2005069365 == 34 &&  cf==1 )))) && a1079106761 == 10)) {
    	cf = 0;
    	a1388584441 = 34 ;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm357(int input) {
    if(((a714559100 == 5 && ((a2005069365 == 34 && ( cf==1  && a969893172 == 34)) && a1079106761 == 11)) && (input == 12))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a928570136 = 33 ;
    	a2005069365 = 36 ;
    	a107446547 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 34 && ((input == 20) && (a1079106761 == 11 && (a969893172 == 34 && (a714559100 == 5 &&  cf==1 )))))) {
    	cf = 0;
    	a1428914468 = 7;
    	a969893172 = 33 ;
    	a976704484 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm359(int input) {
    if((((input == 11) && (a714559100 == 6 && ((a2005069365 == 34 &&  cf==1 ) && a969893172 == 34))) && a1086754137 == 5)) {
    	cf = 0;
    	a925870636 = 10;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a666963702 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a969893172 == 34 && ((((input == 17) && (a714559100 == 6 &&  cf==1 )) && a2005069365 == 34) && a1086754137 == 5))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a1690193643 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1086754137 == 5 && ((a714559100 == 6 && (a969893172 == 34 && ((input == 20) &&  cf==1 ))) && a2005069365 == 34))) {
    	cf = 0;
    	a925870636 = 10;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a666963702 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm360(int input) {
    if((a1086754137 == 7 && ((((input == 5) && (a969893172 == 34 &&  cf==1 )) && a2005069365 == 34) && a714559100 == 6))) {
    	cf = 0;
    	a240738299 = 35 ;
    	a2005069365 = 35 ;
    	a1153134505 = 32 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1086754137 == 7 && ((input == 20) && (( cf==1  && a714559100 == 6) && a969893172 == 34))) && a2005069365 == 34)) {
    	cf = 0;
    	a1519100789 = 5;
    	a2005069365 = 35 ;
    	a369539608 = 33 ;
    	a1894975097 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm361(int input) {
    if(((a2005069365 == 34 && ((input == 2) && (a714559100 == 6 && (a1086754137 == 8 &&  cf==1 )))) && a969893172 == 34)) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 7) && (a714559100 == 6 && ((a2005069365 == 34 && (a969893172 == 34 &&  cf==1 )) && a1086754137 == 8)))) {
    	cf = 0;
    	a107446547 = 14;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a986008840 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm362(int input) {
    if((a1086754137 == 9 && (a2005069365 == 34 && (((a969893172 == 34 &&  cf==1 ) && (input == 10)) && a714559100 == 6)))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a369539608 = 32 ;
    	a1904774218 = 35 ;
    	a1124714117 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm363(int input) {
    if((a969893172 == 34 && (a2005069365 == 34 && ((( cf==1  && a1086754137 == 10) && (input == 1)) && a714559100 == 6)))) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a925870636 = 10;
    	a666963702 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1086754137 == 10 && (((a714559100 == 6 &&  cf==1 ) && a2005069365 == 34) && (input == 8))) && a969893172 == 34)) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 15) && (a969893172 == 34 && ((( cf==1  && a714559100 == 6) && a2005069365 == 34) && a1086754137 == 10)))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a569036257 = 6;
    	a1838812917 = 33 ;
    	a205734433 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm364(int input) {
    if((a2005069365 == 34 && (((input == 11) && ((a1086754137 == 11 &&  cf==1 ) && a714559100 == 6)) && a969893172 == 34))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a1325377146 = 36 ;
    	a569036257 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a1086754137 == 11 && (((input == 17) &&  cf==1 ) && a714559100 == 6)) && a2005069365 == 34) && a969893172 == 34)) {
    	cf = 0;
    	a1428914468 = 13;
    	a969893172 = 33 ;
    	a2125137407 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm365(int input) {
    if(((((( cf==1  && a1166586546 == 8) && a969893172 == 34) && a2005069365 == 34) && (input == 8)) && a714559100 == 7)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1153134505 = 33 ;
    	a1519100789 = 7;
    	a1243394452 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 34 && (a714559100 == 7 && (a969893172 == 34 && ((input == 16) && (a1166586546 == 8 &&  cf==1 )))))) {
    	cf = 0;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1153134505 = 33 ;
    	a1243394452 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm366(int input) {
    if(((((( cf==1  && (input == 5)) && a1166586546 == 10) && a2005069365 == 34) && a714559100 == 7) && a969893172 == 34)) {
    	cf = 0;
    	a2124036967 = 32 ;
    	a969893172 = 36 ;
    	a1194623510 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a969893172 == 34 && (((a2005069365 == 34 &&  cf==1 ) && a714559100 == 7) && a1166586546 == 10)) && (input == 13))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a369539608 = 34 ;
    	a1684674520 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 34 && (a1166586546 == 10 && (a969893172 == 34 && (a714559100 == 7 && ((input == 14) &&  cf==1 )))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm367(int input) {
    if(((input == 7) && (a714559100 == 7 && (a2005069365 == 34 && (a1166586546 == 11 && ( cf==1  && a969893172 == 34)))))) {
    	cf = 0;
    	a88077474 = 33 ;
    	a2005069365 = 35 ;
    	a928570136 = 33 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1166586546 == 11 && ((input == 10) && (a969893172 == 34 && ( cf==1  && a714559100 == 7)))) && a2005069365 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 4;
    	a240738299 = 34 ;
    	a1109056640 = 3; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a969893172 == 34 && (a2005069365 == 34 && (a1166586546 == 11 && ((a714559100 == 7 &&  cf==1 ) && (input == 11)))))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a815941786 = 32 ;
    	a107446547 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm368(int input) {
    if((((a1166586546 == 12 && (((input == 5) &&  cf==1 ) && a2005069365 == 34)) && a714559100 == 7) && a969893172 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a369539608 = 33 ;
    	a1958000800 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a714559100 == 7 && ((input == 14) && ((a2005069365 == 34 &&  cf==1 ) && a969893172 == 34))) && a1166586546 == 12)) {
    	cf = 0;
    	a1775644016 = 11;
    	a1838812917 = 36 ;
    	a2005069365 = 36 ;
    	a1566584718 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm369(int input) {
    if((a969893172 == 34 && (a2005069365 == 34 && (a714559100 == 7 && (( cf==1  && (input == 11)) && a1166586546 == 14))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a679327000 = 36 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a714559100 == 7 && ((a2005069365 == 34 &&  cf==1 ) && a969893172 == 34)) && (input == 16)) && a1166586546 == 14)) {
    	cf = 0;
    	a747683138 = 32 ;
    	a2059681452 = 33 ;
    	a2005069365 = 33 ;
    	a2110599067 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm370(int input) {
    if((a969893172 == 34 && ((input == 11) && ((( cf==1  && a714559100 == 7) && a2005069365 == 34) && a1166586546 == 15)))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a969893172 == 34 && (( cf==1  && a2005069365 == 34) && (input == 20))) && a1166586546 == 15) && a714559100 == 7)) {
    	cf = 0;
    	a1052150692 = 8;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1144659688 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm371(int input) {
    if((((a714559100 == 8 && (( cf==1  && a969893172 == 34) && a1093326457 == 32)) && (input == 4)) && a2005069365 == 34)) {
    	cf = 0;
    	a2002331280 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((input == 8) && (a1093326457 == 32 &&  cf==1 )) && a2005069365 == 34) && a969893172 == 34) && a714559100 == 8)) {
    	cf = 0;
    	a747683138 = 32 ;
    	a2059681452 = 33 ;
    	a2005069365 = 33 ;
    	a2110599067 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 34 && (a714559100 == 8 && (a1093326457 == 32 && ((a969893172 == 34 &&  cf==1 ) && (input == 19)))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 12;
    	a1682504076 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm372(int input) {
    if((a714559100 == 8 && (((( cf==1  && a2005069365 == 34) && a1093326457 == 33) && a969893172 == 34) && (input == 1)))) {
    	cf = 0;
    	a714559100 = 6;
    	a1086754137 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm373(int input) {
    if((((input == 4) && (a2005069365 == 34 && (( cf==1  && a969893172 == 34) && a1093326457 == 34))) && a714559100 == 8)) {
    	cf = 0;
    	a969893172 = 35 ;
    	a834910632 = 32 ;
    	a685667843 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm374(int input) {
    if((a714559100 == 8 && ((input == 4) && ((a1093326457 == 35 && ( cf==1  && a2005069365 == 34)) && a969893172 == 34)))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a569036257 = 4;
    	a2005069365 = 36 ;
    	a1549928701 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((input == 5) && (a2005069365 == 34 && (a969893172 == 34 &&  cf==1 ))) && a714559100 == 8) && a1093326457 == 35)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a569036257 = 4;
    	a1838812917 = 33 ;
    	a1549928701 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a969893172 == 34 && ((a714559100 == 8 && (a1093326457 == 35 &&  cf==1 )) && a2005069365 == 34)) && (input == 6))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1684687706 = 12;
    	a2059681452 = 34 ;
    	a1710271440 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a969893172 == 34 && ((input == 16) && (a1093326457 == 35 && (a2005069365 == 34 &&  cf==1 )))) && a714559100 == 8)) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1684687706 = 12;
    	a1710271440 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm375(int input) {
    if((((a2005069365 == 34 && (( cf==1  && a969893172 == 34) && a1093326457 == 36)) && a714559100 == 8) && (input == 3))) {
    	cf = 0;
    	a685667843 = 14;
    	a969893172 = 35 ;
    	a2138261183 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((input == 4) && (a714559100 == 8 && (a2005069365 == 34 &&  cf==1 ))) && a1093326457 == 36) && a969893172 == 34)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a1498704550 = 32 ;
    	a714559100 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 34 && (a714559100 == 8 && ((input == 14) && (a969893172 == 34 && (a1093326457 == 36 &&  cf==1 )))))) {
    	cf = 0;
    	a650110038 = 34 ;
    	a969893172 = 32 ;
    	a349181387 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 34 && (a714559100 == 8 && (((input == 16) &&  cf==1 ) && a969893172 == 34))) && a1093326457 == 36)) {
    	cf = 0;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a369539608 = 32 ;
    	a1958000800 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm376(int input) {
    if((a304497462 == 7 && (a714559100 == 9 && ((input == 2) && (( cf==1  && a969893172 == 34) && a2005069365 == 34))))) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a2005069365 = 32 ;
    	a369539608 = 36 ;
    	a1577567933 = 32 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 34 && (((a304497462 == 7 && ( cf==1  && a714559100 == 9)) && a969893172 == 34) && (input == 20)))) {
    	cf = 0;
    	a740799408 = 32 ;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1775644016 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm377(int input) {
    if((a714559100 == 9 && (a969893172 == 34 && ((( cf==1  && a304497462 == 9) && a2005069365 == 34) && (input == 1))))) {
    	cf = 0;
    	a1093326457 = 35 ;
    	a714559100 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a2005069365 == 34 && (a304497462 == 9 && ( cf==1  && a714559100 == 9))) && a969893172 == 34) && (input == 5))) {
    	cf = 0;
    	a1093326457 = 35 ;
    	a714559100 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a969893172 == 34 && (((( cf==1  && a714559100 == 9) && a304497462 == 9) && a2005069365 == 34) && (input == 8)))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a2135613870 = 34 ;
    	a107446547 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 20) && (((a2005069365 == 34 && ( cf==1  && a714559100 == 9)) && a969893172 == 34) && a304497462 == 9))) {
    	cf = 0;
    	a1519100789 = 9;
    	a1958000800 = 9;
    	a2005069365 = 35 ;
    	a1754726785 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm378(int input) {
    if((a304497462 == 10 && (a714559100 == 9 && ((input == 2) && ((a2005069365 == 34 &&  cf==1 ) && a969893172 == 34))))) {
    	cf = 0;
    	a569036257 = 10;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a920118831 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a714559100 == 9 && (a969893172 == 34 && (a2005069365 == 34 && ( cf==1  && a304497462 == 10)))) && (input == 3))) {
    	cf = 0;
    	a2002331280 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 15) && (((( cf==1  && a2005069365 == 34) && a304497462 == 10) && a969893172 == 34) && a714559100 == 9))) {
    	cf = 0;
    	a369539608 = 33 ;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a2077351330 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm379(int input) {
    if((a304497462 == 11 && (((input == 7) && ((a714559100 == 9 &&  cf==1 ) && a969893172 == 34)) && a2005069365 == 34))) {
    	cf = 0;
    	a714559100 = 7;
    	a1166586546 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm380(int input) {
    if((a1468138070 == 33 && (((input == 6) && (a969893172 == 34 && (a714559100 == 10 &&  cf==1 ))) && a2005069365 == 34))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1872268177 = 34 ;
    	a1958000800 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a714559100 == 10 && (a969893172 == 34 && ((a2005069365 == 34 && ( cf==1  && (input == 10))) && a1468138070 == 33)))) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a925870636 = 8;
    	a2005069365 = 32 ;
    	a1883016343 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a714559100 == 10 && ((a1468138070 == 33 && (a969893172 == 34 &&  cf==1 )) && a2005069365 == 34)) && (input == 19))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a27741386 = 36 ;
    	a792575314 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm381(int input) {
    if(((((( cf==1  && (input == 5)) && a1468138070 == 34) && a714559100 == 10) && a969893172 == 34) && a2005069365 == 34)) {
    	cf = 0;
    	a1428914468 = 10;
    	a969893172 = 33 ;
    	a954368445 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((input == 17) && (a714559100 == 10 && (a2005069365 == 34 && (a1468138070 == 34 &&  cf==1 )))) && a969893172 == 34)) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a2125137407 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm383(int input) {
    if((a714559100 == 11 && ((input == 3) && ((a2005069365 == 34 && ( cf==1  && a687007811 == 33)) && a969893172 == 34)))) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a687007811 == 33 && ((input == 8) && (a2005069365 == 34 && (a969893172 == 34 && (a714559100 == 11 &&  cf==1 )))))) {
    	cf = 0;
    	a1428914468 = 10;
    	a969893172 = 33 ;
    	a954368445 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm384(int input) {
    if(((a714559100 == 11 && ((a2005069365 == 34 && (a969893172 == 34 &&  cf==1 )) && (input == 3))) && a687007811 == 35)) {
    	cf = 0;
    	a650110038 = 36 ;
    	a969893172 = 32 ;
    	a221974990 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a969893172 == 34 && ((a2005069365 == 34 && ( cf==1  && a714559100 == 11)) && a687007811 == 35)) && (input == 7))) {
    	cf = 0;
    	a650110038 = 36 ;
    	a969893172 = 32 ;
    	a221974990 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a714559100 == 11 && ((((input == 11) &&  cf==1 ) && a2005069365 == 34) && a969893172 == 34)) && a687007811 == 35)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a240738299 = 35 ;
    	a1153134505 = 33 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm385(int input) {
    if(((a687007811 == 36 && (a969893172 == 34 && (((input == 7) &&  cf==1 ) && a714559100 == 11))) && a2005069365 == 34)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a369539608 = 36 ;
    	a1577567933 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a687007811 == 36 && (((a714559100 == 11 &&  cf==1 ) && (input == 14)) && a969893172 == 34)) && a2005069365 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 5;
    	a369539608 = 33 ;
    	a1894975097 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a714559100 == 11 && ((a2005069365 == 34 && ((input == 16) &&  cf==1 )) && a969893172 == 34)) && a687007811 == 36)) {
    	cf = 0;
    	a1519100789 = 9;
    	a1872268177 = 32 ;
    	a2005069365 = 35 ;
    	a1958000800 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a969893172 == 34 && (((( cf==1  && a714559100 == 11) && (input == 20)) && a687007811 == 36) && a2005069365 == 34))) {
    	cf = 0;
    	a1498704550 = 34 ;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a714559100 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm386(int input) {
    if((((((input == 2) && (a1116999236 == 10 &&  cf==1 )) && a714559100 == 12) && a2005069365 == 34) && a969893172 == 34)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1129866701 = 10;
    	a2059681452 = 35 ;
    	a596573336 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 10) && (a969893172 == 34 && (a2005069365 == 34 && ((a714559100 == 12 &&  cf==1 ) && a1116999236 == 10))))) {
    	cf = 0;
    	a925870636 = 8;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a1883016343 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a714559100 == 12 && (((a1116999236 == 10 &&  cf==1 ) && a2005069365 == 34) && a969893172 == 34)) && (input == 13))) {
    	cf = 0;
    	a1093326457 = 35 ;
    	a714559100 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((input == 15) && (a714559100 == 12 && (a1116999236 == 10 && ( cf==1  && a2005069365 == 34)))) && a969893172 == 34)) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 8;
    	a2005069365 = 35 ;
    	a1144659688 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm387(int input) {
    if((((a969893172 == 34 && (((input == 20) &&  cf==1 ) && a714559100 == 12)) && a2005069365 == 34) && a1116999236 == 11)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a747683138 = 33 ;
    	a2059681452 = 33 ;
    	a1682504076 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm388(int input) {
    if((a714559100 == 12 && (a969893172 == 34 && ((a1116999236 == 13 && ((input == 11) &&  cf==1 )) && a2005069365 == 34)))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1775644016 = 11;
    	a2005069365 = 36 ;
    	a1566584718 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a969893172 == 34 && ((( cf==1  && a714559100 == 12) && (input == 13)) && a1116999236 == 13)) && a2005069365 == 34)) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a369539608 = 33 ;
    	a2005069365 = 32 ;
    	a2077351330 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 34 && (((((input == 16) &&  cf==1 ) && a1116999236 == 13) && a969893172 == 34) && a714559100 == 12))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1146785657 = 32 ;
    	a2059681452 = 35 ;
    	a1129866701 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1116999236 == 13 && (a2005069365 == 34 && ((a969893172 == 34 && ((input == 17) &&  cf==1 )) && a714559100 == 12)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 6;
    	a604409338 = 35 ;
    	a1688003115 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm389(int input) {
    if((((input == 1) && (a714559100 == 12 && ((a969893172 == 34 &&  cf==1 ) && a1116999236 == 14))) && a2005069365 == 34)) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a1960724031 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((( cf==1  && a2005069365 == 34) && a969893172 == 34) && a1116999236 == 14) && (input == 13)) && a714559100 == 12)) {
    	cf = 0;
    	a1093326457 = 33 ;
    	a714559100 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a714559100 == 12 && (a1116999236 == 14 && (((input == 17) && (a2005069365 == 34 &&  cf==1 )) && a969893172 == 34)))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a1388584441 = 32 ;
    	a2005069365 = 33 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm390(int input) {
    if((a1116999236 == 16 && (((input == 6) && (( cf==1  && a714559100 == 12) && a969893172 == 34)) && a2005069365 == 34))) {
    	cf = 0;
    	a369539608 = 33 ;
    	a1519100789 = 5;
    	a2005069365 = 35 ;
    	a1894975097 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((input == 14) && ((a2005069365 == 34 &&  cf==1 ) && a714559100 == 12)) && a1116999236 == 16) && a969893172 == 34)) {
    	cf = 0;
    	a240738299 = 34 ;
    	a1519100789 = 4;
    	a2005069365 = 35 ;
    	a1109056640 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 34 && (((( cf==1  && (input == 20)) && a969893172 == 34) && a714559100 == 12) && a1116999236 == 16))) {
    	cf = 0;
    	a1204193075 = 35 ;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm13(int input) {
    if(( cf==1  && a714559100 == 5)) {
    	if(( cf==1  && a1079106761 == 8)) {
    		calculate_outputm354(input);
    	} 
    	if((a1079106761 == 10 &&  cf==1 )) {
    		calculate_outputm356(input);
    	} 
    	if(( cf==1  && a1079106761 == 11)) {
    		calculate_outputm357(input);
    	} 
    } 
    if(( cf==1  && a714559100 == 6)) {
    	if(( cf==1  && a1086754137 == 5)) {
    		calculate_outputm359(input);
    	} 
    	if((a1086754137 == 7 &&  cf==1 )) {
    		calculate_outputm360(input);
    	} 
    	if(( cf==1  && a1086754137 == 8)) {
    		calculate_outputm361(input);
    	} 
    	if((a1086754137 == 9 &&  cf==1 )) {
    		calculate_outputm362(input);
    	} 
    	if(( cf==1  && a1086754137 == 10)) {
    		calculate_outputm363(input);
    	} 
    	if((a1086754137 == 11 &&  cf==1 )) {
    		calculate_outputm364(input);
    	} 
    } 
    if(( cf==1  && a714559100 == 7)) {
    	if((a1166586546 == 8 &&  cf==1 )) {
    		calculate_outputm365(input);
    	} 
    	if((a1166586546 == 10 &&  cf==1 )) {
    		calculate_outputm366(input);
    	} 
    	if((a1166586546 == 11 &&  cf==1 )) {
    		calculate_outputm367(input);
    	} 
    	if((a1166586546 == 12 &&  cf==1 )) {
    		calculate_outputm368(input);
    	} 
    	if((a1166586546 == 14 &&  cf==1 )) {
    		calculate_outputm369(input);
    	} 
    	if(( cf==1  && a1166586546 == 15)) {
    		calculate_outputm370(input);
    	} 
    } 
    if(( cf==1  && a714559100 == 8)) {
    	if((a1093326457 == 32 &&  cf==1 )) {
    		calculate_outputm371(input);
    	} 
    	if((a1093326457 == 33 &&  cf==1 )) {
    		calculate_outputm372(input);
    	} 
    	if(( cf==1  && a1093326457 == 34)) {
    		calculate_outputm373(input);
    	} 
    	if((a1093326457 == 35 &&  cf==1 )) {
    		calculate_outputm374(input);
    	} 
    	if(( cf==1  && a1093326457 == 36)) {
    		calculate_outputm375(input);
    	} 
    } 
    if((a714559100 == 9 &&  cf==1 )) {
    	if(( cf==1  && a304497462 == 7)) {
    		calculate_outputm376(input);
    	} 
    	if(( cf==1  && a304497462 == 9)) {
    		calculate_outputm377(input);
    	} 
    	if(( cf==1  && a304497462 == 10)) {
    		calculate_outputm378(input);
    	} 
    	if(( cf==1  && a304497462 == 11)) {
    		calculate_outputm379(input);
    	} 
    } 
    if((a714559100 == 10 &&  cf==1 )) {
    	if((a1468138070 == 33 &&  cf==1 )) {
    		calculate_outputm380(input);
    	} 
    	if(( cf==1  && a1468138070 == 34)) {
    		calculate_outputm381(input);
    	} 
    } 
    if((a714559100 == 11 &&  cf==1 )) {
    	if((a687007811 == 33 &&  cf==1 )) {
    		calculate_outputm383(input);
    	} 
    	if((a687007811 == 35 &&  cf==1 )) {
    		calculate_outputm384(input);
    	} 
    	if((a687007811 == 36 &&  cf==1 )) {
    		calculate_outputm385(input);
    	} 
    } 
    if((a714559100 == 12 &&  cf==1 )) {
    	if((a1116999236 == 10 &&  cf==1 )) {
    		calculate_outputm386(input);
    	} 
    	if((a1116999236 == 11 &&  cf==1 )) {
    		calculate_outputm387(input);
    	} 
    	if(( cf==1  && a1116999236 == 13)) {
    		calculate_outputm388(input);
    	} 
    	if(( cf==1  && a1116999236 == 14)) {
    		calculate_outputm389(input);
    	} 
    	if((a1116999236 == 16 &&  cf==1 )) {
    		calculate_outputm390(input);
    	} 
    } 
}
 void calculate_outputm391(int input) {
    if((a969893172 == 35 && (a685667843 == 9 && (a1498704550 == 33 && (( cf==1  && a2005069365 == 34) && (input == 11)))))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a2135613870 = 34 ;
    	a107446547 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((input == 14) && ((a1498704550 == 33 &&  cf==1 ) && a685667843 == 9)) && a969893172 == 35) && a2005069365 == 34)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a369539608 = 34 ;
    	a1754726785 = 13; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm392(int input) {
    if((a969893172 == 35 && (a2005069365 == 34 && (((a1498704550 == 35 &&  cf==1 ) && (input == 1)) && a685667843 == 9)))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a1498704550 = 33 ;
    	a2005069365 = 36 ;
    	a714559100 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a685667843 == 9 && ((a1498704550 == 35 &&  cf==1 ) && a2005069365 == 34)) && (input == 4)) && a969893172 == 35)) {
    	cf = 0;
    	a1872268177 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 34 && (a685667843 == 9 && (a1498704550 == 35 && (a969893172 == 35 && ( cf==1  && (input == 7))))))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1684687706 = 12;
    	a1710271440 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a685667843 == 9 && ((( cf==1  && (input == 13)) && a2005069365 == 34) && a1498704550 == 35)) && a969893172 == 35)) {
    	cf = 0;
    	a650110038 = 33 ;
    	a969893172 = 32 ;
    	a1015737466 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm393(int input) {
    if((((((input == 3) && ( cf==1  && a685667843 == 9)) && a2005069365 == 34) && a1498704550 == 36) && a969893172 == 35)) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a1498704550 == 36 && ( cf==1  && a685667843 == 9)) && a2005069365 == 34) && a969893172 == 35) && (input == 5))) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1498704550 == 36 && (a2005069365 == 34 && (a685667843 == 9 && (((input == 20) &&  cf==1 ) && a969893172 == 35))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm394(int input) {
    if((a834910632 == 32 && ((input == 13) && ((a2005069365 == 34 && ( cf==1  && a685667843 == 10)) && a969893172 == 35)))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a1093326457 = 34 ;
    	a714559100 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm395(int input) {
    if((a834910632 == 34 && ((input == 1) && ((a969893172 == 35 && ( cf==1  && a2005069365 == 34)) && a685667843 == 10)))) {
    	cf = 0;
    	a2124036967 = 32 ;
    	a969893172 = 36 ;
    	a1194623510 = 33 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a834910632 == 34 && ((a685667843 == 10 &&  cf==1 ) && (input == 2))) && a2005069365 == 34) && a969893172 == 35)) {
    	cf = 0;
    	a925870636 = 8;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a1883016343 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm397(int input) {
    if((a834910632 == 36 && (a2005069365 == 34 && ((( cf==1  && a969893172 == 35) && a685667843 == 10) && (input == 4))))) {
    	cf = 0;
    	a1204193075 = 36 ;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a969893172 == 35 && ((((input == 10) && (a834910632 == 36 &&  cf==1 )) && a2005069365 == 34) && a685667843 == 10))) {
    	cf = 0;
    	a844311967 = 32 ;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a749536178 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((input == 11) && (((a834910632 == 36 &&  cf==1 ) && a685667843 == 10) && a969893172 == 35)) && a2005069365 == 34)) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a353267992 = 32 ;
    	a2005069365 = 36 ;
    	a107446547 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 15) && (a2005069365 == 34 && (a834910632 == 36 && (a685667843 == 10 && (a969893172 == 35 &&  cf==1 )))))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a1428914468 = 7;
    	a976704484 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm398(int input) {
    if(((a1639827725 == 33 && ((a685667843 == 11 && ( cf==1  && a2005069365 == 34)) && a969893172 == 35)) && (input == 3))) {
    	cf = 0;
    	a927953139 = 34 ;
    	a2005069365 = 36 ;
    	a1838812917 = 32 ;
    	a1857807887 = 34 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((a1639827725 == 33 && (a969893172 == 35 &&  cf==1 )) && a2005069365 == 34) && (input == 5)) && a685667843 == 11)) {
    	cf = 0;
    	a969893172 = 33 ;
    	a1428914468 = 7;
    	a976704484 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1639827725 == 33 && (a685667843 == 11 && ((input == 17) && ( cf==1  && a969893172 == 35)))) && a2005069365 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a246458106 = 36 ;
    	a1243394452 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm400(int input) {
    if((((((input == 1) && ( cf==1  && a2005069365 == 34)) && a969893172 == 35) && a685667843 == 12) && a67466277 == 32)) {
    	cf = 0;
    	a969893172 = 34 ;
    	a1468138070 = 33 ;
    	a714559100 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((( cf==1  && a685667843 == 12) && a67466277 == 32) && a969893172 == 35) && (input == 10)) && a2005069365 == 34)) {
    	cf = 0;
    	a1872268177 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a969893172 == 35 && ((((a685667843 == 12 &&  cf==1 ) && a67466277 == 32) && a2005069365 == 34) && (input == 17)))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a1872268177 = 36 ;
    	a1428914468 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm401(int input) {
    if((((a2005069365 == 34 && ((input == 13) && (a969893172 == 35 &&  cf==1 ))) && a685667843 == 12) && a67466277 == 33)) {
    	cf = 0;
    	a107446547 = 12;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a1682504076 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a969893172 == 35 && (a2005069365 == 34 && (a67466277 == 33 &&  cf==1 ))) && (input == 20)) && a685667843 == 12)) {
    	cf = 0;
    	a738616794 = 35 ;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1052150692 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm402(int input) {
    if((((a969893172 == 35 && (( cf==1  && a685667843 == 12) && (input == 6))) && a2005069365 == 34) && a67466277 == 35)) {
    	cf = 0;
    	a969893172 = 34 ;
    	a714559100 = 7;
    	a1166586546 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((a969893172 == 35 &&  cf==1 ) && a685667843 == 12) && a67466277 == 35) && a2005069365 == 34) && (input == 15))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 13;
    	a2005069365 = 33 ;
    	a1271566896 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a67466277 == 35 && (((( cf==1  && a685667843 == 12) && (input == 20)) && a2005069365 == 34) && a969893172 == 35))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a110820676 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 34 && (a67466277 == 35 && (a969893172 == 35 && ((a685667843 == 12 &&  cf==1 ) && (input == 5)))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a27741386 = 34 ;
    	a1009240021 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm403(int input) {
    if((a685667843 == 12 && (((a2005069365 == 34 && ( cf==1  && a969893172 == 35)) && (input == 6)) && a67466277 == 36))) {
    	cf = 0;
    	a714559100 = 7;
    	a969893172 = 34 ;
    	a1166586546 = 15; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a685667843 == 12 && ((a2005069365 == 34 && ((input == 13) &&  cf==1 )) && a67466277 == 36)) && a969893172 == 35)) {
    	cf = 0;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1204193075 = 34 ;
    	a1243394452 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a67466277 == 36 && (a969893172 == 35 && ((input == 15) && (a2005069365 == 34 && (a685667843 == 12 &&  cf==1 )))))) {
    	cf = 0;
    	a714559100 = 6;
    	a969893172 = 34 ;
    	a1086754137 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm404(int input) {
    if((a2005069365 == 34 && ((input == 7) && (a969893172 == 35 && ((a685667843 == 13 &&  cf==1 ) && a169540124 == 32))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm405(int input) {
    if(((a169540124 == 36 && (a685667843 == 13 && (a2005069365 == 34 && ( cf==1  && (input == 1))))) && a969893172 == 35)) {
    	cf = 0;
    	a925870636 = 10;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a666963702 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a969893172 == 35 && (((( cf==1  && (input == 10)) && a685667843 == 13) && a169540124 == 36) && a2005069365 == 34))) {
    	cf = 0;
    	a88077474 = 34 ;
    	a2005069365 = 35 ;
    	a2016510333 = 33 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((((input == 13) &&  cf==1 ) && a685667843 == 13) && a2005069365 == 34) && a169540124 == 36) && a969893172 == 35)) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a169540124 == 36 && ((((input == 15) &&  cf==1 ) && a2005069365 == 34) && a969893172 == 35)) && a685667843 == 13)) {
    	cf = 0;
    	a1904774218 = 36 ;
    	a928570136 = 33 ;
    	a2005069365 = 32 ;
    	a806083420 = 36 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm406(int input) {
    if((((a2005069365 == 34 && (a2138261183 == 5 && (a969893172 == 35 &&  cf==1 ))) && (input == 7)) && a685667843 == 14)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 12;
    	a1655731851 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a685667843 == 14 && (a2138261183 == 5 && (a2005069365 == 34 && (a969893172 == 35 &&  cf==1 )))) && (input == 19))) {
    	cf = 0;
    	a727645622 = 34 ;
    	a240738299 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm407(int input) {
    if(((a2138261183 == 6 && ((input == 6) && ((a2005069365 == 34 &&  cf==1 ) && a969893172 == 35))) && a685667843 == 14)) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1843210244 = 36 ;
    	a1684687706 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 34 && (((( cf==1  && a969893172 == 35) && a2138261183 == 6) && a685667843 == 14) && (input == 7)))) {
    	cf = 0;
    	a2124036967 = 36 ;
    	a969893172 = 36 ;
    	a524102808 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2138261183 == 6 && (((a969893172 == 35 &&  cf==1 ) && a685667843 == 14) && (input == 19))) && a2005069365 == 34)) {
    	cf = 0;
    	a169540124 = 36 ;
    	a685667843 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm408(int input) {
    if((((a685667843 == 14 && (( cf==1  && (input == 13)) && a2138261183 == 7)) && a969893172 == 35) && a2005069365 == 34)) {
    	cf = 0;
    	a928570136 = 36 ;
    	a2005069365 = 32 ;
    	a1904774218 = 36 ;
    	a998584754 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm409(int input) {
    if(((a685667843 == 14 && ((a2005069365 == 34 && ( cf==1  && (input == 4))) && a2138261183 == 8)) && a969893172 == 35)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 10;
    	a2125137407 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a2138261183 == 8 && (((a969893172 == 35 &&  cf==1 ) && (input == 8)) && a685667843 == 14)) && a2005069365 == 34)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a369539608 = 34 ;
    	a1754726785 = 15; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a685667843 == 14 && (((a2138261183 == 8 && (a2005069365 == 34 &&  cf==1 )) && (input == 15)) && a969893172 == 35))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 7;
    	a207863872 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm410(int input) {
    if(((a2005069365 == 34 && (((a685667843 == 14 &&  cf==1 ) && a969893172 == 35) && a2138261183 == 9)) && (input == 2))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 11;
    	a2005069365 = 33 ;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a2138261183 == 9 && (a969893172 == 35 && (a2005069365 == 34 && ((input == 14) &&  cf==1 )))) && a685667843 == 14)) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a685667843 == 14 && (a969893172 == 35 && (a2138261183 == 9 && ((a2005069365 == 34 &&  cf==1 ) && (input == 19)))))) {
    	cf = 0;
    	a2124036967 = 35 ;
    	a969893172 = 36 ;
    	a1942309322 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm411(int input) {
    if(((a685667843 == 14 && (a969893172 == 35 && (a2005069365 == 34 && (a2138261183 == 10 &&  cf==1 )))) && (input == 6))) {
    	cf = 0;
    	a1243394452 = 8;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a529769874 = 2; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a2005069365 == 34 && (((input == 13) && ( cf==1  && a2138261183 == 10)) && a969893172 == 35)) && a685667843 == 14)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a844311967 = 32 ;
    	a749536178 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm412(int input) {
    if((((a2005069365 == 34 && (((input == 6) &&  cf==1 ) && a2138261183 == 11)) && a685667843 == 14) && a969893172 == 35)) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1239184736 = 35 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((input == 11) && (a2138261183 == 11 && (a2005069365 == 34 && (a685667843 == 14 &&  cf==1 )))) && a969893172 == 35)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1239184736 = 35 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a969893172 == 35 && ((((a685667843 == 14 &&  cf==1 ) && (input == 15)) && a2005069365 == 34) && a2138261183 == 11))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2124036967 = 35 ;
    	a1942309322 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((((a969893172 == 35 &&  cf==1 ) && (input == 17)) && a685667843 == 14) && a2005069365 == 34) && a2138261183 == 11)) {
    	cf = 0;
    	a2124036967 = 35 ;
    	a969893172 = 36 ;
    	a1942309322 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm413(int input) {
    if((((input == 15) && ((a685667843 == 14 && (a2138261183 == 12 &&  cf==1 )) && a969893172 == 35)) && a2005069365 == 34)) {
    	cf = 0;
    	a2138261183 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm414(int input) {
    if(((input == 3) && (a685667843 == 15 && ((a1950243878 == 32 && ( cf==1  && a2005069365 == 34)) && a969893172 == 35)))) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a679327000 = 36 ;
    	a2005069365 = 33 ;
    	a1124714117 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm415(int input) {
    if((a969893172 == 35 && ((((input == 2) && (a1950243878 == 35 &&  cf==1 )) && a685667843 == 15) && a2005069365 == 34))) {
    	cf = 0;
    	a1498704550 = 36 ;
    	a685667843 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm416(int input) {
    if((((a969893172 == 35 && (a2005069365 == 34 && ((input == 3) &&  cf==1 ))) && a685667843 == 15) && a1950243878 == 36)) {
    	cf = 0;
    	a650110038 = 33 ;
    	a969893172 = 32 ;
    	a1015737466 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm417(int input) {
    if(((a367284938 == 32 && (a969893172 == 35 && (a685667843 == 16 && ( cf==1  && a2005069365 == 34)))) && (input == 2))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 34 ;
    	a2059681452 = 32 ;
    	a603781876 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a367284938 == 32 && ((a685667843 == 16 && (a2005069365 == 34 && (a969893172 == 35 &&  cf==1 ))) && (input == 3)))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a714559100 = 12;
    	a1655731851 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a685667843 == 16 && (a367284938 == 32 && ( cf==1  && (input == 8)))) && a2005069365 == 34) && a969893172 == 35)) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 36 ;
    	a221974990 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a685667843 == 16 && (((( cf==1  && (input == 12)) && a367284938 == 32) && a2005069365 == 34) && a969893172 == 35))) {
    	cf = 0;
    	a1239184736 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm418(int input) {
    if((((a2005069365 == 34 && ((input == 1) && (a685667843 == 16 &&  cf==1 ))) && a367284938 == 33) && a969893172 == 35)) {
    	cf = 0;
    	a679327000 = 34 ;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a603781876 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a685667843 == 16 && ((a2005069365 == 34 && (a969893172 == 35 && ( cf==1  && a367284938 == 33))) && (input == 3)))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2124036967 = 36 ;
    	a524102808 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a969893172 == 35 && ((a685667843 == 16 && (a2005069365 == 34 && ( cf==1  && a367284938 == 33))) && (input == 4)))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1775644016 = 11;
    	a1566584718 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm419(int input) {
    if((((input == 4) && ((a367284938 == 36 && (a685667843 == 16 &&  cf==1 )) && a969893172 == 35)) && a2005069365 == 34)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a925870636 = 13;
    	a759122969 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a2005069365 == 34 && (a367284938 == 36 && ( cf==1  && a969893172 == 35))) && (input == 14)) && a685667843 == 16)) {
    	cf = 0;
    	a679327000 = 34 ;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a603781876 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((input == 17) && (a685667843 == 16 &&  cf==1 )) && a2005069365 == 34) && a367284938 == 36) && a969893172 == 35)) {
    	cf = 0;
    	a569036257 = 10;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a920118831 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm14(int input) {
    if((a685667843 == 9 &&  cf==1 )) {
    	if(( cf==1  && a1498704550 == 33)) {
    		calculate_outputm391(input);
    	} 
    	if(( cf==1  && a1498704550 == 35)) {
    		calculate_outputm392(input);
    	} 
    	if(( cf==1  && a1498704550 == 36)) {
    		calculate_outputm393(input);
    	} 
    } 
    if(( cf==1  && a685667843 == 10)) {
    	if((a834910632 == 32 &&  cf==1 )) {
    		calculate_outputm394(input);
    	} 
    	if(( cf==1  && a834910632 == 34)) {
    		calculate_outputm395(input);
    	} 
    	if(( cf==1  && a834910632 == 36)) {
    		calculate_outputm397(input);
    	} 
    } 
    if((a685667843 == 11 &&  cf==1 )) {
    	if(( cf==1  && a1639827725 == 33)) {
    		calculate_outputm398(input);
    	} 
    } 
    if((a685667843 == 12 &&  cf==1 )) {
    	if(( cf==1  && a67466277 == 32)) {
    		calculate_outputm400(input);
    	} 
    	if((a67466277 == 33 &&  cf==1 )) {
    		calculate_outputm401(input);
    	} 
    	if((a67466277 == 35 &&  cf==1 )) {
    		calculate_outputm402(input);
    	} 
    	if(( cf==1  && a67466277 == 36)) {
    		calculate_outputm403(input);
    	} 
    } 
    if(( cf==1  && a685667843 == 13)) {
    	if((a169540124 == 32 &&  cf==1 )) {
    		calculate_outputm404(input);
    	} 
    	if((a169540124 == 36 &&  cf==1 )) {
    		calculate_outputm405(input);
    	} 
    } 
    if(( cf==1  && a685667843 == 14)) {
    	if(( cf==1  && a2138261183 == 5)) {
    		calculate_outputm406(input);
    	} 
    	if((a2138261183 == 6 &&  cf==1 )) {
    		calculate_outputm407(input);
    	} 
    	if(( cf==1  && a2138261183 == 7)) {
    		calculate_outputm408(input);
    	} 
    	if(( cf==1  && a2138261183 == 8)) {
    		calculate_outputm409(input);
    	} 
    	if((a2138261183 == 9 &&  cf==1 )) {
    		calculate_outputm410(input);
    	} 
    	if(( cf==1  && a2138261183 == 10)) {
    		calculate_outputm411(input);
    	} 
    	if(( cf==1  && a2138261183 == 11)) {
    		calculate_outputm412(input);
    	} 
    	if((a2138261183 == 12 &&  cf==1 )) {
    		calculate_outputm413(input);
    	} 
    } 
    if((a685667843 == 15 &&  cf==1 )) {
    	if((a1950243878 == 32 &&  cf==1 )) {
    		calculate_outputm414(input);
    	} 
    	if(( cf==1  && a1950243878 == 35)) {
    		calculate_outputm415(input);
    	} 
    	if((a1950243878 == 36 &&  cf==1 )) {
    		calculate_outputm416(input);
    	} 
    } 
    if(( cf==1  && a685667843 == 16)) {
    	if((a367284938 == 32 &&  cf==1 )) {
    		calculate_outputm417(input);
    	} 
    	if((a367284938 == 33 &&  cf==1 )) {
    		calculate_outputm418(input);
    	} 
    	if(( cf==1  && a367284938 == 36)) {
    		calculate_outputm419(input);
    	} 
    } 
}
 void calculate_outputm420(int input) {
    if(((a1194623510 == 32 && ((( cf==1  && a2005069365 == 34) && a969893172 == 36) && (input == 1))) && a2124036967 == 32)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1739072993 = 36 ;
    	a113788596 = 35 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a2005069365 == 34 && (a1194623510 == 32 && ((input == 5) &&  cf==1 ))) && a969893172 == 36) && a2124036967 == 32)) {
    	cf = 0;
    	a2124036967 = 36 ;
    	a524102808 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a969893172 == 36 && (((a2005069365 == 34 && ( cf==1  && (input == 11))) && a1194623510 == 32) && a2124036967 == 32))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 36 ;
    	a928570136 = 35 ;
    	a666963702 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm421(int input) {
    if((a2124036967 == 32 && (a1194623510 == 33 && (((input == 1) && (a2005069365 == 34 &&  cf==1 )) && a969893172 == 36)))) {
    	cf = 0;
    	a240738299 = 33 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4;
    	a201083786 = 15; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1194623510 == 33 && ((((a2005069365 == 34 &&  cf==1 ) && a2124036967 == 32) && (input == 17)) && a969893172 == 36))) {
    	cf = 0;
    	a240738299 = 33 ;
    	a1519100789 = 4;
    	a2005069365 = 35 ;
    	a201083786 = 15; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm422(int input) {
    if(((a2005069365 == 34 && (((a1194623510 == 34 &&  cf==1 ) && a969893172 == 36) && a2124036967 == 32)) && (input == 3))) {
    	cf = 0;
    	a240738299 = 32 ;
    	a2005069365 = 35 ;
    	a1756771009 = 36 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm423(int input) {
    if((a1194623510 == 35 && (((( cf==1  && (input == 7)) && a2124036967 == 32) && a969893172 == 36) && a2005069365 == 34))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1904774218 = 32 ;
    	a1838812917 = 33 ;
    	a569036257 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((a969893172 == 36 &&  cf==1 ) && a2005069365 == 34) && a1194623510 == 35) && (input == 15)) && a2124036967 == 32)) {
    	cf = 0;
    	a1428914468 = 8;
    	a969893172 = 33 ;
    	a1699038459 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm424(int input) {
    if((((a969893172 == 36 && ((a2005069365 == 34 &&  cf==1 ) && a1194623510 == 36)) && a2124036967 == 32) && (input == 17))) {
    	cf = 0;
    	a927953139 = 35 ;
    	a2005069365 = 36 ;
    	a1838812917 = 32 ;
    	a397915314 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm426(int input) {
    if((((a2005069365 == 34 && (a245033430 == 11 && ( cf==1  && a969893172 == 36))) && a2124036967 == 33) && (input == 8))) {
    	cf = 0;
    	a369539608 = 35 ;
    	a1307756142 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((( cf==1  && a2005069365 == 34) && a969893172 == 36) && a2124036967 == 33) && a245033430 == 11) && (input == 20))) {
    	cf = 0;
    	a1838812917 = 32 ;
    	a927953139 = 34 ;
    	a2005069365 = 36 ;
    	a1857807887 = 34 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm428(int input) {
    if((((((a969893172 == 36 &&  cf==1 ) && (input == 2)) && a2005069365 == 34) && a245033430 == 13) && a2124036967 == 33)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 8;
    	a2005069365 = 33 ;
    	a1505404504 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2124036967 == 33 && ((a245033430 == 13 && (a2005069365 == 34 && (a969893172 == 36 &&  cf==1 ))) && (input == 16)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1684674520 = 35 ;
    	a369539608 = 34 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a969893172 == 36 && (a245033430 == 13 && ( cf==1  && a2005069365 == 34))) && (input == 19)) && a2124036967 == 33)) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm429(int input) {
    if((a245033430 == 14 && ((((input == 13) && (a969893172 == 36 &&  cf==1 )) && a2005069365 == 34) && a2124036967 == 33))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a991719280 = 32 ;
    	a569036257 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a245033430 == 14 && ( cf==1  && (input == 19))) && a2124036967 == 33) && a2005069365 == 34) && a969893172 == 36)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a602507557 = 34 ;
    	a2059681452 = 34 ;
    	a1684687706 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2124036967 == 33 && (a245033430 == 14 && (a969893172 == 36 && ((a2005069365 == 34 &&  cf==1 ) && (input == 20)))))) {
    	cf = 0;
    	a928570136 = 35 ;
    	a2005069365 = 32 ;
    	a1904774218 = 36 ;
    	a666963702 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm431(int input) {
    if(((a2124036967 == 33 && (a245033430 == 16 && (a969893172 == 36 && (a2005069365 == 34 &&  cf==1 )))) && (input == 1))) {
    	cf = 0;
    	a1958000800 = 13;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a593874874 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a245033430 == 16 && (a2124036967 == 33 && (a969893172 == 36 && ( cf==1  && (input == 11))))) && a2005069365 == 34)) {
    	cf = 0;
    	a1775644016 = 11;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1566584718 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((( cf==1  && (input == 16)) && a969893172 == 36) && a245033430 == 16) && a2005069365 == 34) && a2124036967 == 33)) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 35 ;
    	a264802066 = 34 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm433(int input) {
    if(((a2124036967 == 34 && (((input == 2) && ( cf==1  && a969893172 == 36)) && a745730534 == 32)) && a2005069365 == 34)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 4;
    	a1549928701 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 15) && (((( cf==1  && a2124036967 == 34) && a745730534 == 32) && a969893172 == 36) && a2005069365 == 34))) {
    	cf = 0;
    	a815941786 = 35 ;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a107446547 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a745730534 == 32 && ((input == 16) && (a2005069365 == 34 && (a969893172 == 36 && (a2124036967 == 34 &&  cf==1 )))))) {
    	cf = 0;
    	a714559100 = 12;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a1655731851 = 4; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2124036967 == 34 && (((a745730534 == 32 && (a969893172 == 36 &&  cf==1 )) && a2005069365 == 34) && (input == 17)))) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm434(int input) {
    if((a745730534 == 33 && (a2124036967 == 34 && (a2005069365 == 34 && (a969893172 == 36 && ( cf==1  && (input == 6))))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 10;
    	a596573336 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2124036967 == 34 && (a2005069365 == 34 && ((( cf==1  && a745730534 == 33) && a969893172 == 36) && (input == 13))))) {
    	cf = 0;
    	a747683138 = 32 ;
    	a2005069365 = 33 ;
    	a2059681452 = 33 ;
    	a2110599067 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm435(int input) {
    if((a2124036967 == 34 && ((((a745730534 == 35 &&  cf==1 ) && (input == 14)) && a2005069365 == 34) && a969893172 == 36))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a353267992 = 34 ;
    	a1838812917 = 34 ;
    	a107446547 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm436(int input) {
    if(((a969893172 == 36 && ((input == 1) && (a2124036967 == 34 && ( cf==1  && a745730534 == 36)))) && a2005069365 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 12;
    	a798343693 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a969893172 == 36 && (((( cf==1  && a2005069365 == 34) && a2124036967 == 34) && (input == 4)) && a745730534 == 36))) {
    	cf = 0;
    	a240738299 = 36 ;
    	a727645622 = 34 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 5) && (((a969893172 == 36 && (a2005069365 == 34 &&  cf==1 )) && a745730534 == 36) && a2124036967 == 34))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1307756142 = 35 ;
    	a369539608 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 34 && ((a969893172 == 36 && ((input == 20) && ( cf==1  && a2124036967 == 34))) && a745730534 == 36))) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm437(int input) {
    if((a2124036967 == 35 && (a1942309322 == 32 && (a2005069365 == 34 && ((a969893172 == 36 &&  cf==1 ) && (input == 8)))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a451941968 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2124036967 == 35 && ((a2005069365 == 34 && (( cf==1  && a1942309322 == 32) && a969893172 == 36)) && (input == 11)))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1843210244 = 34 ;
    	a1684687706 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1942309322 == 32 && (a969893172 == 36 && (a2124036967 == 35 && (((input == 16) &&  cf==1 ) && a2005069365 == 34))))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 35 ;
    	a264802066 = 36 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2124036967 == 35 && ((input == 17) && ((( cf==1  && a969893172 == 36) && a1942309322 == 32) && a2005069365 == 34)))) {
    	cf = 0;
    	a650110038 = 36 ;
    	a969893172 = 32 ;
    	a221974990 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm438(int input) {
    if((a1942309322 == 34 && (a969893172 == 36 && (a2124036967 == 35 && ((input == 4) && ( cf==1  && a2005069365 == 34)))))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 11;
    	a2005069365 = 33 ;
    	a691578539 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((a2005069365 == 34 &&  cf==1 ) && a969893172 == 36) && a1942309322 == 34) && a2124036967 == 35) && (input == 8))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1775644016 = 6;
    	a2005069365 = 36 ;
    	a200393381 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((a2124036967 == 35 &&  cf==1 ) && a2005069365 == 34) && a1942309322 == 34) && (input == 16)) && a969893172 == 36)) {
    	cf = 0;
    	a1129866701 = 12;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a461439918 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm439(int input) {
    if((a1942309322 == 35 && ((input == 2) && (((a2005069365 == 34 &&  cf==1 ) && a969893172 == 36) && a2124036967 == 35)))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1843210244 = 33 ;
    	a1684687706 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 34 && (a1942309322 == 35 && ((((input == 12) &&  cf==1 ) && a969893172 == 36) && a2124036967 == 35)))) {
    	cf = 0;
    	a1519100789 = 9;
    	a1872268177 = 32 ;
    	a2005069365 = 35 ;
    	a1958000800 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a1942309322 == 35 && (a969893172 == 36 &&  cf==1 )) && a2124036967 == 35) && a2005069365 == 34) && (input == 16))) {
    	cf = 0;
    	a1428914468 = 7;
    	a969893172 = 33 ;
    	a976704484 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm440(int input) {
    if((a2005069365 == 34 && (((a2124036967 == 35 && ( cf==1  && a969893172 == 36)) && (input == 3)) && a1942309322 == 36))) {
    	cf = 0;
    	a650110038 = 36 ;
    	a969893172 = 32 ;
    	a221974990 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 8) && (((a969893172 == 36 && (a1942309322 == 36 &&  cf==1 )) && a2005069365 == 34) && a2124036967 == 35))) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 34 && ((a2124036967 == 35 && ((a969893172 == 36 &&  cf==1 ) && a1942309322 == 36)) && (input == 17)))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1239184736 = 35 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm441(int input) {
    if((a2005069365 == 34 && ((input == 11) && ((a969893172 == 36 && ( cf==1  && a524102808 == 6)) && a2124036967 == 36)))) {
    	cf = 0;
    	a569036257 = 10;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a920118831 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2124036967 == 36 && ((input == 16) && (a969893172 == 36 && (a2005069365 == 34 &&  cf==1 )))) && a524102808 == 6)) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a2005069365 = 32 ;
    	a369539608 = 32 ;
    	a1124714117 = 1; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm442(int input) {
    if(((input == 1) && (((( cf==1  && a524102808 == 7) && a2124036967 == 36) && a969893172 == 36) && a2005069365 == 34))) {
    	cf = 0;
    	a1085908735 = 34 ;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1052150692 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 11) && (a2124036967 == 36 && (( cf==1  && a524102808 == 7) && a2005069365 == 34))) && a969893172 == 36)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a969893172 == 36 && (a2124036967 == 36 && ((a2005069365 == 34 &&  cf==1 ) && a524102808 == 7))) && (input == 17))) {
    	cf = 0;
    	a969893172 = 35 ;
    	a367284938 = 33 ;
    	a685667843 = 16; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a2005069365 == 34 && (((a2124036967 == 36 &&  cf==1 ) && (input == 19)) && a524102808 == 7)) && a969893172 == 36)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1085908735 = 34 ;
    	a1519100789 = 2;
    	a1052150692 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm443(int input) {
    if(((((a2005069365 == 34 && ( cf==1  && a524102808 == 8)) && a969893172 == 36) && a2124036967 == 36) && (input == 16))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a107446547 = 13;
    	a2059681452 = 36 ;
    	a132648993 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm444(int input) {
    if((((a969893172 == 36 && (a524102808 == 9 && ((input == 10) &&  cf==1 ))) && a2005069365 == 34) && a2124036967 == 36)) {
    	cf = 0;
    	a1958000800 = 9;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1754726785 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm446(int input) {
    if(((((a524102808 == 11 && ((input == 4) &&  cf==1 )) && a969893172 == 36) && a2124036967 == 36) && a2005069365 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 4;
    	a240738299 = 34 ;
    	a1109056640 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2124036967 == 36 && (a524102808 == 11 && (a2005069365 == 34 && (( cf==1  && (input == 7)) && a969893172 == 36))))) {
    	cf = 0;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a928570136 = 32 ;
    	a836757480 = 34 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a969893172 == 36 && (((( cf==1  && a2005069365 == 34) && (input == 10)) && a2124036967 == 36) && a524102808 == 11))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1052150692 = 10;
    	a1519100789 = 2;
    	a662123779 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((a2124036967 == 36 && ( cf==1  && (input == 16))) && a969893172 == 36) && a2005069365 == 34) && a524102808 == 11)) {
    	cf = 0;
    	a714559100 = 9;
    	a969893172 = 34 ;
    	a304497462 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm447(int input) {
    if(((a2005069365 == 34 && (((a969893172 == 36 &&  cf==1 ) && a2124036967 == 36) && a524102808 == 12)) && (input == 11))) {
    	cf = 0;
    	a714559100 = 7;
    	a969893172 = 34 ;
    	a1166586546 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm15(int input) {
    if((a2124036967 == 32 &&  cf==1 )) {
    	if(( cf==1  && a1194623510 == 32)) {
    		calculate_outputm420(input);
    	} 
    	if(( cf==1  && a1194623510 == 33)) {
    		calculate_outputm421(input);
    	} 
    	if(( cf==1  && a1194623510 == 34)) {
    		calculate_outputm422(input);
    	} 
    	if((a1194623510 == 35 &&  cf==1 )) {
    		calculate_outputm423(input);
    	} 
    	if(( cf==1  && a1194623510 == 36)) {
    		calculate_outputm424(input);
    	} 
    } 
    if(( cf==1  && a2124036967 == 33)) {
    	if(( cf==1  && a245033430 == 11)) {
    		calculate_outputm426(input);
    	} 
    	if((a245033430 == 13 &&  cf==1 )) {
    		calculate_outputm428(input);
    	} 
    	if(( cf==1  && a245033430 == 14)) {
    		calculate_outputm429(input);
    	} 
    	if((a245033430 == 16 &&  cf==1 )) {
    		calculate_outputm431(input);
    	} 
    } 
    if((a2124036967 == 34 &&  cf==1 )) {
    	if((a745730534 == 32 &&  cf==1 )) {
    		calculate_outputm433(input);
    	} 
    	if((a745730534 == 33 &&  cf==1 )) {
    		calculate_outputm434(input);
    	} 
    	if((a745730534 == 35 &&  cf==1 )) {
    		calculate_outputm435(input);
    	} 
    	if(( cf==1  && a745730534 == 36)) {
    		calculate_outputm436(input);
    	} 
    } 
    if(( cf==1  && a2124036967 == 35)) {
    	if(( cf==1  && a1942309322 == 32)) {
    		calculate_outputm437(input);
    	} 
    	if((a1942309322 == 34 &&  cf==1 )) {
    		calculate_outputm438(input);
    	} 
    	if((a1942309322 == 35 &&  cf==1 )) {
    		calculate_outputm439(input);
    	} 
    	if(( cf==1  && a1942309322 == 36)) {
    		calculate_outputm440(input);
    	} 
    } 
    if(( cf==1  && a2124036967 == 36)) {
    	if(( cf==1  && a524102808 == 6)) {
    		calculate_outputm441(input);
    	} 
    	if((a524102808 == 7 &&  cf==1 )) {
    		calculate_outputm442(input);
    	} 
    	if(( cf==1  && a524102808 == 8)) {
    		calculate_outputm443(input);
    	} 
    	if((a524102808 == 9 &&  cf==1 )) {
    		calculate_outputm444(input);
    	} 
    	if((a524102808 == 11 &&  cf==1 )) {
    		calculate_outputm446(input);
    	} 
    	if((a524102808 == 12 &&  cf==1 )) {
    		calculate_outputm447(input);
    	} 
    } 
}
 void calculate_outputm448(int input) {
    if(((a2005069365 == 35 && (a1052150692 == 6 && ((a451941968 == 32 &&  cf==1 ) && a1519100789 == 2))) && (input == 2))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a925870636 = 9;
    	a904637882 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((a1052150692 == 6 &&  cf==1 ) && a2005069365 == 35) && (input == 12)) && a451941968 == 32) && a1519100789 == 2)) {
    	cf = 0;
    	a1519100789 = 3;
    	a88077474 = 35 ;
    	a534598694 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a451941968 == 32 && (a2005069365 == 35 && ((input == 15) && (( cf==1  && a1052150692 == 6) && a1519100789 == 2))))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a650110038 = 36 ;
    	a221974990 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 35 && ((( cf==1  && a1519100789 == 2) && a451941968 == 32) && (input == 20))) && a1052150692 == 6)) {
    	cf = 0;
    	a604409338 = 35 ;
    	a1519100789 = 6;
    	a1688003115 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm449(int input) {
    if(((a451941968 == 34 && (a1052150692 == 6 && ((input == 1) && ( cf==1  && a2005069365 == 35)))) && a1519100789 == 2)) {
    	cf = 0;
    	a1052150692 = 7;
    	a71813398 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 35 && (((( cf==1  && a451941968 == 34) && (input == 5)) && a1519100789 == 2) && a1052150692 == 6))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 32 ;
    	a927953139 = 34 ;
    	a1857807887 = 34 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm450(int input) {
    if((((input == 2) && (a1052150692 == 6 && (a451941968 == 35 && (a1519100789 == 2 &&  cf==1 )))) && a2005069365 == 35)) {
    	cf = 0;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a347749795 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1052150692 == 6 && ((a1519100789 == 2 && (a451941968 == 35 &&  cf==1 )) && a2005069365 == 35)) && (input == 8))) {
    	cf = 0;
    	a1519100789 = 8;
    	a113788596 = 36 ;
    	a772592654 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 35 && (((input == 13) && (a1519100789 == 2 &&  cf==1 )) && a1052150692 == 6)) && a451941968 == 35)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 14;
    	a2138261183 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm451(int input) {
    if((a1052150692 == 7 && ((((a2005069365 == 35 &&  cf==1 ) && (input == 1)) && a1519100789 == 2) && a71813398 == 3))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2005069365 == 35 && ((a71813398 == 3 && (a1052150692 == 7 &&  cf==1 )) && a1519100789 == 2)) && (input == 3))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm453(int input) {
    if(((((a1519100789 == 2 && ( cf==1  && (input == 1))) && a2005069365 == 35) && a71813398 == 8) && a1052150692 == 7)) {
    	cf = 0;
    	a369539608 = 33 ;
    	a1519100789 = 5;
    	a1894975097 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1519100789 == 2 && (a71813398 == 8 && ( cf==1  && a2005069365 == 35))) && a1052150692 == 7) && (input == 16))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a650110038 = 36 ;
    	a221974990 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 35 && ((input == 17) && (a1519100789 == 2 && ((a71813398 == 8 &&  cf==1 ) && a1052150692 == 7))))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a107446547 = 15;
    	a2005069365 = 36 ;
    	a275125637 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm454(int input) {
    if((a1052150692 == 7 && ((a1519100789 == 2 && (a71813398 == 9 && (a2005069365 == 35 &&  cf==1 ))) && (input == 4)))) {
    	cf = 0;
    	a1243394452 = 4;
    	a1519100789 = 7;
    	a685344195 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 11) && ((a1052150692 == 7 && ((a2005069365 == 35 &&  cf==1 ) && a71813398 == 9)) && a1519100789 == 2))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a928570136 = 33 ;
    	a107446547 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a71813398 == 9 && ((((a1519100789 == 2 &&  cf==1 ) && a2005069365 == 35) && a1052150692 == 7) && (input == 12)))) {
    	cf = 0;
    	a1958000800 = 12;
    	a1519100789 = 9;
    	a798343693 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm455(int input) {
    if(((((input == 2) && ((a1519100789 == 2 &&  cf==1 ) && a1052150692 == 8)) && a2005069365 == 35) && a1144659688 == 4)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 14;
    	a2138261183 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1052150692 == 8 && (((input == 6) && ( cf==1  && a2005069365 == 35)) && a1519100789 == 2)) && a1144659688 == 4)) {
    	cf = 0;
    	a925870636 = 13;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a759122969 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1144659688 == 4 && ((input == 12) && (((a2005069365 == 35 &&  cf==1 ) && a1519100789 == 2) && a1052150692 == 8)))) {
    	cf = 0;
    	a928570136 = 35 ;
    	a2005069365 = 32 ;
    	a1904774218 = 36 ;
    	a666963702 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm456(int input) {
    if((a1052150692 == 8 && ((input == 8) && ((a2005069365 == 35 && ( cf==1  && a1144659688 == 5)) && a1519100789 == 2)))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 12;
    	a1682504076 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1144659688 == 5 && ((a2005069365 == 35 &&  cf==1 ) && (input == 16))) && a1519100789 == 2) && a1052150692 == 8)) {
    	cf = 0;
    	a113788596 = 36 ;
    	a1519100789 = 8;
    	a772592654 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm457(int input) {
    if(((a1519100789 == 2 && ((input == 1) && (( cf==1  && a1052150692 == 8) && a1144659688 == 6))) && a2005069365 == 35)) {
    	cf = 0;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a347749795 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1144659688 == 6 && (a1052150692 == 8 && ((a2005069365 == 35 &&  cf==1 ) && (input == 5)))) && a1519100789 == 2)) {
    	cf = 0;
    	a650110038 = 33 ;
    	a2005069365 = 34 ;
    	a969893172 = 32 ;
    	a1015737466 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1519100789 == 2 && (((( cf==1  && a1052150692 == 8) && a1144659688 == 6) && a2005069365 == 35) && (input == 8)))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a714559100 = 7;
    	a1166586546 = 15; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm458(int input) {
    if((a1144659688 == 8 && (((a1519100789 == 2 && (a1052150692 == 8 &&  cf==1 )) && a2005069365 == 35) && (input == 2)))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2005069365 == 35 && (a1519100789 == 2 && (a1052150692 == 8 && (a1144659688 == 8 &&  cf==1 )))) && (input == 5))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a1144659688 == 8 && (a2005069365 == 35 && (a1519100789 == 2 &&  cf==1 ))) && a1052150692 == 8) && (input == 7))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a714559100 = 12;
    	a969893172 = 34 ;
    	a1116999236 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm459(int input) {
    if((a1519100789 == 2 && (a1144659688 == 10 && ((a2005069365 == 35 && ((input == 6) &&  cf==1 )) && a1052150692 == 8)))) {
    	cf = 0;
    	a714559100 = 6;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a1086754137 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1519100789 == 2 && (a1052150692 == 8 && (((input == 11) &&  cf==1 ) && a1144659688 == 10))) && a2005069365 == 35)) {
    	cf = 0;
    	a928570136 = 33 ;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a107446547 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1519100789 == 2 && ((input == 14) && (a1052150692 == 8 && (a1144659688 == 10 && (a2005069365 == 35 &&  cf==1 )))))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 10;
    	a596573336 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm460(int input) {
    if((a1519100789 == 2 && ((((a2005069365 == 35 &&  cf==1 ) && a1144659688 == 11) && (input == 14)) && a1052150692 == 8))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a369539608 = 36 ;
    	a1904774218 = 35 ;
    	a1577567933 = 35 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 35 && (a1052150692 == 8 && (a1144659688 == 11 && (( cf==1  && a1519100789 == 2) && (input == 19)))))) {
    	cf = 0;
    	a679327000 = 33 ;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a2065134388 = 16; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm461(int input) {
    if((a1519100789 == 2 && (a738616794 == 33 && ((a1052150692 == 9 && (a2005069365 == 35 &&  cf==1 )) && (input == 12))))) {
    	cf = 0;
    	a369539608 = 32 ;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a1124714117 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1052150692 == 9 && (a738616794 == 33 && ((( cf==1  && a2005069365 == 35) && (input == 13)) && a1519100789 == 2)))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 10;
    	a2125137407 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm462(int input) {
    if((a738616794 == 34 && ((a1519100789 == 2 && (( cf==1  && a2005069365 == 35) && (input == 6))) && a1052150692 == 9))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a1690193643 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 35 && ((a1519100789 == 2 && (((input == 8) &&  cf==1 ) && a738616794 == 34)) && a1052150692 == 9))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a2005069365 = 36 ;
    	a1739072993 = 33 ;
    	a1775644016 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm463(int input) {
    if((a1519100789 == 2 && ((input == 3) && (a2005069365 == 35 && (a738616794 == 35 && (a1052150692 == 9 &&  cf==1 )))))) {
    	cf = 0;
    	a650110038 = 35 ;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a264802066 = 34 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm464(int input) {
    if((a1052150692 == 10 && ((a662123779 == 7 && (( cf==1  && a1519100789 == 2) && a2005069365 == 35)) && (input == 10)))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a747683138 = 35 ;
    	a2059681452 = 33 ;
    	a1039723590 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 11) && ((((a1052150692 == 10 &&  cf==1 ) && a1519100789 == 2) && a2005069365 == 35) && a662123779 == 7))) {
    	cf = 0;
    	a1498704550 = 34 ;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm465(int input) {
    if((a662123779 == 8 && (((input == 1) && (a2005069365 == 35 && ( cf==1  && a1519100789 == 2))) && a1052150692 == 10))) {
    	cf = 0;
    	a569036257 = 4;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a1549928701 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1052150692 == 10 && ((((input == 13) && (a1519100789 == 2 &&  cf==1 )) && a2005069365 == 35) && a662123779 == 8))) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm466(int input) {
    if((a1519100789 == 2 && ((((a1052150692 == 10 &&  cf==1 ) && a662123779 == 9) && (input == 1)) && a2005069365 == 35))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 2) && (((( cf==1  && a1519100789 == 2) && a1052150692 == 10) && a2005069365 == 35) && a662123779 == 9))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a107446547 = 14;
    	a2005069365 = 33 ;
    	a986008840 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1519100789 == 2 && ( cf==1  && a662123779 == 9)) && a2005069365 == 35) && (input == 15)) && a1052150692 == 10)) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm468(int input) {
    if(((a1052150692 == 10 && (((a662123779 == 11 &&  cf==1 ) && a2005069365 == 35) && (input == 2))) && a1519100789 == 2)) {
    	cf = 0;
    	a1872268177 = 32 ;
    	a1519100789 = 9;
    	a1958000800 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a662123779 == 11 && ((((a2005069365 == 35 &&  cf==1 ) && a1052150692 == 10) && (input == 3)) && a1519100789 == 2))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a714559100 = 7;
    	a1166586546 = 15; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a1519100789 == 2 && ((a2005069365 == 35 &&  cf==1 ) && a662123779 == 11)) && (input == 12)) && a1052150692 == 10)) {
    	cf = 0;
    	a1129866701 = 8;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1505404504 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a2005069365 == 35 && (( cf==1  && (input == 19)) && a1519100789 == 2)) && a662123779 == 11) && a1052150692 == 10)) {
    	cf = 0;
    	a1307756142 = 35 ;
    	a369539608 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm469(int input) {
    if((a1052150692 == 11 && (a1519100789 == 2 && (a1089968358 == 6 && (a2005069365 == 35 && ((input == 2) &&  cf==1 )))))) {
    	cf = 0;
    	a650110038 = 35 ;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a264802066 = 34 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1089968358 == 6 && (((a1052150692 == 11 && ( cf==1  && a1519100789 == 2)) && a2005069365 == 35) && (input == 13)))) {
    	cf = 0;
    	a369539608 = 36 ;
    	a1519100789 = 9;
    	a1958000800 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1089968358 == 6 && (((a1519100789 == 2 && ( cf==1  && (input == 20))) && a1052150692 == 11) && a2005069365 == 35))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1388584441 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm470(int input) {
    if(((a1052150692 == 11 && ((( cf==1  && a1089968358 == 7) && a1519100789 == 2) && (input == 7))) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a27741386 = 36 ;
    	a1904774218 = 32 ;
    	a792575314 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm471(int input) {
    if(((input == 11) && (a1519100789 == 2 && (a1052150692 == 11 && (a2005069365 == 35 && ( cf==1  && a1089968358 == 8)))))) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a679327000 = 32 ;
    	a2005069365 = 33 ;
    	a103910758 = 33 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1052150692 == 11 && (a1089968358 == 8 && (a2005069365 == 35 && ((a1519100789 == 2 &&  cf==1 ) && (input == 12)))))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1093326457 = 35 ;
    	a714559100 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1052150692 == 11 && ((a1519100789 == 2 && (((input == 14) &&  cf==1 ) && a2005069365 == 35)) && a1089968358 == 8))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a2059681452 = 35 ;
    	a1838812917 = 34 ;
    	a107446547 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm472(int input) {
    if(((input == 1) && (a1052150692 == 11 && (a1519100789 == 2 && ((a2005069365 == 35 &&  cf==1 ) && a1089968358 == 10))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1684687706 = 9;
    	a2059681452 = 34 ;
    	a892217980 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm473(int input) {
    if((((a1957279511 == 1 && ((input == 6) && (a1052150692 == 12 &&  cf==1 ))) && a2005069365 == 35) && a1519100789 == 2)) {
    	cf = 0;
    	a714559100 = 7;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a1166586546 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1052150692 == 12 && (a1957279511 == 1 && ((input == 17) && (a1519100789 == 2 && ( cf==1  && a2005069365 == 35)))))) {
    	cf = 0;
    	a1052150692 = 8;
    	a1144659688 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm474(int input) {
    if(((input == 3) && (((a2005069365 == 35 && (a1052150692 == 12 &&  cf==1 )) && a1519100789 == 2) && a1957279511 == 3))) {
    	cf = 0;
    	a367284938 = 32 ;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 16; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 6) && (((a1957279511 == 3 && ( cf==1  && a1519100789 == 2)) && a2005069365 == 35) && a1052150692 == 12))) {
    	cf = 0;
    	a714559100 = 12;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a1655731851 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm475(int input) {
    if(((a2005069365 == 35 && (a1519100789 == 2 && ((input == 2) && ( cf==1  && a1957279511 == 4)))) && a1052150692 == 12)) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 35 ;
    	a2005069365 = 34 ;
    	a264802066 = 34 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1957279511 == 4 && (a1052150692 == 12 && ((((input == 13) &&  cf==1 ) && a2005069365 == 35) && a1519100789 == 2)))) {
    	cf = 0;
    	a240738299 = 34 ;
    	a1519100789 = 4;
    	a1109056640 = 1; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1957279511 == 4 && ((a2005069365 == 35 && (( cf==1  && (input == 14)) && a1519100789 == 2)) && a1052150692 == 12))) {
    	cf = 0;
    	a491478835 = 32 ;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm476(int input) {
    if((a1052150692 == 12 && ((a1519100789 == 2 && (a1957279511 == 6 && ( cf==1  && (input == 12)))) && a2005069365 == 35))) {
    	cf = 0;
    	a1904774218 = 36 ;
    	a928570136 = 33 ;
    	a2005069365 = 32 ;
    	a806083420 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm477(int input) {
    if(((((( cf==1  && (input == 14)) && a2005069365 == 35) && a1957279511 == 8) && a1519100789 == 2) && a1052150692 == 12)) {
    	cf = 0;
    	a569036257 = 6;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a205734433 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 35 && (((input == 16) && ( cf==1  && a1052150692 == 12)) && a1519100789 == 2)) && a1957279511 == 8)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 12;
    	a1682504076 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((( cf==1  && (input == 17)) && a1052150692 == 12) && a1519100789 == 2) && a1957279511 == 8) && a2005069365 == 35)) {
    	cf = 0;
    	a844311967 = 33 ;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a1380627758 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm478(int input) {
    if((a2005069365 == 35 && (a1085908735 == 32 && ((a1052150692 == 13 && (a1519100789 == 2 &&  cf==1 )) && (input == 16))))) {
    	cf = 0;
    	a113788596 = 34 ;
    	a1519100789 = 8;
    	a1688003115 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1085908735 == 32 && (((a1052150692 == 13 &&  cf==1 ) && (input == 19)) && a2005069365 == 35)) && a1519100789 == 2)) {
    	cf = 0;
    	a1052150692 = 7;
    	a71813398 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm479(int input) {
    if((a1052150692 == 13 && ((a2005069365 == 35 && (a1519100789 == 2 && (a1085908735 == 34 &&  cf==1 ))) && (input == 5)))) {
    	cf = 0;
    	a1052150692 = 8;
    	a1144659688 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1519100789 == 2 && (a2005069365 == 35 && (((a1085908735 == 34 &&  cf==1 ) && a1052150692 == 13) && (input == 16))))) {
    	cf = 0;
    	a1146785657 = 34 ;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((((a1052150692 == 13 &&  cf==1 ) && a2005069365 == 35) && a1519100789 == 2) && (input == 20)) && a1085908735 == 34)) {
    	cf = 0;
    	a367284938 = 33 ;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 16; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm480(int input) {
    if((a1519100789 == 2 && ((a2005069365 == 35 && (a1085908735 == 36 && ( cf==1  && (input == 5)))) && a1052150692 == 13))) {
    	cf = 0;
    	a1052150692 = 10;
    	a662123779 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 35 && ((a1519100789 == 2 && (( cf==1  && (input == 8)) && a1052150692 == 13)) && a1085908735 == 36))) {
    	cf = 0;
    	a1388584441 = 34 ;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((a1085908735 == 36 &&  cf==1 ) && a1052150692 == 13) && a2005069365 == 35) && a1519100789 == 2) && (input == 10))) {
    	cf = 0;
    	a604409338 = 35 ;
    	a369539608 = 32 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 20) && (a1085908735 == 36 && (((a1519100789 == 2 &&  cf==1 ) && a1052150692 == 13) && a2005069365 == 35)))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 10;
    	a954368445 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm16(int input) {
    if(( cf==1  && a1052150692 == 6)) {
    	if((a451941968 == 32 &&  cf==1 )) {
    		calculate_outputm448(input);
    	} 
    	if((a451941968 == 34 &&  cf==1 )) {
    		calculate_outputm449(input);
    	} 
    	if(( cf==1  && a451941968 == 35)) {
    		calculate_outputm450(input);
    	} 
    } 
    if(( cf==1  && a1052150692 == 7)) {
    	if(( cf==1  && a71813398 == 3)) {
    		calculate_outputm451(input);
    	} 
    	if(( cf==1  && a71813398 == 8)) {
    		calculate_outputm453(input);
    	} 
    	if(( cf==1  && a71813398 == 9)) {
    		calculate_outputm454(input);
    	} 
    } 
    if((a1052150692 == 8 &&  cf==1 )) {
    	if((a1144659688 == 4 &&  cf==1 )) {
    		calculate_outputm455(input);
    	} 
    	if(( cf==1  && a1144659688 == 5)) {
    		calculate_outputm456(input);
    	} 
    	if(( cf==1  && a1144659688 == 6)) {
    		calculate_outputm457(input);
    	} 
    	if((a1144659688 == 8 &&  cf==1 )) {
    		calculate_outputm458(input);
    	} 
    	if(( cf==1  && a1144659688 == 10)) {
    		calculate_outputm459(input);
    	} 
    	if(( cf==1  && a1144659688 == 11)) {
    		calculate_outputm460(input);
    	} 
    } 
    if(( cf==1  && a1052150692 == 9)) {
    	if((a738616794 == 33 &&  cf==1 )) {
    		calculate_outputm461(input);
    	} 
    	if(( cf==1  && a738616794 == 34)) {
    		calculate_outputm462(input);
    	} 
    	if(( cf==1  && a738616794 == 35)) {
    		calculate_outputm463(input);
    	} 
    } 
    if(( cf==1  && a1052150692 == 10)) {
    	if((a662123779 == 7 &&  cf==1 )) {
    		calculate_outputm464(input);
    	} 
    	if((a662123779 == 8 &&  cf==1 )) {
    		calculate_outputm465(input);
    	} 
    	if(( cf==1  && a662123779 == 9)) {
    		calculate_outputm466(input);
    	} 
    	if(( cf==1  && a662123779 == 11)) {
    		calculate_outputm468(input);
    	} 
    } 
    if((a1052150692 == 11 &&  cf==1 )) {
    	if((a1089968358 == 6 &&  cf==1 )) {
    		calculate_outputm469(input);
    	} 
    	if((a1089968358 == 7 &&  cf==1 )) {
    		calculate_outputm470(input);
    	} 
    	if((a1089968358 == 8 &&  cf==1 )) {
    		calculate_outputm471(input);
    	} 
    	if(( cf==1  && a1089968358 == 10)) {
    		calculate_outputm472(input);
    	} 
    } 
    if((a1052150692 == 12 &&  cf==1 )) {
    	if((a1957279511 == 1 &&  cf==1 )) {
    		calculate_outputm473(input);
    	} 
    	if((a1957279511 == 3 &&  cf==1 )) {
    		calculate_outputm474(input);
    	} 
    	if(( cf==1  && a1957279511 == 4)) {
    		calculate_outputm475(input);
    	} 
    	if(( cf==1  && a1957279511 == 6)) {
    		calculate_outputm476(input);
    	} 
    	if((a1957279511 == 8 &&  cf==1 )) {
    		calculate_outputm477(input);
    	} 
    } 
    if((a1052150692 == 13 &&  cf==1 )) {
    	if((a1085908735 == 32 &&  cf==1 )) {
    		calculate_outputm478(input);
    	} 
    	if((a1085908735 == 34 &&  cf==1 )) {
    		calculate_outputm479(input);
    	} 
    	if((a1085908735 == 36 &&  cf==1 )) {
    		calculate_outputm480(input);
    	} 
    } 
}
 void calculate_outputm481(int input) {
    if(((input == 17) && (a2005069365 == 35 && (a88077474 == 32 && ((a1519100789 == 3 &&  cf==1 ) && a1904774218 == 32))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a369539608 = 33 ;
    	a1904774218 = 35 ;
    	a2077351330 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1519100789 == 3 && (a1904774218 == 32 &&  cf==1 )) && (input == 20)) && a2005069365 == 35) && a88077474 == 32)) {
    	cf = 0;
    	a369539608 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm483(int input) {
    if(((input == 2) && ((a2005069365 == 35 && (a928570136 == 32 && ( cf==1  && a1519100789 == 3))) && a88077474 == 33))) {
    	cf = 0;
    	a369539608 = 33 ;
    	a1519100789 = 5;
    	a1894975097 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((input == 8) && (a928570136 == 32 && ( cf==1  && a1519100789 == 3))) && a2005069365 == 35) && a88077474 == 33)) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1492184786 = 35 ;
    	a2005069365 = 36 ;
    	a1775644016 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1519100789 == 3 && (a2005069365 == 35 && ((input == 14) &&  cf==1 ))) && a88077474 == 33) && a928570136 == 32)) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a2124036967 = 36 ;
    	a524102808 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1519100789 == 3 && ((input == 16) && (((a928570136 == 32 &&  cf==1 ) && a88077474 == 33) && a2005069365 == 35)))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 34 ;
    	a2005069365 = 34 ;
    	a349181387 = 1; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((input == 19) && (a2005069365 == 35 && (a928570136 == 32 &&  cf==1 ))) && a88077474 == 33) && a1519100789 == 3)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a369539608 = 33 ;
    	a1904774218 = 35 ;
    	a2077351330 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm484(int input) {
    if((((input == 3) && (a2005069365 == 35 && (( cf==1  && a928570136 == 33) && a1519100789 == 3))) && a88077474 == 33)) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a1684687706 = 11;
    	a2005069365 = 33 ;
    	a18979981 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a928570136 == 33 && (((( cf==1  && a2005069365 == 35) && a88077474 == 33) && (input == 6)) && a1519100789 == 3))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 10;
    	a596573336 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a88077474 == 33 && (((input == 12) && (a2005069365 == 35 && (a928570136 == 33 &&  cf==1 ))) && a1519100789 == 3))) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a679327000 = 34 ;
    	a603781876 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a928570136 == 33 && (((a2005069365 == 35 &&  cf==1 ) && a88077474 == 33) && a1519100789 == 3)) && (input == 14))) {
    	cf = 0;
    	a1519100789 = 8;
    	a113788596 = 36 ;
    	a772592654 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm485(int input) {
    if((a1519100789 == 3 && (a2005069365 == 35 && (a928570136 == 34 && (a88077474 == 33 && ( cf==1  && (input == 1))))))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 35 ;
    	a2005069365 = 34 ;
    	a264802066 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 35 && ((input == 3) && ((a1519100789 == 3 && ( cf==1  && a88077474 == 33)) && a928570136 == 34)))) {
    	cf = 0;
    	a1052150692 = 7;
    	a1519100789 = 2;
    	a71813398 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1519100789 == 3 && (a88077474 == 33 && (( cf==1  && a928570136 == 34) && a2005069365 == 35))) && (input == 10))) {
    	cf = 0;
    	a1519100789 = 7;
    	a1243394452 = 4;
    	a685344195 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm486(int input) {
    if((a928570136 == 36 && (((input == 14) && (a2005069365 == 35 && (a88077474 == 33 &&  cf==1 ))) && a1519100789 == 3))) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a2005069365 = 32 ;
    	a369539608 = 32 ;
    	a1124714117 = 1; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm487(int input) {
    if((((((input == 5) && (a2005069365 == 35 &&  cf==1 )) && a2016510333 == 32) && a1519100789 == 3) && a88077474 == 34)) {
    	cf = 0;
    	a1519100789 = 9;
    	a2002331280 = 35 ;
    	a1958000800 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 35 && (a88077474 == 34 && ((input == 14) && (a2016510333 == 32 && ( cf==1  && a1519100789 == 3)))))) {
    	cf = 0;
    	a369539608 = 34 ;
    	a1684674520 = 36 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm488(int input) {
    if(((input == 5) && (a88077474 == 34 && ((a1519100789 == 3 && (a2005069365 == 35 &&  cf==1 )) && a2016510333 == 33)))) {
    	cf = 0;
    	a1519100789 = 9;
    	a2002331280 = 33 ;
    	a1958000800 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a88077474 == 34 && ((a2005069365 == 35 && (a1519100789 == 3 &&  cf==1 )) && (input == 8))) && a2016510333 == 33)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 10;
    	a954368445 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 17) && ((a2005069365 == 35 && (a2016510333 == 33 && ( cf==1  && a1519100789 == 3))) && a88077474 == 34))) {
    	cf = 0;
    	a169540124 = 36 ;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((a1519100789 == 3 && ((input == 19) &&  cf==1 )) && a2005069365 == 35) && a88077474 == 34) && a2016510333 == 33)) {
    	cf = 0;
    	a844311967 = 35 ;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a205734433 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm489(int input) {
    if((a1519100789 == 3 && (((a88077474 == 34 && ( cf==1  && (input == 5))) && a2016510333 == 36) && a2005069365 == 35))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm490(int input) {
    if(((a534598694 == 6 && (a88077474 == 35 && (a1519100789 == 3 && (a2005069365 == 35 &&  cf==1 )))) && (input == 13))) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a1960724031 = 34 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 35 && ((((a88077474 == 35 &&  cf==1 ) && a1519100789 == 3) && (input == 19)) && a534598694 == 6))) {
    	cf = 0;
    	a714559100 = 10;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a2125137407 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1519100789 == 3 && (((input == 16) && (( cf==1  && a2005069365 == 35) && a534598694 == 6)) && a88077474 == 35))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 11;
    	a18979981 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm491(int input) {
    if((((a2005069365 == 35 && (a88077474 == 35 && ( cf==1  && (input == 4)))) && a534598694 == 7) && a1519100789 == 3)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a569036257 = 4;
    	a1549928701 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 35 && ((a1519100789 == 3 && (((input == 16) &&  cf==1 ) && a534598694 == 7)) && a88077474 == 35))) {
    	cf = 0;
    	a451941968 = 32 ;
    	a1519100789 = 2;
    	a1052150692 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm492(int input) {
    if((a88077474 == 35 && (((a1519100789 == 3 && ( cf==1  && a534598694 == 10)) && a2005069365 == 35) && (input == 3)))) {
    	cf = 0;
    	a1958000800 = 13;
    	a1519100789 = 9;
    	a593874874 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a534598694 == 10 && ((input == 17) &&  cf==1 )) && a2005069365 == 35) && a1519100789 == 3) && a88077474 == 35)) {
    	cf = 0;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a1428914468 = 13;
    	a2125137407 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm493(int input) {
    if((a2005069365 == 35 && ((a88077474 == 35 && (( cf==1  && (input == 2)) && a534598694 == 12)) && a1519100789 == 3))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1129866701 = 11;
    	a2059681452 = 35 ;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1519100789 == 3 && (((input == 7) && ( cf==1  && a88077474 == 35)) && a534598694 == 12)) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a534598694 == 12 && ((a88077474 == 35 && ( cf==1  && a1519100789 == 3)) && (input == 8))) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a1690193643 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a88077474 == 35 && ((((input == 10) && (a2005069365 == 35 &&  cf==1 )) && a1519100789 == 3) && a534598694 == 12))) {
    	cf = 0;
    	a747683138 = 36 ;
    	a2005069365 = 33 ;
    	a2059681452 = 33 ;
    	a1172911487 = 32 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a534598694 == 12 && (a2005069365 == 35 && ((a1519100789 == 3 && (a88077474 == 35 &&  cf==1 )) && (input == 4))))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 10;
    	a2005069365 = 36 ;
    	a2125137407 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm494(int input) {
    if((a744476156 == 32 && (a2005069365 == 35 && (a1519100789 == 3 && ((input == 17) && (a88077474 == 36 &&  cf==1 )))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a747683138 = 34 ;
    	a2059681452 = 33 ;
    	a1428914468 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a744476156 == 32 && (a1519100789 == 3 && ((input == 19) && (a88077474 == 36 &&  cf==1 )))) && a2005069365 == 35)) {
    	cf = 0;
    	a679327000 = 36 ;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a1124714117 = 1; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm495(int input) {
    if((a2005069365 == 35 && (((input == 3) && (a744476156 == 33 && (a1519100789 == 3 &&  cf==1 ))) && a88077474 == 36))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a27741386 = 33 ;
    	a706302795 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1519100789 == 3 && (((( cf==1  && a88077474 == 36) && a744476156 == 33) && a2005069365 == 35) && (input == 12)))) {
    	cf = 0;
    	a369539608 = 34 ;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a1754726785 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a88077474 == 36 && (((a1519100789 == 3 && (a744476156 == 33 &&  cf==1 )) && a2005069365 == 35) && (input == 13)))) {
    	cf = 0;
    	a369539608 = 34 ;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a1754726785 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 35 && (((input == 20) && ( cf==1  && a1519100789 == 3)) && a744476156 == 33)) && a88077474 == 36)) {
    	cf = 0;
    	a27741386 = 33 ;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a706302795 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm496(int input) {
    if(((input == 2) && (((a744476156 == 34 && (a88077474 == 36 &&  cf==1 )) && a2005069365 == 35) && a1519100789 == 3))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a844311967 = 33 ;
    	a2005069365 = 32 ;
    	a1380627758 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm17(int input) {
    if(( cf==1  && a88077474 == 32)) {
    	if((a1904774218 == 32 &&  cf==1 )) {
    		calculate_outputm481(input);
    	} 
    } 
    if((a88077474 == 33 &&  cf==1 )) {
    	if(( cf==1  && a928570136 == 32)) {
    		calculate_outputm483(input);
    	} 
    	if((a928570136 == 33 &&  cf==1 )) {
    		calculate_outputm484(input);
    	} 
    	if((a928570136 == 34 &&  cf==1 )) {
    		calculate_outputm485(input);
    	} 
    	if((a928570136 == 36 &&  cf==1 )) {
    		calculate_outputm486(input);
    	} 
    } 
    if((a88077474 == 34 &&  cf==1 )) {
    	if((a2016510333 == 32 &&  cf==1 )) {
    		calculate_outputm487(input);
    	} 
    	if((a2016510333 == 33 &&  cf==1 )) {
    		calculate_outputm488(input);
    	} 
    	if((a2016510333 == 36 &&  cf==1 )) {
    		calculate_outputm489(input);
    	} 
    } 
    if(( cf==1  && a88077474 == 35)) {
    	if((a534598694 == 6 &&  cf==1 )) {
    		calculate_outputm490(input);
    	} 
    	if((a534598694 == 7 &&  cf==1 )) {
    		calculate_outputm491(input);
    	} 
    	if((a534598694 == 10 &&  cf==1 )) {
    		calculate_outputm492(input);
    	} 
    	if((a534598694 == 12 &&  cf==1 )) {
    		calculate_outputm493(input);
    	} 
    } 
    if(( cf==1  && a88077474 == 36)) {
    	if((a744476156 == 32 &&  cf==1 )) {
    		calculate_outputm494(input);
    	} 
    	if(( cf==1  && a744476156 == 33)) {
    		calculate_outputm495(input);
    	} 
    	if((a744476156 == 34 &&  cf==1 )) {
    		calculate_outputm496(input);
    	} 
    } 
}
 void calculate_outputm497(int input) {
    if(((input == 17) && (a2005069365 == 35 && (a1519100789 == 4 && ((a1756771009 == 32 &&  cf==1 ) && a240738299 == 32))))) {
    	cf = 0;
    	a369539608 = 34 ;
    	a1684674520 = 36 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm498(int input) {
    if((a240738299 == 32 && ((input == 10) && ((( cf==1  && a2005069365 == 35) && a1756771009 == 34) && a1519100789 == 4)))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a1428914468 = 7;
    	a976704484 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm499(int input) {
    if(((((( cf==1  && a240738299 == 32) && a2005069365 == 35) && a1756771009 == 36) && a1519100789 == 4) && (input == 13))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a679327000 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm500(int input) {
    if(((input == 10) && (((( cf==1  && a2005069365 == 35) && a240738299 == 33) && a201083786 == 13) && a1519100789 == 4))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 10;
    	a920118831 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm501(int input) {
    if((((a201083786 == 14 && (((input == 7) &&  cf==1 ) && a2005069365 == 35)) && a1519100789 == 4) && a240738299 == 33)) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 10;
    	a662123779 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm502(int input) {
    if(((a1519100789 == 4 && (a240738299 == 33 && (a201083786 == 15 && ( cf==1  && (input == 4))))) && a2005069365 == 35)) {
    	cf = 0;
    	a1519100789 = 6;
    	a604409338 = 33 ;
    	a954368445 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a240738299 == 33 && ((a201083786 == 15 && (((input == 6) &&  cf==1 ) && a2005069365 == 35)) && a1519100789 == 4))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a569036257 = 10;
    	a920118831 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a240738299 == 33 && (((input == 14) &&  cf==1 ) && a201083786 == 15)) && a2005069365 == 35) && a1519100789 == 4)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a369539608 = 34 ;
    	a1754726785 = 15; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a201083786 == 15 && (((a1519100789 == 4 &&  cf==1 ) && a2005069365 == 35) && a240738299 == 33)) && (input == 20))) {
    	cf = 0;
    	a2124036967 = 32 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a1194623510 = 33 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm503(int input) {
    if((((((a1519100789 == 4 &&  cf==1 ) && a201083786 == 16) && (input == 4)) && a240738299 == 33) && a2005069365 == 35)) {
    	cf = 0;
    	a1093326457 = 34 ;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a714559100 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 7) && ((((a201083786 == 16 &&  cf==1 ) && a240738299 == 33) && a2005069365 == 35) && a1519100789 == 4))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a747683138 = 35 ;
    	a2059681452 = 33 ;
    	a1039723590 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a240738299 == 33 && (a1519100789 == 4 && ((( cf==1  && a201083786 == 16) && a2005069365 == 35) && (input == 10))))) {
    	cf = 0;
    	a107446547 = 12;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a1682504076 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm504(int input) {
    if(((a201083786 == 17 && ((input == 11) && (a1519100789 == 4 && (a240738299 == 33 &&  cf==1 )))) && a2005069365 == 35)) {
    	cf = 0;
    	a604409338 = 33 ;
    	a1519100789 = 6;
    	a954368445 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm505(int input) {
    if((a240738299 == 34 && ((a1519100789 == 4 && ((input == 2) && ( cf==1  && a2005069365 == 35))) && a1109056640 == 1))) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 12;
    	a1957279511 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((( cf==1  && a1109056640 == 1) && a240738299 == 34) && a1519100789 == 4) && (input == 12)) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a367284938 = 36 ;
    	a969893172 = 35 ;
    	a685667843 = 16; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 16) && (((a1519100789 == 4 && ( cf==1  && a2005069365 == 35)) && a1109056640 == 1) && a240738299 == 34))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a714559100 = 12;
    	a2005069365 = 34 ;
    	a1116999236 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1109056640 == 1 && (((( cf==1  && a240738299 == 34) && a1519100789 == 4) && (input == 20)) && a2005069365 == 35))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1872268177 = 35 ;
    	a1428914468 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1519100789 == 4 && ((a1109056640 == 1 && ( cf==1  && (input == 4))) && a2005069365 == 35)) && a240738299 == 34)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 33 ;
    	a747683138 = 35 ;
    	a1039723590 = 35 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm507(int input) {
    if(((((( cf==1  && a1519100789 == 4) && a1109056640 == 3) && a2005069365 == 35) && (input == 20)) && a240738299 == 34)) {
    	cf = 0;
    	a925870636 = 10;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a666963702 = 16; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm508(int input) {
    if((((input == 4) && ((a2005069365 == 35 && (a240738299 == 34 &&  cf==1 )) && a1519100789 == 4)) && a1109056640 == 4)) {
    	cf = 0;
    	a1052150692 = 11;
    	a1519100789 = 2;
    	a1089968358 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a240738299 == 34 && ((a2005069365 == 35 && (a1109056640 == 4 && (a1519100789 == 4 &&  cf==1 ))) && (input == 17)))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2124036967 = 34 ;
    	a2005069365 = 34 ;
    	a745730534 = 33 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm510(int input) {
    if((a2005069365 == 35 && ((input == 3) && ((( cf==1  && a240738299 == 34) && a1519100789 == 4) && a1109056640 == 6)))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a687007811 = 35 ;
    	a2005069365 = 34 ;
    	a714559100 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((input == 4) && (( cf==1  && a240738299 == 34) && a1109056640 == 6)) && a2005069365 == 35) && a1519100789 == 4)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a1325377146 = 36 ;
    	a569036257 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1109056640 == 6 && (a240738299 == 34 && (a1519100789 == 4 && (( cf==1  && a2005069365 == 35) && (input == 12)))))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a1428914468 = 10;
    	a954368445 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm511(int input) {
    if(((a1109056640 == 8 && (a240738299 == 34 && (a2005069365 == 35 && (a1519100789 == 4 &&  cf==1 )))) && (input == 5))) {
    	cf = 0;
    	a113788596 = 32 ;
    	a1561044360 = 36 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 20) && (a240738299 == 34 && (a1519100789 == 4 && (a1109056640 == 8 &&  cf==1 )))) && a2005069365 == 35)) {
    	cf = 0;
    	a604409338 = 35 ;
    	a1519100789 = 6;
    	a1688003115 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm512(int input) {
    if((((input == 6) && (((a2005069365 == 35 &&  cf==1 ) && a240738299 == 35) && a1519100789 == 4)) && a1153134505 == 32)) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a206599328 = 34 ;
    	a2005069365 = 36 ;
    	a714559100 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1153134505 == 32 && ((input == 8) && ((a2005069365 == 35 && ( cf==1  && a240738299 == 35)) && a1519100789 == 4)))) {
    	cf = 0;
    	a714559100 = 6;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1086754137 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 35 && (a240738299 == 35 && ((input == 12) && (a1153134505 == 32 && ( cf==1  && a1519100789 == 4)))))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a206599328 = 34 ;
    	a2005069365 = 36 ;
    	a714559100 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm513(int input) {
    if(((((a2005069365 == 35 && ( cf==1  && a1153134505 == 33)) && (input == 2)) && a1519100789 == 4) && a240738299 == 35)) {
    	cf = 0;
    	a367284938 = 32 ;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 16; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1519100789 == 4 && (a1153134505 == 33 && ( cf==1  && a240738299 == 35))) && a2005069365 == 35) && (input == 3))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a107446547 = 14;
    	a986008840 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a240738299 == 35 && (a1519100789 == 4 && ((a1153134505 == 33 &&  cf==1 ) && a2005069365 == 35))) && (input == 5))) {
    	cf = 0;
    	a1085908735 = 34 ;
    	a1519100789 = 2;
    	a1052150692 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1519100789 == 4 && ((a1153134505 == 33 && ((input == 13) && (a2005069365 == 35 &&  cf==1 ))) && a240738299 == 35))) {
    	cf = 0;
    	a844311967 = 33 ;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a1380627758 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1153134505 == 33 && ((( cf==1  && a1519100789 == 4) && (input == 15)) && a2005069365 == 35)) && a240738299 == 35)) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a679327000 = 34 ;
    	a603781876 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm514(int input) {
    if((((a2005069365 == 35 && (( cf==1  && a1519100789 == 4) && a240738299 == 35)) && a1153134505 == 34) && (input == 6))) {
    	cf = 0;
    	a1815432985 = 35 ;
    	a1519100789 = 7;
    	a1243394452 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((a1153134505 == 34 && ((input == 13) &&  cf==1 )) && a240738299 == 35) && a2005069365 == 35) && a1519100789 == 4)) {
    	cf = 0;
    	a1838812917 = 32 ;
    	a2005069365 = 36 ;
    	a927953139 = 34 ;
    	a1857807887 = 35 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1519100789 == 4 && ((a240738299 == 35 && (a2005069365 == 35 &&  cf==1 )) && a1153134505 == 34)) && (input == 17))) {
    	cf = 0;
    	a714559100 = 7;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1166586546 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a240738299 == 35 && (a1519100789 == 4 && (a1153134505 == 34 && ( cf==1  && a2005069365 == 35)))) && (input == 19))) {
    	cf = 0;
    	a240738299 = 34 ;
    	a1109056640 = 2; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm515(int input) {
    if((a1153134505 == 36 && ((a2005069365 == 35 && (( cf==1  && (input == 1)) && a240738299 == 35)) && a1519100789 == 4))) {
    	cf = 0;
    	a1153134505 = 33 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a240738299 == 35 && (a1519100789 == 4 && (((a2005069365 == 35 &&  cf==1 ) && (input == 3)) && a1153134505 == 36)))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a679327000 = 34 ;
    	a603781876 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 35 && (((( cf==1  && a1519100789 == 4) && a240738299 == 35) && (input == 11)) && a1153134505 == 36))) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a240738299 == 35 && (a1153134505 == 36 && (a2005069365 == 35 && ( cf==1  && (input == 13))))) && a1519100789 == 4)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 34 ;
    	a2059681452 = 32 ;
    	a603781876 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm516(int input) {
    if(((((a1519100789 == 4 && ( cf==1  && a240738299 == 36)) && (input == 2)) && a727645622 == 34) && a2005069365 == 35)) {
    	cf = 0;
    	a2124036967 = 32 ;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a1194623510 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a240738299 == 36 && ((( cf==1  && (input == 7)) && a727645622 == 34) && a1519100789 == 4)) && a2005069365 == 35)) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((( cf==1  && a727645622 == 34) && a2005069365 == 35) && a1519100789 == 4) && a240738299 == 36) && (input == 10))) {
    	cf = 0;
    	a1428914468 = 8;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1699038459 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm517(int input) {
    if(((((( cf==1  && a727645622 == 36) && a1519100789 == 4) && (input == 10)) && a2005069365 == 35) && a240738299 == 36)) {
    	cf = 0;
    	a113788596 = 36 ;
    	a1519100789 = 8;
    	a772592654 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a1519100789 == 4 && ((a2005069365 == 35 &&  cf==1 ) && a240738299 == 36)) && a727645622 == 36) && (input == 14))) {
    	cf = 0;
    	a1561044360 = 35 ;
    	a113788596 = 32 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1519100789 == 4 && (((a2005069365 == 35 && ( cf==1  && (input == 20))) && a240738299 == 36) && a727645622 == 36))) {
    	cf = 0;
    	a747683138 = 35 ;
    	a2059681452 = 33 ;
    	a2005069365 = 33 ;
    	a1039723590 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm18(int input) {
    if(( cf==1  && a240738299 == 32)) {
    	if(( cf==1  && a1756771009 == 32)) {
    		calculate_outputm497(input);
    	} 
    	if(( cf==1  && a1756771009 == 34)) {
    		calculate_outputm498(input);
    	} 
    	if((a1756771009 == 36 &&  cf==1 )) {
    		calculate_outputm499(input);
    	} 
    } 
    if((a240738299 == 33 &&  cf==1 )) {
    	if((a201083786 == 13 &&  cf==1 )) {
    		calculate_outputm500(input);
    	} 
    	if((a201083786 == 14 &&  cf==1 )) {
    		calculate_outputm501(input);
    	} 
    	if(( cf==1  && a201083786 == 15)) {
    		calculate_outputm502(input);
    	} 
    	if(( cf==1  && a201083786 == 16)) {
    		calculate_outputm503(input);
    	} 
    	if((a201083786 == 17 &&  cf==1 )) {
    		calculate_outputm504(input);
    	} 
    } 
    if((a240738299 == 34 &&  cf==1 )) {
    	if(( cf==1  && a1109056640 == 1)) {
    		calculate_outputm505(input);
    	} 
    	if(( cf==1  && a1109056640 == 3)) {
    		calculate_outputm507(input);
    	} 
    	if((a1109056640 == 4 &&  cf==1 )) {
    		calculate_outputm508(input);
    	} 
    	if(( cf==1  && a1109056640 == 6)) {
    		calculate_outputm510(input);
    	} 
    	if((a1109056640 == 8 &&  cf==1 )) {
    		calculate_outputm511(input);
    	} 
    } 
    if((a240738299 == 35 &&  cf==1 )) {
    	if((a1153134505 == 32 &&  cf==1 )) {
    		calculate_outputm512(input);
    	} 
    	if((a1153134505 == 33 &&  cf==1 )) {
    		calculate_outputm513(input);
    	} 
    	if((a1153134505 == 34 &&  cf==1 )) {
    		calculate_outputm514(input);
    	} 
    	if((a1153134505 == 36 &&  cf==1 )) {
    		calculate_outputm515(input);
    	} 
    } 
    if(( cf==1  && a240738299 == 36)) {
    	if((a727645622 == 34 &&  cf==1 )) {
    		calculate_outputm516(input);
    	} 
    	if((a727645622 == 36 &&  cf==1 )) {
    		calculate_outputm517(input);
    	} 
    } 
}
 void calculate_outputm518(int input) {
    if(((a604409338 == 35 && ((input == 4) && ((a2005069365 == 35 &&  cf==1 ) && a369539608 == 32))) && a1519100789 == 5)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((( cf==1  && a369539608 == 32) && a604409338 == 35) && a2005069365 == 35) && (input == 5)) && a1519100789 == 5)) {
    	cf = 0;
    	a1085908735 = 36 ;
    	a1519100789 = 2;
    	a1052150692 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 7) && (a369539608 == 32 && ((a2005069365 == 35 &&  cf==1 ) && a1519100789 == 5))) && a604409338 == 35)) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm519(int input) {
    if((((a1894975097 == 8 && (a1519100789 == 5 && (a369539608 == 33 &&  cf==1 ))) && a2005069365 == 35) && (input == 1))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a844311967 = 32 ;
    	a2005069365 = 32 ;
    	a749536178 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1519100789 == 5 && (((((input == 19) &&  cf==1 ) && a369539608 == 33) && a1894975097 == 8) && a2005069365 == 35))) {
    	cf = 0;
    	a679327000 = 33 ;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a2065134388 = 15; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm521(int input) {
    if((((((a369539608 == 33 &&  cf==1 ) && a1894975097 == 10) && a2005069365 == 35) && a1519100789 == 5) && (input == 6))) {
    	cf = 0;
    	a1519100789 = 7;
    	a1243394452 = 4;
    	a685344195 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 7) && ((( cf==1  && a1519100789 == 5) && a369539608 == 33) && a1894975097 == 10)) && a2005069365 == 35)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a569036257 = 10;
    	a2005069365 = 36 ;
    	a920118831 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a2005069365 == 35 && ( cf==1  && a369539608 == 33)) && a1519100789 == 5) && (input == 12)) && a1894975097 == 10)) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2124036967 = 35 ;
    	a2005069365 = 34 ;
    	a1942309322 = 36 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((( cf==1  && (input == 16)) && a1894975097 == 10) && a1519100789 == 5) && a2005069365 == 35) && a369539608 == 33)) {
    	cf = 0;
    	a1519100789 = 9;
    	a1958000800 = 12;
    	a798343693 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm522(int input) {
    if((a2005069365 == 35 && (a1519100789 == 5 && ((input == 11) && ((a369539608 == 33 &&  cf==1 ) && a1894975097 == 11))))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a206599328 = 34 ;
    	a2005069365 = 36 ;
    	a714559100 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm524(int input) {
    if((a1894975097 == 13 && (((input == 8) && (a369539608 == 33 && ( cf==1  && a2005069365 == 35))) && a1519100789 == 5))) {
    	cf = 0;
    	a927953139 = 32 ;
    	a2005069365 = 36 ;
    	a1838812917 = 32 ;
    	a1096033747 = 34 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 35 && (a1894975097 == 13 && ((input == 19) && (a369539608 == 33 && (a1519100789 == 5 &&  cf==1 )))))) {
    	cf = 0;
    	a1519100789 = 6;
    	a604409338 = 36 ;
    	a1688003115 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a369539608 == 33 && (a2005069365 == 35 && (a1519100789 == 5 && ((input == 20) && (a1894975097 == 13 &&  cf==1 )))))) {
    	cf = 0;
    	a650110038 = 33 ;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a1015737466 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm526(int input) {
    if((((a369539608 == 34 && (a1519100789 == 5 && (a2005069365 == 35 &&  cf==1 ))) && (input == 5)) && a1684674520 == 34)) {
    	cf = 0;
    	a1958000800 = 12;
    	a1519100789 = 9;
    	a798343693 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1684674520 == 34 && (((a1519100789 == 5 &&  cf==1 ) && (input == 10)) && a2005069365 == 35)) && a369539608 == 34)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 11;
    	a2005069365 = 33 ;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1684674520 == 34 && (a2005069365 == 35 && (((input == 11) &&  cf==1 ) && a1519100789 == 5))) && a369539608 == 34)) {
    	cf = 0;
    	a27741386 = 36 ;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a792575314 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm527(int input) {
    if((a1684674520 == 35 && ((a1519100789 == 5 && (( cf==1  && a2005069365 == 35) && (input == 6))) && a369539608 == 34))) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 8;
    	a1144659688 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a369539608 == 34 && ((a2005069365 == 35 &&  cf==1 ) && a1684674520 == 35)) && (input == 19)) && a1519100789 == 5)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 8;
    	a1505404504 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1519100789 == 5 && (((input == 20) && (a1684674520 == 35 && ( cf==1  && a369539608 == 34))) && a2005069365 == 35))) {
    	cf = 0;
    	a2124036967 = 32 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a1194623510 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 5) && (a2005069365 == 35 && (((a1684674520 == 35 &&  cf==1 ) && a1519100789 == 5) && a369539608 == 34)))) {
    	cf = 0;
    	a107446547 = 13;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a132648993 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm528(int input) {
    if((((((input == 3) && ( cf==1  && a1519100789 == 5)) && a369539608 == 34) && a1684674520 == 36) && a2005069365 == 35)) {
    	cf = 0;
    	a679327000 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a2065134388 = 17; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 20) && (a2005069365 == 35 && (a1684674520 == 36 && ((a369539608 == 34 &&  cf==1 ) && a1519100789 == 5))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm530(int input) {
    if((a2005069365 == 35 && (((( cf==1  && a1519100789 == 5) && (input == 5)) && a369539608 == 35) && a1307756142 == 35))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm532(int input) {
    if((((a1519100789 == 5 && (((input == 3) &&  cf==1 ) && a2005069365 == 35)) && a369539608 == 36) && a347749795 == 9)) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm533(int input) {
    if((((input == 2) && (a2005069365 == 35 && ((a369539608 == 36 &&  cf==1 ) && a1519100789 == 5))) && a347749795 == 10)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 13;
    	a1271566896 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 3) && ((a2005069365 == 35 && (a1519100789 == 5 && (a369539608 == 36 &&  cf==1 ))) && a347749795 == 10))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a1428914468 = 13;
    	a2005069365 = 34 ;
    	a2125137407 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm534(int input) {
    if((a2005069365 == 35 && ((a1519100789 == 5 && ((a347749795 == 11 &&  cf==1 ) && (input == 2))) && a369539608 == 36))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 11;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 35 && ((a369539608 == 36 && ((a347749795 == 11 &&  cf==1 ) && (input == 6))) && a1519100789 == 5))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a2124036967 = 35 ;
    	a1942309322 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 35 && (((a347749795 == 11 && ((input == 7) &&  cf==1 )) && a369539608 == 36) && a1519100789 == 5))) {
    	cf = 0;
    	a451941968 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a2005069365 == 35 && (a369539608 == 36 &&  cf==1 )) && (input == 15)) && a1519100789 == 5) && a347749795 == 11)) {
    	cf = 0;
    	a2124036967 = 35 ;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a1942309322 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm535(int input) {
    if((a369539608 == 36 && (a347749795 == 12 && (((a2005069365 == 35 &&  cf==1 ) && a1519100789 == 5) && (input == 12))))) {
    	cf = 0;
    	a27741386 = 36 ;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a792575314 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a369539608 == 36 && ((input == 13) && (( cf==1  && a1519100789 == 5) && a2005069365 == 35))) && a347749795 == 12)) {
    	cf = 0;
    	a2002331280 = 33 ;
    	a1519100789 = 9;
    	a1958000800 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm19(int input) {
    if(( cf==1  && a369539608 == 32)) {
    	if(( cf==1  && a604409338 == 35)) {
    		calculate_outputm518(input);
    	} 
    } 
    if((a369539608 == 33 &&  cf==1 )) {
    	if((a1894975097 == 8 &&  cf==1 )) {
    		calculate_outputm519(input);
    	} 
    	if((a1894975097 == 10 &&  cf==1 )) {
    		calculate_outputm521(input);
    	} 
    	if(( cf==1  && a1894975097 == 11)) {
    		calculate_outputm522(input);
    	} 
    	if((a1894975097 == 13 &&  cf==1 )) {
    		calculate_outputm524(input);
    	} 
    } 
    if(( cf==1  && a369539608 == 34)) {
    	if((a1684674520 == 34 &&  cf==1 )) {
    		calculate_outputm526(input);
    	} 
    	if(( cf==1  && a1684674520 == 35)) {
    		calculate_outputm527(input);
    	} 
    	if((a1684674520 == 36 &&  cf==1 )) {
    		calculate_outputm528(input);
    	} 
    } 
    if(( cf==1  && a369539608 == 35)) {
    	if(( cf==1  && a1307756142 == 35)) {
    		calculate_outputm530(input);
    	} 
    } 
    if((a369539608 == 36 &&  cf==1 )) {
    	if((a347749795 == 9 &&  cf==1 )) {
    		calculate_outputm532(input);
    	} 
    	if((a347749795 == 10 &&  cf==1 )) {
    		calculate_outputm533(input);
    	} 
    	if(( cf==1  && a347749795 == 11)) {
    		calculate_outputm534(input);
    	} 
    	if((a347749795 == 12 &&  cf==1 )) {
    		calculate_outputm535(input);
    	} 
    } 
}
 void calculate_outputm536(int input) {
    if((a1519100789 == 6 && (a2005069365 == 35 && (a604409338 == 32 && ((a1756771009 == 32 &&  cf==1 ) && (input == 10)))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 14;
    	a986008840 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a1519100789 == 6 && (( cf==1  && a1756771009 == 32) && a2005069365 == 35)) && a604409338 == 32) && (input == 19))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a925870636 = 8;
    	a1883016343 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm537(int input) {
    if(((((( cf==1  && a1756771009 == 33) && (input == 5)) && a1519100789 == 6) && a604409338 == 32) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a747683138 = 34 ;
    	a2059681452 = 33 ;
    	a1428914468 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a604409338 == 32 && (((input == 8) && (( cf==1  && a1756771009 == 33) && a1519100789 == 6)) && a2005069365 == 35))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a844311967 = 35 ;
    	a205734433 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 35 && ((a1756771009 == 33 && (a1519100789 == 6 && ( cf==1  && (input == 15)))) && a604409338 == 32))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a829511935 = 32 ;
    	a1129866701 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((a1756771009 == 33 &&  cf==1 ) && a604409338 == 32) && a1519100789 == 6) && (input == 1)) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a714559100 = 5;
    	a1079106761 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm538(int input) {
    if((a1756771009 == 36 && ((input == 6) && (a604409338 == 32 && (( cf==1  && a1519100789 == 6) && a2005069365 == 35))))) {
    	cf = 0;
    	a1519100789 = 7;
    	a1204193075 = 34 ;
    	a1243394452 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a2005069365 == 35 && (a604409338 == 32 && (a1756771009 == 36 &&  cf==1 ))) && (input == 10)) && a1519100789 == 6)) {
    	cf = 0;
    	a1519100789 = 8;
    	a113788596 = 36 ;
    	a772592654 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 35 && (((input == 11) && ((a604409338 == 32 &&  cf==1 ) && a1519100789 == 6)) && a1756771009 == 36))) {
    	cf = 0;
    	a240738299 = 34 ;
    	a1519100789 = 4;
    	a1109056640 = 1; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1519100789 == 6 && (a1756771009 == 36 && (((input == 16) && ( cf==1  && a604409338 == 32)) && a2005069365 == 35)))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a107446547 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm539(int input) {
    if(((a954368445 == 1 && (a604409338 == 33 && (a2005069365 == 35 && ((input == 10) &&  cf==1 )))) && a1519100789 == 6)) {
    	cf = 0;
    	a925870636 = 8;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a1883016343 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm540(int input) {
    if((a1519100789 == 6 && ((input == 5) && ((a954368445 == 3 && ( cf==1  && a604409338 == 33)) && a2005069365 == 35)))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 34 ;
    	a2059681452 = 32 ;
    	a603781876 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((a1519100789 == 6 && ( cf==1  && a2005069365 == 35)) && (input == 12)) && a604409338 == 33) && a954368445 == 3)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a525429632 = 35 ;
    	a969893172 = 33 ;
    	a1428914468 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a954368445 == 3 && (a1519100789 == 6 && ((((input == 16) &&  cf==1 ) && a604409338 == 33) && a2005069365 == 35)))) {
    	cf = 0;
    	a369539608 = 34 ;
    	a1684674520 = 34 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a604409338 == 33 && ((a954368445 == 3 && ((a1519100789 == 6 &&  cf==1 ) && a2005069365 == 35)) && (input == 19)))) {
    	cf = 0;
    	a27741386 = 35 ;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a829511935 = 35 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm541(int input) {
    if((a1519100789 == 6 && ((input == 16) && (a604409338 == 33 && ((a954368445 == 4 &&  cf==1 ) && a2005069365 == 35))))) {
    	cf = 0;
    	a2124036967 = 34 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a745730534 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm542(int input) {
    if((((a1519100789 == 6 && ((a2005069365 == 35 &&  cf==1 ) && a954368445 == 5)) && a604409338 == 33) && (input == 5))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a1275896582 = 32 ;
    	a2005069365 = 33 ;
    	a107446547 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1519100789 == 6 && (a2005069365 == 35 && (a954368445 == 5 && (((input == 6) &&  cf==1 ) && a604409338 == 33))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1129866701 = 11;
    	a2059681452 = 35 ;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a954368445 == 5 && (a604409338 == 33 && ((a1519100789 == 6 &&  cf==1 ) && a2005069365 == 35))) && (input == 8))) {
    	cf = 0;
    	a1519100789 = 9;
    	a1958000800 = 13;
    	a593874874 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm543(int input) {
    if(((a2005069365 == 35 && (a1519100789 == 6 && (a954368445 == 6 && ((input == 2) &&  cf==1 )))) && a604409338 == 33)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a1690193643 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm546(int input) {
    if(((a1519100789 == 6 && (a933478840 == 34 && (((input == 7) &&  cf==1 ) && a604409338 == 34))) && a2005069365 == 35)) {
    	cf = 0;
    	a1775644016 = 11;
    	a1838812917 = 36 ;
    	a2005069365 = 36 ;
    	a1566584718 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 16) && (a2005069365 == 35 && (a604409338 == 34 && ( cf==1  && a933478840 == 34)))) && a1519100789 == 6)) {
    	cf = 0;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a650110038 = 34 ;
    	a349181387 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm547(int input) {
    if(((a2005069365 == 35 && ((( cf==1  && (input == 6)) && a1519100789 == 6) && a604409338 == 34)) && a933478840 == 36)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1775644016 = 6;
    	a200393381 = 2; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((input == 19) && (( cf==1  && a604409338 == 34) && a2005069365 == 35)) && a1519100789 == 6) && a933478840 == 36)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a714559100 = 12;
    	a1838812917 = 35 ;
    	a1655731851 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1519100789 == 6 && (((a2005069365 == 35 &&  cf==1 ) && a604409338 == 34) && (input == 20))) && a933478840 == 36)) {
    	cf = 0;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a928570136 = 35 ;
    	a666963702 = 15; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm548(int input) {
    if(((a1519100789 == 6 && ((( cf==1  && (input == 2)) && a604409338 == 35) && a2005069365 == 35)) && a1688003115 == 7)) {
    	cf = 0;
    	a569036257 = 4;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a1549928701 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((input == 8) && ((a2005069365 == 35 &&  cf==1 ) && a1688003115 == 7)) && a604409338 == 35) && a1519100789 == 6)) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((input == 10) && (a604409338 == 35 &&  cf==1 )) && a1519100789 == 6) && a2005069365 == 35) && a1688003115 == 7)) {
    	cf = 0;
    	a1519100789 = 2;
    	a451941968 = 32 ;
    	a1052150692 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a2005069365 == 35 && (a1519100789 == 6 && ((a604409338 == 35 &&  cf==1 ) && a1688003115 == 7))) && (input == 14))) {
    	cf = 0;
    	a525429632 = 33 ;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm549(int input) {
    if((a1688003115 == 8 && ((input == 6) && (a1519100789 == 6 && (( cf==1  && a2005069365 == 35) && a604409338 == 35))))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a353267992 = 36 ;
    	a107446547 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1519100789 == 6 && ((a604409338 == 35 && (( cf==1  && (input == 11)) && a2005069365 == 35)) && a1688003115 == 8))) {
    	cf = 0;
    	a1519100789 = 9;
    	a1872268177 = 32 ;
    	a1958000800 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 13) && (a604409338 == 35 && (a2005069365 == 35 && ((a1688003115 == 8 &&  cf==1 ) && a1519100789 == 6))))) {
    	cf = 0;
    	a738616794 = 34 ;
    	a1519100789 = 2;
    	a1052150692 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a1688003115 == 8 && ((input == 16) && ( cf==1  && a2005069365 == 35))) && a604409338 == 35) && a1519100789 == 6)) {
    	cf = 0;
    	a969893172 = 34 ;
    	a1093326457 = 35 ;
    	a2005069365 = 34 ;
    	a714559100 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm550(int input) {
    if((a1688003115 == 10 && ((a604409338 == 35 && ((input == 11) && ( cf==1  && a2005069365 == 35))) && a1519100789 == 6))) {
    	cf = 0;
    	a1519100789 = 8;
    	a113788596 = 36 ;
    	a772592654 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 13) && (((a1519100789 == 6 && (a1688003115 == 10 &&  cf==1 )) && a2005069365 == 35) && a604409338 == 35))) {
    	cf = 0;
    	a1052150692 = 12;
    	a1519100789 = 2;
    	a1957279511 = 3; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1688003115 == 10 && ((((input == 15) &&  cf==1 ) && a604409338 == 35) && a1519100789 == 6)) && a2005069365 == 35)) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a679327000 = 34 ;
    	a603781876 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm551(int input) {
    if((a604409338 == 35 && (a2005069365 == 35 && (a1519100789 == 6 && (( cf==1  && (input == 2)) && a1688003115 == 13))))) {
    	cf = 0;
    	a714559100 = 12;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a1655731851 = 3; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm553(int input) {
    if((((a2005069365 == 35 && (( cf==1  && a604409338 == 36) && a1519100789 == 6)) && a1688003115 == 9) && (input == 12))) {
    	cf = 0;
    	a369539608 = 36 ;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a1577567933 = 36 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1688003115 == 9 && ((a2005069365 == 35 && (( cf==1  && a1519100789 == 6) && (input == 17))) && a604409338 == 36))) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a925870636 = 8;
    	a1883016343 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm554(int input) {
    if((a604409338 == 36 && (a1519100789 == 6 && ((( cf==1  && a1688003115 == 10) && (input == 12)) && a2005069365 == 35)))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a844311967 = 35 ;
    	a205734433 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1688003115 == 10 && (a604409338 == 36 && ((a1519100789 == 6 && (a2005069365 == 35 &&  cf==1 )) && (input == 15))))) {
    	cf = 0;
    	a925870636 = 8;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a1883016343 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm555(int input) {
    if(((((a2005069365 == 35 && (a604409338 == 36 &&  cf==1 )) && a1688003115 == 11) && a1519100789 == 6) && (input == 1))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a465336174 = 35 ;
    	a2005069365 = 36 ;
    	a569036257 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm556(int input) {
    if((a2005069365 == 35 && (a1519100789 == 6 && (a604409338 == 36 && ((input == 7) && ( cf==1  && a1688003115 == 12)))))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a569036257 = 10;
    	a1838812917 = 33 ;
    	a920118831 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm557(int input) {
    if(((input == 10) && ((a1688003115 == 13 && (a2005069365 == 35 && ( cf==1  && a1519100789 == 6))) && a604409338 == 36))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a525429632 = 34 ;
    	a1428914468 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((a2005069365 == 35 &&  cf==1 ) && a1519100789 == 6) && a604409338 == 36) && (input == 13)) && a1688003115 == 13)) {
    	cf = 0;
    	a969893172 = 34 ;
    	a687007811 = 33 ;
    	a2005069365 = 34 ;
    	a714559100 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1688003115 == 13 && (a2005069365 == 35 && (a1519100789 == 6 && ((input == 14) && (a604409338 == 36 &&  cf==1 )))))) {
    	cf = 0;
    	a1684687706 = 9;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a892217980 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1688003115 == 13 && (( cf==1  && a604409338 == 36) && a2005069365 == 35)) && (input == 20)) && a1519100789 == 6)) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a679327000 = 34 ;
    	a603781876 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm20(int input) {
    if(( cf==1  && a604409338 == 32)) {
    	if(( cf==1  && a1756771009 == 32)) {
    		calculate_outputm536(input);
    	} 
    	if(( cf==1  && a1756771009 == 33)) {
    		calculate_outputm537(input);
    	} 
    	if((a1756771009 == 36 &&  cf==1 )) {
    		calculate_outputm538(input);
    	} 
    } 
    if((a604409338 == 33 &&  cf==1 )) {
    	if(( cf==1  && a954368445 == 1)) {
    		calculate_outputm539(input);
    	} 
    	if((a954368445 == 3 &&  cf==1 )) {
    		calculate_outputm540(input);
    	} 
    	if((a954368445 == 4 &&  cf==1 )) {
    		calculate_outputm541(input);
    	} 
    	if(( cf==1  && a954368445 == 5)) {
    		calculate_outputm542(input);
    	} 
    	if((a954368445 == 6 &&  cf==1 )) {
    		calculate_outputm543(input);
    	} 
    } 
    if((a604409338 == 34 &&  cf==1 )) {
    	if((a933478840 == 34 &&  cf==1 )) {
    		calculate_outputm546(input);
    	} 
    	if((a933478840 == 36 &&  cf==1 )) {
    		calculate_outputm547(input);
    	} 
    } 
    if(( cf==1  && a604409338 == 35)) {
    	if((a1688003115 == 7 &&  cf==1 )) {
    		calculate_outputm548(input);
    	} 
    	if((a1688003115 == 8 &&  cf==1 )) {
    		calculate_outputm549(input);
    	} 
    	if((a1688003115 == 10 &&  cf==1 )) {
    		calculate_outputm550(input);
    	} 
    	if(( cf==1  && a1688003115 == 13)) {
    		calculate_outputm551(input);
    	} 
    } 
    if((a604409338 == 36 &&  cf==1 )) {
    	if(( cf==1  && a1688003115 == 9)) {
    		calculate_outputm553(input);
    	} 
    	if(( cf==1  && a1688003115 == 10)) {
    		calculate_outputm554(input);
    	} 
    	if(( cf==1  && a1688003115 == 11)) {
    		calculate_outputm555(input);
    	} 
    	if((a1688003115 == 12 &&  cf==1 )) {
    		calculate_outputm556(input);
    	} 
    	if(( cf==1  && a1688003115 == 13)) {
    		calculate_outputm557(input);
    	} 
    } 
}
 void calculate_outputm559(int input) {
    if((((a2005069365 == 35 && ((a1735753243 == 5 &&  cf==1 ) && a1519100789 == 7)) && a1243394452 == 2) && (input == 8))) {
    	cf = 0;
    	a27741386 = 33 ;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a706302795 = 15; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 35 && (a1735753243 == 5 && (a1243394452 == 2 && ((input == 17) && ( cf==1  && a1519100789 == 7)))))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a107446547 = 15;
    	a275125637 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 9) && ((( cf==1  && a1519100789 == 7) && a1735753243 == 5) && a1243394452 == 2)) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a1795880353 = 36 ;
    	a107446547 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm560(int input) {
    if((a2005069365 == 35 && (((a1519100789 == 7 && ((input == 1) &&  cf==1 )) && a1735753243 == 6) && a1243394452 == 2))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a569036257 = 10;
    	a1838812917 = 33 ;
    	a920118831 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1735753243 == 6 && (a1243394452 == 2 && (a2005069365 == 35 && ((input == 7) &&  cf==1 )))) && a1519100789 == 7)) {
    	cf = 0;
    	a1843210244 = 36 ;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1684687706 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a1243394452 == 2 && ((a2005069365 == 35 &&  cf==1 ) && a1735753243 == 6)) && a1519100789 == 7) && (input == 11))) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 10;
    	a662123779 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm561(int input) {
    if(((((a1735753243 == 7 && (a1243394452 == 2 &&  cf==1 )) && a1519100789 == 7) && a2005069365 == 35) && (input == 5))) {
    	cf = 0;
    	a714559100 = 12;
    	a2005069365 = 36 ;
    	a1838812917 = 35 ;
    	a1655731851 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((input == 8) && (a1735753243 == 7 && ( cf==1  && a1243394452 == 2))) && a2005069365 == 35) && a1519100789 == 7)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 32 ;
    	a650110038 = 35 ;
    	a264802066 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1519100789 == 7 && ((input == 10) && ((( cf==1  && a1735753243 == 7) && a1243394452 == 2) && a2005069365 == 35)))) {
    	cf = 0;
    	a1519100789 = 9;
    	a1958000800 = 12;
    	a798343693 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 20) && ((a2005069365 == 35 && (( cf==1  && a1519100789 == 7) && a1735753243 == 7)) && a1243394452 == 2))) {
    	cf = 0;
    	a1519100789 = 9;
    	a1872268177 = 34 ;
    	a1958000800 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm562(int input) {
    if((a2005069365 == 35 && ((a1519100789 == 7 && (( cf==1  && (input == 5)) && a1815432985 == 32)) && a1243394452 == 3))) {
    	cf = 0;
    	a1775644016 = 11;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1566584718 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1519100789 == 7 && ((input == 12) && (a1243394452 == 3 && (a1815432985 == 32 && ( cf==1  && a2005069365 == 35)))))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a2135613870 = 36 ;
    	a1428914468 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2005069365 == 35 && ((input == 19) && ((a1815432985 == 32 &&  cf==1 ) && a1519100789 == 7))) && a1243394452 == 3)) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 7;
    	a71813398 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm565(int input) {
    if((a1815432985 == 35 && (a2005069365 == 35 && ((a1519100789 == 7 && ( cf==1  && a1243394452 == 3)) && (input == 6))))) {
    	cf = 0;
    	a834910632 = 36 ;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1815432985 == 35 && ((( cf==1  && a2005069365 == 35) && a1519100789 == 7) && a1243394452 == 3)) && (input == 17))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a714559100 = 5;
    	a969893172 = 34 ;
    	a1079106761 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm566(int input) {
    if((((a2005069365 == 35 && ((a1519100789 == 7 &&  cf==1 ) && a1815432985 == 36)) && a1243394452 == 3) && (input == 1))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 35 ;
    	a2005069365 = 34 ;
    	a264802066 = 34 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 35 && (a1243394452 == 3 && (a1815432985 == 36 && (a1519100789 == 7 && ((input == 2) &&  cf==1 )))))) {
    	cf = 0;
    	a650110038 = 34 ;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a349181387 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1815432985 == 36 && ((input == 6) && (a1243394452 == 3 && ((a2005069365 == 35 &&  cf==1 ) && a1519100789 == 7))))) {
    	cf = 0;
    	a844311967 = 36 ;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a1235481610 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a1243394452 == 3 && ((input == 11) && (a2005069365 == 35 &&  cf==1 ))) && a1519100789 == 7) && a1815432985 == 36)) {
    	cf = 0;
    	a88077474 = 35 ;
    	a1519100789 = 3;
    	a534598694 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm567(int input) {
    if((a685344195 == 7 && (a1243394452 == 4 && ((input == 8) && (( cf==1  && a1519100789 == 7) && a2005069365 == 35))))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a110820676 = 32 ;
    	a714559100 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1243394452 == 4 && (a2005069365 == 35 && ((a1519100789 == 7 && ((input == 11) &&  cf==1 )) && a685344195 == 7)))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a107446547 = 15;
    	a1838812917 = 34 ;
    	a275125637 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a685344195 == 7 && (((((input == 20) &&  cf==1 ) && a1519100789 == 7) && a2005069365 == 35) && a1243394452 == 4))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a2124036967 = 36 ;
    	a524102808 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm568(int input) {
    if((a1243394452 == 4 && (((( cf==1  && a2005069365 == 35) && a685344195 == 8) && (input == 11)) && a1519100789 == 7))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a844311967 = 33 ;
    	a1380627758 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1243394452 == 4 && ((a685344195 == 8 && (a1519100789 == 7 && ((input == 20) &&  cf==1 ))) && a2005069365 == 35))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm569(int input) {
    if(((a1243394452 == 4 && ((((input == 20) &&  cf==1 ) && a685344195 == 9) && a2005069365 == 35)) && a1519100789 == 7)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a27741386 = 32 ;
    	a1904774218 = 32 ;
    	a928570136 = 34 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm571(int input) {
    if((a1519100789 == 7 && (((a685344195 == 14 && (a1243394452 == 4 &&  cf==1 )) && a2005069365 == 35) && (input == 3)))) {
    	cf = 0;
    	a1519100789 = 9;
    	a1958000800 = 12;
    	a798343693 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 35 && (a1519100789 == 7 && (a1243394452 == 4 && (( cf==1  && a685344195 == 14) && (input == 5)))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 35 && (a1243394452 == 4 && (a685344195 == 14 && ((a1519100789 == 7 &&  cf==1 ) && (input == 16)))))) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a27741386 = 36 ;
    	a2005069365 = 32 ;
    	a792575314 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a685344195 == 14 && (((( cf==1  && (input == 19)) && a1519100789 == 7) && a2005069365 == 35) && a1243394452 == 4))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1239184736 = 35 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm572(int input) {
    if(((a2005069365 == 35 && (a1243394452 == 5 && (( cf==1  && a246458106 == 33) && a1519100789 == 7))) && (input == 4))) {
    	cf = 0;
    	a1129866701 = 10;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a596573336 = 13; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 35 && (a1519100789 == 7 && (((a1243394452 == 5 &&  cf==1 ) && a246458106 == 33) && (input == 6))))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a169540124 = 32 ;
    	a685667843 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a246458106 == 33 && (a1243394452 == 5 && ((( cf==1  && (input == 13)) && a2005069365 == 35) && a1519100789 == 7)))) {
    	cf = 0;
    	a714559100 = 6;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a1086754137 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1243394452 == 5 && (a1519100789 == 7 && (((a246458106 == 33 &&  cf==1 ) && a2005069365 == 35) && (input == 20))))) {
    	cf = 0;
    	a1872268177 = 34 ;
    	a1519100789 = 9;
    	a1958000800 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm574(int input) {
    if((a1519100789 == 7 && ((a246458106 == 36 && (a1243394452 == 5 && (a2005069365 == 35 &&  cf==1 ))) && (input == 4)))) {
    	cf = 0;
    	a1153134505 = 33 ;
    	a240738299 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((((a246458106 == 36 &&  cf==1 ) && a2005069365 == 35) && a1243394452 == 5) && a1519100789 == 7) && (input == 8))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a679327000 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1519100789 == 7 && (((( cf==1  && a246458106 == 36) && (input == 17)) && a1243394452 == 5) && a2005069365 == 35))) {
    	cf = 0;
    	a240738299 = 35 ;
    	a1153134505 = 33 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 19) && ((a1519100789 == 7 && (a246458106 == 36 && ( cf==1  && a1243394452 == 5))) && a2005069365 == 35))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm575(int input) {
    if(((((( cf==1  && a1519100789 == 7) && (input == 12)) && a132552289 == 6) && a2005069365 == 35) && a1243394452 == 6)) {
    	cf = 0;
    	a1519100789 = 6;
    	a604409338 = 33 ;
    	a954368445 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm576(int input) {
    if(((input == 6) && (a132552289 == 7 && ((a1519100789 == 7 && (a1243394452 == 6 &&  cf==1 )) && a2005069365 == 35)))) {
    	cf = 0;
    	a1307756142 = 35 ;
    	a369539608 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a132552289 == 7 && (a2005069365 == 35 && ( cf==1  && a1243394452 == 6))) && a1519100789 == 7) && (input == 8))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 10;
    	a2005069365 = 33 ;
    	a596573336 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a132552289 == 7 && (a1519100789 == 7 && ((a2005069365 == 35 && ((input == 15) &&  cf==1 )) && a1243394452 == 6)))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a525429632 = 34 ;
    	a1838812917 = 36 ;
    	a1775644016 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((input == 19) && ((a1243394452 == 6 &&  cf==1 ) && a132552289 == 7)) && a2005069365 == 35) && a1519100789 == 7)) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a27741386 = 36 ;
    	a792575314 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm577(int input) {
    if((a1243394452 == 6 && (a2005069365 == 35 && ((a1519100789 == 7 && ((input == 2) &&  cf==1 )) && a132552289 == 9)))) {
    	cf = 0;
    	a1519100789 = 5;
    	a369539608 = 36 ;
    	a347749795 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1519100789 == 7 && (((a132552289 == 9 && ( cf==1  && a2005069365 == 35)) && a1243394452 == 6) && (input == 6)))) {
    	cf = 0;
    	a1093326457 = 35 ;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a714559100 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 13) && (a132552289 == 9 && (a2005069365 == 35 && ( cf==1  && a1243394452 == 6)))) && a1519100789 == 7)) {
    	cf = 0;
    	a925870636 = 8;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a1883016343 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 17) && (a2005069365 == 35 && (a132552289 == 9 && (a1243394452 == 6 &&  cf==1 )))) && a1519100789 == 7)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1129866701 = 8;
    	a2059681452 = 35 ;
    	a1505404504 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm578(int input) {
    if(((a132552289 == 11 && ((a1519100789 == 7 && (a1243394452 == 6 &&  cf==1 )) && a2005069365 == 35)) && (input == 13))) {
    	cf = 0;
    	a1243394452 = 8;
    	a529769874 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1519100789 == 7 && ((((a132552289 == 11 &&  cf==1 ) && a2005069365 == 35) && (input == 14)) && a1243394452 == 6))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 5;
    	a2005069365 = 36 ;
    	a1089968358 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm579(int input) {
    if((((a2005069365 == 35 && ((a1204193075 == 34 &&  cf==1 ) && a1519100789 == 7)) && (input == 11)) && a1243394452 == 7)) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm580(int input) {
    if((a1243394452 == 7 && ((a1519100789 == 7 && (( cf==1  && a1204193075 == 35) && (input == 2))) && a2005069365 == 35))) {
    	cf = 0;
    	a1153134505 = 34 ;
    	a1243394452 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 4) && ((((a1243394452 == 7 &&  cf==1 ) && a2005069365 == 35) && a1519100789 == 7) && a1204193075 == 35))) {
    	cf = 0;
    	a1275896582 = 34 ;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a107446547 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1204193075 == 35 && (((a1243394452 == 7 && (a1519100789 == 7 &&  cf==1 )) && a2005069365 == 35) && (input == 17)))) {
    	cf = 0;
    	a1519100789 = 8;
    	a113788596 = 33 ;
    	a137564664 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm581(int input) {
    if((a2005069365 == 35 && ((a1204193075 == 36 && (( cf==1  && a1243394452 == 7) && (input == 5))) && a1519100789 == 7))) {
    	cf = 0;
    	a685667843 = 14;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a2138261183 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1519100789 == 7 && (a1204193075 == 36 && (((a2005069365 == 35 &&  cf==1 ) && a1243394452 == 7) && (input == 20))))) {
    	cf = 0;
    	a928570136 = 32 ;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a836757480 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm582(int input) {
    if((((((a1243394452 == 8 &&  cf==1 ) && a2005069365 == 35) && a529769874 == 2) && a1519100789 == 7) && (input == 4))) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a1960724031 = 34 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1243394452 == 8 && (a1519100789 == 7 && (((input == 15) && ( cf==1  && a2005069365 == 35)) && a529769874 == 2)))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a714559100 = 10;
    	a1838812917 = 35 ;
    	a2125137407 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1243394452 == 8 && (a2005069365 == 35 && (a529769874 == 2 && (a1519100789 == 7 &&  cf==1 )))) && (input == 20))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a369539608 = 36 ;
    	a1904774218 = 35 ;
    	a1577567933 = 36 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm583(int input) {
    if((((a1243394452 == 8 && (( cf==1  && a2005069365 == 35) && a1519100789 == 7)) && a529769874 == 3) && (input == 4))) {
    	cf = 0;
    	a1239184736 = 35 ;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((input == 15) && ((a2005069365 == 35 && (a529769874 == 3 &&  cf==1 )) && a1519100789 == 7)) && a1243394452 == 8)) {
    	cf = 0;
    	a1129866701 = 11;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm584(int input) {
    if(((a529769874 == 4 && ((a1519100789 == 7 && (a2005069365 == 35 &&  cf==1 )) && (input == 2))) && a1243394452 == 8)) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a369539608 = 34 ;
    	a2005069365 = 32 ;
    	a1754726785 = 15; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((input == 6) && (a2005069365 == 35 && (a1519100789 == 7 && ( cf==1  && a1243394452 == 8)))) && a529769874 == 4)) {
    	cf = 0;
    	a928570136 = 33 ;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a107446547 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a2005069365 == 35 && ((input == 8) && (a1243394452 == 8 &&  cf==1 ))) && a1519100789 == 7) && a529769874 == 4)) {
    	cf = 0;
    	a2002331280 = 33 ;
    	a1519100789 = 9;
    	a1958000800 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a529769874 == 4 && ((a1519100789 == 7 && (a1243394452 == 8 && (a2005069365 == 35 &&  cf==1 ))) && (input == 11)))) {
    	cf = 0;
    	a1052150692 = 12;
    	a1519100789 = 2;
    	a1957279511 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm585(int input) {
    if(((((input == 10) && ((a529769874 == 5 &&  cf==1 ) && a1519100789 == 7)) && a1243394452 == 8) && a2005069365 == 35)) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 12) && (((a1243394452 == 8 && ( cf==1  && a1519100789 == 7)) && a529769874 == 5) && a2005069365 == 35))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 4;
    	a1549928701 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((input == 20) && (a1519100789 == 7 && (( cf==1  && a529769874 == 5) && a2005069365 == 35))) && a1243394452 == 8)) {
    	cf = 0;
    	a815941786 = 35 ;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a107446547 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm586(int input) {
    if(((((input == 13) && (a1519100789 == 7 && (a1243394452 == 8 &&  cf==1 ))) && a529769874 == 6) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 4;
    	a1549928701 = 15; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a2005069365 == 35 && (( cf==1  && a1243394452 == 8) && a529769874 == 6)) && a1519100789 == 7) && (input == 19))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a679327000 = 35 ;
    	a1960724031 = 36 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm587(int input) {
    if((((a1243394452 == 8 && (a529769874 == 7 && (a2005069365 == 35 &&  cf==1 ))) && a1519100789 == 7) && (input == 11))) {
    	cf = 0;
    	a714559100 = 6;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a1086754137 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm588(int input) {
    if((((input == 12) && ((a2005069365 == 35 && ( cf==1  && a1519100789 == 7)) && a529769874 == 8)) && a1243394452 == 8)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a1904774218 = 36 ;
    	a569036257 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm589(int input) {
    if((a1243394452 == 9 && ((input == 2) && ((( cf==1  && a2005069365 == 35) && a1153134505 == 32) && a1519100789 == 7)))) {
    	cf = 0;
    	a367284938 = 32 ;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 16; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 3) && (((a2005069365 == 35 && ( cf==1  && a1243394452 == 9)) && a1153134505 == 32) && a1519100789 == 7))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm590(int input) {
    if((a2005069365 == 35 && ((a1519100789 == 7 && (a1153134505 == 33 && ((input == 1) &&  cf==1 ))) && a1243394452 == 9))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a1428914468 = 10;
    	a954368445 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1243394452 == 9 && ((( cf==1  && a1153134505 == 33) && a2005069365 == 35) && (input == 2))) && a1519100789 == 7)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a844311967 = 36 ;
    	a1904774218 = 33 ;
    	a1235481610 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 35 && (((a1519100789 == 7 && (a1153134505 == 33 &&  cf==1 )) && a1243394452 == 9) && (input == 4)))) {
    	cf = 0;
    	a1519100789 = 9;
    	a1958000800 = 13;
    	a593874874 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1153134505 == 33 && ((a1519100789 == 7 && ( cf==1  && (input == 6))) && a1243394452 == 9)) && a2005069365 == 35)) {
    	cf = 0;
    	a714559100 = 7;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1166586546 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm591(int input) {
    if((((a1519100789 == 7 && ((input == 5) && ( cf==1  && a2005069365 == 35))) && a1153134505 == 34) && a1243394452 == 9)) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a844311967 = 33 ;
    	a1380627758 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a1153134505 == 34 && (((input == 8) &&  cf==1 ) && a2005069365 == 35)) && a1519100789 == 7) && a1243394452 == 9)) {
    	cf = 0;
    	a1204193075 = 35 ;
    	a1243394452 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((a2005069365 == 35 && (a1243394452 == 9 &&  cf==1 )) && a1519100789 == 7) && (input == 16)) && a1153134505 == 34)) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1388584441 = 33 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm592(int input) {
    if((a1153134505 == 35 && ((a1243394452 == 9 && (a1519100789 == 7 && (a2005069365 == 35 &&  cf==1 ))) && (input == 1)))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1129866701 = 12;
    	a2059681452 = 35 ;
    	a461439918 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((((input == 15) && ( cf==1  && a1153134505 == 35)) && a1243394452 == 9) && a2005069365 == 35) && a1519100789 == 7)) {
    	cf = 0;
    	a240738299 = 33 ;
    	a1519100789 = 4;
    	a201083786 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm593(int input) {
    if(((a1519100789 == 7 && ((a1153134505 == 36 && (a2005069365 == 35 &&  cf==1 )) && a1243394452 == 9)) && (input == 3))) {
    	cf = 0;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a347749795 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a2005069365 == 35 && (a1519100789 == 7 && ( cf==1  && a1153134505 == 36))) && a1243394452 == 9) && (input == 6))) {
    	cf = 0;
    	a240738299 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1519100789 == 7 && ((a1243394452 == 9 && ( cf==1  && (input == 7))) && a2005069365 == 35)) && a1153134505 == 36)) {
    	cf = 0;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a714559100 = 6;
    	a1086754137 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1153134505 == 36 && (a1243394452 == 9 && (a2005069365 == 35 && ((input == 13) &&  cf==1 )))) && a1519100789 == 7)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a48792734 = 33 ;
    	a925870636 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm21(int input) {
    if((a1243394452 == 2 &&  cf==1 )) {
    	if(( cf==1  && a1735753243 == 5)) {
    		calculate_outputm559(input);
    	} 
    	if((a1735753243 == 6 &&  cf==1 )) {
    		calculate_outputm560(input);
    	} 
    	if((a1735753243 == 7 &&  cf==1 )) {
    		calculate_outputm561(input);
    	} 
    } 
    if((a1243394452 == 3 &&  cf==1 )) {
    	if((a1815432985 == 32 &&  cf==1 )) {
    		calculate_outputm562(input);
    	} 
    	if(( cf==1  && a1815432985 == 35)) {
    		calculate_outputm565(input);
    	} 
    	if(( cf==1  && a1815432985 == 36)) {
    		calculate_outputm566(input);
    	} 
    } 
    if(( cf==1  && a1243394452 == 4)) {
    	if(( cf==1  && a685344195 == 7)) {
    		calculate_outputm567(input);
    	} 
    	if((a685344195 == 8 &&  cf==1 )) {
    		calculate_outputm568(input);
    	} 
    	if(( cf==1  && a685344195 == 9)) {
    		calculate_outputm569(input);
    	} 
    	if(( cf==1  && a685344195 == 14)) {
    		calculate_outputm571(input);
    	} 
    } 
    if((a1243394452 == 5 &&  cf==1 )) {
    	if(( cf==1  && a246458106 == 33)) {
    		calculate_outputm572(input);
    	} 
    	if((a246458106 == 36 &&  cf==1 )) {
    		calculate_outputm574(input);
    	} 
    } 
    if(( cf==1  && a1243394452 == 6)) {
    	if(( cf==1  && a132552289 == 6)) {
    		calculate_outputm575(input);
    	} 
    	if((a132552289 == 7 &&  cf==1 )) {
    		calculate_outputm576(input);
    	} 
    	if(( cf==1  && a132552289 == 9)) {
    		calculate_outputm577(input);
    	} 
    	if((a132552289 == 11 &&  cf==1 )) {
    		calculate_outputm578(input);
    	} 
    } 
    if((a1243394452 == 7 &&  cf==1 )) {
    	if((a1204193075 == 34 &&  cf==1 )) {
    		calculate_outputm579(input);
    	} 
    	if((a1204193075 == 35 &&  cf==1 )) {
    		calculate_outputm580(input);
    	} 
    	if((a1204193075 == 36 &&  cf==1 )) {
    		calculate_outputm581(input);
    	} 
    } 
    if((a1243394452 == 8 &&  cf==1 )) {
    	if((a529769874 == 2 &&  cf==1 )) {
    		calculate_outputm582(input);
    	} 
    	if((a529769874 == 3 &&  cf==1 )) {
    		calculate_outputm583(input);
    	} 
    	if((a529769874 == 4 &&  cf==1 )) {
    		calculate_outputm584(input);
    	} 
    	if((a529769874 == 5 &&  cf==1 )) {
    		calculate_outputm585(input);
    	} 
    	if((a529769874 == 6 &&  cf==1 )) {
    		calculate_outputm586(input);
    	} 
    	if(( cf==1  && a529769874 == 7)) {
    		calculate_outputm587(input);
    	} 
    	if(( cf==1  && a529769874 == 8)) {
    		calculate_outputm588(input);
    	} 
    } 
    if(( cf==1  && a1243394452 == 9)) {
    	if(( cf==1  && a1153134505 == 32)) {
    		calculate_outputm589(input);
    	} 
    	if(( cf==1  && a1153134505 == 33)) {
    		calculate_outputm590(input);
    	} 
    	if((a1153134505 == 34 &&  cf==1 )) {
    		calculate_outputm591(input);
    	} 
    	if((a1153134505 == 35 &&  cf==1 )) {
    		calculate_outputm592(input);
    	} 
    	if((a1153134505 == 36 &&  cf==1 )) {
    		calculate_outputm593(input);
    	} 
    } 
}
 void calculate_outputm594(int input) {
    if(((((( cf==1  && a1519100789 == 8) && a113788596 == 32) && a2005069365 == 35) && (input == 14)) && a1561044360 == 32)) {
    	cf = 0;
    	a1428914468 = 10;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a954368445 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 19) && (a2005069365 == 35 && (a113788596 == 32 && (a1519100789 == 8 && ( cf==1  && a1561044360 == 32)))))) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a679327000 = 36 ;
    	a2005069365 = 33 ;
    	a1124714117 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm595(int input) {
    if(((a2005069365 == 35 && (((a1561044360 == 35 &&  cf==1 ) && a113788596 == 32) && (input == 2))) && a1519100789 == 8)) {
    	cf = 0;
    	a727645622 = 36 ;
    	a240738299 = 36 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1561044360 == 35 && ((a113788596 == 32 && (a1519100789 == 8 && ( cf==1  && a2005069365 == 35))) && (input == 11)))) {
    	cf = 0;
    	a240738299 = 36 ;
    	a727645622 = 36 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 17) && (a113788596 == 32 && (a1519100789 == 8 && ((a1561044360 == 35 &&  cf==1 ) && a2005069365 == 35))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm596(int input) {
    if((a113788596 == 32 && (a1519100789 == 8 && (a2005069365 == 35 && (((input == 8) &&  cf==1 ) && a1561044360 == 36))))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a1388584441 = 34 ;
    	a2005069365 = 33 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm597(int input) {
    if(((a113788596 == 33 && (a1519100789 == 8 && (( cf==1  && a137564664 == 12) && a2005069365 == 35))) && (input == 1))) {
    	cf = 0;
    	a1519100789 = 5;
    	a369539608 = 36 ;
    	a347749795 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1519100789 == 8 && (a2005069365 == 35 && ((( cf==1  && a113788596 == 33) && (input == 6)) && a137564664 == 12)))) {
    	cf = 0;
    	a27741386 = 35 ;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a829511935 = 35 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 35 && ((input == 11) && ((a1519100789 == 8 &&  cf==1 ) && a113788596 == 33))) && a137564664 == 12)) {
    	cf = 0;
    	a1958000800 = 13;
    	a1519100789 = 9;
    	a593874874 = 15; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 35 && ((((a137564664 == 12 &&  cf==1 ) && a113788596 == 33) && (input == 15)) && a1519100789 == 8))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a844311967 = 35 ;
    	a1904774218 = 33 ;
    	a205734433 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm598(int input) {
    if((a2005069365 == 35 && (a1519100789 == 8 && ((( cf==1  && a113788596 == 33) && a137564664 == 13) && (input == 12))))) {
    	cf = 0;
    	a1428914468 = 7;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a976704484 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 13) && (a2005069365 == 35 && ((a1519100789 == 8 && (a113788596 == 33 &&  cf==1 )) && a137564664 == 13)))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1775644016 = 8;
    	a1166586546 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm599(int input) {
    if(((input == 20) && (a1519100789 == 8 && (a2005069365 == 35 && (( cf==1  && a113788596 == 33) && a137564664 == 15))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a369539608 = 34 ;
    	a1754726785 = 15; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm600(int input) {
    if((((a1519100789 == 8 && (( cf==1  && (input == 3)) && a113788596 == 33)) && a2005069365 == 35) && a137564664 == 16)) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 35 && ((a1519100789 == 8 && (( cf==1  && (input == 10)) && a137564664 == 16)) && a113788596 == 33))) {
    	cf = 0;
    	a169540124 = 32 ;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a137564664 == 16 && (( cf==1  && (input == 12)) && a2005069365 == 35)) && a1519100789 == 8) && a113788596 == 33)) {
    	cf = 0;
    	a1428914468 = 10;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a954368445 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a2005069365 == 35 && ((a1519100789 == 8 &&  cf==1 ) && (input == 15))) && a113788596 == 33) && a137564664 == 16)) {
    	cf = 0;
    	a369539608 = 32 ;
    	a1904774218 = 35 ;
    	a2005069365 = 32 ;
    	a1124714117 = 1; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm601(int input) {
    if(((a1519100789 == 8 && ((( cf==1  && (input == 2)) && a113788596 == 33) && a137564664 == 17)) && a2005069365 == 35)) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a2005069365 = 32 ;
    	a369539608 = 36 ;
    	a1577567933 = 36 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a113788596 == 33 && ((a1519100789 == 8 && (a2005069365 == 35 && (a137564664 == 17 &&  cf==1 ))) && (input == 5)))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1093326457 = 35 ;
    	a714559100 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm602(int input) {
    if(((((a2005069365 == 35 && ( cf==1  && a1688003115 == 7)) && a1519100789 == 8) && (input == 12)) && a113788596 == 34)) {
    	cf = 0;
    	a369539608 = 34 ;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a1754726785 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 35 && (((( cf==1  && a1688003115 == 7) && a113788596 == 34) && (input == 14)) && a1519100789 == 8))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a1428914468 = 13;
    	a2005069365 = 34 ;
    	a2125137407 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a113788596 == 34 && (a1519100789 == 8 && ((a1688003115 == 7 && ( cf==1  && (input == 15))) && a2005069365 == 35)))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a714559100 = 7;
    	a2005069365 = 34 ;
    	a1166586546 = 15; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a1688003115 == 7 && (( cf==1  && (input == 19)) && a2005069365 == 35)) && a1519100789 == 8) && a113788596 == 34)) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a369539608 = 34 ;
    	a2005069365 = 32 ;
    	a1754726785 = 15; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm603(int input) {
    if((a2005069365 == 35 && (a1519100789 == 8 && ((( cf==1  && a113788596 == 34) && (input == 1)) && a1688003115 == 8)))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a48792734 = 33 ;
    	a925870636 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1688003115 == 8 && ((a1519100789 == 8 && (( cf==1  && a2005069365 == 35) && (input == 2))) && a113788596 == 34))) {
    	cf = 0;
    	a88077474 = 36 ;
    	a744476156 = 33 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1519100789 == 8 && (a113788596 == 34 && ((a1688003115 == 8 && (a2005069365 == 35 &&  cf==1 )) && (input == 4))))) {
    	cf = 0;
    	a1519100789 = 9;
    	a369539608 = 35 ;
    	a1958000800 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1688003115 == 8 && ((a1519100789 == 8 && (a113788596 == 34 &&  cf==1 )) && (input == 17))) && a2005069365 == 35)) {
    	cf = 0;
    	a1052150692 = 8;
    	a1519100789 = 2;
    	a1144659688 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm604(int input) {
    if(((input == 5) && (a1688003115 == 12 && (a113788596 == 34 && (a1519100789 == 8 && (a2005069365 == 35 &&  cf==1 )))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1795880353 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a113788596 == 34 && ((a1519100789 == 8 && ( cf==1  && (input == 20))) && a2005069365 == 35)) && a1688003115 == 12)) {
    	cf = 0;
    	a1186984341 = 32 ;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1684687706 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm605(int input) {
    if((((a1519100789 == 8 && (a2005069365 == 35 && ( cf==1  && (input == 3)))) && a113788596 == 35) && a1739072993 == 32)) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 5;
    	a2005069365 = 36 ;
    	a1089968358 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1519100789 == 8 && (a2005069365 == 35 && ((a113788596 == 35 &&  cf==1 ) && (input == 6)))) && a1739072993 == 32)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1843210244 = 35 ;
    	a1684687706 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 10) && (((a1739072993 == 32 && ( cf==1  && a1519100789 == 8)) && a113788596 == 35) && a2005069365 == 35))) {
    	cf = 0;
    	a604409338 = 36 ;
    	a1519100789 = 6;
    	a1688003115 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 35 && (a1519100789 == 8 && ((( cf==1  && (input == 15)) && a1739072993 == 32) && a113788596 == 35)))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a2124036967 = 35 ;
    	a1942309322 = 34 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a1739072993 == 32 && ( cf==1  && a1519100789 == 8)) && (input == 13)) && a2005069365 == 35) && a113788596 == 35)) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a679327000 = 36 ;
    	a1124714117 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm606(int input) {
    if((a2005069365 == 35 && ((input == 7) && (a1519100789 == 8 && (a113788596 == 35 && ( cf==1  && a1739072993 == 34)))))) {
    	cf = 0;
    	a113788596 = 36 ;
    	a772592654 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm607(int input) {
    if((a113788596 == 35 && ((a1519100789 == 8 && (a1739072993 == 36 && (a2005069365 == 35 &&  cf==1 ))) && (input == 5)))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a491478835 = 33 ;
    	a714559100 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1519100789 == 8 && (((( cf==1  && a2005069365 == 35) && a113788596 == 35) && a1739072993 == 36) && (input == 19)))) {
    	cf = 0;
    	a1950243878 = 32 ;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 15; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm608(int input) {
    if((((input == 1) && ((( cf==1  && a113788596 == 36) && a1519100789 == 8) && a2005069365 == 35)) && a772592654 == 5)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 34 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1519100789 == 8 && (a2005069365 == 35 && ((input == 10) && (a113788596 == 36 && (a772592654 == 5 &&  cf==1 )))))) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a2005069365 = 33 ;
    	a747683138 = 32 ;
    	a2110599067 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1519100789 == 8 && ((a113788596 == 36 &&  cf==1 ) && a2005069365 == 35)) && a772592654 == 5) && (input == 15))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a353267992 = 36 ;
    	a107446547 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a113788596 == 36 && (a2005069365 == 35 && ((( cf==1  && (input == 20)) && a1519100789 == 8) && a772592654 == 5)))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a2135613870 = 34 ;
    	a107446547 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm609(int input) {
    if((((a2005069365 == 35 && ((input == 12) && (a772592654 == 6 &&  cf==1 ))) && a1519100789 == 8) && a113788596 == 36)) {
    	cf = 0;
    	a1519100789 = 7;
    	a1243394452 = 4;
    	a685344195 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1519100789 == 8 && (a772592654 == 6 && (( cf==1  && a2005069365 == 35) && a113788596 == 36))) && (input == 14))) {
    	cf = 0;
    	a1325377146 = 36 ;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a772592654 == 6 && (a2005069365 == 35 && (a113788596 == 36 && ( cf==1  && a1519100789 == 8)))) && (input == 16))) {
    	cf = 0;
    	a1153134505 = 32 ;
    	a240738299 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm610(int input) {
    if((a1519100789 == 8 && (a772592654 == 7 && (a2005069365 == 35 && (a113788596 == 36 && ( cf==1  && (input == 1))))))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 10;
    	a920118831 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a2005069365 == 35 && ((a113788596 == 36 &&  cf==1 ) && (input == 3))) && a1519100789 == 8) && a772592654 == 7)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a569036257 = 10;
    	a1838812917 = 33 ;
    	a920118831 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 35 && (a1519100789 == 8 && (a772592654 == 7 && ((input == 12) &&  cf==1 )))) && a113788596 == 36)) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 19) && (a1519100789 == 8 && ((a2005069365 == 35 && ( cf==1  && a772592654 == 7)) && a113788596 == 36)))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm611(int input) {
    if(((input == 8) && (a2005069365 == 35 && (a772592654 == 9 && (a1519100789 == 8 && ( cf==1  && a113788596 == 36)))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a113788596 == 36 && (a772592654 == 9 && ((input == 11) &&  cf==1 ))) && a2005069365 == 35) && a1519100789 == 8)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a525429632 = 33 ;
    	a969893172 = 33 ;
    	a1428914468 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 13) && ((a113788596 == 36 && ((a772592654 == 9 &&  cf==1 ) && a2005069365 == 35)) && a1519100789 == 8))) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((input == 15) && (( cf==1  && a113788596 == 36) && a1519100789 == 8)) && a772592654 == 9) && a2005069365 == 35)) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm613(int input) {
    if(((a1519100789 == 8 && ((input == 4) && (a772592654 == 11 && (a113788596 == 36 &&  cf==1 )))) && a2005069365 == 35)) {
    	cf = 0;
    	a1519100789 = 2;
    	a451941968 = 35 ;
    	a1052150692 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a772592654 == 11 && ((a2005069365 == 35 && (a113788596 == 36 && ( cf==1  && (input == 13)))) && a1519100789 == 8))) {
    	cf = 0;
    	a1129866701 = 11;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1519100789 == 8 && (a2005069365 == 35 && (a113788596 == 36 && (a772592654 == 11 && ((input == 15) &&  cf==1 )))))) {
    	cf = 0;
    	a1519100789 = 2;
    	a451941968 = 35 ;
    	a1052150692 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((a1519100789 == 8 &&  cf==1 ) && a2005069365 == 35) && (input == 20)) && a772592654 == 11) && a113788596 == 36)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a2124036967 = 35 ;
    	a1942309322 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm22(int input) {
    if((a113788596 == 32 &&  cf==1 )) {
    	if((a1561044360 == 32 &&  cf==1 )) {
    		calculate_outputm594(input);
    	} 
    	if((a1561044360 == 35 &&  cf==1 )) {
    		calculate_outputm595(input);
    	} 
    	if((a1561044360 == 36 &&  cf==1 )) {
    		calculate_outputm596(input);
    	} 
    } 
    if(( cf==1  && a113788596 == 33)) {
    	if(( cf==1  && a137564664 == 12)) {
    		calculate_outputm597(input);
    	} 
    	if(( cf==1  && a137564664 == 13)) {
    		calculate_outputm598(input);
    	} 
    	if(( cf==1  && a137564664 == 15)) {
    		calculate_outputm599(input);
    	} 
    	if(( cf==1  && a137564664 == 16)) {
    		calculate_outputm600(input);
    	} 
    	if((a137564664 == 17 &&  cf==1 )) {
    		calculate_outputm601(input);
    	} 
    } 
    if(( cf==1  && a113788596 == 34)) {
    	if(( cf==1  && a1688003115 == 7)) {
    		calculate_outputm602(input);
    	} 
    	if(( cf==1  && a1688003115 == 8)) {
    		calculate_outputm603(input);
    	} 
    	if(( cf==1  && a1688003115 == 12)) {
    		calculate_outputm604(input);
    	} 
    } 
    if(( cf==1  && a113788596 == 35)) {
    	if((a1739072993 == 32 &&  cf==1 )) {
    		calculate_outputm605(input);
    	} 
    	if(( cf==1  && a1739072993 == 34)) {
    		calculate_outputm606(input);
    	} 
    	if((a1739072993 == 36 &&  cf==1 )) {
    		calculate_outputm607(input);
    	} 
    } 
    if(( cf==1  && a113788596 == 36)) {
    	if(( cf==1  && a772592654 == 5)) {
    		calculate_outputm608(input);
    	} 
    	if((a772592654 == 6 &&  cf==1 )) {
    		calculate_outputm609(input);
    	} 
    	if((a772592654 == 7 &&  cf==1 )) {
    		calculate_outputm610(input);
    	} 
    	if((a772592654 == 9 &&  cf==1 )) {
    		calculate_outputm611(input);
    	} 
    	if((a772592654 == 11 &&  cf==1 )) {
    		calculate_outputm613(input);
    	} 
    } 
}
 void calculate_outputm614(int input) {
    if(((((((input == 7) &&  cf==1 ) && a1872268177 == 32) && a1958000800 == 6) && a1519100789 == 9) && a2005069365 == 35)) {
    	cf = 0;
    	a2124036967 = 32 ;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a1194623510 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 11) && ((a1958000800 == 6 && (a2005069365 == 35 &&  cf==1 )) && a1519100789 == 9)) && a1872268177 == 32)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a2124036967 = 32 ;
    	a1194623510 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1958000800 == 6 && (a1519100789 == 9 && (a1872268177 == 32 && ((input == 19) &&  cf==1 )))) && a2005069365 == 35)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a1904774218 = 32 ;
    	a2005069365 = 36 ;
    	a569036257 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm616(int input) {
    if(((((( cf==1  && a2005069365 == 35) && (input == 19)) && a1872268177 == 34) && a1519100789 == 9) && a1958000800 == 6)) {
    	cf = 0;
    	a1815432985 = 36 ;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a569036257 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm617(int input) {
    if(((((( cf==1  && a1958000800 == 6) && a2005069365 == 35) && a1519100789 == 9) && (input == 16)) && a1872268177 == 36)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a465336174 = 35 ;
    	a2005069365 = 36 ;
    	a569036257 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm618(int input) {
    if(((a2005069365 == 35 && ((a207863872 == 8 && (a1519100789 == 9 &&  cf==1 )) && (input == 2))) && a1958000800 == 7)) {
    	cf = 0;
    	a240738299 = 32 ;
    	a1756771009 = 34 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm619(int input) {
    if((a2005069365 == 35 && ((((a207863872 == 9 &&  cf==1 ) && (input == 8)) && a1958000800 == 7) && a1519100789 == 9))) {
    	cf = 0;
    	a1498704550 = 34 ;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a714559100 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm620(int input) {
    if(((a1958000800 == 7 && ((a1519100789 == 9 && ( cf==1  && a207863872 == 10)) && (input == 2))) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 32 ;
    	a927953139 = 33 ;
    	a1944506598 = 33 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((input == 5) && (( cf==1  && a1958000800 == 7) && a2005069365 == 35)) && a1519100789 == 9) && a207863872 == 10)) {
    	cf = 0;
    	a1428914468 = 7;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a976704484 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm621(int input) {
    if((a2005069365 == 35 && ((input == 3) && (a1958000800 == 7 && ((a207863872 == 12 &&  cf==1 ) && a1519100789 == 9))))) {
    	cf = 0;
    	a1519100789 = 3;
    	a88077474 = 35 ;
    	a534598694 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm622(int input) {
    if(((((a2005069365 == 35 && ( cf==1  && a1958000800 == 7)) && a1519100789 == 9) && (input == 3)) && a207863872 == 13)) {
    	cf = 0;
    	a714559100 = 5;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a1089968358 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1958000800 == 7 && ((input == 5) && (a2005069365 == 35 && (a207863872 == 13 && ( cf==1  && a1519100789 == 9)))))) {
    	cf = 0;
    	a369539608 = 34 ;
    	a1904774218 = 35 ;
    	a2005069365 = 32 ;
    	a1754726785 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1519100789 == 9 && (a2005069365 == 35 && ((a207863872 == 13 && (a1958000800 == 7 &&  cf==1 )) && (input == 13))))) {
    	cf = 0;
    	a1519100789 = 7;
    	a246458106 = 36 ;
    	a1243394452 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1958000800 == 7 && (a2005069365 == 35 && ((a207863872 == 13 && ( cf==1  && (input == 19))) && a1519100789 == 9)))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a1093326457 = 35 ;
    	a969893172 = 34 ;
    	a714559100 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm623(int input) {
    if(((a1958000800 == 7 && (a1519100789 == 9 && (((input == 1) &&  cf==1 ) && a2005069365 == 35))) && a207863872 == 14)) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 8) && ((a207863872 == 14 && ((a1958000800 == 7 &&  cf==1 ) && a2005069365 == 35)) && a1519100789 == 9))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a2124036967 = 32 ;
    	a969893172 = 36 ;
    	a1194623510 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 35 && (a1519100789 == 9 && (a207863872 == 14 && (( cf==1  && a1958000800 == 7) && (input == 17)))))) {
    	cf = 0;
    	a2124036967 = 32 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a1194623510 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm624(int input) {
    if((((a1184734075 == 8 && (( cf==1  && a1519100789 == 9) && a1958000800 == 8)) && (input == 4)) && a2005069365 == 35)) {
    	cf = 0;
    	a1428914468 = 13;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a2125137407 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm625(int input) {
    if(((((a2005069365 == 35 && ( cf==1  && a1184734075 == 9)) && a1519100789 == 9) && (input == 1)) && a1958000800 == 8)) {
    	cf = 0;
    	a679327000 = 32 ;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a103910758 = 33 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1519100789 == 9 && ((input == 5) && (a2005069365 == 35 && (a1184734075 == 9 && ( cf==1  && a1958000800 == 8)))))) {
    	cf = 0;
    	a240738299 = 35 ;
    	a1153134505 = 36 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((input == 11) && (a1958000800 == 8 &&  cf==1 )) && a1184734075 == 9) && a1519100789 == 9) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 10;
    	a954368445 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 16) && (a1519100789 == 9 && ((a1184734075 == 9 && (a2005069365 == 35 &&  cf==1 )) && a1958000800 == 8)))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a844311967 = 35 ;
    	a205734433 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm626(int input) {
    if(((((( cf==1  && a2005069365 == 35) && a1958000800 == 8) && (input == 6)) && a1184734075 == 10) && a1519100789 == 9)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a747683138 = 35 ;
    	a2059681452 = 33 ;
    	a1039723590 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1958000800 == 8 && (a2005069365 == 35 && (a1519100789 == 9 && (((input == 13) &&  cf==1 ) && a1184734075 == 10))))) {
    	cf = 0;
    	a1519100789 = 2;
    	a738616794 = 34 ;
    	a1052150692 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm627(int input) {
    if((((a1184734075 == 11 && ((a1519100789 == 9 &&  cf==1 ) && a2005069365 == 35)) && a1958000800 == 8) && (input == 3))) {
    	cf = 0;
    	a679327000 = 34 ;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a603781876 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1958000800 == 8 && (a1184734075 == 11 &&  cf==1 )) && (input == 13)) && a1519100789 == 9) && a2005069365 == 35)) {
    	cf = 0;
    	a113788596 = 32 ;
    	a1561044360 = 35 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 35 && (((input == 19) && ((a1184734075 == 11 &&  cf==1 ) && a1958000800 == 8)) && a1519100789 == 9))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 10;
    	a596573336 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm628(int input) {
    if(((((( cf==1  && (input == 8)) && a2005069365 == 35) && a1184734075 == 12) && a1519100789 == 9) && a1958000800 == 8)) {
    	cf = 0;
    	a353267992 = 36 ;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a107446547 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 16) && (a1184734075 == 12 && ((a1958000800 == 8 &&  cf==1 ) && a1519100789 == 9))) && a2005069365 == 35)) {
    	cf = 0;
    	a1958000800 = 12;
    	a798343693 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1519100789 == 9 && (((input == 17) && (a1184734075 == 12 && (a2005069365 == 35 &&  cf==1 ))) && a1958000800 == 8))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a369539608 = 36 ;
    	a1577567933 = 36 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm629(int input) {
    if(((((a1519100789 == 9 && ( cf==1  && a1958000800 == 8)) && a2005069365 == 35) && (input == 5)) && a1184734075 == 13)) {
    	cf = 0;
    	a113788596 = 34 ;
    	a1519100789 = 8;
    	a1688003115 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm630(int input) {
    if(((a2005069365 == 35 && (a1519100789 == 9 && ((a1184734075 == 14 &&  cf==1 ) && (input == 4)))) && a1958000800 == 8)) {
    	cf = 0;
    	a240738299 = 32 ;
    	a1756771009 = 36 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 35 && (a1958000800 == 8 && ((a1184734075 == 14 && ( cf==1  && (input == 12))) && a1519100789 == 9)))) {
    	cf = 0;
    	a1519100789 = 7;
    	a1204193075 = 34 ;
    	a1243394452 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1958000800 == 8 && (((( cf==1  && (input == 13)) && a1519100789 == 9) && a2005069365 == 35) && a1184734075 == 14))) {
    	cf = 0;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a347749795 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm631(int input) {
    if((((input == 11) && (a1958000800 == 9 && (a1754726785 == 8 && (a1519100789 == 9 &&  cf==1 )))) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 32 ;
    	a927953139 = 36 ;
    	a169540124 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm632(int input) {
    if((a1754726785 == 10 && ((((a1958000800 == 9 &&  cf==1 ) && a2005069365 == 35) && a1519100789 == 9) && (input == 6)))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 10;
    	a596573336 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a2005069365 == 35 && (a1754726785 == 10 && (a1519100789 == 9 && (a1958000800 == 9 &&  cf==1 )))) && (input == 15))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a928570136 = 33 ;
    	a107446547 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a1754726785 == 10 && ( cf==1  && a1519100789 == 9)) && a1958000800 == 9) && a2005069365 == 35) && (input == 16))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a569036257 = 10;
    	a1838812917 = 33 ;
    	a920118831 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm633(int input) {
    if((a2005069365 == 35 && (a1958000800 == 9 && (((a1519100789 == 9 &&  cf==1 ) && (input == 16)) && a1754726785 == 11)))) {
    	cf = 0;
    	a206599328 = 35 ;
    	a1838812917 = 35 ;
    	a2005069365 = 36 ;
    	a714559100 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 35 && (a1958000800 == 9 && (a1519100789 == 9 && (( cf==1  && a1754726785 == 11) && (input == 20)))))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2005069365 = 36 ;
    	a107446547 = 15;
    	a275125637 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm634(int input) {
    if(((a2002331280 == 33 && (a2005069365 == 35 && (a1958000800 == 10 && (a1519100789 == 9 &&  cf==1 )))) && (input == 1))) {
    	cf = 0;
    	a88077474 = 34 ;
    	a2016510333 = 33 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 11) && (a1958000800 == 10 && (a1519100789 == 9 && (a2005069365 == 35 && (a2002331280 == 33 &&  cf==1 )))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm635(int input) {
    if(((((( cf==1  && (input == 5)) && a2005069365 == 35) && a1519100789 == 9) && a2002331280 == 35) && a1958000800 == 10)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm636(int input) {
    if(((a2002331280 == 36 && ((( cf==1  && a2005069365 == 35) && a1958000800 == 10) && a1519100789 == 9)) && (input == 10))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a67466277 = 35 ;
    	a969893172 = 35 ;
    	a685667843 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1958000800 == 10 && (a2005069365 == 35 && (a1519100789 == 9 && (( cf==1  && (input == 13)) && a2002331280 == 36))))) {
    	cf = 0;
    	a240738299 = 34 ;
    	a1519100789 = 4;
    	a1109056640 = 1; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 16) && (((a1519100789 == 9 && (a1958000800 == 10 &&  cf==1 )) && a2002331280 == 36) && a2005069365 == 35))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1684687706 = 9;
    	a2059681452 = 34 ;
    	a892217980 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 1) && (((a1519100789 == 9 && (a1958000800 == 10 &&  cf==1 )) && a2005069365 == 35) && a2002331280 == 36))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a1795880353 = 35 ;
    	a107446547 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm637(int input) {
    if(((input == 6) && ((a2005069365 == 35 && ((a369539608 == 32 &&  cf==1 ) && a1519100789 == 9)) && a1958000800 == 11))) {
    	cf = 0;
    	a685667843 = 14;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a2138261183 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 35 && (((a369539608 == 32 && (a1519100789 == 9 &&  cf==1 )) && a1958000800 == 11) && (input == 8)))) {
    	cf = 0;
    	a969893172 = 35 ;
    	a169540124 = 36 ;
    	a2005069365 = 34 ;
    	a685667843 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a369539608 == 32 && ((a1958000800 == 11 && (a2005069365 == 35 && (a1519100789 == 9 &&  cf==1 ))) && (input == 14)))) {
    	cf = 0;
    	a67466277 = 35 ;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm638(int input) {
    if((a2005069365 == 35 && (((((input == 4) &&  cf==1 ) && a1958000800 == 11) && a369539608 == 33) && a1519100789 == 9))) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 11;
    	a1089968358 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a1519100789 == 9 && (a1958000800 == 11 && ( cf==1  && a369539608 == 33))) && (input == 10)) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1571676929 = 34 ;
    	a1904774218 = 34 ;
    	a925870636 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm639(int input) {
    if((a1958000800 == 11 && (a2005069365 == 35 && (a369539608 == 34 && ((a1519100789 == 9 &&  cf==1 ) && (input == 12)))))) {
    	cf = 0;
    	a246458106 = 36 ;
    	a1519100789 = 7;
    	a1243394452 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1958000800 == 11 && ((( cf==1  && (input == 17)) && a2005069365 == 35) && a1519100789 == 9)) && a369539608 == 34)) {
    	cf = 0;
    	a1519100789 = 7;
    	a246458106 = 36 ;
    	a1243394452 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm640(int input) {
    if((a1519100789 == 9 && ((a1958000800 == 11 && (( cf==1  && a369539608 == 35) && (input == 14))) && a2005069365 == 35))) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1519100789 == 9 && ( cf==1  && a1958000800 == 11)) && a369539608 == 35) && (input == 16)) && a2005069365 == 35)) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a1690193643 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1958000800 == 11 && (((a1519100789 == 9 && ((input == 19) &&  cf==1 )) && a2005069365 == 35) && a369539608 == 35))) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm641(int input) {
    if((a369539608 == 36 && (a2005069365 == 35 && ((input == 4) && (a1519100789 == 9 && ( cf==1  && a1958000800 == 11)))))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 11;
    	a2005069365 = 33 ;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 7) && (a1519100789 == 9 && (a369539608 == 36 && (a1958000800 == 11 &&  cf==1 )))) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1239184736 = 35 ;
    	a2059681452 = 34 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1958000800 == 11 && (a1519100789 == 9 && (a369539608 == 36 && ((input == 10) && (a2005069365 == 35 &&  cf==1 )))))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1239184736 = 35 ;
    	a1684687706 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 16) && (a369539608 == 36 && ((a2005069365 == 35 && (a1958000800 == 11 &&  cf==1 )) && a1519100789 == 9)))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm643(int input) {
    if((a798343693 == 7 && (((input == 4) && (a1519100789 == 9 && ( cf==1  && a2005069365 == 35))) && a1958000800 == 12))) {
    	cf = 0;
    	a88077474 = 33 ;
    	a928570136 = 36 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 35 && ((a1958000800 == 12 && (( cf==1  && (input == 12)) && a1519100789 == 9)) && a798343693 == 7))) {
    	cf = 0;
    	a1428914468 = 13;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a2125137407 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 15) && (a798343693 == 7 && ((( cf==1  && a1519100789 == 9) && a2005069365 == 35) && a1958000800 == 12)))) {
    	cf = 0;
    	a834910632 = 32 ;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a798343693 == 7 && ((input == 19) && (a1958000800 == 12 && (a2005069365 == 35 &&  cf==1 )))) && a1519100789 == 9)) {
    	cf = 0;
    	a27741386 = 36 ;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a792575314 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm644(int input) {
    if(((a1958000800 == 12 && ((a1519100789 == 9 && ((input == 2) &&  cf==1 )) && a2005069365 == 35)) && a798343693 == 9)) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1775644016 = 8;
    	a2005069365 = 36 ;
    	a1166586546 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a798343693 == 9 && (((input == 7) && (a1958000800 == 12 && (a1519100789 == 9 &&  cf==1 ))) && a2005069365 == 35))) {
    	cf = 0;
    	a1519100789 = 8;
    	a113788596 = 33 ;
    	a137564664 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 10) && (a798343693 == 9 && (((a2005069365 == 35 &&  cf==1 ) && a1958000800 == 12) && a1519100789 == 9)))) {
    	cf = 0;
    	a925870636 = 10;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a666963702 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm645(int input) {
    if((a2005069365 == 35 && (a1519100789 == 9 && ((input == 6) && (a798343693 == 10 && (a1958000800 == 12 &&  cf==1 )))))) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1958000800 == 12 && (a2005069365 == 35 && ((input == 10) && (a798343693 == 10 && (a1519100789 == 9 &&  cf==1 )))))) {
    	cf = 0;
    	a925870636 = 10;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a666963702 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((( cf==1  && (input == 15)) && a798343693 == 10) && a1958000800 == 12) && a1519100789 == 9) && a2005069365 == 35)) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a2005069365 = 36 ;
    	a1775644016 = 8;
    	a1166586546 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1958000800 == 12 && (a2005069365 == 35 && (a1519100789 == 9 && (a798343693 == 10 && ((input == 20) &&  cf==1 )))))) {
    	cf = 0;
    	a2005069365 = 36 ;
    	a1838812917 = 36 ;
    	a1775644016 = 8;
    	a1166586546 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm647(int input) {
    if(((((input == 4) && (( cf==1  && a2005069365 == 35) && a1519100789 == 9)) && a593874874 == 10) && a1958000800 == 13)) {
    	cf = 0;
    	a353267992 = 36 ;
    	a2005069365 = 36 ;
    	a1838812917 = 34 ;
    	a107446547 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1958000800 == 13 && ((a1519100789 == 9 && ( cf==1  && a2005069365 == 35)) && (input == 7))) && a593874874 == 10)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a27741386 = 32 ;
    	a928570136 = 34 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a593874874 == 10 && ((input == 13) && (a1958000800 == 13 && (a1519100789 == 9 &&  cf==1 )))) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a1428914468 = 7;
    	a969893172 = 33 ;
    	a976704484 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm648(int input) {
    if((a593874874 == 12 && ((((input == 3) && ( cf==1  && a1958000800 == 13)) && a2005069365 == 35) && a1519100789 == 9))) {
    	cf = 0;
    	a1519100789 = 6;
    	a604409338 = 33 ;
    	a954368445 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a2005069365 == 35 && (a1958000800 == 13 && (( cf==1  && a1519100789 == 9) && a593874874 == 12))) && (input == 10))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a714559100 = 5;
    	a2005069365 = 34 ;
    	a1079106761 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((a1519100789 == 9 && (a1958000800 == 13 &&  cf==1 )) && a2005069365 == 35) && a593874874 == 12) && (input == 14))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a1428914468 = 7;
    	a2005069365 = 34 ;
    	a976704484 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a1519100789 == 9 && ((input == 20) && (a593874874 == 12 &&  cf==1 ))) && a1958000800 == 13) && a2005069365 == 35)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 12;
    	a1682504076 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm649(int input) {
    if((a1958000800 == 13 && (a1519100789 == 9 && ((a593874874 == 13 && ((input == 1) &&  cf==1 )) && a2005069365 == 35)))) {
    	cf = 0;
    	a593874874 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((a2005069365 == 35 &&  cf==1 ) && (input == 7)) && a1958000800 == 13) && a593874874 == 13) && a1519100789 == 9)) {
    	cf = 0;
    	a1684674520 = 36 ;
    	a369539608 = 34 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a593874874 == 13 && (((input == 15) && ( cf==1  && a1519100789 == 9)) && a2005069365 == 35)) && a1958000800 == 13)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a650110038 = 34 ;
    	a969893172 = 32 ;
    	a349181387 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1958000800 == 13 && (((input == 19) && (a593874874 == 13 &&  cf==1 )) && a2005069365 == 35)) && a1519100789 == 9)) {
    	cf = 0;
    	a679327000 = 34 ;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm650(int input) {
    if((a2005069365 == 35 && ((a593874874 == 14 && (a1958000800 == 13 && ((input == 5) &&  cf==1 ))) && a1519100789 == 9))) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a679327000 = 33 ;
    	a2065134388 = 17; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a593874874 == 14 && ((( cf==1  && a1958000800 == 13) && a1519100789 == 9) && (input == 10))) && a2005069365 == 35)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a1815432985 = 36 ;
    	a2005069365 = 36 ;
    	a569036257 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm651(int input) {
    if((a593874874 == 15 && (((( cf==1  && a2005069365 == 35) && a1958000800 == 13) && a1519100789 == 9) && (input == 1)))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 11;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 35 && (a593874874 == 15 && ((input == 6) && (a1519100789 == 9 && (a1958000800 == 13 &&  cf==1 )))))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a2005069365 = 36 ;
    	a1775644016 = 6;
    	a200393381 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm652(int input) {
    if(((a1519100789 == 9 && (a593874874 == 16 && (a2005069365 == 35 && ((input == 7) &&  cf==1 )))) && a1958000800 == 13)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a569036257 = 6;
    	a205734433 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((input == 12) && (a1519100789 == 9 && ( cf==1  && a593874874 == 16))) && a1958000800 == 13) && a2005069365 == 35)) {
    	cf = 0;
    	a569036257 = 10;
    	a1838812917 = 33 ;
    	a2005069365 = 36 ;
    	a920118831 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 35 && ((a1958000800 == 13 && (a593874874 == 16 && (a1519100789 == 9 &&  cf==1 ))) && (input == 15)))) {
    	cf = 0;
    	a2124036967 = 36 ;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a524102808 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1519100789 == 9 && (a1958000800 == 13 && ((a2005069365 == 35 &&  cf==1 ) && (input == 19)))) && a593874874 == 16)) {
    	cf = 0;
    	a1519100789 = 7;
    	a1204193075 = 34 ;
    	a1243394452 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm23(int input) {
    if((a1958000800 == 6 &&  cf==1 )) {
    	if((a1872268177 == 32 &&  cf==1 )) {
    		calculate_outputm614(input);
    	} 
    	if(( cf==1  && a1872268177 == 34)) {
    		calculate_outputm616(input);
    	} 
    	if(( cf==1  && a1872268177 == 36)) {
    		calculate_outputm617(input);
    	} 
    } 
    if(( cf==1  && a1958000800 == 7)) {
    	if(( cf==1  && a207863872 == 8)) {
    		calculate_outputm618(input);
    	} 
    	if(( cf==1  && a207863872 == 9)) {
    		calculate_outputm619(input);
    	} 
    	if(( cf==1  && a207863872 == 10)) {
    		calculate_outputm620(input);
    	} 
    	if(( cf==1  && a207863872 == 12)) {
    		calculate_outputm621(input);
    	} 
    	if((a207863872 == 13 &&  cf==1 )) {
    		calculate_outputm622(input);
    	} 
    	if(( cf==1  && a207863872 == 14)) {
    		calculate_outputm623(input);
    	} 
    } 
    if(( cf==1  && a1958000800 == 8)) {
    	if(( cf==1  && a1184734075 == 8)) {
    		calculate_outputm624(input);
    	} 
    	if(( cf==1  && a1184734075 == 9)) {
    		calculate_outputm625(input);
    	} 
    	if((a1184734075 == 10 &&  cf==1 )) {
    		calculate_outputm626(input);
    	} 
    	if(( cf==1  && a1184734075 == 11)) {
    		calculate_outputm627(input);
    	} 
    	if((a1184734075 == 12 &&  cf==1 )) {
    		calculate_outputm628(input);
    	} 
    	if((a1184734075 == 13 &&  cf==1 )) {
    		calculate_outputm629(input);
    	} 
    	if((a1184734075 == 14 &&  cf==1 )) {
    		calculate_outputm630(input);
    	} 
    } 
    if((a1958000800 == 9 &&  cf==1 )) {
    	if(( cf==1  && a1754726785 == 8)) {
    		calculate_outputm631(input);
    	} 
    	if((a1754726785 == 10 &&  cf==1 )) {
    		calculate_outputm632(input);
    	} 
    	if(( cf==1  && a1754726785 == 11)) {
    		calculate_outputm633(input);
    	} 
    } 
    if(( cf==1  && a1958000800 == 10)) {
    	if((a2002331280 == 33 &&  cf==1 )) {
    		calculate_outputm634(input);
    	} 
    	if((a2002331280 == 35 &&  cf==1 )) {
    		calculate_outputm635(input);
    	} 
    	if((a2002331280 == 36 &&  cf==1 )) {
    		calculate_outputm636(input);
    	} 
    } 
    if((a1958000800 == 11 &&  cf==1 )) {
    	if(( cf==1  && a369539608 == 32)) {
    		calculate_outputm637(input);
    	} 
    	if((a369539608 == 33 &&  cf==1 )) {
    		calculate_outputm638(input);
    	} 
    	if(( cf==1  && a369539608 == 34)) {
    		calculate_outputm639(input);
    	} 
    	if(( cf==1  && a369539608 == 35)) {
    		calculate_outputm640(input);
    	} 
    	if(( cf==1  && a369539608 == 36)) {
    		calculate_outputm641(input);
    	} 
    } 
    if(( cf==1  && a1958000800 == 12)) {
    	if(( cf==1  && a798343693 == 7)) {
    		calculate_outputm643(input);
    	} 
    	if(( cf==1  && a798343693 == 9)) {
    		calculate_outputm644(input);
    	} 
    	if(( cf==1  && a798343693 == 10)) {
    		calculate_outputm645(input);
    	} 
    } 
    if((a1958000800 == 13 &&  cf==1 )) {
    	if(( cf==1  && a593874874 == 10)) {
    		calculate_outputm647(input);
    	} 
    	if((a593874874 == 12 &&  cf==1 )) {
    		calculate_outputm648(input);
    	} 
    	if((a593874874 == 13 &&  cf==1 )) {
    		calculate_outputm649(input);
    	} 
    	if(( cf==1  && a593874874 == 14)) {
    		calculate_outputm650(input);
    	} 
    	if(( cf==1  && a593874874 == 15)) {
    		calculate_outputm651(input);
    	} 
    	if((a593874874 == 16 &&  cf==1 )) {
    		calculate_outputm652(input);
    	} 
    } 
}
 void calculate_outputm653(int input) {
    if((((input == 4) && (a927953139 == 32 && (a1838812917 == 32 && ( cf==1  && a1096033747 == 33)))) && a2005069365 == 36)) {
    	cf = 0;
    	a844311967 = 32 ;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a749536178 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm654(int input) {
    if((a1096033747 == 34 && (((( cf==1  && (input == 7)) && a927953139 == 32) && a1838812917 == 32) && a2005069365 == 36))) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a569036257 = 6;
    	a205734433 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1096033747 == 34 && ((((input == 8) && ( cf==1  && a2005069365 == 36)) && a1838812917 == 32) && a927953139 == 32))) {
    	cf = 0;
    	a1468138070 = 34 ;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a714559100 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 36 && ((((a927953139 == 32 &&  cf==1 ) && a1096033747 == 34) && a1838812917 == 32) && (input == 17)))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 10;
    	a954368445 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm656(int input) {
    if((a927953139 == 33 && (((( cf==1  && a1838812917 == 32) && (input == 1)) && a2005069365 == 36) && a1944506598 == 33))) {
    	cf = 0;
    	a27741386 = 36 ;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a792575314 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm657(int input) {
    if((a927953139 == 33 && ((input == 3) && (a1838812917 == 32 && (a2005069365 == 36 && ( cf==1  && a1944506598 == 35)))))) {
    	cf = 0;
    	a1684687706 = 11;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a18979981 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 7) && (a1944506598 == 35 && (((a1838812917 == 32 &&  cf==1 ) && a927953139 == 33) && a2005069365 == 36)))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a714559100 = 6;
    	a1086754137 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 36 && (((( cf==1  && a927953139 == 33) && a1838812917 == 32) && a1944506598 == 35) && (input == 10)))) {
    	cf = 0;
    	a2124036967 = 36 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a524102808 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((input == 19) && (((a1838812917 == 32 &&  cf==1 ) && a1944506598 == 35) && a927953139 == 33)) && a2005069365 == 36)) {
    	cf = 0;
    	a27741386 = 32 ;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a928570136 = 34 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm658(int input) {
    if(((a1838812917 == 32 && ((((input == 11) &&  cf==1 ) && a927953139 == 34) && a2005069365 == 36)) && a1857807887 == 33)) {
    	cf = 0;
    	a714559100 = 6;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1086754137 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1857807887 == 33 && ((( cf==1  && a927953139 == 34) && a2005069365 == 36) && a1838812917 == 32)) && (input == 13))) {
    	cf = 0;
    	a925870636 = 9;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a904637882 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm659(int input) {
    if(((a2005069365 == 36 && (((a1838812917 == 32 &&  cf==1 ) && a1857807887 == 34) && a927953139 == 34)) && (input == 11))) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm660(int input) {
    if((a1838812917 == 32 && ((a2005069365 == 36 && ((input == 10) && (a927953139 == 34 &&  cf==1 ))) && a1857807887 == 35))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a1843210244 = 32 ;
    	a2005069365 = 33 ;
    	a107446547 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm661(int input) {
    if((a2005069365 == 36 && (((input == 7) && (a927953139 == 35 && (a397915314 == 2 &&  cf==1 ))) && a1838812917 == 32))) {
    	cf = 0;
    	a1243394452 = 4;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a685344195 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1838812917 == 32 && (((a927953139 == 35 && ( cf==1  && a397915314 == 2)) && a2005069365 == 36) && (input == 13)))) {
    	cf = 0;
    	a1498704550 = 33 ;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm662(int input) {
    if((a2005069365 == 36 && ((input == 1) && (((a927953139 == 35 &&  cf==1 ) && a397915314 == 3) && a1838812917 == 32)))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a844311967 = 33 ;
    	a1380627758 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((( cf==1  && a2005069365 == 36) && a397915314 == 3) && a1838812917 == 32) && a927953139 == 35) && (input == 5))) {
    	cf = 0;
    	a679327000 = 32 ;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a103910758 = 33 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1838812917 == 32 && (a2005069365 == 36 && ((input == 6) && ( cf==1  && a397915314 == 3)))) && a927953139 == 35)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1958000800 = 9;
    	a1519100789 = 9;
    	a1754726785 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm663(int input) {
    if((((a2005069365 == 36 && ((input == 12) && ( cf==1  && a1838812917 == 32))) && a927953139 == 35) && a397915314 == 4)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 10;
    	a596573336 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm664(int input) {
    if((((a2005069365 == 36 && (a1838812917 == 32 && ( cf==1  && a397915314 == 6))) && (input == 10)) && a927953139 == 35)) {
    	cf = 0;
    	a113788596 = 36 ;
    	a1519100789 = 8;
    	a2005069365 = 35 ;
    	a772592654 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm666(int input) {
    if(((input == 2) && ((a2005069365 == 36 && ((a927953139 == 35 &&  cf==1 ) && a1838812917 == 32)) && a397915314 == 9))) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a2005069365 = 32 ;
    	a925870636 = 8;
    	a1883016343 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a397915314 == 9 && (a927953139 == 35 && ((input == 13) && ( cf==1  && a1838812917 == 32)))) && a2005069365 == 36)) {
    	cf = 0;
    	a1153134505 = 32 ;
    	a240738299 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm667(int input) {
    if((a1838812917 == 32 && (a169540124 == 32 && ((input == 13) && (( cf==1  && a927953139 == 36) && a2005069365 == 36))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1958000800 = 9;
    	a1519100789 = 9;
    	a1754726785 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm24(int input) {
    if((a927953139 == 32 &&  cf==1 )) {
    	if((a1096033747 == 33 &&  cf==1 )) {
    		calculate_outputm653(input);
    	} 
    	if((a1096033747 == 34 &&  cf==1 )) {
    		calculate_outputm654(input);
    	} 
    } 
    if((a927953139 == 33 &&  cf==1 )) {
    	if((a1944506598 == 33 &&  cf==1 )) {
    		calculate_outputm656(input);
    	} 
    	if(( cf==1  && a1944506598 == 35)) {
    		calculate_outputm657(input);
    	} 
    } 
    if(( cf==1  && a927953139 == 34)) {
    	if((a1857807887 == 33 &&  cf==1 )) {
    		calculate_outputm658(input);
    	} 
    	if(( cf==1  && a1857807887 == 34)) {
    		calculate_outputm659(input);
    	} 
    	if(( cf==1  && a1857807887 == 35)) {
    		calculate_outputm660(input);
    	} 
    } 
    if((a927953139 == 35 &&  cf==1 )) {
    	if((a397915314 == 2 &&  cf==1 )) {
    		calculate_outputm661(input);
    	} 
    	if(( cf==1  && a397915314 == 3)) {
    		calculate_outputm662(input);
    	} 
    	if(( cf==1  && a397915314 == 4)) {
    		calculate_outputm663(input);
    	} 
    	if((a397915314 == 6 &&  cf==1 )) {
    		calculate_outputm664(input);
    	} 
    	if(( cf==1  && a397915314 == 9)) {
    		calculate_outputm666(input);
    	} 
    } 
    if(( cf==1  && a927953139 == 36)) {
    	if(( cf==1  && a169540124 == 32)) {
    		calculate_outputm667(input);
    	} 
    } 
}
 void calculate_outputm669(int input) {
    if((a1838812917 == 33 && (((input == 13) && (a991719280 == 32 && ( cf==1  && a2005069365 == 36))) && a569036257 == 3))) {
    	cf = 0;
    	a925870636 = 8;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a1883016343 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm670(int input) {
    if((a569036257 == 3 && (((a2005069365 == 36 && ( cf==1  && a1838812917 == 33)) && a991719280 == 33) && (input == 8)))) {
    	cf = 0;
    	a1153134505 = 36 ;
    	a240738299 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 36 && (a569036257 == 3 && (( cf==1  && (input == 12)) && a1838812917 == 33))) && a991719280 == 33)) {
    	cf = 0;
    	a465336174 = 35 ;
    	a569036257 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((a991719280 == 33 && ( cf==1  && a2005069365 == 36)) && a1838812917 == 33) && (input == 17)) && a569036257 == 3)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a369539608 = 32 ;
    	a1904774218 = 35 ;
    	a1124714117 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1838812917 == 33 && ((input == 19) && ((( cf==1  && a569036257 == 3) && a2005069365 == 36) && a991719280 == 33)))) {
    	cf = 0;
    	a1129866701 = 10;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a596573336 = 13; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm671(int input) {
    if(((a2005069365 == 36 && ((( cf==1  && (input == 1)) && a569036257 == 3) && a991719280 == 35)) && a1838812917 == 33)) {
    	cf = 0;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a738616794 = 33 ;
    	a1052150692 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 7) && ((a1838812917 == 33 && (a569036257 == 3 && ( cf==1  && a2005069365 == 36))) && a991719280 == 35))) {
    	cf = 0;
    	a2124036967 = 36 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a524102808 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a569036257 == 3 && ((a2005069365 == 36 && ((input == 13) && (a1838812917 == 33 &&  cf==1 ))) && a991719280 == 35))) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a369539608 = 35 ;
    	a2005069365 = 32 ;
    	a363404159 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 20) && (((a1838812917 == 33 && ( cf==1  && a569036257 == 3)) && a991719280 == 35) && a2005069365 == 36))) {
    	cf = 0;
    	a1561044360 = 32 ;
    	a113788596 = 32 ;
    	a2005069365 = 35 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm672(int input) {
    if((a569036257 == 4 && (a1838812917 == 33 && ((input == 1) && (a2005069365 == 36 && ( cf==1  && a1549928701 == 8)))))) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a369539608 = 36 ;
    	a2005069365 = 32 ;
    	a1577567933 = 36 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((input == 4) && (a569036257 == 4 &&  cf==1 )) && a2005069365 == 36) && a1549928701 == 8) && a1838812917 == 33)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 7;
    	a207863872 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a2005069365 == 36 && ((input == 11) && ( cf==1  && a1549928701 == 8))) && a569036257 == 4) && a1838812917 == 33)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a747683138 = 35 ;
    	a2059681452 = 33 ;
    	a1039723590 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm673(int input) {
    if(((a1838812917 == 33 && (a2005069365 == 36 && (( cf==1  && a569036257 == 4) && a1549928701 == 10))) && (input == 10))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a525429632 = 33 ;
    	a2005069365 = 34 ;
    	a1428914468 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 12) && (((a1549928701 == 10 && (a569036257 == 4 &&  cf==1 )) && a1838812917 == 33) && a2005069365 == 36))) {
    	cf = 0;
    	a933478840 = 34 ;
    	a2005069365 = 35 ;
    	a604409338 = 34 ;
    	a1519100789 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a569036257 == 4 && (a2005069365 == 36 && ((input == 14) && (( cf==1  && a1838812917 == 33) && a1549928701 == 10))))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a1684687706 = 12;
    	a2005069365 = 33 ;
    	a1710271440 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1549928701 == 10 && (((input == 19) && (a1838812917 == 33 && (a2005069365 == 36 &&  cf==1 ))) && a569036257 == 4))) {
    	cf = 0;
    	a714559100 = 12;
    	a1838812917 = 35 ;
    	a1655731851 = 4; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a569036257 == 4 && (((a1838812917 == 33 &&  cf==1 ) && (input == 11)) && a1549928701 == 10)) && a2005069365 == 36)) {
    	cf = 0;
    	a747683138 = 35 ;
    	a2005069365 = 33 ;
    	a2059681452 = 33 ;
    	a1039723590 = 34 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm674(int input) {
    if((a2005069365 == 36 && (a569036257 == 4 && ((input == 10) && (a1838812917 == 33 && ( cf==1  && a1549928701 == 11)))))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 35 ;
    	a2005069365 = 34 ;
    	a264802066 = 32 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a569036257 == 4 && (a1549928701 == 11 && (a2005069365 == 36 && ( cf==1  && a1838812917 == 33)))) && (input == 15))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a714559100 = 5;
    	a2005069365 = 34 ;
    	a1079106761 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1838812917 == 33 && ((a2005069365 == 36 &&  cf==1 ) && (input == 16))) && a569036257 == 4) && a1549928701 == 11)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a714559100 = 6;
    	a1086754137 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((input == 20) && (a569036257 == 4 && ( cf==1  && a2005069365 == 36))) && a1838812917 == 33) && a1549928701 == 11)) {
    	cf = 0;
    	a1243394452 = 4;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a685344195 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm675(int input) {
    if((a1549928701 == 13 && (a2005069365 == 36 && ((input == 1) && (a569036257 == 4 && ( cf==1  && a1838812917 == 33)))))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1775644016 = 6;
    	a200393381 = 1; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1549928701 == 13 && ((a1838812917 == 33 && ((input == 2) && (a2005069365 == 36 &&  cf==1 ))) && a569036257 == 4))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a1428914468 = 8;
    	a2005069365 = 34 ;
    	a1699038459 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 36 && (a569036257 == 4 && (a1838812917 == 33 && (a1549928701 == 13 && ( cf==1  && (input == 7))))))) {
    	cf = 0;
    	a246458106 = 33 ;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1243394452 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1549928701 == 13 && (a2005069365 == 36 && (a1838812917 == 33 && (a569036257 == 4 && ( cf==1  && (input == 16))))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a27741386 = 36 ;
    	a1904774218 = 32 ;
    	a792575314 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm676(int input) {
    if((((input == 19) && (a2005069365 == 36 && (a1549928701 == 14 && ( cf==1  && a1838812917 == 33)))) && a569036257 == 4)) {
    	cf = 0;
    	a369539608 = 35 ;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a363404159 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm677(int input) {
    if(((a2005069365 == 36 && ((input == 1) && (a569036257 == 4 && ( cf==1  && a1838812917 == 33)))) && a1549928701 == 15)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a679327000 = 33 ;
    	a2065134388 = 17; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 10) && (a1838812917 == 33 && (a569036257 == 4 && (a2005069365 == 36 && (a1549928701 == 15 &&  cf==1 )))))) {
    	cf = 0;
    	a1815432985 = 36 ;
    	a569036257 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm680(int input) {
    if((((input == 3) && (((a569036257 == 5 &&  cf==1 ) && a2005069365 == 36) && a1838812917 == 33)) && a1815432985 == 36)) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a679327000 = 33 ;
    	a2065134388 = 17; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((a2005069365 == 36 &&  cf==1 ) && a1815432985 == 36) && a1838812917 == 33) && (input == 5)) && a569036257 == 5)) {
    	cf = 0;
    	a1795880353 = 32 ;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a1838812917 == 33 && (a1815432985 == 36 && ( cf==1  && (input == 7)))) && a2005069365 == 36) && a569036257 == 5)) {
    	cf = 0;
    	a714559100 = 11;
    	a1838812917 = 35 ;
    	a805812408 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm682(int input) {
    if((((((a569036257 == 6 &&  cf==1 ) && a1838812917 == 33) && (input == 16)) && a2005069365 == 36) && a205734433 == 10)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 11;
    	a2005069365 = 33 ;
    	a691578539 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm683(int input) {
    if((a1838812917 == 33 && ((a205734433 == 11 && (a569036257 == 6 && ( cf==1  && (input == 15)))) && a2005069365 == 36))) {
    	cf = 0;
    	a1739072993 = 33 ;
    	a1838812917 = 36 ;
    	a1775644016 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a569036257 == 6 && (a2005069365 == 36 && ((input == 16) &&  cf==1 ))) && a1838812917 == 33) && a205734433 == 11)) {
    	cf = 0;
    	a1519100789 = 2;
    	a1052150692 = 8;
    	a2005069365 = 35 ;
    	a1144659688 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 17) && (a569036257 == 6 && (((a205734433 == 11 &&  cf==1 ) && a1838812917 == 33) && a2005069365 == 36)))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a2135613870 = 35 ;
    	a2005069365 = 34 ;
    	a1428914468 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm684(int input) {
    if((a205734433 == 12 && (a1838812917 == 33 && (((a569036257 == 6 &&  cf==1 ) && a2005069365 == 36) && (input == 4))))) {
    	cf = 0;
    	a1093326457 = 34 ;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a714559100 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 15) && (a1838812917 == 33 && (a2005069365 == 36 && (a569036257 == 6 && (a205734433 == 12 &&  cf==1 )))))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2135613870 = 34 ;
    	a107446547 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a205734433 == 12 && (a2005069365 == 36 && ( cf==1  && (input == 16)))) && a569036257 == 6) && a1838812917 == 33)) {
    	cf = 0;
    	a1519100789 = 5;
    	a2005069365 = 35 ;
    	a369539608 = 36 ;
    	a347749795 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm685(int input) {
    if((((a569036257 == 6 && ((a205734433 == 13 &&  cf==1 ) && a1838812917 == 33)) && (input == 3)) && a2005069365 == 36)) {
    	cf = 0;
    	a88077474 = 33 ;
    	a2005069365 = 35 ;
    	a928570136 = 32 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a2005069365 == 36 && (a205734433 == 13 && (a569036257 == 6 && (a1838812917 == 33 && ( cf==1  && (input == 5))))))) {
    	cf = 0;
    	a714559100 = 12;
    	a1838812917 = 35 ;
    	a1655731851 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a569036257 == 6 && (a2005069365 == 36 && ((input == 11) && (a1838812917 == 33 && (a205734433 == 13 &&  cf==1 )))))) {
    	cf = 0;
    	a2124036967 = 34 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a745730534 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a205734433 == 13 && ((a569036257 == 6 && (a1838812917 == 33 && ( cf==1  && a2005069365 == 36))) && (input == 20)))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a1428914468 = 7;
    	a976704484 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm686(int input) {
    if(((a569036257 == 6 && ((((input == 3) &&  cf==1 ) && a205734433 == 14) && a1838812917 == 33)) && a2005069365 == 36)) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a928570136 = 33 ;
    	a107446547 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a569036257 == 6 && ((input == 7) && ((( cf==1  && a1838812917 == 33) && a205734433 == 14) && a2005069365 == 36)))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a685667843 = 14;
    	a969893172 = 35 ;
    	a2138261183 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a1838812917 == 33 && ((input == 14) && (a2005069365 == 36 &&  cf==1 ))) && a205734433 == 14) && a569036257 == 6)) {
    	cf = 0;
    	a569036257 = 4;
    	a1549928701 = 15; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 20) && ((a1838812917 == 33 && ((a205734433 == 14 &&  cf==1 ) && a569036257 == 6)) && a2005069365 == 36))) {
    	cf = 0;
    	a1243394452 = 4;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a685344195 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm687(int input) {
    if((a2005069365 == 36 && (a1838812917 == 33 && ((( cf==1  && a205734433 == 15) && a569036257 == 6) && (input == 11))))) {
    	cf = 0;
    	a1958000800 = 8;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1184734075 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1838812917 == 33 && (a2005069365 == 36 && (a205734433 == 15 && ((a569036257 == 6 &&  cf==1 ) && (input == 17)))))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1350444666 = 33 ;
    	a1775644016 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a1838812917 == 33 && ((input == 20) &&  cf==1 )) && a2005069365 == 36) && a205734433 == 15) && a569036257 == 6)) {
    	cf = 0;
    	a1519100789 = 6;
    	a2005069365 = 35 ;
    	a604409338 = 36 ;
    	a1688003115 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm689(int input) {
    if((a1838812917 == 33 && (((( cf==1  && a465336174 == 34) && (input == 2)) && a569036257 == 7) && a2005069365 == 36))) {
    	cf = 0;
    	a491478835 = 32 ;
    	a1838812917 = 35 ;
    	a714559100 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm690(int input) {
    if((((a569036257 == 7 && (((input == 1) &&  cf==1 ) && a465336174 == 35)) && a2005069365 == 36) && a1838812917 == 33)) {
    	cf = 0;
    	a27741386 = 33 ;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a706302795 = 15; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a569036257 == 7 && ((a2005069365 == 36 && (( cf==1  && a465336174 == 35) && (input == 13))) && a1838812917 == 33))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1243394452 = 2;
    	a1519100789 = 7;
    	a1735753243 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm691(int input) {
    if((a1838812917 == 33 && ((((a2005069365 == 36 &&  cf==1 ) && a569036257 == 8) && (input == 1)) && a1325377146 == 32))) {
    	cf = 0;
    	a2124036967 = 34 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a745730534 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm692(int input) {
    if(((((input == 3) && (( cf==1  && a1325377146 == 33) && a1838812917 == 33)) && a2005069365 == 36) && a569036257 == 8)) {
    	cf = 0;
    	a1838812917 = 32 ;
    	a927953139 = 35 ;
    	a397915314 = 3; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1838812917 == 33 && (((a569036257 == 8 &&  cf==1 ) && a2005069365 == 36) && (input == 5))) && a1325377146 == 33)) {
    	cf = 0;
    	a1571676929 = 36 ;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a925870636 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1325377146 == 33 && (a1838812917 == 33 && (a569036257 == 8 && ((input == 17) && (a2005069365 == 36 &&  cf==1 )))))) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a747683138 = 32 ;
    	a2005069365 = 33 ;
    	a2110599067 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 20) && (a2005069365 == 36 && (a1838812917 == 33 && (a1325377146 == 33 && (a569036257 == 8 &&  cf==1 )))))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2124036967 = 33 ;
    	a2005069365 = 34 ;
    	a245033430 = 16; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm693(int input) {
    if((a1325377146 == 36 && (a1838812917 == 33 && (a2005069365 == 36 && (((input == 13) &&  cf==1 ) && a569036257 == 8))))) {
    	cf = 0;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1052150692 = 8;
    	a1144659688 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm694(int input) {
    if((a1838812917 == 33 && (((a569036257 == 9 && ( cf==1  && a1904774218 == 32)) && (input == 5)) && a2005069365 == 36))) {
    	cf = 0;
    	a1872268177 = 32 ;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1958000800 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 8) && (a569036257 == 9 && ((a2005069365 == 36 && ( cf==1  && a1904774218 == 32)) && a1838812917 == 33)))) {
    	cf = 0;
    	a1958000800 = 7;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a207863872 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1838812917 == 33 && (a2005069365 == 36 && ((a569036257 == 9 && ( cf==1  && (input == 10))) && a1904774218 == 32)))) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 10;
    	a2125137407 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm696(int input) {
    if((((a1838812917 == 33 && ((a1904774218 == 36 &&  cf==1 ) && a2005069365 == 36)) && a569036257 == 9) && (input == 13))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1684687706 = 11;
    	a2059681452 = 34 ;
    	a18979981 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm697(int input) {
    if((a569036257 == 10 && (a2005069365 == 36 && (((a920118831 == 6 &&  cf==1 ) && a1838812917 == 33) && (input == 4))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a1690193643 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 36 && (((a569036257 == 10 && ( cf==1  && (input == 10))) && a1838812917 == 33) && a920118831 == 6))) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a920118831 == 6 && ((a2005069365 == 36 && (( cf==1  && (input == 11)) && a1838812917 == 33)) && a569036257 == 10))) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 16) && ((a569036257 == 10 && (a920118831 == 6 && (a2005069365 == 36 &&  cf==1 ))) && a1838812917 == 33))) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm698(int input) {
    if((a1838812917 == 33 && (a2005069365 == 36 && ((a920118831 == 7 && (a569036257 == 10 &&  cf==1 )) && (input == 15))))) {
    	cf = 0;
    	a1958000800 = 7;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a207863872 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1838812917 == 33 && ((input == 16) && (a569036257 == 10 && (( cf==1  && a2005069365 == 36) && a920118831 == 7))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 11;
    	a18979981 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm699(int input) {
    if((a2005069365 == 36 && (((( cf==1  && a920118831 == 8) && a1838812917 == 33) && (input == 14)) && a569036257 == 10))) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a2005069365 = 33 ;
    	a747683138 = 32 ;
    	a2110599067 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 19) && (((( cf==1  && a1838812917 == 33) && a2005069365 == 36) && a920118831 == 8) && a569036257 == 10))) {
    	cf = 0;
    	a1684674520 = 36 ;
    	a2005069365 = 35 ;
    	a369539608 = 34 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm700(int input) {
    if((a920118831 == 9 && (a569036257 == 10 && ((input == 1) && ((a2005069365 == 36 &&  cf==1 ) && a1838812917 == 33))))) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm701(int input) {
    if(((a920118831 == 10 && (a1838812917 == 33 && (a569036257 == 10 && ((input == 6) &&  cf==1 )))) && a2005069365 == 36)) {
    	cf = 0;
    	a1127376297 = 34 ;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a925870636 = 15; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((input == 2) && ((( cf==1  && a569036257 == 10) && a920118831 == 10) && a2005069365 == 36)) && a1838812917 == 33)) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a925870636 = 9;
    	a2005069365 = 32 ;
    	a904637882 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm702(int input) {
    if((a2005069365 == 36 && ((a1838812917 == 33 && ((input == 1) && (a920118831 == 11 &&  cf==1 ))) && a569036257 == 10))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1684687706 = 12;
    	a1710271440 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1838812917 == 33 && ((((input == 11) && ( cf==1  && a2005069365 == 36)) && a569036257 == 10) && a920118831 == 11))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a844311967 = 35 ;
    	a2005069365 = 32 ;
    	a205734433 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 36 && ((input == 15) && (a569036257 == 10 && (a920118831 == 11 && ( cf==1  && a1838812917 == 33)))))) {
    	cf = 0;
    	a1129866701 = 8;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1505404504 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm703(int input) {
    if((a920118831 == 12 && ((input == 13) && (a569036257 == 10 && (a1838812917 == 33 && (a2005069365 == 36 &&  cf==1 )))))) {
    	cf = 0;
    	a113788596 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 8;
    	a772592654 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm25(int input) {
    if((a569036257 == 3 &&  cf==1 )) {
    	if(( cf==1  && a991719280 == 32)) {
    		calculate_outputm669(input);
    	} 
    	if(( cf==1  && a991719280 == 33)) {
    		calculate_outputm670(input);
    	} 
    	if(( cf==1  && a991719280 == 35)) {
    		calculate_outputm671(input);
    	} 
    } 
    if((a569036257 == 4 &&  cf==1 )) {
    	if(( cf==1  && a1549928701 == 8)) {
    		calculate_outputm672(input);
    	} 
    	if(( cf==1  && a1549928701 == 10)) {
    		calculate_outputm673(input);
    	} 
    	if((a1549928701 == 11 &&  cf==1 )) {
    		calculate_outputm674(input);
    	} 
    	if(( cf==1  && a1549928701 == 13)) {
    		calculate_outputm675(input);
    	} 
    	if(( cf==1  && a1549928701 == 14)) {
    		calculate_outputm676(input);
    	} 
    	if(( cf==1  && a1549928701 == 15)) {
    		calculate_outputm677(input);
    	} 
    } 
    if((a569036257 == 5 &&  cf==1 )) {
    	if((a1815432985 == 36 &&  cf==1 )) {
    		calculate_outputm680(input);
    	} 
    } 
    if((a569036257 == 6 &&  cf==1 )) {
    	if((a205734433 == 10 &&  cf==1 )) {
    		calculate_outputm682(input);
    	} 
    	if((a205734433 == 11 &&  cf==1 )) {
    		calculate_outputm683(input);
    	} 
    	if((a205734433 == 12 &&  cf==1 )) {
    		calculate_outputm684(input);
    	} 
    	if((a205734433 == 13 &&  cf==1 )) {
    		calculate_outputm685(input);
    	} 
    	if((a205734433 == 14 &&  cf==1 )) {
    		calculate_outputm686(input);
    	} 
    	if(( cf==1  && a205734433 == 15)) {
    		calculate_outputm687(input);
    	} 
    } 
    if(( cf==1  && a569036257 == 7)) {
    	if((a465336174 == 34 &&  cf==1 )) {
    		calculate_outputm689(input);
    	} 
    	if(( cf==1  && a465336174 == 35)) {
    		calculate_outputm690(input);
    	} 
    } 
    if((a569036257 == 8 &&  cf==1 )) {
    	if((a1325377146 == 32 &&  cf==1 )) {
    		calculate_outputm691(input);
    	} 
    	if((a1325377146 == 33 &&  cf==1 )) {
    		calculate_outputm692(input);
    	} 
    	if(( cf==1  && a1325377146 == 36)) {
    		calculate_outputm693(input);
    	} 
    } 
    if((a569036257 == 9 &&  cf==1 )) {
    	if(( cf==1  && a1904774218 == 32)) {
    		calculate_outputm694(input);
    	} 
    	if((a1904774218 == 36 &&  cf==1 )) {
    		calculate_outputm696(input);
    	} 
    } 
    if((a569036257 == 10 &&  cf==1 )) {
    	if(( cf==1  && a920118831 == 6)) {
    		calculate_outputm697(input);
    	} 
    	if(( cf==1  && a920118831 == 7)) {
    		calculate_outputm698(input);
    	} 
    	if(( cf==1  && a920118831 == 8)) {
    		calculate_outputm699(input);
    	} 
    	if(( cf==1  && a920118831 == 9)) {
    		calculate_outputm700(input);
    	} 
    	if(( cf==1  && a920118831 == 10)) {
    		calculate_outputm701(input);
    	} 
    	if(( cf==1  && a920118831 == 11)) {
    		calculate_outputm702(input);
    	} 
    	if((a920118831 == 12 &&  cf==1 )) {
    		calculate_outputm703(input);
    	} 
    } 
}
 void calculate_outputm704(int input) {
    if((a2005069365 == 36 && (a107446547 == 8 && (((input == 14) && (a928570136 == 32 &&  cf==1 )) && a1838812917 == 34)))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a829511935 = 36 ;
    	a2059681452 = 35 ;
    	a1129866701 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm705(int input) {
    if(((((( cf==1  && a107446547 == 8) && (input == 3)) && a2005069365 == 36) && a928570136 == 33) && a1838812917 == 34)) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 36 && (a1838812917 == 34 && (a107446547 == 8 && ( cf==1  && a928570136 == 33)))) && (input == 20))) {
    	cf = 0;
    	a1690193643 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm706(int input) {
    if(((((input == 12) && (a2005069365 == 36 && (a107446547 == 8 &&  cf==1 ))) && a928570136 == 34) && a1838812917 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a369539608 = 36 ;
    	a1958000800 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm707(int input) {
    if((a67466277 == 32 && ((input == 3) && ((( cf==1  && a2005069365 == 36) && a107446547 == 9) && a1838812917 == 34)))) {
    	cf = 0;
    	a27741386 = 35 ;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a829511935 = 35 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((((a107446547 == 9 &&  cf==1 ) && (input == 5)) && a2005069365 == 36) && a1838812917 == 34) && a67466277 == 32)) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a107446547 == 9 && ((((a2005069365 == 36 &&  cf==1 ) && a67466277 == 32) && a1838812917 == 34) && (input == 16)))) {
    	cf = 0;
    	a714559100 = 5;
    	a1838812917 = 35 ;
    	a1089968358 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 19) && (a107446547 == 9 && (a1838812917 == 34 && ((a2005069365 == 36 &&  cf==1 ) && a67466277 == 32))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 9;
    	a1754726785 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm708(int input) {
    if((a1838812917 == 34 && ((a107446547 == 9 && ((input == 3) && (a67466277 == 36 &&  cf==1 ))) && a2005069365 == 36))) {
    	cf = 0;
    	a1052150692 = 7;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a71813398 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 36 && (((( cf==1  && a67466277 == 36) && a107446547 == 9) && (input == 7)) && a1838812917 == 34))) {
    	cf = 0;
    	a1958000800 = 9;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1754726785 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 10) && (a107446547 == 9 && (a2005069365 == 36 && (a1838812917 == 34 && ( cf==1  && a67466277 == 36)))))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a714559100 = 6;
    	a1086754137 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 36 && (((( cf==1  && (input == 15)) && a107446547 == 9) && a1838812917 == 34) && a67466277 == 36))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1561044360 = 35 ;
    	a113788596 = 32 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm709(int input) {
    if((a2005069365 == 36 && ((a107446547 == 10 && (a1838812917 == 34 && (a990124478 == 36 &&  cf==1 ))) && (input == 4)))) {
    	cf = 0;
    	a714559100 = 12;
    	a1838812917 = 35 ;
    	a1655731851 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1838812917 == 34 && (((((input == 8) &&  cf==1 ) && a2005069365 == 36) && a990124478 == 36) && a107446547 == 10))) {
    	cf = 0;
    	a1519100789 = 3;
    	a2005069365 = 35 ;
    	a88077474 = 35 ;
    	a534598694 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a107446547 == 10 && ((((input == 15) && (a990124478 == 36 &&  cf==1 )) && a1838812917 == 34) && a2005069365 == 36))) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a1684687706 = 12;
    	a2005069365 = 33 ;
    	a1710271440 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm710(int input) {
    if((a107446547 == 11 && (a2005069365 == 36 && ((input == 1) && (a353267992 == 32 && ( cf==1  && a1838812917 == 34)))))) {
    	cf = 0;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a738616794 = 34 ;
    	a1052150692 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((input == 6) && (a2005069365 == 36 && ((a353267992 == 32 &&  cf==1 ) && a1838812917 == 34))) && a107446547 == 11)) {
    	cf = 0;
    	a1153134505 = 36 ;
    	a2005069365 = 35 ;
    	a240738299 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a353267992 == 32 && ((input == 12) && (a2005069365 == 36 && (a107446547 == 11 && ( cf==1  && a1838812917 == 34)))))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a714559100 = 7;
    	a1166586546 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm711(int input) {
    if((((a1838812917 == 34 && ((a2005069365 == 36 &&  cf==1 ) && (input == 2))) && a353267992 == 34) && a107446547 == 11)) {
    	cf = 0;
    	a27741386 = 35 ;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a829511935 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 7) && (a2005069365 == 36 && (((a353267992 == 34 &&  cf==1 ) && a107446547 == 11) && a1838812917 == 34)))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 8;
    	a1505404504 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((( cf==1  && a1838812917 == 34) && (input == 10)) && a2005069365 == 36) && a353267992 == 34) && a107446547 == 11)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a844311967 = 33 ;
    	a1380627758 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm712(int input) {
    if((a107446547 == 11 && (a1838812917 == 34 && ((( cf==1  && a353267992 == 35) && a2005069365 == 36) && (input == 15))))) {
    	cf = 0;
    	a650110038 = 33 ;
    	a2005069365 = 34 ;
    	a969893172 = 32 ;
    	a1015737466 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1838812917 == 34 && (a107446547 == 11 && (a353267992 == 35 && (a2005069365 == 36 && ( cf==1  && (input == 16))))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 34 ;
    	a1127376297 = 36 ;
    	a925870636 = 15; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm713(int input) {
    if(((((a2005069365 == 36 && ( cf==1  && a353267992 == 36)) && a107446547 == 11) && a1838812917 == 34) && (input == 6))) {
    	cf = 0;
    	a1815432985 = 36 ;
    	a1838812917 = 33 ;
    	a569036257 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a107446547 == 11 && ((( cf==1  && a353267992 == 36) && a1838812917 == 34) && a2005069365 == 36)) && (input == 10))) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm714(int input) {
    if((a107446547 == 12 && ((input == 2) && (a2005069365 == 36 && (a815941786 == 32 && ( cf==1  && a1838812917 == 34)))))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a1690193643 = 35 ;
    	a107446547 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 7) && ((a107446547 == 12 && (( cf==1  && a815941786 == 32) && a1838812917 == 34)) && a2005069365 == 36))) {
    	cf = 0;
    	a714559100 = 11;
    	a1838812917 = 35 ;
    	a805812408 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1838812917 == 34 && ((a815941786 == 32 && (( cf==1  && a107446547 == 12) && (input == 16))) && a2005069365 == 36))) {
    	cf = 0;
    	a569036257 = 6;
    	a1838812917 = 33 ;
    	a205734433 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a2005069365 == 36 && ( cf==1  && (input == 17))) && a1838812917 == 34) && a815941786 == 32) && a107446547 == 12)) {
    	cf = 0;
    	a67466277 = 32 ;
    	a107446547 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm715(int input) {
    if(((((a107446547 == 12 && ( cf==1  && a2005069365 == 36)) && a815941786 == 35) && a1838812917 == 34) && (input == 4))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a525429632 = 35 ;
    	a1428914468 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 13) && (a1838812917 == 34 && ((a2005069365 == 36 && ( cf==1  && a107446547 == 12)) && a815941786 == 35)))) {
    	cf = 0;
    	a1388584441 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 14) && (a2005069365 == 36 && (a1838812917 == 34 && (a815941786 == 35 && ( cf==1  && a107446547 == 12)))))) {
    	cf = 0;
    	a2124036967 = 34 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a745730534 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1838812917 == 34 && ((a107446547 == 12 && ((input == 20) && (a2005069365 == 36 &&  cf==1 ))) && a815941786 == 35))) {
    	cf = 0;
    	a1243394452 = 8;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a529769874 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm717(int input) {
    if(((a2059681452 == 33 && (((input == 3) && ( cf==1  && a1838812917 == 34)) && a107446547 == 13)) && a2005069365 == 36)) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 11;
    	a805812408 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((a1838812917 == 34 &&  cf==1 ) && a2059681452 == 33) && a2005069365 == 36) && a107446547 == 13) && (input == 11))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a714559100 = 9;
    	a304497462 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm718(int input) {
    if((a2005069365 == 36 && ((((a2059681452 == 34 &&  cf==1 ) && a107446547 == 13) && a1838812917 == 34) && (input == 4)))) {
    	cf = 0;
    	a714559100 = 9;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a304497462 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a107446547 == 13 && ((input == 5) && ( cf==1  && a1838812917 == 34))) && a2059681452 == 34) && a2005069365 == 36)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 12;
    	a2005069365 = 33 ;
    	a461439918 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((input == 11) && (a2005069365 == 36 && (a107446547 == 13 &&  cf==1 ))) && a1838812917 == 34) && a2059681452 == 34)) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1350444666 = 36 ;
    	a1775644016 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 36 && ((input == 19) && (a1838812917 == 34 && ((a2059681452 == 34 &&  cf==1 ) && a107446547 == 13))))) {
    	cf = 0;
    	a1519100789 = 8;
    	a2005069365 = 35 ;
    	a113788596 = 33 ;
    	a137564664 = 16; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm719(int input) {
    if(((((a1838812917 == 34 && ((input == 3) &&  cf==1 )) && a2005069365 == 36) && a2059681452 == 35) && a107446547 == 13)) {
    	cf = 0;
    	a107446547 = 14;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a986008840 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm721(int input) {
    if((((a107446547 == 14 && (a2005069365 == 36 && (a2135613870 == 34 &&  cf==1 ))) && a1838812917 == 34) && (input == 13))) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm722(int input) {
    if((a107446547 == 14 && (((a1838812917 == 34 && ((input == 3) &&  cf==1 )) && a2135613870 == 36) && a2005069365 == 36))) {
    	cf = 0;
    	a1519100789 = 7;
    	a1153134505 = 35 ;
    	a2005069365 = 35 ;
    	a1243394452 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a2135613870 == 36 && (a1838812917 == 34 && ((a2005069365 == 36 &&  cf==1 ) && a107446547 == 14))) && (input == 13))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a2124036967 = 32 ;
    	a969893172 = 36 ;
    	a1194623510 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1838812917 == 34 && ((input == 20) && (a2005069365 == 36 && ((a2135613870 == 36 &&  cf==1 ) && a107446547 == 14))))) {
    	cf = 0;
    	a107446547 = 12;
    	a2005069365 = 33 ;
    	a2059681452 = 36 ;
    	a1682504076 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((a1838812917 == 34 && ( cf==1  && a2005069365 == 36)) && (input == 5)) && a107446547 == 14) && a2135613870 == 36)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a844311967 = 35 ;
    	a205734433 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm723(int input) {
    if((a1838812917 == 34 && ((a2005069365 == 36 && (( cf==1  && (input == 4)) && a107446547 == 15)) && a275125637 == 6))) {
    	cf = 0;
    	a650110038 = 35 ;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a264802066 = 34 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 36 && (a1838812917 == 34 && (a107446547 == 15 && (((input == 8) &&  cf==1 ) && a275125637 == 6))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a369539608 = 36 ;
    	a1958000800 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((a2005069365 == 36 && (a107446547 == 15 &&  cf==1 )) && (input == 17)) && a1838812917 == 34) && a275125637 == 6)) {
    	cf = 0;
    	a714559100 = 12;
    	a1838812917 = 35 ;
    	a1655731851 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 20) && ((a107446547 == 15 && ((a275125637 == 6 &&  cf==1 ) && a2005069365 == 36)) && a1838812917 == 34))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1492184786 = 33 ;
    	a1775644016 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm724(int input) {
    if((((a275125637 == 7 && ((input == 6) && ( cf==1  && a2005069365 == 36))) && a107446547 == 15) && a1838812917 == 34)) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 10) && (((a107446547 == 15 && (a1838812917 == 34 &&  cf==1 )) && a275125637 == 7) && a2005069365 == 36))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a933478840 = 34 ;
    	a604409338 = 34 ;
    	a1519100789 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 11) && (a275125637 == 7 && (a2005069365 == 36 && (a1838812917 == 34 && (a107446547 == 15 &&  cf==1 )))))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a1690193643 = 33 ;
    	a2005069365 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm725(int input) {
    if((((a1838812917 == 34 && (a275125637 == 8 && (a107446547 == 15 &&  cf==1 ))) && a2005069365 == 36) && (input == 2))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a747683138 = 34 ;
    	a2059681452 = 33 ;
    	a1428914468 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm726(int input) {
    if((((a2005069365 == 36 && (( cf==1  && a1838812917 == 34) && (input == 3))) && a107446547 == 15) && a275125637 == 9)) {
    	cf = 0;
    	a1519100789 = 8;
    	a2005069365 = 35 ;
    	a113788596 = 36 ;
    	a772592654 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1838812917 == 34 && ((a107446547 == 15 && (((input == 12) &&  cf==1 ) && a2005069365 == 36)) && a275125637 == 9))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a1388584441 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a107446547 == 15 && (a2005069365 == 36 && (a1838812917 == 34 && (a275125637 == 9 && ( cf==1  && (input == 16))))))) {
    	cf = 0;
    	a275125637 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm727(int input) {
    if(((input == 2) && (a1838812917 == 34 && ((( cf==1  && a275125637 == 10) && a2005069365 == 36) && a107446547 == 15)))) {
    	cf = 0;
    	a1204193075 = 34 ;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1243394452 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1838812917 == 34 && (((input == 14) && (a107446547 == 15 &&  cf==1 )) && a2005069365 == 36)) && a275125637 == 10)) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a679327000 = 34 ;
    	a603781876 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 16) && (a275125637 == 10 && (((a107446547 == 15 &&  cf==1 ) && a2005069365 == 36) && a1838812917 == 34)))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a844311967 = 33 ;
    	a1904774218 = 33 ;
    	a1380627758 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 20) && (a275125637 == 10 && (a2005069365 == 36 && (( cf==1  && a107446547 == 15) && a1838812917 == 34))))) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a2124036967 = 34 ;
    	a745730534 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm26(int input) {
    if((a107446547 == 8 &&  cf==1 )) {
    	if(( cf==1  && a928570136 == 32)) {
    		calculate_outputm704(input);
    	} 
    	if((a928570136 == 33 &&  cf==1 )) {
    		calculate_outputm705(input);
    	} 
    	if(( cf==1  && a928570136 == 34)) {
    		calculate_outputm706(input);
    	} 
    } 
    if(( cf==1  && a107446547 == 9)) {
    	if(( cf==1  && a67466277 == 32)) {
    		calculate_outputm707(input);
    	} 
    	if(( cf==1  && a67466277 == 36)) {
    		calculate_outputm708(input);
    	} 
    } 
    if(( cf==1  && a107446547 == 10)) {
    	if(( cf==1  && a990124478 == 36)) {
    		calculate_outputm709(input);
    	} 
    } 
    if(( cf==1  && a107446547 == 11)) {
    	if(( cf==1  && a353267992 == 32)) {
    		calculate_outputm710(input);
    	} 
    	if((a353267992 == 34 &&  cf==1 )) {
    		calculate_outputm711(input);
    	} 
    	if((a353267992 == 35 &&  cf==1 )) {
    		calculate_outputm712(input);
    	} 
    	if(( cf==1  && a353267992 == 36)) {
    		calculate_outputm713(input);
    	} 
    } 
    if((a107446547 == 12 &&  cf==1 )) {
    	if((a815941786 == 32 &&  cf==1 )) {
    		calculate_outputm714(input);
    	} 
    	if(( cf==1  && a815941786 == 35)) {
    		calculate_outputm715(input);
    	} 
    } 
    if((a107446547 == 13 &&  cf==1 )) {
    	if((a2059681452 == 33 &&  cf==1 )) {
    		calculate_outputm717(input);
    	} 
    	if((a2059681452 == 34 &&  cf==1 )) {
    		calculate_outputm718(input);
    	} 
    	if((a2059681452 == 35 &&  cf==1 )) {
    		calculate_outputm719(input);
    	} 
    } 
    if((a107446547 == 14 &&  cf==1 )) {
    	if(( cf==1  && a2135613870 == 34)) {
    		calculate_outputm721(input);
    	} 
    	if((a2135613870 == 36 &&  cf==1 )) {
    		calculate_outputm722(input);
    	} 
    } 
    if((a107446547 == 15 &&  cf==1 )) {
    	if((a275125637 == 6 &&  cf==1 )) {
    		calculate_outputm723(input);
    	} 
    	if(( cf==1  && a275125637 == 7)) {
    		calculate_outputm724(input);
    	} 
    	if(( cf==1  && a275125637 == 8)) {
    		calculate_outputm725(input);
    	} 
    	if((a275125637 == 9 &&  cf==1 )) {
    		calculate_outputm726(input);
    	} 
    	if((a275125637 == 10 &&  cf==1 )) {
    		calculate_outputm727(input);
    	} 
    } 
}
 void calculate_outputm728(int input) {
    if(((a1089968358 == 4 && (((a1838812917 == 35 &&  cf==1 ) && (input == 1)) && a2005069365 == 36)) && a714559100 == 5)) {
    	cf = 0;
    	a1684687706 = 9;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a892217980 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((( cf==1  && a714559100 == 5) && a1089968358 == 4) && (input == 5)) && a2005069365 == 36) && a1838812917 == 35)) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a2005069365 = 33 ;
    	a747683138 = 36 ;
    	a1172911487 = 34 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm729(int input) {
    if(((a714559100 == 5 && ((input == 2) && ((a1838812917 == 35 &&  cf==1 ) && a1089968358 == 5))) && a2005069365 == 36)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a2124036967 = 34 ;
    	a969893172 = 36 ;
    	a745730534 = 36 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a714559100 == 5 && ((((input == 4) && (a1838812917 == 35 &&  cf==1 )) && a1089968358 == 5) && a2005069365 == 36))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a714559100 = 9;
    	a2005069365 = 34 ;
    	a304497462 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1838812917 == 35 && ((a1089968358 == 5 && ( cf==1  && a2005069365 == 36)) && a714559100 == 5)) && (input == 6))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 8;
    	a1184734075 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a2005069365 == 36 && ( cf==1  && a714559100 == 5)) && (input == 17)) && a1089968358 == 5) && a1838812917 == 35)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1610737594 = 36 ;
    	a1428914468 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm730(int input) {
    if(((a1838812917 == 35 && (((input == 16) && ( cf==1  && a714559100 == 5)) && a2005069365 == 36)) && a1089968358 == 6)) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a525429632 = 34 ;
    	a1775644016 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm732(int input) {
    if((((a2005069365 == 36 && ((input == 6) && ( cf==1  && a1089968358 == 8))) && a714559100 == 5) && a1838812917 == 35)) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1089968358 == 8 && ((a1838812917 == 35 &&  cf==1 ) && a714559100 == 5)) && a2005069365 == 36) && (input == 11))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 8;
    	a2005069365 = 33 ;
    	a1505404504 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a714559100 == 5 && (a1838812917 == 35 && ( cf==1  && a1089968358 == 8))) && a2005069365 == 36) && (input == 16))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a844311967 = 35 ;
    	a205734433 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm733(int input) {
    if(((((a1838812917 == 35 && ( cf==1  && a714559100 == 5)) && (input == 10)) && a2005069365 == 36) && a1089968358 == 10)) {
    	cf = 0;
    	a969893172 = 36 ;
    	a2124036967 = 36 ;
    	a2005069365 = 34 ;
    	a524102808 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 19) && (((a714559100 == 5 && ( cf==1  && a1089968358 == 10)) && a1838812917 == 35) && a2005069365 == 36))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a369539608 = 34 ;
    	a1904774218 = 35 ;
    	a1754726785 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm734(int input) {
    if(((((a2005069365 == 36 && ((input == 3) &&  cf==1 )) && a714559100 == 5) && a1089968358 == 11) && a1838812917 == 35)) {
    	cf = 0;
    	a1129866701 = 8;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1505404504 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 36 && (a1838812917 == 35 && ((a714559100 == 5 &&  cf==1 ) && (input == 5)))) && a1089968358 == 11)) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a1350444666 = 32 ;
    	a1775644016 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a2005069365 == 36 && (((a1838812917 == 35 && ( cf==1  && a1089968358 == 11)) && (input == 16)) && a714559100 == 5))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a844311967 = 36 ;
    	a1235481610 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a714559100 == 5 && (((a1089968358 == 11 && ((input == 20) &&  cf==1 )) && a2005069365 == 36) && a1838812917 == 35))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a107446547 = 15;
    	a2005069365 = 33 ;
    	a1566584718 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm735(int input) {
    if((a110820676 == 32 && (a1838812917 == 35 && (a714559100 == 6 && ((input == 11) && ( cf==1  && a2005069365 == 36)))))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a650110038 = 35 ;
    	a969893172 = 32 ;
    	a264802066 = 32 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a110820676 == 32 && (((input == 12) && (a1838812917 == 35 && (a714559100 == 6 &&  cf==1 ))) && a2005069365 == 36))) {
    	cf = 0;
    	a525429632 = 35 ;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a1428914468 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm736(int input) {
    if((a110820676 == 34 && (a714559100 == 6 && (a2005069365 == 36 && (( cf==1  && (input == 12)) && a1838812917 == 35))))) {
    	cf = 0;
    	a604409338 = 33 ;
    	a1519100789 = 6;
    	a2005069365 = 35 ;
    	a954368445 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1838812917 == 35 && ((a110820676 == 34 && ((input == 20) &&  cf==1 )) && a714559100 == 6)) && a2005069365 == 36)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a369539608 = 36 ;
    	a1958000800 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm737(int input) {
    if(((((input == 11) && ((a110820676 == 36 &&  cf==1 ) && a2005069365 == 36)) && a714559100 == 6) && a1838812917 == 35)) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a2059681452 = 34 ;
    	a107446547 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 13) && (a110820676 == 36 && ((a714559100 == 6 && ( cf==1  && a2005069365 == 36)) && a1838812917 == 35)))) {
    	cf = 0;
    	a569036257 = 4;
    	a1838812917 = 33 ;
    	a1549928701 = 13; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((a110820676 == 36 && (a714559100 == 6 &&  cf==1 )) && a1838812917 == 35) && a2005069365 == 36) && (input == 15))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a1093326457 = 36 ;
    	a2005069365 = 34 ;
    	a714559100 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm738(int input) {
    if((((input == 2) && (a2005069365 == 36 && (a491478835 == 32 && ( cf==1  && a1838812917 == 35)))) && a714559100 == 7)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a27741386 = 33 ;
    	a706302795 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 36 && ((a1838812917 == 35 && (( cf==1  && a714559100 == 7) && a491478835 == 32)) && (input == 7)))) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a1690193643 = 33 ;
    	a2005069365 = 33 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a491478835 == 32 && ((a1838812917 == 35 && (a2005069365 == 36 && ((input == 11) &&  cf==1 ))) && a714559100 == 7))) {
    	cf = 0;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a2005069365 = 35 ;
    	a347749795 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((((input == 13) &&  cf==1 ) && a491478835 == 32) && a2005069365 == 36) && a1838812917 == 35) && a714559100 == 7)) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm739(int input) {
    if(((a2005069365 == 36 && ((a1838812917 == 35 && ( cf==1  && a491478835 == 33)) && (input == 2))) && a714559100 == 7)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a107446547 = 12;
    	a2059681452 = 36 ;
    	a1682504076 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((input == 6) && (( cf==1  && a2005069365 == 36) && a714559100 == 7)) && a491478835 == 33) && a1838812917 == 35)) {
    	cf = 0;
    	a2135613870 = 34 ;
    	a1838812917 = 34 ;
    	a107446547 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((input == 10) && (a714559100 == 7 && ( cf==1  && a1838812917 == 35))) && a2005069365 == 36) && a491478835 == 33)) {
    	cf = 0;
    	a650110038 = 34 ;
    	a2005069365 = 34 ;
    	a969893172 = 32 ;
    	a349181387 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a2005069365 == 36 && ((input == 12) && ((( cf==1  && a714559100 == 7) && a491478835 == 33) && a1838812917 == 35)))) {
    	cf = 0;
    	a1684687706 = 11;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a18979981 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm740(int input) {
    if((a1838812917 == 35 && ((input == 7) && (a491478835 == 35 && (( cf==1  && a714559100 == 7) && a2005069365 == 36))))) {
    	cf = 0;
    	a1243394452 = 2;
    	a1519100789 = 7;
    	a2005069365 = 35 ;
    	a1735753243 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1838812917 == 35 && ((a491478835 == 35 && (a714559100 == 7 && (a2005069365 == 36 &&  cf==1 ))) && (input == 20)))) {
    	cf = 0;
    	a1519100789 = 7;
    	a1243394452 = 2;
    	a2005069365 = 35 ;
    	a1735753243 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm741(int input) {
    if(((((((input == 4) &&  cf==1 ) && a491478835 == 36) && a714559100 == 7) && a2005069365 == 36) && a1838812917 == 35)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1129866701 = 13;
    	a2005069365 = 33 ;
    	a1271566896 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2005069365 == 36 && ((input == 5) && (((a714559100 == 7 &&  cf==1 ) && a1838812917 == 35) && a491478835 == 36)))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 35 ;
    	a2005069365 = 34 ;
    	a264802066 = 34 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 16) && (a714559100 == 7 && (a1838812917 == 35 && ((a2005069365 == 36 &&  cf==1 ) && a491478835 == 36))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1204193075 = 34 ;
    	a1519100789 = 7;
    	a1243394452 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a714559100 == 7 && ((a491478835 == 36 &&  cf==1 ) && a1838812917 == 35)) && (input == 17)) && a2005069365 == 36)) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a679327000 = 36 ;
    	a2005069365 = 33 ;
    	a1124714117 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm742(int input) {
    if(((((( cf==1  && a714559100 == 8) && a1838812917 == 35) && a2005069365 == 36) && a206599328 == 33) && (input == 3))) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a747683138 = 35 ;
    	a2005069365 = 33 ;
    	a1039723590 = 36 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm743(int input) {
    if(((a206599328 == 34 && ((input == 13) && ((a2005069365 == 36 &&  cf==1 ) && a1838812917 == 35))) && a714559100 == 8)) {
    	cf = 0;
    	a2059681452 = 36 ;
    	a2005069365 = 33 ;
    	a1275896582 = 32 ;
    	a107446547 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 14) && (a2005069365 == 36 && (( cf==1  && a714559100 == 8) && a1838812917 == 35))) && a206599328 == 34)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1815432985 = 34 ;
    	a1243394452 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm744(int input) {
    if((a206599328 == 35 && (a2005069365 == 36 && (((a1838812917 == 35 &&  cf==1 ) && a714559100 == 8) && (input == 4))))) {
    	cf = 0;
    	a1388584441 = 34 ;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a714559100 == 8 && (((( cf==1  && a2005069365 == 36) && (input == 6)) && a206599328 == 35) && a1838812917 == 35))) {
    	cf = 0;
    	a1388584441 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm745(int input) {
    if((a206599328 == 36 && ((input == 5) && (((a2005069365 == 36 &&  cf==1 ) && a714559100 == 8) && a1838812917 == 35)))) {
    	cf = 0;
    	a969893172 = 35 ;
    	a685667843 = 14;
    	a2005069365 = 34 ;
    	a2138261183 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a714559100 == 8 && ((a2005069365 == 36 && (a206599328 == 36 && (a1838812917 == 35 &&  cf==1 ))) && (input == 10)))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a604409338 = 33 ;
    	a1519100789 = 6;
    	a954368445 = 4; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((( cf==1  && a714559100 == 8) && a206599328 == 36) && a1838812917 == 35) && (input == 19)) && a2005069365 == 36)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a569036257 = 4;
    	a1549928701 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a2005069365 == 36 && ((input == 20) && (a206599328 == 36 && ( cf==1  && a1838812917 == 35)))) && a714559100 == 8)) {
    	cf = 0;
    	a110820676 = 34 ;
    	a714559100 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm746(int input) {
    if(((a1498704550 == 32 && ((a714559100 == 9 && (a1838812917 == 35 &&  cf==1 )) && (input == 15))) && a2005069365 == 36)) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 10;
    	a596573336 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm747(int input) {
    if((((input == 8) && (a1838812917 == 35 && (a714559100 == 9 && (a1498704550 == 33 &&  cf==1 )))) && a2005069365 == 36)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a88077474 = 36 ;
    	a744476156 = 33 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((input == 10) && ((a2005069365 == 36 &&  cf==1 ) && a1838812917 == 35)) && a714559100 == 9) && a1498704550 == 33)) {
    	cf = 0;
    	a604409338 = 33 ;
    	a2005069365 = 35 ;
    	a1519100789 = 6;
    	a954368445 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm748(int input) {
    if((a2005069365 == 36 && ((((input == 4) && (a1498704550 == 34 &&  cf==1 )) && a1838812917 == 35) && a714559100 == 9))) {
    	cf = 0;
    	a1958000800 = 7;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a207863872 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1498704550 == 34 && (a2005069365 == 36 && (a714559100 == 9 && ((a1838812917 == 35 &&  cf==1 ) && (input == 12)))))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 36 ;
    	a928570136 = 33 ;
    	a806083420 = 36 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm749(int input) {
    if((a714559100 == 9 && ((((input == 5) && (a1498704550 == 35 &&  cf==1 )) && a1838812917 == 35) && a2005069365 == 36))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a369539608 = 35 ;
    	a1307756142 = 35 ;
    	a1519100789 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((input == 7) && (a1498704550 == 35 && (( cf==1  && a1838812917 == 35) && a2005069365 == 36))) && a714559100 == 9)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a1498704550 = 36 ;
    	a685667843 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1498704550 == 35 && ((a2005069365 == 36 && ( cf==1  && a714559100 == 9)) && a1838812917 == 35)) && (input == 11))) {
    	cf = 0;
    	a2059681452 = 33 ;
    	a747683138 = 35 ;
    	a2005069365 = 33 ;
    	a1039723590 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm750(int input) {
    if((((input == 8) && (((a1498704550 == 36 &&  cf==1 ) && a714559100 == 9) && a2005069365 == 36)) && a1838812917 == 35)) {
    	cf = 0;
    	a1739072993 = 32 ;
    	a2005069365 = 35 ;
    	a113788596 = 35 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a714559100 == 9 && (((( cf==1  && a1498704550 == 36) && a1838812917 == 35) && (input == 11)) && a2005069365 == 36))) {
    	cf = 0;
    	a679327000 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a2065134388 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 17) && ((a1838812917 == 35 && (a714559100 == 9 && (a2005069365 == 36 &&  cf==1 ))) && a1498704550 == 36))) {
    	cf = 0;
    	a1519100789 = 6;
    	a2005069365 = 35 ;
    	a604409338 = 33 ;
    	a954368445 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm751(int input) {
    if(((a2125137407 == 5 && (a714559100 == 10 && (( cf==1  && a1838812917 == 35) && (input == 14)))) && a2005069365 == 36)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a2124036967 = 32 ;
    	a969893172 = 36 ;
    	a1194623510 = 35 ; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a2005069365 == 36 && ((a714559100 == 10 && (a2125137407 == 5 &&  cf==1 )) && (input == 20))) && a1838812917 == 35)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a679327000 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm753(int input) {
    if((a2005069365 == 36 && ((a714559100 == 10 && (( cf==1  && a1838812917 == 35) && a2125137407 == 8)) && (input == 12)))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 32 ;
    	a2059681452 = 32 ;
    	a103910758 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2125137407 == 8 && ((a714559100 == 10 && (a1838812917 == 35 && (a2005069365 == 36 &&  cf==1 ))) && (input == 15)))) {
    	cf = 0;
    	a747683138 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 33 ;
    	a1682504076 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a714559100 == 10 && (((input == 5) && ( cf==1  && a1838812917 == 35)) && a2125137407 == 8)) && a2005069365 == 36)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a369539608 = 35 ;
    	a1904774218 = 35 ;
    	a363404159 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm754(int input) {
    if((a1838812917 == 35 && (a2005069365 == 36 && ((a714559100 == 10 && ( cf==1  && a2125137407 == 9)) && (input == 5))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a240738299 = 34 ;
    	a1519100789 = 4;
    	a1109056640 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1838812917 == 35 && ((input == 10) && ( cf==1  && a714559100 == 10))) && a2125137407 == 9) && a2005069365 == 36)) {
    	cf = 0;
    	a2124036967 = 34 ;
    	a969893172 = 36 ;
    	a2005069365 = 34 ;
    	a745730534 = 35 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((((a1838812917 == 35 &&  cf==1 ) && a714559100 == 10) && a2005069365 == 36) && (input == 12)) && a2125137407 == 9)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a685667843 = 14;
    	a969893172 = 35 ;
    	a2138261183 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a2125137407 == 9 && ((a1838812917 == 35 &&  cf==1 ) && (input == 20))) && a2005069365 == 36) && a714559100 == 10)) {
    	cf = 0;
    	a714559100 = 5;
    	a1089968358 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm755(int input) {
    if((a1838812917 == 35 && ((a714559100 == 10 && ((input == 4) && (a2125137407 == 11 &&  cf==1 ))) && a2005069365 == 36))) {
    	cf = 0;
    	a1756771009 = 36 ;
    	a2005069365 = 35 ;
    	a604409338 = 32 ;
    	a1519100789 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a714559100 == 10 && ((input == 13) && ( cf==1  && a2005069365 == 36))) && a1838812917 == 35) && a2125137407 == 11)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a369539608 = 34 ;
    	a1754726785 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm756(int input) {
    if(((input == 3) && (a1838812917 == 35 && (a805812408 == 7 && (a714559100 == 11 && ( cf==1  && a2005069365 == 36)))))) {
    	cf = 0;
    	a88077474 = 34 ;
    	a2016510333 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm757(int input) {
    if(((a714559100 == 11 && ((a1838812917 == 35 && (a805812408 == 8 &&  cf==1 )) && (input == 5))) && a2005069365 == 36)) {
    	cf = 0;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a1843210244 = 36 ;
    	a1684687706 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a714559100 == 11 && ((input == 10) && (( cf==1  && a2005069365 == 36) && a805812408 == 8))) && a1838812917 == 35)) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 14;
    	a2138261183 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1838812917 == 35 && ((((a2005069365 == 36 &&  cf==1 ) && a714559100 == 11) && (input == 20)) && a805812408 == 8))) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 33 ;
    	a2005069365 = 34 ;
    	a1015737466 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm760(int input) {
    if(((input == 20) && ((a714559100 == 11 && (( cf==1  && a2005069365 == 36) && a1838812917 == 35)) && a805812408 == 11))) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a27741386 = 32 ;
    	a928570136 = 34 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm761(int input) {
    if(((((( cf==1  && a2005069365 == 36) && a1838812917 == 35) && a805812408 == 12) && a714559100 == 11) && (input == 5))) {
    	cf = 0;
    	a1838812917 = 36 ;
    	a525429632 = 34 ;
    	a1775644016 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm762(int input) {
    if(((a714559100 == 11 && ((( cf==1  && a2005069365 == 36) && a1838812917 == 35) && a805812408 == 13)) && (input == 3))) {
    	cf = 0;
    	a969893172 = 33 ;
    	a2005069365 = 34 ;
    	a1428914468 = 10;
    	a954368445 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1838812917 == 35 && ((( cf==1  && a2005069365 == 36) && a805812408 == 13) && (input == 12))) && a714559100 == 11)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a925870636 = 9;
    	a1904774218 = 34 ;
    	a904637882 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a714559100 == 11 && ((( cf==1  && (input == 17)) && a805812408 == 13) && a2005069365 == 36)) && a1838812917 == 35)) {
    	cf = 0;
    	a1052150692 = 10;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a662123779 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm763(int input) {
    if(((input == 1) && (((a1838812917 == 35 && (a714559100 == 11 &&  cf==1 )) && a2005069365 == 36) && a805812408 == 14))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a829511935 = 34 ;
    	a2059681452 = 35 ;
    	a1129866701 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a805812408 == 14 && (a1838812917 == 35 && ((a2005069365 == 36 &&  cf==1 ) && a714559100 == 11))) && (input == 8))) {
    	cf = 0;
    	a604409338 = 33 ;
    	a1519100789 = 6;
    	a2005069365 = 35 ;
    	a954368445 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a805812408 == 14 && ((input == 17) && (a1838812917 == 35 && (a2005069365 == 36 &&  cf==1 )))) && a714559100 == 11)) {
    	cf = 0;
    	a744476156 = 33 ;
    	a88077474 = 36 ;
    	a2005069365 = 35 ;
    	a1519100789 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a805812408 == 14 && (((a1838812917 == 35 &&  cf==1 ) && a714559100 == 11) && a2005069365 == 36)) && (input == 20))) {
    	cf = 0;
    	a369539608 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a1958000800 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm764(int input) {
    if((a1655731851 == 3 && ((input == 10) && (a1838812917 == 35 && ((a714559100 == 12 &&  cf==1 ) && a2005069365 == 36))))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a714559100 == 12 && ((a2005069365 == 36 && (( cf==1  && a1655731851 == 3) && a1838812917 == 35)) && (input == 11)))) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a2005069365 = 33 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 20) && ((a1655731851 == 3 && (a1838812917 == 35 && (a714559100 == 12 &&  cf==1 ))) && a2005069365 == 36))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a679327000 = 35 ;
    	a2059681452 = 35 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm765(int input) {
    if(((a714559100 == 12 && ((input == 8) && (a1838812917 == 35 && (a2005069365 == 36 &&  cf==1 )))) && a1655731851 == 4)) {
    	cf = 0;
    	a815941786 = 35 ;
    	a1838812917 = 34 ;
    	a107446547 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm766(int input) {
    if(((input == 5) && (a1838812917 == 35 && (a714559100 == 12 && (a2005069365 == 36 && (a1655731851 == 5 &&  cf==1 )))))) {
    	cf = 0;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1052150692 = 12;
    	a1957279511 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm767(int input) {
    if(((((input == 1) && (a714559100 == 12 && ( cf==1  && a1838812917 == 35))) && a1655731851 == 6) && a2005069365 == 36)) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a714559100 == 12 && ((input == 11) && (((a1655731851 == 6 &&  cf==1 ) && a1838812917 == 35) && a2005069365 == 36)))) {
    	cf = 0;
    	a679327000 = 33 ;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a2065134388 = 17; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1655731851 == 6 && ((((input == 15) &&  cf==1 ) && a714559100 == 12) && a2005069365 == 36)) && a1838812917 == 35)) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a679327000 = 33 ;
    	a2005069365 = 33 ;
    	a2065134388 = 17; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm768(int input) {
    if((((((a1838812917 == 35 &&  cf==1 ) && a1655731851 == 7) && a2005069365 == 36) && a714559100 == 12) && (input == 6))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a347749795 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm769(int input) {
    if(((a1655731851 == 8 && ((a2005069365 == 36 && ( cf==1  && a714559100 == 12)) && (input == 20))) && a1838812917 == 35)) {
    	cf = 0;
    	a714559100 = 10;
    	a2125137407 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm770(int input) {
    if((a2005069365 == 36 && (a1655731851 == 9 && ((input == 16) && (a714559100 == 12 && ( cf==1  && a1838812917 == 35)))))) {
    	cf = 0;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a834910632 = 34 ;
    	a685667843 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm27(int input) {
    if(( cf==1  && a714559100 == 5)) {
    	if(( cf==1  && a1089968358 == 4)) {
    		calculate_outputm728(input);
    	} 
    	if(( cf==1  && a1089968358 == 5)) {
    		calculate_outputm729(input);
    	} 
    	if((a1089968358 == 6 &&  cf==1 )) {
    		calculate_outputm730(input);
    	} 
    	if(( cf==1  && a1089968358 == 8)) {
    		calculate_outputm732(input);
    	} 
    	if(( cf==1  && a1089968358 == 10)) {
    		calculate_outputm733(input);
    	} 
    	if(( cf==1  && a1089968358 == 11)) {
    		calculate_outputm734(input);
    	} 
    } 
    if(( cf==1  && a714559100 == 6)) {
    	if(( cf==1  && a110820676 == 32)) {
    		calculate_outputm735(input);
    	} 
    	if(( cf==1  && a110820676 == 34)) {
    		calculate_outputm736(input);
    	} 
    	if(( cf==1  && a110820676 == 36)) {
    		calculate_outputm737(input);
    	} 
    } 
    if(( cf==1  && a714559100 == 7)) {
    	if((a491478835 == 32 &&  cf==1 )) {
    		calculate_outputm738(input);
    	} 
    	if((a491478835 == 33 &&  cf==1 )) {
    		calculate_outputm739(input);
    	} 
    	if((a491478835 == 35 &&  cf==1 )) {
    		calculate_outputm740(input);
    	} 
    	if(( cf==1  && a491478835 == 36)) {
    		calculate_outputm741(input);
    	} 
    } 
    if(( cf==1  && a714559100 == 8)) {
    	if((a206599328 == 33 &&  cf==1 )) {
    		calculate_outputm742(input);
    	} 
    	if((a206599328 == 34 &&  cf==1 )) {
    		calculate_outputm743(input);
    	} 
    	if(( cf==1  && a206599328 == 35)) {
    		calculate_outputm744(input);
    	} 
    	if(( cf==1  && a206599328 == 36)) {
    		calculate_outputm745(input);
    	} 
    } 
    if(( cf==1  && a714559100 == 9)) {
    	if((a1498704550 == 32 &&  cf==1 )) {
    		calculate_outputm746(input);
    	} 
    	if(( cf==1  && a1498704550 == 33)) {
    		calculate_outputm747(input);
    	} 
    	if(( cf==1  && a1498704550 == 34)) {
    		calculate_outputm748(input);
    	} 
    	if((a1498704550 == 35 &&  cf==1 )) {
    		calculate_outputm749(input);
    	} 
    	if(( cf==1  && a1498704550 == 36)) {
    		calculate_outputm750(input);
    	} 
    } 
    if(( cf==1  && a714559100 == 10)) {
    	if(( cf==1  && a2125137407 == 5)) {
    		calculate_outputm751(input);
    	} 
    	if((a2125137407 == 8 &&  cf==1 )) {
    		calculate_outputm753(input);
    	} 
    	if(( cf==1  && a2125137407 == 9)) {
    		calculate_outputm754(input);
    	} 
    	if(( cf==1  && a2125137407 == 11)) {
    		calculate_outputm755(input);
    	} 
    } 
    if((a714559100 == 11 &&  cf==1 )) {
    	if(( cf==1  && a805812408 == 7)) {
    		calculate_outputm756(input);
    	} 
    	if((a805812408 == 8 &&  cf==1 )) {
    		calculate_outputm757(input);
    	} 
    	if(( cf==1  && a805812408 == 11)) {
    		calculate_outputm760(input);
    	} 
    	if(( cf==1  && a805812408 == 12)) {
    		calculate_outputm761(input);
    	} 
    	if(( cf==1  && a805812408 == 13)) {
    		calculate_outputm762(input);
    	} 
    	if(( cf==1  && a805812408 == 14)) {
    		calculate_outputm763(input);
    	} 
    } 
    if(( cf==1  && a714559100 == 12)) {
    	if((a1655731851 == 3 &&  cf==1 )) {
    		calculate_outputm764(input);
    	} 
    	if(( cf==1  && a1655731851 == 4)) {
    		calculate_outputm765(input);
    	} 
    	if((a1655731851 == 5 &&  cf==1 )) {
    		calculate_outputm766(input);
    	} 
    	if((a1655731851 == 6 &&  cf==1 )) {
    		calculate_outputm767(input);
    	} 
    	if(( cf==1  && a1655731851 == 7)) {
    		calculate_outputm768(input);
    	} 
    	if(( cf==1  && a1655731851 == 8)) {
    		calculate_outputm769(input);
    	} 
    	if((a1655731851 == 9 &&  cf==1 )) {
    		calculate_outputm770(input);
    	} 
    } 
}
 void calculate_outputm771(int input) {
    if((a200393381 == 1 && ((a2005069365 == 36 && (a1775644016 == 6 && ((input == 4) &&  cf==1 ))) && a1838812917 == 36))) {
    	cf = 0;
    	a650110038 = 36 ;
    	a969893172 = 32 ;
    	a2005069365 = 34 ;
    	a221974990 = 13; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm772(int input) {
    if((a1838812917 == 36 && ((input == 1) && (a2005069365 == 36 && (a200393381 == 2 && ( cf==1  && a1775644016 == 6)))))) {
    	cf = 0;
    	a2059681452 = 32 ;
    	a679327000 = 32 ;
    	a2005069365 = 33 ;
    	a103910758 = 33 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1775644016 == 6 && (a2005069365 == 36 && (a1838812917 == 36 && (a200393381 == 2 && ((input == 10) &&  cf==1 )))))) {
    	cf = 0;
    	a844311967 = 33 ;
    	a2005069365 = 32 ;
    	a1904774218 = 33 ;
    	a1380627758 = 4; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((a1775644016 == 6 &&  cf==1 ) && a200393381 == 2) && (input == 13)) && a1838812917 == 36) && a2005069365 == 36)) {
    	cf = 0;
    	a369539608 = 32 ;
    	a1904774218 = 35 ;
    	a2005069365 = 32 ;
    	a1124714117 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 20) && (a1775644016 == 6 && (a2005069365 == 36 && (a200393381 == 2 &&  cf==1 )))) && a1838812917 == 36)) {
    	cf = 0;
    	a1904774218 = 34 ;
    	a925870636 = 9;
    	a2005069365 = 32 ;
    	a904637882 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm774(int input) {
    if(((a1838812917 == 36 && (a1775644016 == 6 && (( cf==1  && a2005069365 == 36) && (input == 2)))) && a200393381 == 7)) {
    	cf = 0;
    	a1519100789 = 9;
    	a1958000800 = 13;
    	a2005069365 = 35 ;
    	a593874874 = 15; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm775(int input) {
    if((((a2005069365 == 36 && (a200393381 == 8 && ((input == 8) &&  cf==1 ))) && a1838812917 == 36) && a1775644016 == 6)) {
    	cf = 0;
    	a928570136 = 36 ;
    	a1904774218 = 36 ;
    	a2005069365 = 32 ;
    	a998584754 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a1775644016 == 6 && (((input == 17) && (a1838812917 == 36 &&  cf==1 )) && a2005069365 == 36)) && a200393381 == 8)) {
    	cf = 0;
    	a1388584441 = 36 ;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm776(int input) {
    if((a1838812917 == 36 && (a1350444666 == 32 && ((input == 2) && ((a1775644016 == 7 &&  cf==1 ) && a2005069365 == 36))))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a67466277 = 36 ;
    	a107446547 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 7) && ((a2005069365 == 36 && (( cf==1  && a1838812917 == 36) && a1775644016 == 7)) && a1350444666 == 32))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a107446547 = 15;
    	a2059681452 = 36 ;
    	a1566584718 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 10) && (a1838812917 == 36 && ((( cf==1  && a1775644016 == 7) && a1350444666 == 32) && a2005069365 == 36)))) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a369539608 = 35 ;
    	a1904774218 = 35 ;
    	a363404159 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm777(int input) {
    if(((a2005069365 == 36 && (a1775644016 == 7 && ((input == 2) && ( cf==1  && a1838812917 == 36)))) && a1350444666 == 33)) {
    	cf = 0;
    	a927953139 = 35 ;
    	a1838812917 = 32 ;
    	a397915314 = 2; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((input == 14) && (a2005069365 == 36 && (( cf==1  && a1838812917 == 36) && a1775644016 == 7))) && a1350444666 == 33)) {
    	cf = 0;
    	a714559100 = 12;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a1116999236 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((input == 16) && (a2005069365 == 36 &&  cf==1 )) && a1350444666 == 33) && a1838812917 == 36) && a1775644016 == 7)) {
    	cf = 0;
    	a525429632 = 32 ;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a1428914468 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm779(int input) {
    if((a1350444666 == 36 && (a1838812917 == 36 && (((a1775644016 == 7 &&  cf==1 ) && a2005069365 == 36) && (input == 2))))) {
    	cf = 0;
    	a113788596 = 32 ;
    	a1561044360 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1838812917 == 36 && ( cf==1  && a1350444666 == 36)) && (input == 4)) && a2005069365 == 36) && a1775644016 == 7)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a369539608 = 33 ;
    	a2077351330 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1775644016 == 7 && (((( cf==1  && a1838812917 == 36) && (input == 11)) && a2005069365 == 36) && a1350444666 == 36))) {
    	cf = 0;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a714559100 = 7;
    	a1166586546 = 15; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((((input == 14) &&  cf==1 ) && a1775644016 == 7) && a1838812917 == 36) && a1350444666 == 36) && a2005069365 == 36)) {
    	cf = 0;
    	a1904774218 = 32 ;
    	a2005069365 = 32 ;
    	a27741386 = 35 ;
    	a829511935 = 35 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm781(int input) {
    if((a1838812917 == 36 && (a1166586546 == 10 && (((a1775644016 == 8 &&  cf==1 ) && a2005069365 == 36) && (input == 3))))) {
    	cf = 0;
    	a650110038 = 32 ;
    	a2005069365 = 34 ;
    	a969893172 = 32 ;
    	a200393381 = 4; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1166586546 == 10 && (((input == 14) && (a1838812917 == 36 &&  cf==1 )) && a1775644016 == 8)) && a2005069365 == 36)) {
    	cf = 0;
    	a969893172 = 34 ;
    	a2005069365 = 34 ;
    	a714559100 = 5;
    	a1079106761 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm783(int input) {
    if((a1166586546 == 12 && (a2005069365 == 36 && (a1775644016 == 8 && (((input == 6) &&  cf==1 ) && a1838812917 == 36))))) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a1960724031 = 36 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1775644016 == 8 && (((a1838812917 == 36 && (a1166586546 == 12 &&  cf==1 )) && a2005069365 == 36) && (input == 8)))) {
    	cf = 0;
    	a679327000 = 35 ;
    	a2059681452 = 32 ;
    	a2005069365 = 33 ;
    	a1960724031 = 36 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm784(int input) {
    if((((a2005069365 == 36 && ((input == 2) && (a1838812917 == 36 &&  cf==1 ))) && a1166586546 == 13) && a1775644016 == 8)) {
    	cf = 0;
    	a1838812917 = 35 ;
    	a714559100 = 5;
    	a1089968358 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2005069365 == 36 && ((((input == 11) && (a1838812917 == 36 &&  cf==1 )) && a1775644016 == 8) && a1166586546 == 13))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a1243394452 = 6;
    	a132552289 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 13) && (a1838812917 == 36 && (a1775644016 == 8 && (a2005069365 == 36 &&  cf==1 )))) && a1166586546 == 13)) {
    	cf = 0;
    	a1519100789 = 4;
    	a2005069365 = 35 ;
    	a240738299 = 33 ;
    	a201083786 = 17; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1166586546 == 13 && ((input == 17) && (( cf==1  && a1838812917 == 36) && a1775644016 == 8))) && a2005069365 == 36)) {
    	cf = 0;
    	a206599328 = 36 ;
    	a1838812917 = 35 ;
    	a714559100 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm785(int input) {
    if((a1166586546 == 14 && ((a1775644016 == 8 && (a1838812917 == 36 && ((input == 1) &&  cf==1 ))) && a2005069365 == 36))) {
    	cf = 0;
    	a1519100789 = 9;
    	a2005069365 = 35 ;
    	a1958000800 = 12;
    	a798343693 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1838812917 == 36 && ((input == 3) && (a1775644016 == 8 && ( cf==1  && a2005069365 == 36)))) && a1166586546 == 14)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1958000800 = 12;
    	a1519100789 = 9;
    	a798343693 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a1775644016 == 8 && ((input == 20) && ( cf==1  && a2005069365 == 36))) && a1166586546 == 14) && a1838812917 == 36)) {
    	cf = 0;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a169540124 = 32 ;
    	a685667843 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm786(int input) {
    if((((((a1775644016 == 9 &&  cf==1 ) && a2005069365 == 36) && a1838812917 == 36) && (input == 5)) && a1739072993 == 32)) {
    	cf = 0;
    	a1428914468 = 10;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a954368445 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm787(int input) {
    if((a2005069365 == 36 && ((((a1775644016 == 9 &&  cf==1 ) && a1838812917 == 36) && a1739072993 == 33) && (input == 7)))) {
    	cf = 0;
    	a738616794 = 34 ;
    	a2005069365 = 35 ;
    	a1519100789 = 2;
    	a1052150692 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a2005069365 == 36 && (a1775644016 == 9 && ((input == 14) && ( cf==1  && a1739072993 == 33)))) && a1838812917 == 36)) {
    	cf = 0;
    	a1904774218 = 35 ;
    	a369539608 = 36 ;
    	a2005069365 = 32 ;
    	a1577567933 = 32 ; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm788(int input) {
    if((a2005069365 == 36 && (a1838812917 == 36 && (a1775644016 == 9 && (((input == 10) &&  cf==1 ) && a1739072993 == 34))))) {
    	cf = 0;
    	a369539608 = 36 ;
    	a1519100789 = 5;
    	a2005069365 = 35 ;
    	a347749795 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 20) && (((a1838812917 == 36 && ( cf==1  && a1739072993 == 34)) && a2005069365 == 36) && a1775644016 == 9))) {
    	cf = 0;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 14;
    	a2138261183 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm789(int input) {
    if((a1739072993 == 36 && (((input == 3) && (a1838812917 == 36 && (a2005069365 == 36 &&  cf==1 ))) && a1775644016 == 9))) {
    	cf = 0;
    	a1153134505 = 34 ;
    	a240738299 = 35 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1838812917 == 36 && (((a1739072993 == 36 && ( cf==1  && a2005069365 == 36)) && (input == 11)) && a1775644016 == 9))) {
    	cf = 0;
    	a714559100 = 10;
    	a1838812917 = 35 ;
    	a2125137407 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1775644016 == 9 && (((a1739072993 == 36 &&  cf==1 ) && (input == 17)) && a1838812917 == 36)) && a2005069365 == 36)) {
    	cf = 0;
    	a1838812917 = 33 ;
    	a569036257 = 10;
    	a920118831 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1838812917 == 36 && (((input == 4) && (a2005069365 == 36 && ( cf==1  && a1775644016 == 9))) && a1739072993 == 36))) {
    	cf = 0;
    	a1052150692 = 10;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a662123779 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm790(int input) {
    if(((input == 2) && (a2005069365 == 36 && ((a1775644016 == 10 && ( cf==1  && a1492184786 == 32)) && a1838812917 == 36)))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a829511935 = 34 ;
    	a2059681452 = 35 ;
    	a1129866701 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1492184786 == 32 && ((input == 11) && (((a1838812917 == 36 &&  cf==1 ) && a2005069365 == 36) && a1775644016 == 10)))) {
    	cf = 0;
    	a2005069365 = 34 ;
    	a969893172 = 33 ;
    	a2135613870 = 36 ;
    	a1428914468 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1492184786 == 32 && ((( cf==1  && a1838812917 == 36) && a1775644016 == 10) && a2005069365 == 36)) && (input == 12))) {
    	cf = 0;
    	a1684687706 = 9;
    	a2059681452 = 34 ;
    	a2005069365 = 33 ;
    	a892217980 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 19) && (((a1775644016 == 10 && (a1838812917 == 36 &&  cf==1 )) && a1492184786 == 32) && a2005069365 == 36))) {
    	cf = 0;
    	a2124036967 = 33 ;
    	a2005069365 = 34 ;
    	a969893172 = 36 ;
    	a245033430 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm791(int input) {
    if((a1838812917 == 36 && ((a1492184786 == 33 && (( cf==1  && a2005069365 == 36) && a1775644016 == 10)) && (input == 11)))) {
    	cf = 0;
    	a1243394452 = 4;
    	a2005069365 = 35 ;
    	a1519100789 = 7;
    	a685344195 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm792(int input) {
    if((((a1775644016 == 10 && (a1838812917 == 36 && ( cf==1  && (input == 1)))) && a1492184786 == 34) && a2005069365 == 36)) {
    	cf = 0;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1052150692 = 7;
    	a71813398 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a1492184786 == 34 && ((input == 8) &&  cf==1 )) && a1775644016 == 10) && a2005069365 == 36) && a1838812917 == 36)) {
    	cf = 0;
    	a1950243878 = 36 ;
    	a969893172 = 35 ;
    	a2005069365 = 34 ;
    	a685667843 = 15; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1492184786 == 34 && ((( cf==1  && a2005069365 == 36) && (input == 12)) && a1775644016 == 10)) && a1838812917 == 36)) {
    	cf = 0;
    	a1958000800 = 13;
    	a2005069365 = 35 ;
    	a1519100789 = 9;
    	a593874874 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a1838812917 == 36 && (( cf==1  && a2005069365 == 36) && (input == 14))) && a1492184786 == 34) && a1775644016 == 10)) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a1519100789 = 8;
    	a113788596 = 33 ;
    	a137564664 = 17; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm793(int input) {
    if(((((a1492184786 == 35 && ( cf==1  && a2005069365 == 36)) && a1775644016 == 10) && (input == 6)) && a1838812917 == 36)) {
    	cf = 0;
    	a969893172 = 32 ;
    	a650110038 = 34 ;
    	a2005069365 = 34 ;
    	a349181387 = 2; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1838812917 == 36 && (((a1492184786 == 35 && (a2005069365 == 36 &&  cf==1 )) && a1775644016 == 10) && (input == 13)))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a679327000 = 32 ;
    	a2005069365 = 33 ;
    	a1129866701 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1838812917 == 36 && (a2005069365 == 36 && (( cf==1  && a1775644016 == 10) && (input == 17)))) && a1492184786 == 35)) {
    	cf = 0;
    	a2005069365 = 32 ;
    	a1904774218 = 32 ;
    	a27741386 = 36 ;
    	a792575314 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 19) && (((( cf==1  && a1775644016 == 10) && a2005069365 == 36) && a1492184786 == 35) && a1838812917 == 36))) {
    	cf = 0;
    	a1492184786 = 34 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm794(int input) {
    if(((((a1775644016 == 11 && (a2005069365 == 36 &&  cf==1 )) && a1838812917 == 36) && a1566584718 == 7) && (input == 10))) {
    	cf = 0;
    	a1739072993 = 34 ;
    	a1775644016 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 16) && (((( cf==1  && a1775644016 == 11) && a1566584718 == 7) && a2005069365 == 36) && a1838812917 == 36))) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a602507557 = 32 ;
    	a2059681452 = 34 ;
    	a1684687706 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm795(int input) {
    if((((((a2005069365 == 36 &&  cf==1 ) && a1838812917 == 36) && a1775644016 == 11) && a1566584718 == 8) && (input == 19))) {
    	cf = 0;
    	a604409338 = 34 ;
    	a2005069365 = 35 ;
    	a933478840 = 34 ;
    	a1519100789 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm796(int input) {
    if((((a1566584718 == 9 && (a1838812917 == 36 && (a1775644016 == 11 &&  cf==1 ))) && a2005069365 == 36) && (input == 10))) {
    	cf = 0;
    	a2059681452 = 35 ;
    	a1838812917 = 34 ;
    	a107446547 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1566584718 == 9 && (((a1838812917 == 36 &&  cf==1 ) && a2005069365 == 36) && (input == 15))) && a1775644016 == 11)) {
    	cf = 0;
    	a369539608 = 32 ;
    	a1904774218 = 35 ;
    	a2005069365 = 32 ;
    	a1124714117 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1775644016 == 11 && (((a2005069365 == 36 && (a1838812917 == 36 &&  cf==1 )) && a1566584718 == 9) && (input == 19)))) {
    	cf = 0;
    	a491478835 = 32 ;
    	a1838812917 = 35 ;
    	a714559100 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a1775644016 == 11 && (a1566584718 == 9 && ( cf==1  && (input == 20)))) && a2005069365 == 36) && a1838812917 == 36)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 34 ;
    	a1684687706 = 9;
    	a892217980 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm797(int input) {
    if((a1838812917 == 36 && ((a1775644016 == 11 && ((a1566584718 == 10 &&  cf==1 ) && (input == 1))) && a2005069365 == 36))) {
    	cf = 0;
    	a240738299 = 35 ;
    	a1153134505 = 33 ;
    	a2005069365 = 35 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1775644016 == 11 && (a2005069365 == 36 && (a1566584718 == 10 && (((input == 7) &&  cf==1 ) && a1838812917 == 36))))) {
    	cf = 0;
    	a2005069365 = 35 ;
    	a240738299 = 35 ;
    	a1153134505 = 33 ;
    	a1519100789 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1566584718 == 10 && (a1838812917 == 36 && (((a1775644016 == 11 &&  cf==1 ) && (input == 10)) && a2005069365 == 36)))) {
    	cf = 0;
    	a1519100789 = 2;
    	a2005069365 = 35 ;
    	a1085908735 = 34 ;
    	a1052150692 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1775644016 == 11 && (a2005069365 == 36 && ((a1566584718 == 10 && ( cf==1  && a1838812917 == 36)) && (input == 14))))) {
    	cf = 0;
    	a367284938 = 33 ;
    	a2005069365 = 34 ;
    	a969893172 = 35 ;
    	a685667843 = 16; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm798(int input) {
    if(((a1838812917 == 36 && ((input == 8) && (a1566584718 == 12 && ( cf==1  && a1775644016 == 11)))) && a2005069365 == 36)) {
    	cf = 0;
    	a2005069365 = 33 ;
    	a2059681452 = 32 ;
    	a679327000 = 36 ;
    	a1124714117 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1838812917 == 36 && (((( cf==1  && a1775644016 == 11) && a2005069365 == 36) && (input == 12)) && a1566584718 == 12))) {
    	cf = 0;
    	a1838812917 = 34 ;
    	a107446547 = 15;
    	a275125637 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm800(int input) {
    if(((a2005069365 == 36 && (a740799408 == 32 && (a1775644016 == 12 && ( cf==1  && a1838812917 == 36)))) && (input == 15))) {
    	cf = 0;
    	a1904774218 = 33 ;
    	a2005069365 = 32 ;
    	a844311967 = 35 ;
    	a205734433 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm801(int input) {
    if((a1838812917 == 36 && (a1775644016 == 12 && ((a740799408 == 34 && ( cf==1  && (input == 6))) && a2005069365 == 36)))) {
    	cf = 0;
    	a714559100 = 6;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a1086754137 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 7) && ((a740799408 == 34 && (a1838812917 == 36 && ( cf==1  && a2005069365 == 36))) && a1775644016 == 12))) {
    	cf = 0;
    	a369539608 = 33 ;
    	a2005069365 = 32 ;
    	a1904774218 = 35 ;
    	a2077351330 = 3; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a740799408 == 34 && ((input == 14) && ((a2005069365 == 36 &&  cf==1 ) && a1775644016 == 12))) && a1838812917 == 36)) {
    	cf = 0;
    	a829511935 = 34 ;
    	a2005069365 = 33 ;
    	a2059681452 = 35 ;
    	a1129866701 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm802(int input) {
    if((a2005069365 == 36 && (((a1838812917 == 36 && (a1775644016 == 12 &&  cf==1 )) && a740799408 == 35) && (input == 12)))) {
    	cf = 0;
    	a714559100 = 12;
    	a1838812917 = 35 ;
    	a1655731851 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm803(int input) {
    if(((((a2005069365 == 36 && ( cf==1  && a1838812917 == 36)) && a1775644016 == 13) && (input == 20)) && a525429632 == 32)) {
    	cf = 0;
    	a687007811 = 36 ;
    	a2005069365 = 34 ;
    	a969893172 = 34 ;
    	a714559100 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm805(int input) {
    if((((((a1775644016 == 13 &&  cf==1 ) && (input == 13)) && a525429632 == 34) && a1838812917 == 36) && a2005069365 == 36)) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm28(int input) {
    if(( cf==1  && a1775644016 == 6)) {
    	if(( cf==1  && a200393381 == 1)) {
    		calculate_outputm771(input);
    	} 
    	if((a200393381 == 2 &&  cf==1 )) {
    		calculate_outputm772(input);
    	} 
    	if((a200393381 == 7 &&  cf==1 )) {
    		calculate_outputm774(input);
    	} 
    	if(( cf==1  && a200393381 == 8)) {
    		calculate_outputm775(input);
    	} 
    } 
    if((a1775644016 == 7 &&  cf==1 )) {
    	if(( cf==1  && a1350444666 == 32)) {
    		calculate_outputm776(input);
    	} 
    	if((a1350444666 == 33 &&  cf==1 )) {
    		calculate_outputm777(input);
    	} 
    	if(( cf==1  && a1350444666 == 36)) {
    		calculate_outputm779(input);
    	} 
    } 
    if(( cf==1  && a1775644016 == 8)) {
    	if((a1166586546 == 10 &&  cf==1 )) {
    		calculate_outputm781(input);
    	} 
    	if((a1166586546 == 12 &&  cf==1 )) {
    		calculate_outputm783(input);
    	} 
    	if(( cf==1  && a1166586546 == 13)) {
    		calculate_outputm784(input);
    	} 
    	if(( cf==1  && a1166586546 == 14)) {
    		calculate_outputm785(input);
    	} 
    } 
    if((a1775644016 == 9 &&  cf==1 )) {
    	if((a1739072993 == 32 &&  cf==1 )) {
    		calculate_outputm786(input);
    	} 
    	if(( cf==1  && a1739072993 == 33)) {
    		calculate_outputm787(input);
    	} 
    	if((a1739072993 == 34 &&  cf==1 )) {
    		calculate_outputm788(input);
    	} 
    	if(( cf==1  && a1739072993 == 36)) {
    		calculate_outputm789(input);
    	} 
    } 
    if(( cf==1  && a1775644016 == 10)) {
    	if((a1492184786 == 32 &&  cf==1 )) {
    		calculate_outputm790(input);
    	} 
    	if((a1492184786 == 33 &&  cf==1 )) {
    		calculate_outputm791(input);
    	} 
    	if((a1492184786 == 34 &&  cf==1 )) {
    		calculate_outputm792(input);
    	} 
    	if((a1492184786 == 35 &&  cf==1 )) {
    		calculate_outputm793(input);
    	} 
    } 
    if((a1775644016 == 11 &&  cf==1 )) {
    	if((a1566584718 == 7 &&  cf==1 )) {
    		calculate_outputm794(input);
    	} 
    	if(( cf==1  && a1566584718 == 8)) {
    		calculate_outputm795(input);
    	} 
    	if((a1566584718 == 9 &&  cf==1 )) {
    		calculate_outputm796(input);
    	} 
    	if((a1566584718 == 10 &&  cf==1 )) {
    		calculate_outputm797(input);
    	} 
    	if(( cf==1  && a1566584718 == 12)) {
    		calculate_outputm798(input);
    	} 
    } 
    if((a1775644016 == 12 &&  cf==1 )) {
    	if(( cf==1  && a740799408 == 32)) {
    		calculate_outputm800(input);
    	} 
    	if(( cf==1  && a740799408 == 34)) {
    		calculate_outputm801(input);
    	} 
    	if(( cf==1  && a740799408 == 35)) {
    		calculate_outputm802(input);
    	} 
    } 
    if(( cf==1  && a1775644016 == 13)) {
    	if((a525429632 == 32 &&  cf==1 )) {
    		calculate_outputm803(input);
    	} 
    	if((a525429632 == 34 &&  cf==1 )) {
    		calculate_outputm805(input);
    	} 
    } 
}

 void calculate_output(int input) {
        cf = 1;

    if((a2005069365 == 32 &&  cf==1 )) {
    	if((a1904774218 == 32 &&  cf==1 )) {
    		calculate_outputm1(input);
    	} 
    	if(( cf==1  && a1904774218 == 33)) {
    		calculate_outputm2(input);
    	} 
    	if((a1904774218 == 34 &&  cf==1 )) {
    		calculate_outputm3(input);
    	} 
    	if((a1904774218 == 35 &&  cf==1 )) {
    		calculate_outputm4(input);
    	} 
    	if(( cf==1  && a1904774218 == 36)) {
    		calculate_outputm5(input);
    	} 
    } 
    if(( cf==1  && a2005069365 == 33)) {
    	if((a2059681452 == 32 &&  cf==1 )) {
    		calculate_outputm6(input);
    	} 
    	if((a2059681452 == 33 &&  cf==1 )) {
    		calculate_outputm7(input);
    	} 
    	if((a2059681452 == 34 &&  cf==1 )) {
    		calculate_outputm8(input);
    	} 
    	if((a2059681452 == 35 &&  cf==1 )) {
    		calculate_outputm9(input);
    	} 
    	if(( cf==1  && a2059681452 == 36)) {
    		calculate_outputm10(input);
    	} 
    } 
    if((a2005069365 == 34 &&  cf==1 )) {
    	if((a969893172 == 32 &&  cf==1 )) {
    		calculate_outputm11(input);
    	} 
    	if((a969893172 == 33 &&  cf==1 )) {
    		calculate_outputm12(input);
    	} 
    	if((a969893172 == 34 &&  cf==1 )) {
    		calculate_outputm13(input);
    	} 
    	if((a969893172 == 35 &&  cf==1 )) {
    		calculate_outputm14(input);
    	} 
    	if((a969893172 == 36 &&  cf==1 )) {
    		calculate_outputm15(input);
    	} 
    } 
    if((a2005069365 == 35 &&  cf==1 )) {
    	if((a1519100789 == 2 &&  cf==1 )) {
    		calculate_outputm16(input);
    	} 
    	if((a1519100789 == 3 &&  cf==1 )) {
    		calculate_outputm17(input);
    	} 
    	if(( cf==1  && a1519100789 == 4)) {
    		calculate_outputm18(input);
    	} 
    	if((a1519100789 == 5 &&  cf==1 )) {
    		calculate_outputm19(input);
    	} 
    	if(( cf==1  && a1519100789 == 6)) {
    		calculate_outputm20(input);
    	} 
    	if(( cf==1  && a1519100789 == 7)) {
    		calculate_outputm21(input);
    	} 
    	if(( cf==1  && a1519100789 == 8)) {
    		calculate_outputm22(input);
    	} 
    	if(( cf==1  && a1519100789 == 9)) {
    		calculate_outputm23(input);
    	} 
    } 
    if(( cf==1  && a2005069365 == 36)) {
    	if((a1838812917 == 32 &&  cf==1 )) {
    		calculate_outputm24(input);
    	} 
    	if(( cf==1  && a1838812917 == 33)) {
    		calculate_outputm25(input);
    	} 
    	if(( cf==1  && a1838812917 == 34)) {
    		calculate_outputm26(input);
    	} 
    	if((a1838812917 == 35 &&  cf==1 )) {
    		calculate_outputm27(input);
    	} 
    	if(( cf==1  && a1838812917 == 36)) {
    		calculate_outputm28(input);
    	} 
    } 
    errorCheck();

    if( cf==1 ) 
    	fprintf(stderr, "Invalid input: %d\n", input); 
}

int main()
{
    // main i/o-loop
    while(1)
    {
        // read input
		int input = 0;
		int ret = scanf("%d", &input);
		if (ret != 1) return 0;       
        // operate eca engine
        if((input != 13) && (input != 16) && (input != 2) && (input != 8) && (input != 9) && (input != 20) && (input != 10) && (input != 17) && (input != 6) && (input != 5) && (input != 15) && (input != 18) && (input != 11) && (input != 12) && (input != 4) && (input != 1) && (input != 19) && (input != 14) && (input != 7) && (input != 3))
          return -2;
        calculate_output(input);
    }
}