#include <stdio.h> 
#include <assert.h>
#include <math.h>
#include <stdlib.h>

void __VERIFIER_error(int i) {
    fprintf(stderr, "error_%d ", i);
    assert(0);
}

	// inputs
	int inputs[] = {7,2,10,15,5,4,6,11,9,1,12,8,3,14,13};

	void errorCheck();
	void calculate_output(int);
	void calculate_outputm1(int);
	void calculate_outputm2(int);
	void calculate_outputm3(int);
	void calculate_outputm4(int);
	void calculate_outputm5(int);
	void calculate_outputm6(int);
	void calculate_outputm7(int);
	void calculate_outputm8(int);
	void calculate_outputm9(int);
	void calculate_outputm10(int);
	void calculate_outputm11(int);
	void calculate_outputm12(int);
	void calculate_outputm13(int);
	void calculate_outputm14(int);
	void calculate_outputm15(int);
	void calculate_outputm16(int);
	void calculate_outputm17(int);
	void calculate_outputm18(int);
	void calculate_outputm19(int);
	void calculate_outputm20(int);
	void calculate_outputm21(int);
	void calculate_outputm22(int);
	void calculate_outputm23(int);
	void calculate_outputm24(int);
	void calculate_outputm25(int);
	void calculate_outputm26(int);
	void calculate_outputm27(int);
	void calculate_outputm28(int);
	void calculate_outputm29(int);
	void calculate_outputm30(int);
	void calculate_outputm31(int);
	void calculate_outputm32(int);
	void calculate_outputm33(int);
	void calculate_outputm34(int);
	void calculate_outputm35(int);
	void calculate_outputm36(int);
	void calculate_outputm37(int);
	void calculate_outputm38(int);
	void calculate_outputm39(int);
	void calculate_outputm40(int);
	void calculate_outputm41(int);
	void calculate_outputm42(int);
	void calculate_outputm43(int);
	void calculate_outputm44(int);
	void calculate_outputm45(int);
	void calculate_outputm46(int);
	void calculate_outputm47(int);
	void calculate_outputm48(int);
	void calculate_outputm49(int);
	void calculate_outputm50(int);
	void calculate_outputm51(int);
	void calculate_outputm52(int);
	void calculate_outputm53(int);
	void calculate_outputm54(int);
	void calculate_outputm55(int);
	void calculate_outputm56(int);
	void calculate_outputm57(int);
	void calculate_outputm58(int);
	void calculate_outputm59(int);
	void calculate_outputm60(int);
	void calculate_outputm61(int);
	void calculate_outputm62(int);
	void calculate_outputm63(int);
	void calculate_outputm64(int);
	void calculate_outputm65(int);
	void calculate_outputm66(int);
	void calculate_outputm67(int);
	void calculate_outputm68(int);
	void calculate_outputm69(int);
	void calculate_outputm70(int);
	void calculate_outputm71(int);
	void calculate_outputm72(int);
	void calculate_outputm73(int);
	void calculate_outputm74(int);
	void calculate_outputm75(int);
	void calculate_outputm76(int);
	void calculate_outputm77(int);
	void calculate_outputm78(int);
	void calculate_outputm79(int);
	void calculate_outputm80(int);
	void calculate_outputm81(int);
	void calculate_outputm82(int);
	void calculate_outputm83(int);
	void calculate_outputm84(int);
	void calculate_outputm85(int);
	void calculate_outputm86(int);
	void calculate_outputm87(int);
	void calculate_outputm88(int);
	void calculate_outputm89(int);
	void calculate_outputm90(int);
	void calculate_outputm91(int);
	void calculate_outputm92(int);
	void calculate_outputm93(int);
	void calculate_outputm94(int);
	void calculate_outputm95(int);
	void calculate_outputm96(int);
	void calculate_outputm97(int);
	void calculate_outputm98(int);
	void calculate_outputm99(int);
	void calculate_outputm100(int);
	void calculate_outputm101(int);
	void calculate_outputm102(int);
	void calculate_outputm103(int);
	void calculate_outputm104(int);
	void calculate_outputm105(int);
	void calculate_outputm106(int);
	void calculate_outputm107(int);
	void calculate_outputm108(int);
	void calculate_outputm109(int);
	void calculate_outputm110(int);
	void calculate_outputm111(int);
	void calculate_outputm112(int);
	void calculate_outputm113(int);
	void calculate_outputm114(int);
	void calculate_outputm115(int);
	void calculate_outputm116(int);
	void calculate_outputm117(int);
	void calculate_outputm118(int);
	void calculate_outputm119(int);
	void calculate_outputm120(int);
	void calculate_outputm121(int);
	void calculate_outputm122(int);
	void calculate_outputm123(int);
	void calculate_outputm124(int);
	void calculate_outputm125(int);
	void calculate_outputm126(int);
	void calculate_outputm127(int);
	void calculate_outputm128(int);
	void calculate_outputm129(int);
	void calculate_outputm130(int);
	void calculate_outputm131(int);
	void calculate_outputm132(int);
	void calculate_outputm133(int);
	void calculate_outputm134(int);
	void calculate_outputm135(int);
	void calculate_outputm136(int);
	void calculate_outputm137(int);
	void calculate_outputm138(int);
	void calculate_outputm139(int);
	void calculate_outputm140(int);
	void calculate_outputm141(int);
	void calculate_outputm142(int);
	void calculate_outputm143(int);
	void calculate_outputm144(int);
	void calculate_outputm145(int);
	void calculate_outputm146(int);
	void calculate_outputm147(int);
	void calculate_outputm148(int);
	void calculate_outputm149(int);
	void calculate_outputm150(int);
	void calculate_outputm151(int);
	void calculate_outputm152(int);
	void calculate_outputm153(int);
	void calculate_outputm154(int);
	void calculate_outputm155(int);
	void calculate_outputm156(int);
	void calculate_outputm157(int);
	void calculate_outputm158(int);
	void calculate_outputm159(int);
	void calculate_outputm160(int);
	void calculate_outputm161(int);
	void calculate_outputm162(int);
	void calculate_outputm163(int);
	void calculate_outputm164(int);
	void calculate_outputm165(int);
	void calculate_outputm166(int);
	void calculate_outputm167(int);
	void calculate_outputm168(int);
	void calculate_outputm169(int);
	void calculate_outputm170(int);
	void calculate_outputm171(int);
	void calculate_outputm172(int);
	void calculate_outputm173(int);
	void calculate_outputm174(int);
	void calculate_outputm175(int);
	void calculate_outputm176(int);
	void calculate_outputm177(int);
	void calculate_outputm178(int);
	void calculate_outputm179(int);
	void calculate_outputm180(int);
	void calculate_outputm181(int);
	void calculate_outputm182(int);
	void calculate_outputm183(int);
	void calculate_outputm184(int);
	void calculate_outputm185(int);
	void calculate_outputm186(int);
	void calculate_outputm187(int);
	void calculate_outputm188(int);
	void calculate_outputm189(int);
	void calculate_outputm190(int);
	void calculate_outputm191(int);
	void calculate_outputm192(int);
	void calculate_outputm193(int);
	void calculate_outputm194(int);
	void calculate_outputm195(int);
	void calculate_outputm196(int);
	void calculate_outputm197(int);
	void calculate_outputm198(int);
	void calculate_outputm199(int);
	void calculate_outputm200(int);
	void calculate_outputm201(int);
	void calculate_outputm202(int);
	void calculate_outputm203(int);
	void calculate_outputm204(int);
	void calculate_outputm205(int);
	void calculate_outputm206(int);
	void calculate_outputm207(int);
	void calculate_outputm208(int);
	void calculate_outputm209(int);
	void calculate_outputm210(int);
	void calculate_outputm211(int);
	void calculate_outputm212(int);
	void calculate_outputm213(int);
	void calculate_outputm214(int);
	void calculate_outputm215(int);
	void calculate_outputm216(int);
	void calculate_outputm217(int);
	void calculate_outputm218(int);
	void calculate_outputm219(int);
	void calculate_outputm220(int);
	void calculate_outputm221(int);
	void calculate_outputm222(int);
	void calculate_outputm223(int);
	void calculate_outputm224(int);
	void calculate_outputm225(int);
	void calculate_outputm226(int);
	void calculate_outputm227(int);
	void calculate_outputm228(int);
	void calculate_outputm229(int);
	void calculate_outputm230(int);
	void calculate_outputm231(int);
	void calculate_outputm232(int);
	void calculate_outputm233(int);
	void calculate_outputm234(int);
	void calculate_outputm235(int);
	void calculate_outputm236(int);
	void calculate_outputm237(int);
	void calculate_outputm238(int);
	void calculate_outputm239(int);
	void calculate_outputm240(int);
	void calculate_outputm241(int);
	void calculate_outputm242(int);
	void calculate_outputm243(int);
	void calculate_outputm244(int);
	void calculate_outputm245(int);
	void calculate_outputm246(int);
	void calculate_outputm247(int);
	void calculate_outputm248(int);
	void calculate_outputm249(int);
	void calculate_outputm250(int);
	void calculate_outputm251(int);
	void calculate_outputm252(int);
	void calculate_outputm253(int);
	void calculate_outputm254(int);
	void calculate_outputm255(int);
	void calculate_outputm256(int);
	void calculate_outputm257(int);
	void calculate_outputm258(int);
	void calculate_outputm259(int);
	void calculate_outputm260(int);
	void calculate_outputm261(int);
	void calculate_outputm262(int);
	void calculate_outputm263(int);
	void calculate_outputm264(int);
	void calculate_outputm265(int);
	void calculate_outputm266(int);
	void calculate_outputm267(int);
	void calculate_outputm268(int);
	void calculate_outputm269(int);
	void calculate_outputm270(int);
	void calculate_outputm271(int);
	void calculate_outputm272(int);
	void calculate_outputm273(int);
	void calculate_outputm274(int);
	void calculate_outputm275(int);
	void calculate_outputm276(int);
	void calculate_outputm277(int);
	void calculate_outputm278(int);
	void calculate_outputm279(int);
	void calculate_outputm280(int);
	void calculate_outputm281(int);
	void calculate_outputm282(int);
	void calculate_outputm283(int);
	void calculate_outputm284(int);
	void calculate_outputm285(int);
	void calculate_outputm286(int);
	void calculate_outputm287(int);
	void calculate_outputm288(int);
	void calculate_outputm289(int);
	void calculate_outputm290(int);
	void calculate_outputm291(int);
	void calculate_outputm292(int);
	void calculate_outputm293(int);
	void calculate_outputm294(int);
	void calculate_outputm295(int);
	void calculate_outputm296(int);
	void calculate_outputm297(int);
	void calculate_outputm298(int);
	void calculate_outputm299(int);
	void calculate_outputm300(int);
	void calculate_outputm301(int);
	void calculate_outputm302(int);
	void calculate_outputm303(int);
	void calculate_outputm304(int);
	void calculate_outputm305(int);
	void calculate_outputm306(int);
	void calculate_outputm307(int);
	void calculate_outputm308(int);
	void calculate_outputm309(int);
	void calculate_outputm310(int);
	void calculate_outputm311(int);
	void calculate_outputm312(int);
	void calculate_outputm313(int);
	void calculate_outputm314(int);
	void calculate_outputm315(int);
	void calculate_outputm316(int);
	void calculate_outputm317(int);
	void calculate_outputm318(int);
	void calculate_outputm319(int);
	void calculate_outputm320(int);
	void calculate_outputm321(int);
	void calculate_outputm322(int);

	 int a10419264  = 35;
	 int a179752516 = 6;
	 int a1736640332 = 6;
	 int a1053530639 = 6;
	 int a127383885 = 5;
	 int a286009693 = 12;
	 int a1837110425 = 5;
	 int a565249046 = 9;
	 int a864013224 = 16;
	 int a2015844410 = 8;
	 int a2121950185  = 34;
	 int a583612627 = 11;
	 int a782039646 = 7;
	 int a1746137894 = 11;
	 int a2135239265  = 32;
	 int a1237428760 = 4;
	 int a940472710 = 9;
	 int a880660927 = 15;
	 int a1498174835  = 32;
	 int cf = 1;
	 int a1132599179  = 36;
	 int a384913899  = 33;
	 int a1438665870 = 6;
	 int a324926224 = 8;
	 int a1510817746 = 9;
	 int a147402251  = 33;
	 int a1478065937  = 35;
	 int a113972147  = 35;
	 int a962095080 = 7;
	 int a932751092 = 5;
	 int a1750379405  = 33;
	 int a620299262  = 32;
	 int a950417444 = 13;
	 int a1959734605 = 7;
	 int a200918022 = 6;
	 int a757401042 = 4;
	 int a1760493561 = 14;
	 int a1074841212 = 7;
	 int a1255937088 = 12;
	 int a1149219151  = 33;
	 int a1273086420  = 36;
	 int a866603139 = 7;
	 int a2045918669 = 7;
	 int a365147679 = 8;
	 int a1383458586 = 8;
	 int a1664587146  = 33;
	 int a307029135  = 35;
	 int a1249410904 = 6;
	 int a598251408  = 33;
	 int a1602107789  = 33;
	 int a1210809645 = 13;
	 int a880642005  = 34;
	 int a338143956  = 32;
	 int a1259748523  = 33;
	 int a1031697847 = 12;
	 int a1851906186  = 33;
	 int a1335229626 = 12;
	 int a389949481  = 36;
	 int a654409942 = 11;
	 int a1250255157 = 11;
	 int a269427955 = 8;


	void errorCheck() {
	    if(((a1250255157 == 14 && a1959734605 == 9) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(0);
	    }
	    if(((a864013224 == 17 && a1273086420 == 36) && a1335229626 == 8)){
	    cf = 0;
	    __VERIFIER_error(1);
	    }
	    if(((a583612627 == 9 && a384913899 == 35) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(2);
	    }
	    if(((a1498174835 == 33 && a1510817746 == 12) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(3);
	    }
	    if(((a654409942 == 11 && a1510817746 == 11) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(4);
	    }
	    if(((a1210809645 == 10 && a1959734605 == 3) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(5);
	    }
	    if(((a1132599179 == 33 && a1959734605 == 4) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(6);
	    }
	    if(((a757401042 == 4 && a269427955 == 9) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(7);
	    }
	    if(((a179752516 == 10 && a1959734605 == 7) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(8);
	    }
	    if(((a598251408 == 34 && a1851906186 == 34) && a1335229626 == 9)){
	    cf = 0;
	    __VERIFIER_error(9);
	    }
	    if(((a1837110425 == 3 && a880660927 == 11) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(10);
	    }
	    if(((a962095080 == 8 && a950417444 == 13) && a1335229626 == 12)){
	    cf = 0;
	    __VERIFIER_error(11);
	    }
	    if(((a1760493561 == 14 && a950417444 == 10) && a1335229626 == 12)){
	    cf = 0;
	    __VERIFIER_error(12);
	    }
	    if(((a200918022 == 7 && a880660927 == 10) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(13);
	    }
	    if(((a365147679 == 14 && a1851906186 == 32) && a1335229626 == 9)){
	    cf = 0;
	    __VERIFIER_error(14);
	    }
	    if(((a1031697847 == 8 && a384913899 == 32) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(15);
	    }
	    if(((a338143956 == 34 && a269427955 == 12) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(16);
	    }
	    if(((a1383458586 == 2 && a1851906186 == 33) && a1335229626 == 9)){
	    cf = 0;
	    __VERIFIER_error(17);
	    }
	    if(((a1478065937 == 35 && a950417444 == 7) && a1335229626 == 12)){
	    cf = 0;
	    __VERIFIER_error(18);
	    }
	    if(((a1478065937 == 34 && a950417444 == 7) && a1335229626 == 12)){
	    cf = 0;
	    __VERIFIER_error(19);
	    }
	    if(((a2015844410 == 8 && a1851906186 == 36) && a1335229626 == 9)){
	    cf = 0;
	    __VERIFIER_error(20);
	    }
	    if(((a1746137894 == 13 && a269427955 == 8) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(21);
	    }
	    if(((a127383885 == 12 && a269427955 == 7) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(22);
	    }
	    if(((a2015844410 == 10 && a1851906186 == 36) && a1335229626 == 9)){
	    cf = 0;
	    __VERIFIER_error(23);
	    }
	    if(((a307029135 == 34 && a384913899 == 33) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(24);
	    }
	    if(((a2135239265 == 33 && a950417444 == 11) && a1335229626 == 12)){
	    cf = 0;
	    __VERIFIER_error(25);
	    }
	    if(((a1053530639 == 9 && a269427955 == 13) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(26);
	    }
	    if(((a1837110425 == 8 && a880660927 == 11) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(27);
	    }
	    if(((a940472710 == 10 && a1510817746 == 7) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(28);
	    }
	    if(((a1438665870 == 10 && a950417444 == 6) && a1335229626 == 12)){
	    cf = 0;
	    __VERIFIER_error(29);
	    }
	    if(((a1210809645 == 9 && a1959734605 == 6) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(30);
	    }
	    if(((a1053530639 == 6 && a269427955 == 13) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(31);
	    }
	    if(((a1760493561 == 13 && a950417444 == 10) && a1335229626 == 12)){
	    cf = 0;
	    __VERIFIER_error(32);
	    }
	    if(((a1664587146 == 34 && a880660927 == 14) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(33);
	    }
	    if(((a866603139 == 7 && a1510817746 == 10) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(34);
	    }
	    if(((a1255937088 == 6 && a950417444 == 12) && a1335229626 == 12)){
	    cf = 0;
	    __VERIFIER_error(35);
	    }
	    if(((a2121950185 == 34 && a880660927 == 9) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(36);
	    }
	    if(((a1383458586 == 3 && a1851906186 == 33) && a1335229626 == 9)){
	    cf = 0;
	    __VERIFIER_error(37);
	    }
	    if(((a324926224 == 1 && a1959734605 == 2) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(38);
	    }
	    if(((a1249410904 == 4 && a880660927 == 13) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(39);
	    }
	    if(((a1959734605 == 6 && a269427955 == 11) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(40);
	    }
	    if(((a1031697847 == 7 && a384913899 == 32) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(41);
	    }
	    if(((a1383458586 == 8 && a1273086420 == 35) && a1335229626 == 8)){
	    cf = 0;
	    __VERIFIER_error(42);
	    }
	    if(((a127383885 == 6 && a269427955 == 7) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(43);
	    }
	    if(((a324926224 == 4 && a1959734605 == 2) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(44);
	    }
	    if(((a782039646 == 10 && a1510817746 == 8) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(45);
	    }
	    if(((a2015844410 == 7 && a1851906186 == 36) && a1335229626 == 9)){
	    cf = 0;
	    __VERIFIER_error(46);
	    }
	    if(((a324926224 == 8 && a1959734605 == 2) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(47);
	    }
	    if(((a1210809645 == 11 && a1959734605 == 3) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(48);
	    }
	    if(((a200918022 == 12 && a880660927 == 10) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(49);
	    }
	    if(((a10419264 == 33 && a384913899 == 34) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(50);
	    }
	    if(((a1250255157 == 10 && a1959734605 == 9) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(51);
	    }
	    if(((a565249046 == 10 && a950417444 == 9) && a1335229626 == 12)){
	    cf = 0;
	    __VERIFIER_error(52);
	    }
	    if(((a2135239265 == 35 && a950417444 == 11) && a1335229626 == 12)){
	    cf = 0;
	    __VERIFIER_error(53);
	    }
	    if(((a324926224 == 7 && a1959734605 == 2) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(54);
	    }
	    if(((a2045918669 == 9 && a880660927 == 12) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(55);
	    }
	    if(((a583612627 == 16 && a384913899 == 35) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(56);
	    }
	    if(((a1074841212 == 10 && a1273086420 == 32) && a1335229626 == 8)){
	    cf = 0;
	    __VERIFIER_error(57);
	    }
	    if(((a932751092 == 7 && a1510817746 == 13) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(58);
	    }
	    if(((a620299262 == 33 && a384913899 == 36) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(59);
	    }
	    if(((a286009693 == 14 && a1959734605 == 8) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(60);
	    }
	    if(((a307029135 == 35 && a384913899 == 33) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(61);
	    }
	    if(((a2135239265 == 36 && a950417444 == 11) && a1335229626 == 12)){
	    cf = 0;
	    __VERIFIER_error(62);
	    }
	    if(((a286009693 == 12 && a1959734605 == 8) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(63);
	    }
	    if(((a286009693 == 8 && a1959734605 == 8) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(64);
	    }
	    if(((a200918022 == 9 && a880660927 == 10) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(65);
	    }
	    if(((a654409942 == 12 && a1510817746 == 11) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(66);
	    }
	    if(((a1132599179 == 36 && a1959734605 == 4) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(67);
	    }
	    if(((a2121950185 == 32 && a880660927 == 9) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(68);
	    }
	    if(((a307029135 == 36 && a384913899 == 33) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(69);
	    }
	    if(((a864013224 == 16 && a1273086420 == 36) && a1335229626 == 8)){
	    cf = 0;
	    __VERIFIER_error(70);
	    }
	    if(((a1210809645 == 7 && a1959734605 == 3) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(71);
	    }
	    if(((a782039646 == 12 && a1510817746 == 8) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(72);
	    }
	    if(((a1746137894 == 15 && a269427955 == 8) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(73);
	    }
	    if(((a365147679 == 8 && a1851906186 == 32) && a1335229626 == 9)){
	    cf = 0;
	    __VERIFIER_error(74);
	    }
	    if(((a757401042 == 5 && a269427955 == 9) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(75);
	    }
	    if(((a1210809645 == 9 && a1959734605 == 3) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(76);
	    }
	    if(((a338143956 == 33 && a269427955 == 12) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(77);
	    }
	    if(((a1249410904 == 10 && a880660927 == 13) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(78);
	    }
	    if(((a127383885 == 5 && a269427955 == 7) && a1335229626 == 11)){
	    cf = 0;
	    __VERIFIER_error(79);
	    }
	    if(((a1498174835 == 36 && a1510817746 == 12) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(80);
	    }
	    if(((a620299262 == 35 && a384913899 == 36) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(81);
	    }
	    if(((a1736640332 == 6 && a880660927 == 15) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(82);
	    }
	    if(((a864013224 == 10 && a1273086420 == 36) && a1335229626 == 8)){
	    cf = 0;
	    __VERIFIER_error(83);
	    }
	    if(((a365147679 == 10 && a1851906186 == 32) && a1335229626 == 9)){
	    cf = 0;
	    __VERIFIER_error(84);
	    }
	    if(((a286009693 == 10 && a1959734605 == 8) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(85);
	    }
	    if(((a1259748523 == 34 && a1273086420 == 34) && a1335229626 == 8)){
	    cf = 0;
	    __VERIFIER_error(86);
	    }
	    if(((a598251408 == 35 && a1851906186 == 34) && a1335229626 == 9)){
	    cf = 0;
	    __VERIFIER_error(87);
	    }
	    if(((a307029135 == 32 && a384913899 == 33) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(88);
	    }
	    if(((a1237428760 == 8 && a1510817746 == 9) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(89);
	    }
	    if(((a1249410904 == 6 && a880660927 == 13) && a1335229626 == 10)){
	    cf = 0;
	    __VERIFIER_error(90);
	    }
	    if(((a654409942 == 15 && a1510817746 == 11) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(91);
	    }
	    if(((a880642005 == 34 && a1273086420 == 33) && a1335229626 == 8)){
	    cf = 0;
	    __VERIFIER_error(92);
	    }
	    if(((a940472710 == 9 && a1510817746 == 7) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(93);
	    }
	    if(((a940472710 == 12 && a1510817746 == 7) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(94);
	    }
	    if(((a1132599179 == 35 && a1959734605 == 4) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(95);
	    }
	    if(((a1259748523 == 36 && a1273086420 == 34) && a1335229626 == 8)){
	    cf = 0;
	    __VERIFIER_error(96);
	    }
	    if(((a932751092 == 1 && a1510817746 == 13) && a1335229626 == 7)){
	    cf = 0;
	    __VERIFIER_error(97);
	    }
	    if(((a1031697847 == 6 && a384913899 == 32) && a1335229626 == 5)){
	    cf = 0;
	    __VERIFIER_error(98);
	    }
	    if(((a179752516 == 9 && a1959734605 == 7) && a1335229626 == 6)){
	    cf = 0;
	    __VERIFIER_error(99);
	    }
	}
 void calculate_outputm59(int input) {
    if((((input == 12) && (a384913899 == 32 && ( cf==1  && a1335229626 == 5))) && a1031697847 == 10)) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 36 ;
    	a864013224 = 15; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((((a384913899 == 32 && ( cf==1  && a1335229626 == 5)) && a1031697847 == 10) && (input == 15))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 35 ;
    	a1383458586 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm60(int input) {
    if((a1031697847 == 12 && (((a1335229626 == 5 &&  cf==1 ) && a384913899 == 32) && (input == 3)))) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 12;
    	a2045918669 = 4; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a384913899 == 32 && ((( cf==1  && (input == 10)) && a1031697847 == 12) && a1335229626 == 5))) {
    	cf = 0;
    	a1959734605 = 2;
    	a1335229626 = 6;
    	a324926224 = 6; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((a1335229626 == 5 && ((input == 13) &&  cf==1 )) && a384913899 == 32) && a1031697847 == 12)) {
    	cf = 0;
    	a950417444 = 10;
    	a1335229626 = 12;
    	a1760493561 = 9; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((a384913899 == 32 && (a1335229626 == 5 && (a1031697847 == 12 && ( cf==1  && (input == 15)))))) {
    	cf = 0;
    	a1851906186 = 36 ;
    	a1335229626 = 9;
    	a2015844410 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1335229626 == 5 && (a384913899 == 32 && ((input == 8) && ( cf==1  && a1031697847 == 12))))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1132599179 = 35 ;
    	a1959734605 = 4; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm1(int input) {
    if((a1031697847 == 10 &&  cf==1 )) {
    	calculate_outputm59(input);
    } 
    if(( cf==1  && a1031697847 == 12)) {
    	calculate_outputm60(input);
    } 
}
 void calculate_outputm62(int input) {
    if((a1335229626 == 5 && (a384913899 == 33 && ((input == 1) && ( cf==1  && a307029135 == 33))))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1498174835 = 35 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((a384913899 == 33 && ( cf==1  && a1335229626 == 5)) && a307029135 == 33) && (input == 7))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 10;
    	a1760493561 = 11; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a384913899 == 33 && (a1335229626 == 5 && ((input == 12) &&  cf==1 ))) && a307029135 == 33)) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 11; 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm2(int input) {
    if((a307029135 == 33 &&  cf==1 )) {
    	calculate_outputm62(input);
    } 
}
 void calculate_outputm66(int input) {
    if((((( cf==1  && a10419264 == 32) && a1335229626 == 5) && a384913899 == 34) && (input == 2))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 9;
    	a565249046 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1335229626 == 5 && ((input == 13) && ((a384913899 == 34 &&  cf==1 ) && a10419264 == 32)))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 33 ;
    	a1383458586 = 7; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a384913899 == 34 && ((a1335229626 == 5 &&  cf==1 ) && (input == 15))) && a10419264 == 32)) {
    	cf = 0;
    	a113972147 = 33 ;
    	a1335229626 = 11;
    	a269427955 = 10; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((input == 4) && (a1335229626 == 5 && (a384913899 == 34 &&  cf==1 ))) && a10419264 == 32)) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 7;
    	a127383885 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm3(int input) {
    if(( cf==1  && a10419264 == 32)) {
    	calculate_outputm66(input);
    } 
}
 void calculate_outputm69(int input) {
    if(((input == 7) && ((a1335229626 == 5 && ( cf==1  && a384913899 == 35)) && a583612627 == 11))) {
    	cf = 0;
    	a1335229626 = 11;
    	a1750379405 = 35 ;
    	a269427955 = 14; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm70(int input) {
    if(((a384913899 == 35 && ((input == 1) && (a583612627 == 12 &&  cf==1 ))) && a1335229626 == 5)) {
    	cf = 0;
    	a1259748523 = 32 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((a384913899 == 35 && (((a1335229626 == 5 &&  cf==1 ) && (input == 6)) && a583612627 == 12))) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 7) && ((a583612627 == 12 && (a1335229626 == 5 &&  cf==1 )) && a384913899 == 35))) {
    	cf = 0;
    	a1259748523 = 32 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm71(int input) {
    if(((input == 2) && ((a384913899 == 35 && ( cf==1  && a1335229626 == 5)) && a583612627 == 13))) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 8;
    	a1746137894 = 17; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((input == 3) && (a583612627 == 13 && (( cf==1  && a1335229626 == 5) && a384913899 == 35)))) {
    	cf = 0;
    	a1602107789 = 36 ;
    	a1335229626 = 6;
    	a1959734605 = 5; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((input == 6) && (a1335229626 == 5 && (a583612627 == 13 &&  cf==1 ))) && a384913899 == 35)) {
    	cf = 0;
    	a1335229626 = 10;
    	a2121950185 = 35 ;
    	a880660927 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1335229626 == 5 && ((( cf==1  && a384913899 == 35) && (input == 10)) && a583612627 == 13))) {
    	cf = 0;
    	a950417444 = 13;
    	a1335229626 = 12;
    	a962095080 = 3; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm72(int input) {
    if((a583612627 == 14 && (((input == 3) && (a384913899 == 35 &&  cf==1 )) && a1335229626 == 5))) {
    	cf = 0;
    	a1259748523 = 32 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((((a384913899 == 35 &&  cf==1 ) && a1335229626 == 5) && (input == 15)) && a583612627 == 14)) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 32 ;
    	a1074841212 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm73(int input) {
    if(((a384913899 == 35 && ((input == 1) && (a583612627 == 15 &&  cf==1 ))) && a1335229626 == 5)) {
    	cf = 0;
    	a1851906186 = 32 ;
    	a1335229626 = 9;
    	a365147679 = 11; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((( cf==1  && a1335229626 == 5) && (input == 6)) && a384913899 == 35) && a583612627 == 15)) {
    	cf = 0;
    	a1602107789 = 32 ;
    	a1335229626 = 6;
    	a1959734605 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a583612627 == 15 && (( cf==1  && a1335229626 == 5) && a384913899 == 35)) && (input == 13))) {
    	cf = 0;
    	a1602107789 = 36 ;
    	a1335229626 = 6;
    	a1959734605 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm4(int input) {
    if(( cf==1  && a583612627 == 11)) {
    	calculate_outputm69(input);
    } 
    if((a583612627 == 12 &&  cf==1 )) {
    	calculate_outputm70(input);
    } 
    if((a583612627 == 13 &&  cf==1 )) {
    	calculate_outputm71(input);
    } 
    if(( cf==1  && a583612627 == 14)) {
    	calculate_outputm72(input);
    } 
    if((a583612627 == 15 &&  cf==1 )) {
    	calculate_outputm73(input);
    } 
}
 void calculate_outputm76(int input) {
    if(((a620299262 == 34 && (a384913899 == 36 && ((input == 3) &&  cf==1 ))) && a1335229626 == 5)) {
    	cf = 0;
    	a269427955 = 11;
    	a1335229626 = 11;
    	a1959734605 = 9; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a620299262 == 34 && ((a1335229626 == 5 && ( cf==1  && a384913899 == 36)) && (input == 8)))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1602107789 = 32 ;
    	a1959734605 = 5; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm5(int input) {
    if(( cf==1  && a620299262 == 34)) {
    	calculate_outputm76(input);
    } 
}
 void calculate_outputm79(int input) {
    if((a324926224 == 3 && ((( cf==1  && a1959734605 == 2) && a1335229626 == 6) && (input == 6)))) {
    	cf = 0;
    	a1335229626 = 10;
    	a2121950185 = 35 ;
    	a880660927 = 9; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a1959734605 == 2 && (( cf==1  && (input == 8)) && a1335229626 == 6)) && a324926224 == 3)) {
    	cf = 0;
    	a880660927 = 13;
    	a1335229626 = 10;
    	a1249410904 = 7; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a324926224 == 3 && ((input == 15) && (a1335229626 == 6 &&  cf==1 ))) && a1959734605 == 2)) {
    	cf = 0;
    	a950417444 = 12;
    	a1335229626 = 12;
    	a1255937088 = 8; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm81(int input) {
    if(((a1335229626 == 6 && (( cf==1  && a324926224 == 6) && a1959734605 == 2)) && (input == 3))) {
    	cf = 0;
    	a620299262 = 34 ;
    	a384913899 = 36 ;
    	a1335229626 = 5; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm6(int input) {
    if((a324926224 == 3 &&  cf==1 )) {
    	calculate_outputm79(input);
    } 
    if((a324926224 == 6 &&  cf==1 )) {
    	calculate_outputm81(input);
    } 
}
 void calculate_outputm85(int input) {
    if((((( cf==1  && a1210809645 == 8) && (input == 1)) && a1335229626 == 6) && a1959734605 == 3)) {
    	cf = 0;
    	a269427955 = 11;
    	a1335229626 = 11;
    	a1959734605 = 9; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((input == 4) && ((a1959734605 == 3 && ( cf==1  && a1210809645 == 8)) && a1335229626 == 6))) {
    	cf = 0;
    	a1273086420 = 34 ;
    	a1259748523 = 35 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1959734605 == 3 && (a1210809645 == 8 && (a1335229626 == 6 && ((input == 8) &&  cf==1 ))))) {
    	cf = 0;
    	a1664587146 = 35 ;
    	a1335229626 = 10;
    	a880660927 = 14; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a1210809645 == 8 && (((a1335229626 == 6 &&  cf==1 ) && a1959734605 == 3) && (input == 10)))) {
    	cf = 0;
    	a1602107789 = 32 ;
    	a1959734605 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm89(int input) {
    if((a1335229626 == 6 && ((((input == 6) &&  cf==1 ) && a1210809645 == 12) && a1959734605 == 3))) {
    	cf = 0;
    	a1510817746 = 9;
    	a1335229626 = 7;
    	a1237428760 = 5; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a1335229626 == 6 && ((a1959734605 == 3 && ((input == 15) &&  cf==1 )) && a1210809645 == 12))) {
    	cf = 0;
    	a1664587146 = 35 ;
    	a1335229626 = 10;
    	a880660927 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm7(int input) {
    if((a1210809645 == 8 &&  cf==1 )) {
    	calculate_outputm85(input);
    } 
    if(( cf==1  && a1210809645 == 12)) {
    	calculate_outputm89(input);
    } 
}
 void calculate_outputm90(int input) {
    if((a1132599179 == 32 && (((input == 10) && (a1335229626 == 6 &&  cf==1 )) && a1959734605 == 4))) {
    	cf = 0;
    	a950417444 = 6;
    	a1335229626 = 12;
    	a1438665870 = 13; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a1335229626 == 6 && ((input == 11) && ( cf==1  && a1132599179 == 32))) && a1959734605 == 4)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1498174835 = 35 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm92(int input) {
    if(((a1959734605 == 4 && (a1335229626 == 6 && ( cf==1  && a1132599179 == 34))) && (input == 6))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 32 ;
    	a1074841212 = 12; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((a1335229626 == 6 && ((a1132599179 == 34 && ( cf==1  && (input == 10))) && a1959734605 == 4))) {
    	cf = 0;
    	a880642005 = 36 ;
    	a1273086420 = 33 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm8(int input) {
    if((a1132599179 == 32 &&  cf==1 )) {
    	calculate_outputm90(input);
    } 
    if((a1132599179 == 34 &&  cf==1 )) {
    	calculate_outputm92(input);
    } 
}
 void calculate_outputm95(int input) {
    if((a1335229626 == 6 && (a1959734605 == 5 && (a1602107789 == 32 && ( cf==1  && (input == 11)))))) {
    	cf = 0;
    	a384913899 = 35 ;
    	a1335229626 = 5;
    	a583612627 = 15; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a1602107789 == 32 && ((a1335229626 == 6 && ( cf==1  && (input == 12))) && a1959734605 == 5))) {
    	cf = 0;
    	a950417444 = 6;
    	a1335229626 = 12;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a1959734605 == 5 && (((input == 13) &&  cf==1 ) && a1602107789 == 32)) && a1335229626 == 6)) {
    	cf = 0;
    	a950417444 = 6;
    	a1335229626 = 12;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a1602107789 == 32 && ((input == 15) && ( cf==1  && a1959734605 == 5))) && a1335229626 == 6)) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm96(int input) {
    if(((((a1602107789 == 35 &&  cf==1 ) && (input == 4)) && a1959734605 == 5) && a1335229626 == 6)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 9;
    	a1237428760 = 4; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1335229626 == 6 && ((input == 12) && (a1602107789 == 35 &&  cf==1 ))) && a1959734605 == 5)) {
    	cf = 0;
    	a1510817746 = 10;
    	a1335229626 = 7;
    	a866603139 = 6; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((a1602107789 == 35 && ((input == 14) && ((a1335229626 == 6 &&  cf==1 ) && a1959734605 == 5)))) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 13;
    	a1249410904 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm97(int input) {
    if((a1335229626 == 6 && ((input == 1) && (a1959734605 == 5 && (a1602107789 == 36 &&  cf==1 ))))) {
    	cf = 0;
    	a384913899 = 35 ;
    	a1335229626 = 5;
    	a583612627 = 15; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((a1959734605 == 5 && ((input == 2) &&  cf==1 )) && a1335229626 == 6) && a1602107789 == 36)) {
    	cf = 0;
    	 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1335229626 == 6 && (a1602107789 == 36 && (((input == 11) &&  cf==1 ) && a1959734605 == 5)))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 9;
    	a1237428760 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm9(int input) {
    if(( cf==1  && a1602107789 == 32)) {
    	calculate_outputm95(input);
    } 
    if(( cf==1  && a1602107789 == 35)) {
    	calculate_outputm96(input);
    } 
    if(( cf==1  && a1602107789 == 36)) {
    	calculate_outputm97(input);
    } 
}
 void calculate_outputm98(int input) {
    if((a1210809645 == 6 && ((a1335229626 == 6 && ( cf==1  && (input == 8))) && a1959734605 == 6))) {
    	cf = 0;
    	a1335229626 = 10;
    	a1664587146 = 33 ;
    	a880660927 = 14; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm100(int input) {
    if((((( cf==1  && a1335229626 == 6) && a1210809645 == 10) && (input == 1)) && a1959734605 == 6)) {
    	cf = 0;
    	a880660927 = 11;
    	a1335229626 = 10;
    	a1837110425 = 5; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1335229626 == 6 && (a1959734605 == 6 && (a1210809645 == 10 &&  cf==1 ))) && (input == 11))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 11;
    	a654409942 = 16; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((( cf==1  && a1210809645 == 10) && a1335229626 == 6) && a1959734605 == 6) && (input == 15))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 13;
    	a932751092 = 2; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm101(int input) {
    if(((a1959734605 == 6 && ((input == 1) && ( cf==1  && a1335229626 == 6))) && a1210809645 == 11)) {
    	cf = 0;
    	a1602107789 = 36 ;
    	a1959734605 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm102(int input) {
    if(((input == 2) && (((a1335229626 == 6 &&  cf==1 ) && a1959734605 == 6) && a1210809645 == 13))) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 13;
    	a1249410904 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1959734605 == 6 &&  cf==1 ) && (input == 8)) && a1335229626 == 6) && a1210809645 == 13)) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 6;
    	a1438665870 = 13; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a1335229626 == 6 && (a1210809645 == 13 && ((a1959734605 == 6 &&  cf==1 ) && (input == 13))))) {
    	cf = 0;
    	a1335229626 = 11;
    	a338143956 = 32 ;
    	a269427955 = 12; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm10(int input) {
    if((a1210809645 == 6 &&  cf==1 )) {
    	calculate_outputm98(input);
    } 
    if((a1210809645 == 10 &&  cf==1 )) {
    	calculate_outputm100(input);
    } 
    if(( cf==1  && a1210809645 == 11)) {
    	calculate_outputm101(input);
    } 
    if((a1210809645 == 13 &&  cf==1 )) {
    	calculate_outputm102(input);
    } 
}
 void calculate_outputm103(int input) {
    if(((a179752516 == 7 && ((input == 4) && (a1959734605 == 7 &&  cf==1 ))) && a1335229626 == 6)) {
    	cf = 0;
    	a1602107789 = 32 ;
    	a1959734605 = 5; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a179752516 == 7 && ((input == 8) && ( cf==1  && a1335229626 == 6))) && a1959734605 == 7)) {
    	cf = 0;
    	a950417444 = 10;
    	a1335229626 = 12;
    	a1760493561 = 10; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a179752516 == 7 && ((( cf==1  && a1335229626 == 6) && a1959734605 == 7) && (input == 10)))) {
    	cf = 0;
    	a269427955 = 11;
    	a1335229626 = 11;
    	a1959734605 = 9; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((input == 11) && ( cf==1  && a1335229626 == 6)) && a179752516 == 7) && a1959734605 == 7)) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 36 ;
    	a864013224 = 14; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm104(int input) {
    if(((a1335229626 == 6 && (a179752516 == 8 && ( cf==1  && (input == 6)))) && a1959734605 == 7)) {
    	cf = 0;
    	a950417444 = 9;
    	a1335229626 = 12;
    	a565249046 = 5; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a179752516 == 8 && (a1959734605 == 7 && (( cf==1  && a1335229626 == 6) && (input == 12))))) {
    	cf = 0;
    	a1335229626 = 10;
    	a2121950185 = 35 ;
    	a880660927 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm107(int input) {
    if((((a179752516 == 12 && (a1335229626 == 6 &&  cf==1 )) && (input == 4)) && a1959734605 == 7)) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 36 ;
    	a864013224 = 15; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((input == 7) && ((a1959734605 == 7 &&  cf==1 ) && a179752516 == 12)) && a1335229626 == 6)) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 35 ;
    	a1383458586 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm11(int input) {
    if(( cf==1  && a179752516 == 7)) {
    	calculate_outputm103(input);
    } 
    if(( cf==1  && a179752516 == 8)) {
    	calculate_outputm104(input);
    } 
    if((a179752516 == 12 &&  cf==1 )) {
    	calculate_outputm107(input);
    } 
}
 void calculate_outputm109(int input) {
    if(((input == 6) && (a1335229626 == 6 && (( cf==1  && a1959734605 == 8) && a286009693 == 9)))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 36 ;
    	a864013224 = 14; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((((input == 8) && ( cf==1  && a1959734605 == 8)) && a1335229626 == 6) && a286009693 == 9)) {
    	cf = 0;
    	a1273086420 = 36 ;
    	a1335229626 = 8;
    	a864013224 = 14; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a1335229626 == 6 && ((input == 10) && (a1959734605 == 8 &&  cf==1 ))) && a286009693 == 9)) {
    	cf = 0;
    	a384913899 = 35 ;
    	a1335229626 = 5;
    	a583612627 = 12; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm112(int input) {
    if((((( cf==1  && a286009693 == 13) && a1959734605 == 8) && a1335229626 == 6) && (input == 8))) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 11;
    	a1959734605 = 9; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm114(int input) {
    if((a1335229626 == 6 && ((input == 1) && (a286009693 == 15 && ( cf==1  && a1959734605 == 8))))) {
    	cf = 0;
    	a880642005 = 36 ;
    	a1273086420 = 33 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a1335229626 == 6 && (a1959734605 == 8 && (a286009693 == 15 && ((input == 7) &&  cf==1 ))))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 36 ;
    	a864013224 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm12(int input) {
    if(( cf==1  && a286009693 == 9)) {
    	calculate_outputm109(input);
    } 
    if(( cf==1  && a286009693 == 13)) {
    	calculate_outputm112(input);
    } 
    if(( cf==1  && a286009693 == 15)) {
    	calculate_outputm114(input);
    } 
}
 void calculate_outputm115(int input) {
    if(((a1250255157 == 8 && (a1959734605 == 9 && (a1335229626 == 6 &&  cf==1 ))) && (input == 12))) {
    	cf = 0;
    	a1335229626 = 5;
    	a384913899 = 35 ;
    	a583612627 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm116(int input) {
    if((((((input == 15) &&  cf==1 ) && a1959734605 == 9) && a1335229626 == 6) && a1250255157 == 9)) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 8;
    	a1746137894 = 17; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm118(int input) {
    if(((input == 7) && ((a1250255157 == 12 && (a1959734605 == 9 &&  cf==1 )) && a1335229626 == 6))) {
    	cf = 0;
    	a950417444 = 6;
    	a1335229626 = 12;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((input == 13) && ((a1959734605 == 9 &&  cf==1 ) && a1250255157 == 12)) && a1335229626 == 6)) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 6;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm119(int input) {
    if(((input == 2) && (((a1250255157 == 13 &&  cf==1 ) && a1959734605 == 9) && a1335229626 == 6))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 36 ;
    	a864013224 = 15; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((( cf==1  && (input == 10)) && a1959734605 == 9) && a1335229626 == 6) && a1250255157 == 13)) {
    	cf = 0;
    	a1273086420 = 33 ;
    	a880642005 = 36 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1959734605 == 9 && (( cf==1  && a1250255157 == 13) && (input == 12))) && a1335229626 == 6)) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 10;
    	a1760493561 = 16; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm121(int input) {
    if((a1250255157 == 15 && ((input == 7) && (a1335229626 == 6 && (a1959734605 == 9 &&  cf==1 ))))) {
    	cf = 0;
    	a1959734605 = 6;
    	a1210809645 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1335229626 == 6 && (a1959734605 == 9 && ( cf==1  && a1250255157 == 15))) && (input == 11))) {
    	cf = 0;
    	a880660927 = 10;
    	a1335229626 = 10;
    	a200918022 = 11; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm13(int input) {
    if(( cf==1  && a1250255157 == 8)) {
    	calculate_outputm115(input);
    } 
    if((a1250255157 == 9 &&  cf==1 )) {
    	calculate_outputm116(input);
    } 
    if((a1250255157 == 12 &&  cf==1 )) {
    	calculate_outputm118(input);
    } 
    if(( cf==1  && a1250255157 == 13)) {
    	calculate_outputm119(input);
    } 
    if((a1250255157 == 15 &&  cf==1 )) {
    	calculate_outputm121(input);
    } 
}
 void calculate_outputm122(int input) {
    if((((a1510817746 == 7 && ( cf==1  && a940472710 == 8)) && a1335229626 == 7) && (input == 1))) {
    	cf = 0;
    	a1851906186 = 35 ;
    	a1149219151 = 32 ;
    	a1335229626 = 9; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((a1335229626 == 7 && ( cf==1  && (input == 6))) && a1510817746 == 7) && a940472710 == 8)) {
    	cf = 0;
    	a1510817746 = 9;
    	a1237428760 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1510817746 == 7 && ((( cf==1  && a940472710 == 8) && a1335229626 == 7) && (input == 8)))) {
    	cf = 0;
    	a1498174835 = 34 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a1510817746 == 7 &&  cf==1 ) && a1335229626 == 7) && a940472710 == 8) && (input == 15))) {
    	cf = 0;
    	a384913899 = 35 ;
    	a1335229626 = 5;
    	a583612627 = 14; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm125(int input) {
    if((a940472710 == 11 && (a1335229626 == 7 && ((input == 1) && (a1510817746 == 7 &&  cf==1 ))))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 36 ;
    	a864013224 = 15; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((a1335229626 == 7 && ( cf==1  && a940472710 == 11)) && (input == 3)) && a1510817746 == 7)) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 36 ;
    	a864013224 = 14; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((input == 4) && ((( cf==1  && a1510817746 == 7) && a940472710 == 11) && a1335229626 == 7))) {
    	cf = 0;
    	a880642005 = 36 ;
    	a1273086420 = 33 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((((a940472710 == 11 &&  cf==1 ) && a1510817746 == 7) && (input == 12)) && a1335229626 == 7)) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 15;
    	a1736640332 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm127(int input) {
    if((a1335229626 == 7 && ((a940472710 == 13 && ((input == 6) &&  cf==1 )) && a1510817746 == 7))) {
    	cf = 0;
    	a384913899 = 33 ;
    	a307029135 = 33 ;
    	a1335229626 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm14(int input) {
    if(( cf==1  && a940472710 == 8)) {
    	calculate_outputm122(input);
    } 
    if(( cf==1  && a940472710 == 11)) {
    	calculate_outputm125(input);
    } 
    if(( cf==1  && a940472710 == 13)) {
    	calculate_outputm127(input);
    } 
}
 void calculate_outputm128(int input) {
    if(((((input == 4) && ( cf==1  && a782039646 == 7)) && a1335229626 == 7) && a1510817746 == 8)) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 35 ;
    	a1383458586 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 13) && ((a1510817746 == 8 && (a1335229626 == 7 &&  cf==1 )) && a782039646 == 7))) {
    	cf = 0;
    	a1335229626 = 5;
    	a384913899 = 35 ;
    	a583612627 = 12; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm130(int input) {
    if((((( cf==1  && a1335229626 == 7) && a1510817746 == 8) && (input == 6)) && a782039646 == 11)) {
    	cf = 0;
    	a1335229626 = 5;
    	a384913899 = 32 ;
    	a1031697847 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((a1335229626 == 7 &&  cf==1 ) && a1510817746 == 8) && a782039646 == 11) && (input == 15))) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 11;
    	a1959734605 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm132(int input) {
    if(((((a1510817746 == 8 &&  cf==1 ) && (input == 11)) && a782039646 == 13) && a1335229626 == 7)) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 11;
    	a1959734605 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1510817746 == 8 && ((input == 13) && ( cf==1  && a782039646 == 13))) && a1335229626 == 7)) {
    	cf = 0;
    	a389949481 = 35 ;
    	a1335229626 = 12;
    	a950417444 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1335229626 == 7 && (a782039646 == 13 &&  cf==1 )) && a1510817746 == 8) && (input == 9))) {
    	cf = 0;
    	a1959734605 = 2;
    	a1335229626 = 6;
    	a324926224 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm133(int input) {
    if((a1510817746 == 8 && (a782039646 == 14 && ((a1335229626 == 7 &&  cf==1 ) && (input == 4))))) {
    	cf = 0;
    	a1273086420 = 34 ;
    	a1259748523 = 33 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((input == 6) && (((a782039646 == 14 &&  cf==1 ) && a1510817746 == 8) && a1335229626 == 7))) {
    	cf = 0;
    	a1510817746 = 9;
    	a1237428760 = 5; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((input == 11) && (((a1335229626 == 7 &&  cf==1 ) && a782039646 == 14) && a1510817746 == 8))) {
    	cf = 0;
    	a1510817746 = 9;
    	a1237428760 = 5; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm15(int input) {
    if(( cf==1  && a782039646 == 7)) {
    	calculate_outputm128(input);
    } 
    if(( cf==1  && a782039646 == 11)) {
    	calculate_outputm130(input);
    } 
    if(( cf==1  && a782039646 == 13)) {
    	calculate_outputm132(input);
    } 
    if((a782039646 == 14 &&  cf==1 )) {
    	calculate_outputm133(input);
    } 
}
 void calculate_outputm134(int input) {
    if((a1510817746 == 9 && ((a1237428760 == 3 && ( cf==1  && (input == 1))) && a1335229626 == 7))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 6;
    	a1438665870 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 6) && (( cf==1  && a1237428760 == 3) && a1335229626 == 7)) && a1510817746 == 9)) {
    	cf = 0;
    	a113972147 = 34 ;
    	a1335229626 = 11;
    	a269427955 = 10; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1335229626 == 7 && ((input == 15) && (a1510817746 == 9 &&  cf==1 ))) && a1237428760 == 3)) {
    	cf = 0;
    	a1259748523 = 33 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm135(int input) {
    if((a1237428760 == 4 && (((input == 1) && ( cf==1  && a1335229626 == 7)) && a1510817746 == 9))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 8;
    	a286009693 = 13; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a1510817746 == 9 && ((( cf==1  && (input == 3)) && a1237428760 == 4) && a1335229626 == 7))) {
    	cf = 0;
    	a1237428760 = 3; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((((a1335229626 == 7 &&  cf==1 ) && (input == 4)) && a1237428760 == 4) && a1510817746 == 9)) {
    	cf = 0;
    	a880660927 = 13;
    	a1335229626 = 10;
    	a1249410904 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((input == 6) && (a1510817746 == 9 && (a1335229626 == 7 && (a1237428760 == 4 &&  cf==1 ))))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 7;
    	a179752516 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm136(int input) {
    if((((( cf==1  && a1335229626 == 7) && (input == 2)) && a1510817746 == 9) && a1237428760 == 5)) {
    	cf = 0;
    	a1335229626 = 12;
    	a389949481 = 36 ;
    	a950417444 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm137(int input) {
    if((a1510817746 == 9 && ((a1237428760 == 6 && (a1335229626 == 7 &&  cf==1 )) && (input == 2)))) {
    	cf = 0;
    	a1510817746 = 10;
    	a866603139 = 4; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((a1510817746 == 9 && (a1335229626 == 7 && (a1237428760 == 6 && ((input == 4) &&  cf==1 ))))) {
    	cf = 0;
    	a1335229626 = 5;
    	a384913899 = 35 ;
    	a583612627 = 15; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a1510817746 == 9 && (a1335229626 == 7 && ( cf==1  && (input == 7)))) && a1237428760 == 6)) {
    	cf = 0;
    	a1335229626 = 10;
    	a1664587146 = 36 ;
    	a880660927 = 14; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1237428760 == 6 && ((a1510817746 == 9 &&  cf==1 ) && (input == 10))) && a1335229626 == 7)) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 9;
    	a1250255157 = 15; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm138(int input) {
    if((a1335229626 == 7 && ((((input == 3) &&  cf==1 ) && a1510817746 == 9) && a1237428760 == 7))) {
    	cf = 0;
    	a1259748523 = 32 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm16(int input) {
    if(( cf==1  && a1237428760 == 3)) {
    	calculate_outputm134(input);
    } 
    if((a1237428760 == 4 &&  cf==1 )) {
    	calculate_outputm135(input);
    } 
    if((a1237428760 == 5 &&  cf==1 )) {
    	calculate_outputm136(input);
    } 
    if((a1237428760 == 6 &&  cf==1 )) {
    	calculate_outputm137(input);
    } 
    if((a1237428760 == 7 &&  cf==1 )) {
    	calculate_outputm138(input);
    } 
}
 void calculate_outputm140(int input) {
    if(((input == 7) && (a866603139 == 4 && (a1335229626 == 7 && (a1510817746 == 10 &&  cf==1 ))))) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 13;
    	a1249410904 = 5; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((((a1335229626 == 7 &&  cf==1 ) && a866603139 == 4) && a1510817746 == 10) && (input == 13))) {
    	cf = 0;
    	a1510817746 = 7;
    	a940472710 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm141(int input) {
    if(((a1335229626 == 7 && (a866603139 == 5 && ( cf==1  && a1510817746 == 10))) && (input == 1))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 12;
    	a1255937088 = 12; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((a866603139 == 5 && (a1335229626 == 7 && (( cf==1  && a1510817746 == 10) && (input == 7))))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 36 ;
    	a864013224 = 11; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((a1335229626 == 7 && ((a1510817746 == 10 && ( cf==1  && a866603139 == 5)) && (input == 10)))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 9;
    	a1250255157 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((input == 13) && ((a1335229626 == 7 && ( cf==1  && a1510817746 == 10)) && a866603139 == 5))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 9;
    	a1250255157 = 13; 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm142(int input) {
    if((a866603139 == 6 && (a1510817746 == 10 && (( cf==1  && a1335229626 == 7) && (input == 7))))) {
    	cf = 0;
    	a1335229626 = 12;
    	a389949481 = 32 ;
    	a950417444 = 8; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a866603139 == 6 && (((a1335229626 == 7 &&  cf==1 ) && a1510817746 == 10) && (input == 13)))) {
    	cf = 0;
    	a1510817746 = 8;
    	a782039646 = 7; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm144(int input) {
    if((a1510817746 == 10 && (a1335229626 == 7 && ((input == 7) && ( cf==1  && a866603139 == 8))))) {
    	cf = 0;
    	a1959734605 = 6;
    	a1335229626 = 6;
    	a1210809645 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a866603139 == 8 && ((input == 13) &&  cf==1 )) && a1510817746 == 10) && a1335229626 == 7)) {
    	cf = 0;
    	a1510817746 = 8;
    	a782039646 = 11; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((a866603139 == 8 && ( cf==1  && a1335229626 == 7)) && a1510817746 == 10) && (input == 6))) {
    	cf = 0;
    	a1959734605 = 2;
    	a1335229626 = 6;
    	a324926224 = 1; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm145(int input) {
    if((((input == 6) && ((a866603139 == 9 &&  cf==1 ) && a1335229626 == 7)) && a1510817746 == 10)) {
    	cf = 0;
    	a1498174835 = 35 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm146(int input) {
    if((((a1335229626 == 7 && (a1510817746 == 10 &&  cf==1 )) && (input == 1)) && a866603139 == 10)) {
    	cf = 0;
    	a1273086420 = 34 ;
    	a1259748523 = 32 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a1335229626 == 7 && ((a866603139 == 10 &&  cf==1 ) && a1510817746 == 10)) && (input == 3))) {
    	cf = 0;
    	a389949481 = 36 ;
    	a1335229626 = 12;
    	a950417444 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a1510817746 == 10 && (a866603139 == 10 && ( cf==1  && (input == 8)))) && a1335229626 == 7)) {
    	cf = 0;
    	a950417444 = 6;
    	a1335229626 = 12;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a1335229626 == 7 && (((input == 11) && ( cf==1  && a866603139 == 10)) && a1510817746 == 10))) {
    	cf = 0;
    	a1335229626 = 12;
    	a389949481 = 36 ;
    	a950417444 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm17(int input) {
    if((a866603139 == 4 &&  cf==1 )) {
    	calculate_outputm140(input);
    } 
    if(( cf==1  && a866603139 == 5)) {
    	calculate_outputm141(input);
    } 
    if(( cf==1  && a866603139 == 6)) {
    	calculate_outputm142(input);
    } 
    if((a866603139 == 8 &&  cf==1 )) {
    	calculate_outputm144(input);
    } 
    if(( cf==1  && a866603139 == 9)) {
    	calculate_outputm145(input);
    } 
    if((a866603139 == 10 &&  cf==1 )) {
    	calculate_outputm146(input);
    } 
}
 void calculate_outputm147(int input) {
    if((a1510817746 == 11 && (a654409942 == 10 && (((input == 7) &&  cf==1 ) && a1335229626 == 7)))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 13;
    	a962095080 = 5; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm150(int input) {
    if((a1335229626 == 7 && ((a1510817746 == 11 && ( cf==1  && (input == 6))) && a654409942 == 13))) {
    	cf = 0;
    	a1959734605 = 8;
    	a1335229626 = 6;
    	a286009693 = 15; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a1335229626 == 7 && (((input == 10) &&  cf==1 ) && a654409942 == 13)) && a1510817746 == 11)) {
    	cf = 0;
    	a950417444 = 13;
    	a1335229626 = 12;
    	a962095080 = 6; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((((a1335229626 == 7 && ( cf==1  && a1510817746 == 11)) && (input == 11)) && a654409942 == 13)) {
    	cf = 0;
    	a1132599179 = 32 ;
    	a1335229626 = 6;
    	a1959734605 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm152(int input) {
    if(((input == 2) && (((a1335229626 == 7 &&  cf==1 ) && a1510817746 == 11) && a654409942 == 16))) {
    	cf = 0;
    	a1259748523 = 35 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((( cf==1  && a1335229626 == 7) && a654409942 == 16) && a1510817746 == 11) && (input == 7))) {
    	cf = 0;
    	a880660927 = 15;
    	a1335229626 = 10;
    	a1736640332 = 9; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((a1510817746 == 11 && ((( cf==1  && a1335229626 == 7) && (input == 15)) && a654409942 == 16))) {
    	cf = 0;
    	a1259748523 = 35 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm18(int input) {
    if((a654409942 == 10 &&  cf==1 )) {
    	calculate_outputm147(input);
    } 
    if((a654409942 == 13 &&  cf==1 )) {
    	calculate_outputm150(input);
    } 
    if((a654409942 == 16 &&  cf==1 )) {
    	calculate_outputm152(input);
    } 
}
 void calculate_outputm153(int input) {
    if(((input == 4) && ((( cf==1  && a1510817746 == 12) && a1335229626 == 7) && a1498174835 == 32))) {
    	cf = 0;
    	a1959734605 = 7;
    	a1335229626 = 6;
    	a179752516 = 7; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1335229626 == 7 && (a1510817746 == 12 && ((input == 8) && (a1498174835 == 32 &&  cf==1 ))))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 3;
    	a1210809645 = 8; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a1498174835 == 32 && (a1510817746 == 12 && ( cf==1  && (input == 13)))) && a1335229626 == 7)) {
    	cf = 0;
    	a1959734605 = 9;
    	a1335229626 = 6;
    	a1250255157 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm155(int input) {
    if((((( cf==1  && a1335229626 == 7) && a1510817746 == 12) && a1498174835 == 34) && (input == 3))) {
    	cf = 0;
    	 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((((( cf==1  && (input == 4)) && a1498174835 == 34) && a1510817746 == 12) && a1335229626 == 7)) {
    	cf = 0;
    	a1510817746 = 13;
    	a932751092 = 5; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((a1498174835 == 34 && ((input == 12) && (a1510817746 == 12 && (a1335229626 == 7 &&  cf==1 ))))) {
    	cf = 0;
    	a1510817746 = 13;
    	a932751092 = 5; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((a1498174835 == 34 && ((a1510817746 == 12 && ( cf==1  && a1335229626 == 7)) && (input == 15)))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 6;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm156(int input) {
    if((((( cf==1  && a1498174835 == 35) && a1510817746 == 12) && (input == 3)) && a1335229626 == 7)) {
    	cf = 0;
    	 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((((input == 6) && (a1510817746 == 12 &&  cf==1 )) && a1498174835 == 35) && a1335229626 == 7)) {
    	cf = 0;
    	a1851906186 = 36 ;
    	a1335229626 = 9;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm19(int input) {
    if(( cf==1  && a1498174835 == 32)) {
    	calculate_outputm153(input);
    } 
    if((a1498174835 == 34 &&  cf==1 )) {
    	calculate_outputm155(input);
    } 
    if((a1498174835 == 35 &&  cf==1 )) {
    	calculate_outputm156(input);
    } 
}
 void calculate_outputm159(int input) {
    if((((((input == 1) &&  cf==1 ) && a1335229626 == 7) && a1510817746 == 13) && a932751092 == 2)) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1335229626 == 7 && (a932751092 == 2 && ((a1510817746 == 13 &&  cf==1 ) && (input == 7))))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 36 ;
    	a864013224 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1510817746 == 13 &&  cf==1 ) && (input == 8)) && a1335229626 == 7) && a932751092 == 2)) {
    	cf = 0;
    	 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((input == 13) && ((a1335229626 == 7 && ( cf==1  && a1510817746 == 13)) && a932751092 == 2))) {
    	cf = 0;
    	a1510817746 = 9;
    	a1237428760 = 5; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm160(int input) {
    if((a932751092 == 5 && ((input == 12) && (a1335229626 == 7 && ( cf==1  && a1510817746 == 13))))) {
    	cf = 0;
    	a1149219151 = 35 ;
    	a1851906186 = 35 ;
    	a1335229626 = 9; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((a1510817746 == 13 && (((a1335229626 == 7 &&  cf==1 ) && a932751092 == 5) && (input == 15)))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 33 ;
    	a1383458586 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 14) && (a1335229626 == 7 && ((a932751092 == 5 &&  cf==1 ) && a1510817746 == 13)))) {
    	cf = 0;
    	a1510817746 = 11;
    	a654409942 = 15; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm161(int input) {
    if((((( cf==1  && (input == 11)) && a932751092 == 6) && a1510817746 == 13) && a1335229626 == 7)) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 6; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm163(int input) {
    if((((a932751092 == 8 && (a1335229626 == 7 &&  cf==1 )) && (input == 1)) && a1510817746 == 13)) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 8;
    	a1746137894 = 12; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((input == 4) && (( cf==1  && a1335229626 == 7) && a932751092 == 8)) && a1510817746 == 13)) {
    	cf = 0;
    	a338143956 = 32 ;
    	a1335229626 = 11;
    	a269427955 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm20(int input) {
    if((a932751092 == 2 &&  cf==1 )) {
    	calculate_outputm159(input);
    } 
    if(( cf==1  && a932751092 == 5)) {
    	calculate_outputm160(input);
    } 
    if((a932751092 == 6 &&  cf==1 )) {
    	calculate_outputm161(input);
    } 
    if((a932751092 == 8 &&  cf==1 )) {
    	calculate_outputm163(input);
    } 
}
 void calculate_outputm164(int input) {
    if((a307029135 == 35 && (a1335229626 == 7 && (( cf==1  && (input == 10)) && a1510817746 == 14)))) {
    	cf = 0;
    	a1510817746 = 13;
    	a932751092 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1335229626 == 7 && (a1510817746 == 14 && (a307029135 == 35 && ( cf==1  && (input == 11)))))) {
    	cf = 0;
    	a1478065937 = 33 ;
    	a1335229626 = 12;
    	a950417444 = 7; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm165(int input) {
    if(((((a1510817746 == 14 &&  cf==1 ) && a1335229626 == 7) && a307029135 == 36) && (input == 1))) {
    	cf = 0;
    	a1498174835 = 35 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a1335229626 == 7 && (((input == 6) &&  cf==1 ) && a307029135 == 36)) && a1510817746 == 14)) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 9;
    	a1250255157 = 12; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((a307029135 == 36 && (a1510817746 == 14 &&  cf==1 )) && a1335229626 == 7) && (input == 8))) {
    	cf = 0;
    	a338143956 = 32 ;
    	a1335229626 = 11;
    	a269427955 = 12; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((input == 10) && (((a1335229626 == 7 &&  cf==1 ) && a307029135 == 36) && a1510817746 == 14))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1602107789 = 36 ;
    	a1959734605 = 5; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm21(int input) {
    if(( cf==1  && a307029135 == 35)) {
    	calculate_outputm164(input);
    } 
    if(( cf==1  && a307029135 == 36)) {
    	calculate_outputm165(input);
    } 
}
 void calculate_outputm167(int input) {
    if((((( cf==1  && a1273086420 == 32) && a1074841212 == 11) && a1335229626 == 8) && (input == 1))) {
    	cf = 0;
    	a1335229626 = 5;
    	a384913899 = 35 ;
    	a583612627 = 14; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a1074841212 == 11 && (( cf==1  && a1273086420 == 32) && (input == 8))) && a1335229626 == 8)) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 8;
    	a1746137894 = 12; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a1074841212 == 11 && (( cf==1  && a1335229626 == 8) && a1273086420 == 32)) && (input == 12))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 6;
    	a1438665870 = 13; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 15) && (a1074841212 == 11 && ((a1273086420 == 32 &&  cf==1 ) && a1335229626 == 8)))) {
    	cf = 0;
    	a950417444 = 10;
    	a1335229626 = 12;
    	a1760493561 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm168(int input) {
    if((((a1074841212 == 12 && (a1335229626 == 8 &&  cf==1 )) && (input == 8)) && a1273086420 == 32)) {
    	cf = 0;
    	a1510817746 = 13;
    	a1335229626 = 7;
    	a932751092 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a1074841212 == 12 && ((a1335229626 == 8 &&  cf==1 ) && a1273086420 == 32)) && (input == 11))) {
    	cf = 0;
    	a880660927 = 10;
    	a1335229626 = 10;
    	a200918022 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1074841212 == 12 && (( cf==1  && (input == 13)) && a1335229626 == 8)) && a1273086420 == 32)) {
    	cf = 0;
    	a880660927 = 11;
    	a1335229626 = 10;
    	a1837110425 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1335229626 == 8 && (((input == 7) && ( cf==1  && a1273086420 == 32)) && a1074841212 == 12))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 8;
    	a782039646 = 10; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm22(int input) {
    if((a1074841212 == 11 &&  cf==1 )) {
    	calculate_outputm167(input);
    } 
    if(( cf==1  && a1074841212 == 12)) {
    	calculate_outputm168(input);
    } 
}
 void calculate_outputm170(int input) {
    if((((a1335229626 == 8 && ((input == 3) &&  cf==1 )) && a1273086420 == 33) && a880642005 == 36)) {
    	cf = 0;
    	a1335229626 = 12;
    	a389949481 = 36 ;
    	a950417444 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a880642005 == 36 && (( cf==1  && a1335229626 == 8) && a1273086420 == 33)) && (input == 10))) {
    	cf = 0;
    	 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a1273086420 == 33 && (a1335229626 == 8 && ((input == 11) &&  cf==1 ))) && a880642005 == 36)) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm23(int input) {
    if((a880642005 == 36 &&  cf==1 )) {
    	calculate_outputm170(input);
    } 
}
 void calculate_outputm171(int input) {
    if((a1259748523 == 32 && (a1335229626 == 8 && (( cf==1  && (input == 6)) && a1273086420 == 34)))) {
    	cf = 0;
    	a1149219151 = 33 ;
    	a1851906186 = 35 ;
    	a1335229626 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1273086420 == 34 && (((a1335229626 == 8 &&  cf==1 ) && (input == 7)) && a1259748523 == 32))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 6;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a1259748523 == 32 && (a1273086420 == 34 && ((a1335229626 == 8 &&  cf==1 ) && (input == 12))))) {
    	cf = 0;
    	a950417444 = 9;
    	a1335229626 = 12;
    	a565249046 = 5; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((( cf==1  && a1259748523 == 32) && a1335229626 == 8) && a1273086420 == 34) && (input == 14))) {
    	cf = 0;
    	a1851906186 = 36 ;
    	a1335229626 = 9;
    	a2015844410 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm172(int input) {
    if(((a1273086420 == 34 && (( cf==1  && a1259748523 == 33) && (input == 10))) && a1335229626 == 8)) {
    	cf = 0;
    	a880660927 = 10;
    	a1335229626 = 10;
    	a200918022 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1259748523 == 33 && ((a1335229626 == 8 &&  cf==1 ) && (input == 12))) && a1273086420 == 34)) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm174(int input) {
    if((a1335229626 == 8 && ((a1273086420 == 34 && ((input == 2) &&  cf==1 )) && a1259748523 == 35))) {
    	cf = 0;
    	 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a1259748523 == 35 && ((a1273086420 == 34 &&  cf==1 ) && a1335229626 == 8)) && (input == 11))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 8;
    	a782039646 = 13; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm24(int input) {
    if(( cf==1  && a1259748523 == 32)) {
    	calculate_outputm171(input);
    } 
    if((a1259748523 == 33 &&  cf==1 )) {
    	calculate_outputm172(input);
    } 
    if(( cf==1  && a1259748523 == 35)) {
    	calculate_outputm174(input);
    } 
}
 void calculate_outputm176(int input) {
    if(((((input == 7) && ( cf==1  && a1273086420 == 35)) && a1383458586 == 2) && a1335229626 == 8)) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 15;
    	a1736640332 = 9; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm177(int input) {
    if(((a1383458586 == 3 && ((input == 3) && (a1273086420 == 35 &&  cf==1 ))) && a1335229626 == 8)) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 7;
    	a179752516 = 8; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((input == 4) && (( cf==1  && a1383458586 == 3) && a1273086420 == 35)) && a1335229626 == 8)) {
    	cf = 0;
    	a389949481 = 34 ;
    	a1335229626 = 12;
    	a950417444 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm178(int input) {
    if(((a1335229626 == 8 && (a1383458586 == 6 && (a1273086420 == 35 &&  cf==1 ))) && (input == 7))) {
    	cf = 0;
    	a1602107789 = 35 ;
    	a1335229626 = 6;
    	a1959734605 = 5; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((a1383458586 == 6 && (a1335229626 == 8 &&  cf==1 )) && a1273086420 == 35) && (input == 11))) {
    	cf = 0;
    	a1273086420 = 32 ;
    	a1074841212 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1273086420 == 35 && ((a1383458586 == 6 && (a1335229626 == 8 &&  cf==1 )) && (input == 13)))) {
    	cf = 0;
    	a598251408 = 36 ;
    	a1851906186 = 34 ;
    	a1335229626 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((((a1335229626 == 8 &&  cf==1 ) && (input == 8)) && a1383458586 == 6) && a1273086420 == 35)) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 10;
    	a200918022 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm179(int input) {
    if((((input == 6) && (a1273086420 == 35 && ( cf==1  && a1383458586 == 7))) && a1335229626 == 8)) {
    	cf = 0;
    	a1273086420 = 34 ;
    	a1259748523 = 32 ; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((a1335229626 == 8 && ((a1383458586 == 7 && ((input == 8) &&  cf==1 )) && a1273086420 == 35))) {
    	cf = 0;
    	a389949481 = 35 ;
    	a1335229626 = 12;
    	a950417444 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((input == 12) && (( cf==1  && a1273086420 == 35) && a1335229626 == 8)) && a1383458586 == 7)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 8;
    	a782039646 = 13; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((((input == 13) &&  cf==1 ) && a1335229626 == 8) && a1273086420 == 35) && a1383458586 == 7)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 8;
    	a782039646 = 13; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm25(int input) {
    if(( cf==1  && a1383458586 == 2)) {
    	calculate_outputm176(input);
    } 
    if((a1383458586 == 3 &&  cf==1 )) {
    	calculate_outputm177(input);
    } 
    if(( cf==1  && a1383458586 == 6)) {
    	calculate_outputm178(input);
    } 
    if((a1383458586 == 7 &&  cf==1 )) {
    	calculate_outputm179(input);
    } 
}
 void calculate_outputm182(int input) {
    if((((input == 1) && (a1335229626 == 8 && (a1273086420 == 36 &&  cf==1 ))) && a864013224 == 11)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1498174835 = 35 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((input == 2) && ((a1273086420 == 36 && ( cf==1  && a864013224 == 11)) && a1335229626 == 8))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1602107789 = 36 ;
    	a1959734605 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1335229626 == 8 && ((((input == 3) &&  cf==1 ) && a1273086420 == 36) && a864013224 == 11))) {
    	cf = 0;
    	 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1273086420 == 36 && ((a864013224 == 11 && ( cf==1  && (input == 8))) && a1335229626 == 8))) {
    	cf = 0;
    	a269427955 = 8;
    	a1335229626 = 11;
    	a1746137894 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm183(int input) {
    if((((( cf==1  && a1273086420 == 36) && a1335229626 == 8) && a864013224 == 13) && (input == 6))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 9;
    	a1250255157 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a864013224 == 13 && ((a1335229626 == 8 && ( cf==1  && a1273086420 == 36)) && (input == 11)))) {
    	cf = 0;
    	a269427955 = 11;
    	a1335229626 = 11;
    	a1959734605 = 9; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((a1273086420 == 36 && ((input == 13) && ((a1335229626 == 8 &&  cf==1 ) && a864013224 == 13)))) {
    	cf = 0;
    	a1335229626 = 11;
    	a338143956 = 35 ;
    	a269427955 = 12; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm184(int input) {
    if(((a1273086420 == 36 && ((input == 3) && (a1335229626 == 8 &&  cf==1 ))) && a864013224 == 14)) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((a864013224 == 14 && ((input == 10) &&  cf==1 )) && a1335229626 == 8) && a1273086420 == 36)) {
    	cf = 0;
    	a1335229626 = 12;
    	a389949481 = 36 ;
    	a950417444 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm185(int input) {
    if((a1273086420 == 36 && ((a1335229626 == 8 && ((input == 3) &&  cf==1 )) && a864013224 == 15))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 8) && ((a1273086420 == 36 && ( cf==1  && a1335229626 == 8)) && a864013224 == 15))) {
    	cf = 0;
    	 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((a1273086420 == 36 && (a864013224 == 15 &&  cf==1 )) && (input == 10)) && a1335229626 == 8)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 7;
    	a940472710 = 11; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm26(int input) {
    if(( cf==1  && a864013224 == 11)) {
    	calculate_outputm182(input);
    } 
    if((a864013224 == 13 &&  cf==1 )) {
    	calculate_outputm183(input);
    } 
    if((a864013224 == 14 &&  cf==1 )) {
    	calculate_outputm184(input);
    } 
    if((a864013224 == 15 &&  cf==1 )) {
    	calculate_outputm185(input);
    } 
}
 void calculate_outputm189(int input) {
    if((a1851906186 == 32 && ((( cf==1  && a365147679 == 9) && a1335229626 == 9) && (input == 7)))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 12;
    	a1255937088 = 8; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a365147679 == 9 && ((( cf==1  && a1851906186 == 32) && (input == 8)) && a1335229626 == 9))) {
    	cf = 0;
    	a1335229626 = 10;
    	a1664587146 = 35 ;
    	a880660927 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm191(int input) {
    if((a365147679 == 11 && (a1851906186 == 32 && ((input == 1) && (a1335229626 == 9 &&  cf==1 ))))) {
    	cf = 0;
    	a950417444 = 6;
    	a1335229626 = 12;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a365147679 == 11 && ((input == 3) && (a1851906186 == 32 && (a1335229626 == 9 &&  cf==1 ))))) {
    	cf = 0;
    	a269427955 = 11;
    	a1335229626 = 11;
    	a1959734605 = 2; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a365147679 == 11 && (a1851906186 == 32 && (( cf==1  && (input == 4)) && a1335229626 == 9)))) {
    	cf = 0;
    	 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a1335229626 == 9 && ((a1851906186 == 32 &&  cf==1 ) && a365147679 == 11)) && (input == 7))) {
    	cf = 0;
    	a384913899 = 35 ;
    	a1335229626 = 5;
    	a583612627 = 15; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm192(int input) {
    if((a1851906186 == 32 && ((a365147679 == 13 && ( cf==1  && a1335229626 == 9)) && (input == 1)))) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 9;
    	a757401042 = 8; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a1335229626 == 9 && (((input == 10) && (a1851906186 == 32 &&  cf==1 )) && a365147679 == 13))) {
    	cf = 0;
    	a1851906186 = 33 ;
    	a1383458586 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1851906186 == 32 && (((input == 11) && (a365147679 == 13 &&  cf==1 )) && a1335229626 == 9))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 10;
    	a866603139 = 8; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((input == 13) && (( cf==1  && a365147679 == 13) && a1335229626 == 9)) && a1851906186 == 32)) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 8;
    	a1746137894 = 14; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a365147679 == 13 && (a1335229626 == 9 && (( cf==1  && a1851906186 == 32) && (input == 8))))) {
    	cf = 0;
    	a1851906186 = 34 ;
    	a598251408 = 35 ; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm27(int input) {
    if(( cf==1  && a365147679 == 9)) {
    	calculate_outputm189(input);
    } 
    if((a365147679 == 11 &&  cf==1 )) {
    	calculate_outputm191(input);
    } 
    if((a365147679 == 13 &&  cf==1 )) {
    	calculate_outputm192(input);
    } 
}
 void calculate_outputm196(int input) {
    if(((a1383458586 == 4 && (( cf==1  && a1335229626 == 9) && a1851906186 == 33)) && (input == 4))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 7;
    	a940472710 = 13; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((a1335229626 == 9 && ((a1383458586 == 4 && ( cf==1  && (input == 10))) && a1851906186 == 33))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 35 ;
    	a1383458586 = 3; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((a1335229626 == 9 && ((input == 15) && (a1383458586 == 4 && (a1851906186 == 33 &&  cf==1 ))))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 10;
    	a1760493561 = 15; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((a1335229626 == 9 && ((input == 5) && (a1383458586 == 4 &&  cf==1 ))) && a1851906186 == 33)) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 13;
    	a1249410904 = 10; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm197(int input) {
    if((a1383458586 == 6 && ((( cf==1  && a1335229626 == 9) && a1851906186 == 33) && (input == 15)))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 10;
    	a1760493561 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm198(int input) {
    if(((a1383458586 == 7 && (( cf==1  && a1851906186 == 33) && (input == 3))) && a1335229626 == 9)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1498174835 = 35 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((input == 6) && ((a1851906186 == 33 && ( cf==1  && a1383458586 == 7)) && a1335229626 == 9))) {
    	cf = 0;
    	a1750379405 = 36 ;
    	a1335229626 = 11;
    	a269427955 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1383458586 == 7 && (((input == 7) && ( cf==1  && a1851906186 == 33)) && a1335229626 == 9))) {
    	cf = 0;
    	a1851906186 = 35 ;
    	a1149219151 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((input == 13) && ((a1851906186 == 33 &&  cf==1 ) && a1383458586 == 7)) && a1335229626 == 9)) {
    	cf = 0;
    	a950417444 = 12;
    	a1335229626 = 12;
    	a1255937088 = 8; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm199(int input) {
    if((a1851906186 == 33 && (((a1383458586 == 9 &&  cf==1 ) && (input == 10)) && a1335229626 == 9))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 9;
    	a1237428760 = 7; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm28(int input) {
    if((a1383458586 == 4 &&  cf==1 )) {
    	calculate_outputm196(input);
    } 
    if(( cf==1  && a1383458586 == 6)) {
    	calculate_outputm197(input);
    } 
    if(( cf==1  && a1383458586 == 7)) {
    	calculate_outputm198(input);
    } 
    if((a1383458586 == 9 &&  cf==1 )) {
    	calculate_outputm199(input);
    } 
}
 void calculate_outputm200(int input) {
    if(((a1851906186 == 34 && (a598251408 == 32 && ((input == 7) &&  cf==1 ))) && a1335229626 == 9)) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 9;
    	a565249046 = 5; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((((a598251408 == 32 &&  cf==1 ) && (input == 8)) && a1851906186 == 34) && a1335229626 == 9)) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 15;
    	a1736640332 = 9; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((a1335229626 == 9 && (((a598251408 == 32 &&  cf==1 ) && (input == 13)) && a1851906186 == 34))) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 13;
    	a1249410904 = 5; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm201(int input) {
    if((a598251408 == 33 && ((((input == 3) &&  cf==1 ) && a1851906186 == 34) && a1335229626 == 9))) {
    	cf = 0;
    	a338143956 = 32 ;
    	a1335229626 = 11;
    	a269427955 = 12; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm204(int input) {
    if((a1335229626 == 9 && (a598251408 == 36 && ((a1851906186 == 34 &&  cf==1 ) && (input == 3))))) {
    	cf = 0;
    	a1335229626 = 5;
    	a384913899 = 35 ;
    	a583612627 = 11; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a598251408 == 36 && (a1335229626 == 9 && (( cf==1  && (input == 12)) && a1851906186 == 34)))) {
    	cf = 0;
    	a950417444 = 13;
    	a1335229626 = 12;
    	a962095080 = 3; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((((input == 6) && ( cf==1  && a598251408 == 36)) && a1851906186 == 34) && a1335229626 == 9)) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 10;
    	a1760493561 = 13; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm29(int input) {
    if((a598251408 == 32 &&  cf==1 )) {
    	calculate_outputm200(input);
    } 
    if(( cf==1  && a598251408 == 33)) {
    	calculate_outputm201(input);
    } 
    if((a598251408 == 36 &&  cf==1 )) {
    	calculate_outputm204(input);
    } 
}
 void calculate_outputm205(int input) {
    if(((a1335229626 == 9 && (( cf==1  && a1851906186 == 35) && a1149219151 == 32)) && (input == 4))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 6;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a1335229626 == 9 && ((input == 7) && (( cf==1  && a1851906186 == 35) && a1149219151 == 32)))) {
    	cf = 0;
    	a1851906186 = 33 ;
    	a1383458586 = 7; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a1335229626 == 9 && ((a1851906186 == 35 && ((input == 8) &&  cf==1 )) && a1149219151 == 32))) {
    	cf = 0;
    	a1851906186 = 33 ;
    	a1383458586 = 7; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm206(int input) {
    if((a1851906186 == 35 && (((a1335229626 == 9 &&  cf==1 ) && a1149219151 == 33) && (input == 3)))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 35 ;
    	a1383458586 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1149219151 == 33 && (((input == 5) && (a1335229626 == 9 &&  cf==1 )) && a1851906186 == 35))) {
    	cf = 0;
    	a1510817746 = 10;
    	a1335229626 = 7;
    	a866603139 = 7; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm207(int input) {
    if(((input == 11) && (a1851906186 == 35 && (( cf==1  && a1335229626 == 9) && a1149219151 == 35)))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1498174835 = 34 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((((((input == 15) &&  cf==1 ) && a1335229626 == 9) && a1149219151 == 35) && a1851906186 == 35)) {
    	cf = 0;
    	a950417444 = 10;
    	a1335229626 = 12;
    	a1760493561 = 11; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm208(int input) {
    if(((a1851906186 == 35 && (a1149219151 == 36 && (a1335229626 == 9 &&  cf==1 ))) && (input == 1))) {
    	cf = 0;
    	a1478065937 = 32 ;
    	a1335229626 = 12;
    	a950417444 = 7; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm30(int input) {
    if(( cf==1  && a1149219151 == 32)) {
    	calculate_outputm205(input);
    } 
    if((a1149219151 == 33 &&  cf==1 )) {
    	calculate_outputm206(input);
    } 
    if(( cf==1  && a1149219151 == 35)) {
    	calculate_outputm207(input);
    } 
    if(( cf==1  && a1149219151 == 36)) {
    	calculate_outputm208(input);
    } 
}
 void calculate_outputm209(int input) {
    if(((input == 3) && ((a1851906186 == 36 && ( cf==1  && a1335229626 == 9)) && a2015844410 == 6))) {
    	cf = 0;
    	a1750379405 = 36 ;
    	a1335229626 = 11;
    	a269427955 = 14; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a1335229626 == 9 && ((input == 10) && (( cf==1  && a1851906186 == 36) && a2015844410 == 6)))) {
    	cf = 0;
    	a1851906186 = 32 ;
    	a365147679 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((((input == 15) && (a2015844410 == 6 && ( cf==1  && a1335229626 == 9))) && a1851906186 == 36)) {
    	cf = 0;
    	a338143956 = 35 ;
    	a1335229626 = 11;
    	a269427955 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm212(int input) {
    if((a1335229626 == 9 && ((a2015844410 == 9 && ((input == 1) &&  cf==1 )) && a1851906186 == 36))) {
    	cf = 0;
    	a1510817746 = 13;
    	a1335229626 = 7;
    	a932751092 = 5; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a1851906186 == 36 && ((a2015844410 == 9 &&  cf==1 ) && a1335229626 == 9)) && (input == 2))) {
    	cf = 0;
    	a384913899 = 34 ;
    	a10419264 = 32 ;
    	a1335229626 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1851906186 == 36 && ((a1335229626 == 9 && ((input == 7) &&  cf==1 )) && a2015844410 == 9))) {
    	cf = 0;
    	a1335229626 = 12;
    	a389949481 = 36 ;
    	a950417444 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((a1851906186 == 36 && ((input == 15) && (a2015844410 == 9 && ( cf==1  && a1335229626 == 9))))) {
    	cf = 0;
    	a1510817746 = 8;
    	a1335229626 = 7;
    	a782039646 = 13; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((a1851906186 == 36 && ((( cf==1  && a2015844410 == 9) && (input == 13)) && a1335229626 == 9))) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 15;
    	a1736640332 = 6; 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm214(int input) {
    if(((input == 2) && (a2015844410 == 11 && (( cf==1  && a1335229626 == 9) && a1851906186 == 36)))) {
    	cf = 0;
    	a950417444 = 6;
    	a1335229626 = 12;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm215(int input) {
    if((((a1335229626 == 9 && ( cf==1  && (input == 10))) && a1851906186 == 36) && a2015844410 == 12)) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 2;
    	a324926224 = 3; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((a1335229626 == 9 && (((a2015844410 == 12 &&  cf==1 ) && (input == 15)) && a1851906186 == 36))) {
    	cf = 0;
    	a1851906186 = 34 ;
    	a598251408 = 33 ; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm216(int input) {
    if(((input == 3) && (a2015844410 == 13 && ((a1851906186 == 36 &&  cf==1 ) && a1335229626 == 9)))) {
    	cf = 0;
    	a1259748523 = 32 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((( cf==1  && a2015844410 == 13) && a1335229626 == 9) && (input == 8)) && a1851906186 == 36)) {
    	cf = 0;
    	a950417444 = 6;
    	a1335229626 = 12;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((input == 15) && ((a2015844410 == 13 && (a1851906186 == 36 &&  cf==1 )) && a1335229626 == 9))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 6;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm31(int input) {
    if(( cf==1  && a2015844410 == 6)) {
    	calculate_outputm209(input);
    } 
    if(( cf==1  && a2015844410 == 9)) {
    	calculate_outputm212(input);
    } 
    if((a2015844410 == 11 &&  cf==1 )) {
    	calculate_outputm214(input);
    } 
    if(( cf==1  && a2015844410 == 12)) {
    	calculate_outputm215(input);
    } 
    if(( cf==1  && a2015844410 == 13)) {
    	calculate_outputm216(input);
    } 
}
 void calculate_outputm219(int input) {
    if((a2121950185 == 35 && (a880660927 == 9 && (( cf==1  && a1335229626 == 10) && (input == 3))))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a880660927 == 9 && ((a1335229626 == 10 && (a2121950185 == 35 &&  cf==1 )) && (input == 7)))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((input == 10) && ((a1335229626 == 10 &&  cf==1 ) && a2121950185 == 35)) && a880660927 == 9)) {
    	cf = 0;
    	a384913899 = 34 ;
    	a10419264 = 32 ;
    	a1335229626 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1335229626 == 10 && (a2121950185 == 35 && (a880660927 == 9 && ( cf==1  && (input == 12)))))) {
    	cf = 0;
    	a1259748523 = 32 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm220(int input) {
    if((((input == 2) && ((a1335229626 == 10 &&  cf==1 ) && a880660927 == 9)) && a2121950185 == 36)) {
    	cf = 0;
    	a1851906186 = 32 ;
    	a1335229626 = 9;
    	a365147679 = 11; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((( cf==1  && a1335229626 == 10) && a880660927 == 9) && a2121950185 == 36) && (input == 7))) {
    	cf = 0;
    	a880660927 = 13;
    	a1249410904 = 5; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((input == 11) && (a1335229626 == 10 && (a880660927 == 9 && (a2121950185 == 36 &&  cf==1 ))))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 10;
    	a1760493561 = 10; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((a1335229626 == 10 && (a2121950185 == 36 && (((input == 15) &&  cf==1 ) && a880660927 == 9)))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 35 ;
    	a1383458586 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm32(int input) {
    if((a2121950185 == 35 &&  cf==1 )) {
    	calculate_outputm219(input);
    } 
    if((a2121950185 == 36 &&  cf==1 )) {
    	calculate_outputm220(input);
    } 
}
 void calculate_outputm222(int input) {
    if(((a200918022 == 8 && (a880660927 == 10 && ( cf==1  && a1335229626 == 10))) && (input == 1))) {
    	cf = 0;
    	a1259748523 = 33 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((input == 3) && (a200918022 == 8 && (a1335229626 == 10 &&  cf==1 ))) && a880660927 == 10)) {
    	cf = 0;
    	a1510817746 = 10;
    	a1335229626 = 7;
    	a866603139 = 10; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((input == 6) && (((a1335229626 == 10 &&  cf==1 ) && a880660927 == 10) && a200918022 == 8))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 9;
    	a1250255157 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1335229626 == 10 && (((input == 10) && ( cf==1  && a200918022 == 8)) && a880660927 == 10))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 11; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm224(int input) {
    if((a1335229626 == 10 && ((a880660927 == 10 && ( cf==1  && a200918022 == 10)) && (input == 10)))) {
    	cf = 0;
    	a2121950185 = 36 ;
    	a880660927 = 9; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((((input == 11) && ( cf==1  && a1335229626 == 10)) && a200918022 == 10) && a880660927 == 10)) {
    	cf = 0;
    	a2135239265 = 32 ;
    	a1335229626 = 12;
    	a950417444 = 11; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((input == 13) && (a1335229626 == 10 && ((a200918022 == 10 &&  cf==1 ) && a880660927 == 10)))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1132599179 = 34 ;
    	a1959734605 = 4; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm225(int input) {
    if(((((input == 7) && ( cf==1  && a880660927 == 10)) && a1335229626 == 10) && a200918022 == 11)) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 11;
    	a1959734605 = 2; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm33(int input) {
    if((a200918022 == 8 &&  cf==1 )) {
    	calculate_outputm222(input);
    } 
    if(( cf==1  && a200918022 == 10)) {
    	calculate_outputm224(input);
    } 
    if(( cf==1  && a200918022 == 11)) {
    	calculate_outputm225(input);
    } 
}
 void calculate_outputm227(int input) {
    if((((a1837110425 == 2 && ((input == 1) &&  cf==1 )) && a880660927 == 11) && a1335229626 == 10)) {
    	cf = 0;
    	a950417444 = 12;
    	a1335229626 = 12;
    	a1255937088 = 11; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((( cf==1  && a1837110425 == 2) && a1335229626 == 10) && a880660927 == 11) && (input == 11))) {
    	cf = 0;
    	a1335229626 = 11;
    	a338143956 = 36 ;
    	a269427955 = 12; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((input == 12) && (a1335229626 == 10 && (( cf==1  && a1837110425 == 2) && a880660927 == 11)))) {
    	cf = 0;
    	a269427955 = 11;
    	a1335229626 = 11;
    	a1959734605 = 3; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((a880660927 == 11 && (((input == 13) &&  cf==1 ) && a1837110425 == 2)) && a1335229626 == 10)) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 13;
    	a1053530639 = 4; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm229(int input) {
    if(((input == 1) && (a1335229626 == 10 && ((a880660927 == 11 &&  cf==1 ) && a1837110425 == 4)))) {
    	cf = 0;
    	a1837110425 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1837110425 == 4 && ((input == 15) &&  cf==1 )) && a880660927 == 11) && a1335229626 == 10)) {
    	cf = 0;
    	a1959734605 = 8;
    	a1335229626 = 6;
    	a286009693 = 9; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm230(int input) {
    if((a1837110425 == 5 && (a1335229626 == 10 && (a880660927 == 11 && ( cf==1  && (input == 8)))))) {
    	cf = 0;
    	a2121950185 = 35 ;
    	a880660927 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm231(int input) {
    if((((a880660927 == 11 && (a1335229626 == 10 &&  cf==1 )) && (input == 1)) && a1837110425 == 6)) {
    	cf = 0;
    	a1510817746 = 10;
    	a1335229626 = 7;
    	a866603139 = 10; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a880660927 == 11 && ((input == 2) && (a1335229626 == 10 &&  cf==1 ))) && a1837110425 == 6)) {
    	cf = 0;
    	a1273086420 = 35 ;
    	a1335229626 = 8;
    	a1383458586 = 7; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a1837110425 == 6 && (a880660927 == 11 && ((input == 10) &&  cf==1 ))) && a1335229626 == 10)) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 8;
    	a1746137894 = 12; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((((a1335229626 == 10 &&  cf==1 ) && (input == 15)) && a880660927 == 11) && a1837110425 == 6)) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 10;
    	a1760493561 = 10; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm232(int input) {
    if((a880660927 == 11 && ((a1335229626 == 10 && ( cf==1  && (input == 4))) && a1837110425 == 7))) {
    	cf = 0;
    	a950417444 = 10;
    	a1335229626 = 12;
    	a1760493561 = 10; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((a1335229626 == 10 && ((input == 11) && (a1837110425 == 7 && (a880660927 == 11 &&  cf==1 ))))) {
    	cf = 0;
    	a1273086420 = 36 ;
    	a1335229626 = 8;
    	a864013224 = 14; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((input == 13) && ((( cf==1  && a1335229626 == 10) && a880660927 == 11) && a1837110425 == 7))) {
    	cf = 0;
    	a1273086420 = 34 ;
    	a1259748523 = 32 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a1335229626 == 10 && (a1837110425 == 7 && ((input == 15) &&  cf==1 ))) && a880660927 == 11)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1498174835 = 34 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm34(int input) {
    if(( cf==1  && a1837110425 == 2)) {
    	calculate_outputm227(input);
    } 
    if((a1837110425 == 4 &&  cf==1 )) {
    	calculate_outputm229(input);
    } 
    if((a1837110425 == 5 &&  cf==1 )) {
    	calculate_outputm230(input);
    } 
    if(( cf==1  && a1837110425 == 6)) {
    	calculate_outputm231(input);
    } 
    if(( cf==1  && a1837110425 == 7)) {
    	calculate_outputm232(input);
    } 
}
 void calculate_outputm234(int input) {
    if(((input == 7) && ((( cf==1  && a2045918669 == 4) && a880660927 == 12) && a1335229626 == 10))) {
    	cf = 0;
    	a950417444 = 12;
    	a1335229626 = 12;
    	a1255937088 = 10; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm235(int input) {
    if((a1335229626 == 10 && (a2045918669 == 8 && (( cf==1  && (input == 1)) && a880660927 == 12)))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 6;
    	a1438665870 = 11; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((input == 2) && (a1335229626 == 10 && ( cf==1  && a880660927 == 12))) && a2045918669 == 8)) {
    	cf = 0;
    	a1851906186 = 34 ;
    	a598251408 = 32 ;
    	a1335229626 = 9; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((a2045918669 == 8 && (((a1335229626 == 10 &&  cf==1 ) && a880660927 == 12) && (input == 10)))) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 6;
    	a1210809645 = 13; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm35(int input) {
    if((a2045918669 == 4 &&  cf==1 )) {
    	calculate_outputm234(input);
    } 
    if(( cf==1  && a2045918669 == 8)) {
    	calculate_outputm235(input);
    } 
}
 void calculate_outputm238(int input) {
    if((a880660927 == 13 && (((a1335229626 == 10 &&  cf==1 ) && (input == 3)) && a1249410904 == 5))) {
    	cf = 0;
    	a1510817746 = 10;
    	a1335229626 = 7;
    	a866603139 = 4; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm240(int input) {
    if(((input == 1) && (a1335229626 == 10 && ((a880660927 == 13 &&  cf==1 ) && a1249410904 == 7)))) {
    	cf = 0;
    	 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a1335229626 == 10 && (a880660927 == 13 && (((input == 8) &&  cf==1 ) && a1249410904 == 7)))) {
    	cf = 0;
    	a1851906186 = 36 ;
    	a1335229626 = 9;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm241(int input) {
    if(((input == 1) && (((a1335229626 == 10 &&  cf==1 ) && a880660927 == 13) && a1249410904 == 8))) {
    	cf = 0;
    	a880642005 = 36 ;
    	a1273086420 = 33 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((input == 10) && ((a1249410904 == 8 && ( cf==1  && a1335229626 == 10)) && a880660927 == 13))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 12;
    	a1255937088 = 8; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1335229626 == 10 && (a1249410904 == 8 && (((input == 15) &&  cf==1 ) && a880660927 == 13)))) {
    	cf = 0;
    	a1664587146 = 35 ;
    	a880660927 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm243(int input) {
    if((((input == 2) && (a1335229626 == 10 && ( cf==1  && a880660927 == 13))) && a1249410904 == 11)) {
    	cf = 0;
    	a950417444 = 10;
    	a1335229626 = 12;
    	a1760493561 = 16; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 3) && (a1335229626 == 10 && (( cf==1  && a1249410904 == 11) && a880660927 == 13)))) {
    	cf = 0;
    	a1478065937 = 35 ;
    	a1335229626 = 12;
    	a950417444 = 7; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm36(int input) {
    if(( cf==1  && a1249410904 == 5)) {
    	calculate_outputm238(input);
    } 
    if(( cf==1  && a1249410904 == 7)) {
    	calculate_outputm240(input);
    } 
    if(( cf==1  && a1249410904 == 8)) {
    	calculate_outputm241(input);
    } 
    if((a1249410904 == 11 &&  cf==1 )) {
    	calculate_outputm243(input);
    } 
}
 void calculate_outputm244(int input) {
    if((((a1335229626 == 10 && ( cf==1  && a880660927 == 14)) && (input == 3)) && a1664587146 == 32)) {
    	cf = 0;
    	a1273086420 = 36 ;
    	a1335229626 = 8;
    	a864013224 = 14; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a1664587146 == 32 && (a880660927 == 14 && (((input == 6) &&  cf==1 ) && a1335229626 == 10)))) {
    	cf = 0;
    	a1335229626 = 5;
    	a384913899 = 35 ;
    	a583612627 = 14; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((((input == 7) && (a1335229626 == 10 &&  cf==1 )) && a880660927 == 14) && a1664587146 == 32)) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 10;
    	a1760493561 = 11; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((input == 15) && (a1664587146 == 32 && (a1335229626 == 10 &&  cf==1 ))) && a880660927 == 14)) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 13; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm245(int input) {
    if(((((input == 10) && ( cf==1  && a1335229626 == 10)) && a880660927 == 14) && a1664587146 == 33)) {
    	cf = 0;
    	a1510817746 = 10;
    	a1335229626 = 7;
    	a866603139 = 10; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a880660927 == 14 && (( cf==1  && a1664587146 == 33) && (input == 11))) && a1335229626 == 10)) {
    	cf = 0;
    	a1335229626 = 6;
    	a1959734605 = 9;
    	a1250255157 = 12; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a880660927 == 14 && (a1335229626 == 10 && (a1664587146 == 33 &&  cf==1 ))) && (input == 13))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 32 ;
    	a365147679 = 11; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a880660927 == 14 && (a1664587146 == 33 && (a1335229626 == 10 && ((input == 15) &&  cf==1 ))))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 12;
    	a1255937088 = 8; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm247(int input) {
    if((a1335229626 == 10 && ((input == 2) && (a1664587146 == 35 && ( cf==1  && a880660927 == 14))))) {
    	cf = 0;
    	a1335229626 = 12;
    	a389949481 = 36 ;
    	a950417444 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a880660927 == 14 && ((a1335229626 == 10 &&  cf==1 ) && a1664587146 == 35)) && (input == 4))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a880660927 == 14 && ((a1664587146 == 35 && (a1335229626 == 10 &&  cf==1 )) && (input == 8)))) {
    	cf = 0;
    	a1273086420 = 34 ;
    	a1259748523 = 32 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((a1335229626 == 10 && ((a880660927 == 14 && ( cf==1  && a1664587146 == 35)) && (input == 11)))) {
    	cf = 0;
    	a389949481 = 36 ;
    	a1335229626 = 12;
    	a950417444 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm248(int input) {
    if((a1664587146 == 36 && ((input == 12) && (a1335229626 == 10 && ( cf==1  && a880660927 == 14))))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 13; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm37(int input) {
    if((a1664587146 == 32 &&  cf==1 )) {
    	calculate_outputm244(input);
    } 
    if(( cf==1  && a1664587146 == 33)) {
    	calculate_outputm245(input);
    } 
    if(( cf==1  && a1664587146 == 35)) {
    	calculate_outputm247(input);
    } 
    if(( cf==1  && a1664587146 == 36)) {
    	calculate_outputm248(input);
    } 
}
 void calculate_outputm250(int input) {
    if(((input == 10) && (((a880660927 == 15 &&  cf==1 ) && a1736640332 == 9) && a1335229626 == 10))) {
    	cf = 0;
    	a1259748523 = 32 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm38(int input) {
    if(( cf==1  && a1736640332 == 9)) {
    	calculate_outputm250(input);
    } 
}
 void calculate_outputm251(int input) {
    if((((((input == 1) &&  cf==1 ) && a147402251 == 32) && a880660927 == 16) && a1335229626 == 10)) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 9;
    	a757401042 = 6; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a880660927 == 16 && ((a1335229626 == 10 &&  cf==1 ) && a147402251 == 32)) && (input == 8))) {
    	cf = 0;
    	a384913899 = 32 ;
    	a1335229626 = 5;
    	a1031697847 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((((a880660927 == 16 &&  cf==1 ) && (input == 7)) && a147402251 == 32) && a1335229626 == 10)) {
    	cf = 0;
    	a1335229626 = 5;
    	a384913899 = 32 ;
    	a1031697847 = 6; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm39(int input) {
    if((a147402251 == 32 &&  cf==1 )) {
    	calculate_outputm251(input);
    } 
}
 void calculate_outputm255(int input) {
    if((((input == 1) && (a1746137894 == 12 && ( cf==1  && a269427955 == 8))) && a1335229626 == 11)) {
    	cf = 0;
    	 
    	 printf("%d\n", 17); fflush(stdout); 
    } if(((input == 2) && (((a269427955 == 8 &&  cf==1 ) && a1746137894 == 12) && a1335229626 == 11))) {
    	cf = 0;
    	 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((a269427955 == 8 && ((a1335229626 == 11 && ((input == 3) &&  cf==1 )) && a1746137894 == 12))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 6;
    	a1438665870 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((((input == 8) &&  cf==1 ) && a269427955 == 8) && a1746137894 == 12) && a1335229626 == 11)) {
    	cf = 0;
    	a950417444 = 6;
    	a1335229626 = 12;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm257(int input) {
    if((a1335229626 == 11 && ((a1746137894 == 14 && ((input == 1) &&  cf==1 )) && a269427955 == 8))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 6;
    	a1438665870 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1335229626 == 11 && (a269427955 == 8 && (( cf==1  && (input == 3)) && a1746137894 == 14)))) {
    	cf = 0;
    	a1498174835 = 32 ;
    	a1335229626 = 7;
    	a1510817746 = 12; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((a1746137894 == 14 && ( cf==1  && a269427955 == 8)) && (input == 4)) && a1335229626 == 11)) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 11;
    	a1837110425 = 2; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((a269427955 == 8 && (a1746137894 == 14 &&  cf==1 )) && (input == 10)) && a1335229626 == 11)) {
    	cf = 0;
    	a1510817746 = 7;
    	a1335229626 = 7;
    	a940472710 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm259(int input) {
    if(((a1746137894 == 17 && (a269427955 == 8 && ( cf==1  && a1335229626 == 11))) && (input == 6))) {
    	cf = 0;
    	a1259748523 = 32 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm41(int input) {
    if((a1746137894 == 12 &&  cf==1 )) {
    	calculate_outputm255(input);
    } 
    if(( cf==1  && a1746137894 == 14)) {
    	calculate_outputm257(input);
    } 
    if(( cf==1  && a1746137894 == 17)) {
    	calculate_outputm259(input);
    } 
}
 void calculate_outputm262(int input) {
    if(((a757401042 == 6 && ((a269427955 == 9 &&  cf==1 ) && a1335229626 == 11)) && (input == 1))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 11;
    	a654409942 = 10; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a269427955 == 9 && (a1335229626 == 11 && ((input == 5) &&  cf==1 ))) && a757401042 == 6)) {
    	cf = 0;
    	a1959734605 = 9;
    	a1335229626 = 6;
    	a1250255157 = 14; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm263(int input) {
    if(((((a1335229626 == 11 &&  cf==1 ) && a269427955 == 9) && (input == 4)) && a757401042 == 8)) {
    	cf = 0;
    	a307029135 = 35 ;
    	a1335229626 = 7;
    	a1510817746 = 14; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((input == 13) && ((a269427955 == 9 && ( cf==1  && a1335229626 == 11)) && a757401042 == 8))) {
    	cf = 0;
    	a1851906186 = 35 ;
    	a1149219151 = 36 ;
    	a1335229626 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a269427955 == 9 && ((a1335229626 == 11 &&  cf==1 ) && (input == 11))) && a757401042 == 8)) {
    	cf = 0;
    	a1959734605 = 3;
    	a1335229626 = 6;
    	a1210809645 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm42(int input) {
    if(( cf==1  && a757401042 == 6)) {
    	calculate_outputm262(input);
    } 
    if(( cf==1  && a757401042 == 8)) {
    	calculate_outputm263(input);
    } 
}
 void calculate_outputm264(int input) {
    if(((input == 1) && (a269427955 == 10 && (a113972147 == 33 && (a1335229626 == 11 &&  cf==1 ))))) {
    	cf = 0;
    	a269427955 = 8;
    	a1746137894 = 17; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((a269427955 == 10 && ((a1335229626 == 11 &&  cf==1 ) && (input == 3))) && a113972147 == 33)) {
    	cf = 0;
    	a1335229626 = 10;
    	a2121950185 = 35 ;
    	a880660927 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 15) && (a113972147 == 33 && ((a269427955 == 10 &&  cf==1 ) && a1335229626 == 11)))) {
    	cf = 0;
    	a113972147 = 34 ; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm265(int input) {
    if(((a1335229626 == 11 && ((input == 15) && (a113972147 == 34 &&  cf==1 ))) && a269427955 == 10)) {
    	cf = 0;
    	a113972147 = 33 ; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm43(int input) {
    if((a113972147 == 33 &&  cf==1 )) {
    	calculate_outputm264(input);
    } 
    if(( cf==1  && a113972147 == 34)) {
    	calculate_outputm265(input);
    } 
}
 void calculate_outputm266(int input) {
    if((a1335229626 == 11 && ((((input == 15) &&  cf==1 ) && a1959734605 == 2) && a269427955 == 11))) {
    	cf = 0;
    	a1510817746 = 9;
    	a1335229626 = 7;
    	a1237428760 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1335229626 == 11 && ((input == 2) && (a1959734605 == 2 && (a269427955 == 11 &&  cf==1 ))))) {
    	cf = 0;
    	a384913899 = 33 ;
    	a307029135 = 36 ;
    	a1335229626 = 5; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm267(int input) {
    if(((input == 3) && (((a1959734605 == 3 &&  cf==1 ) && a269427955 == 11) && a1335229626 == 11))) {
    	cf = 0;
    	a269427955 = 8;
    	a1746137894 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1335229626 == 11 &&  cf==1 ) && a1959734605 == 3) && a269427955 == 11) && (input == 4))) {
    	cf = 0;
    	a269427955 = 8;
    	a1746137894 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm268(int input) {
    if((a1959734605 == 5 && (((input == 3) && ( cf==1  && a1335229626 == 11)) && a269427955 == 11))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 35 ;
    	a1383458586 = 7; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm270(int input) {
    if((((a1335229626 == 11 && (a269427955 == 11 &&  cf==1 )) && (input == 6)) && a1959734605 == 7)) {
    	cf = 0;
    	a1510817746 = 10;
    	a1335229626 = 7;
    	a866603139 = 10; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a269427955 == 11 && ((a1959734605 == 7 && ( cf==1  && a1335229626 == 11)) && (input == 13)))) {
    	cf = 0;
    	a1510817746 = 9;
    	a1335229626 = 7;
    	a1237428760 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm271(int input) {
    if((a1959734605 == 8 && ((input == 8) && (( cf==1  && a269427955 == 11) && a1335229626 == 11)))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 9;
    	a565249046 = 7; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 13) && ((a1959734605 == 8 && ( cf==1  && a1335229626 == 11)) && a269427955 == 11))) {
    	cf = 0;
    	a338143956 = 32 ;
    	a269427955 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm272(int input) {
    if((a1335229626 == 11 && (((a1959734605 == 9 &&  cf==1 ) && (input == 8)) && a269427955 == 11))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((input == 10) && (( cf==1  && a269427955 == 11) && a1959734605 == 9)) && a1335229626 == 11)) {
    	cf = 0;
    	a10419264 = 32 ;
    	a384913899 = 34 ;
    	a1335229626 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1335229626 == 11 && (((input == 11) &&  cf==1 ) && a269427955 == 11)) && a1959734605 == 9)) {
    	cf = 0;
    	a1259748523 = 32 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((a269427955 == 11 && ( cf==1  && (input == 13))) && a1335229626 == 11) && a1959734605 == 9)) {
    	cf = 0;
    	a1851906186 = 36 ;
    	a1335229626 = 9;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm44(int input) {
    if((a1959734605 == 2 &&  cf==1 )) {
    	calculate_outputm266(input);
    } 
    if((a1959734605 == 3 &&  cf==1 )) {
    	calculate_outputm267(input);
    } 
    if((a1959734605 == 5 &&  cf==1 )) {
    	calculate_outputm268(input);
    } 
    if(( cf==1  && a1959734605 == 7)) {
    	calculate_outputm270(input);
    } 
    if(( cf==1  && a1959734605 == 8)) {
    	calculate_outputm271(input);
    } 
    if(( cf==1  && a1959734605 == 9)) {
    	calculate_outputm272(input);
    } 
}
 void calculate_outputm273(int input) {
    if((a338143956 == 32 && (a1335229626 == 11 && (((input == 11) &&  cf==1 ) && a269427955 == 12)))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((input == 13) && (a1335229626 == 11 && ((a338143956 == 32 &&  cf==1 ) && a269427955 == 12)))) {
    	cf = 0;
    	a269427955 = 11;
    	a1959734605 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm276(int input) {
    if(((((input == 1) && ( cf==1  && a1335229626 == 11)) && a269427955 == 12) && a338143956 == 35)) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 9;
    	a565249046 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 10) && (a1335229626 == 11 && (a269427955 == 12 && ( cf==1  && a338143956 == 35))))) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 9;
    	a565249046 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a269427955 == 12 && ( cf==1  && (input == 15))) && a338143956 == 35) && a1335229626 == 11)) {
    	cf = 0;
    	a1335229626 = 12;
    	a950417444 = 9;
    	a565249046 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm277(int input) {
    if(((a269427955 == 12 && (((input == 2) &&  cf==1 ) && a1335229626 == 11)) && a338143956 == 36)) {
    	cf = 0;
    	a269427955 = 11;
    	a1959734605 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((input == 8) && ( cf==1  && a1335229626 == 11)) && a338143956 == 36) && a269427955 == 12)) {
    	cf = 0;
    	a338143956 = 32 ; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((a338143956 == 36 && (a269427955 == 12 &&  cf==1 )) && (input == 10)) && a1335229626 == 11)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1498174835 = 34 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((a269427955 == 12 && ((( cf==1  && (input == 12)) && a1335229626 == 11) && a338143956 == 36))) {
    	cf = 0;
    	a1498174835 = 34 ;
    	a1335229626 = 7;
    	a1510817746 = 12; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm45(int input) {
    if(( cf==1  && a338143956 == 32)) {
    	calculate_outputm273(input);
    } 
    if(( cf==1  && a338143956 == 35)) {
    	calculate_outputm276(input);
    } 
    if((a338143956 == 36 &&  cf==1 )) {
    	calculate_outputm277(input);
    } 
}
 void calculate_outputm278(int input) {
    if(((((a1053530639 == 4 &&  cf==1 ) && (input == 3)) && a1335229626 == 11) && a269427955 == 13)) {
    	cf = 0;
    	a1335229626 = 5;
    	a384913899 = 35 ;
    	a583612627 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a269427955 == 13 && ((input == 13) && (( cf==1  && a1053530639 == 4) && a1335229626 == 11)))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 36 ;
    	a2015844410 = 13; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm280(int input) {
    if((a269427955 == 13 && (a1053530639 == 7 && (( cf==1  && a1335229626 == 11) && (input == 3))))) {
    	cf = 0;
    	a950417444 = 12;
    	a1335229626 = 12;
    	a1255937088 = 8; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a269427955 == 13 && ((input == 10) &&  cf==1 )) && a1053530639 == 7) && a1335229626 == 11)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1498174835 = 34 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a269427955 == 13 && ((input == 15) && (a1053530639 == 7 &&  cf==1 ))) && a1335229626 == 11)) {
    	cf = 0;
    	a1273086420 = 34 ;
    	a1259748523 = 32 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm282(int input) {
    if(((a1335229626 == 11 && (a269427955 == 13 && ((input == 2) &&  cf==1 ))) && a1053530639 == 10)) {
    	cf = 0;
    	a1335229626 = 5;
    	a384913899 = 35 ;
    	a583612627 = 12; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm46(int input) {
    if((a1053530639 == 4 &&  cf==1 )) {
    	calculate_outputm278(input);
    } 
    if(( cf==1  && a1053530639 == 7)) {
    	calculate_outputm280(input);
    } 
    if((a1053530639 == 10 &&  cf==1 )) {
    	calculate_outputm282(input);
    } 
}
 void calculate_outputm283(int input) {
    if(((((a1335229626 == 11 &&  cf==1 ) && a1750379405 == 35) && (input == 2)) && a269427955 == 14)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 9;
    	a1237428760 = 5; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((input == 6) && ((( cf==1  && a269427955 == 14) && a1335229626 == 11) && a1750379405 == 35))) {
    	cf = 0;
    	a1750379405 = 36 ; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((a1335229626 == 11 && ((( cf==1  && a1750379405 == 35) && a269427955 == 14) && (input == 11)))) {
    	cf = 0;
    	a950417444 = 12;
    	a1335229626 = 12;
    	a1255937088 = 8; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a1335229626 == 11 && ((input == 12) && ( cf==1  && a269427955 == 14))) && a1750379405 == 35)) {
    	cf = 0;
    	a1273086420 = 35 ;
    	a1335229626 = 8;
    	a1383458586 = 6; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm284(int input) {
    if((((a1335229626 == 11 && ( cf==1  && a269427955 == 14)) && a1750379405 == 36) && (input == 7))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 33 ;
    	a1383458586 = 7; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a269427955 == 14 && ((a1750379405 == 36 && ( cf==1  && a1335229626 == 11)) && (input == 8)))) {
    	cf = 0;
    	a950417444 = 6;
    	a1335229626 = 12;
    	a1438665870 = 6; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm47(int input) {
    if((a1750379405 == 35 &&  cf==1 )) {
    	calculate_outputm283(input);
    } 
    if((a1750379405 == 36 &&  cf==1 )) {
    	calculate_outputm284(input);
    } 
}
 void calculate_outputm285(int input) {
    if(((a1438665870 == 6 && (((input == 2) &&  cf==1 ) && a950417444 == 6)) && a1335229626 == 12)) {
    	cf = 0;
    	a147402251 = 32 ;
    	a1335229626 = 10;
    	a880660927 = 16; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((input == 10) && (a1335229626 == 12 && ( cf==1  && a950417444 == 6))) && a1438665870 == 6)) {
    	cf = 0;
    	a1851906186 = 36 ;
    	a1335229626 = 9;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1438665870 == 6 && ((a950417444 == 6 && ((input == 11) &&  cf==1 )) && a1335229626 == 12))) {
    	cf = 0;
    	a269427955 = 11;
    	a1335229626 = 11;
    	a1959734605 = 2; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((((a1438665870 == 6 &&  cf==1 ) && a1335229626 == 12) && a950417444 == 6) && (input == 5))) {
    	cf = 0;
    	a384913899 = 33 ;
    	a307029135 = 32 ;
    	a1335229626 = 5; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm286(int input) {
    if((a1438665870 == 7 && (a950417444 == 6 && (((input == 1) &&  cf==1 ) && a1335229626 == 12)))) {
    	cf = 0;
    	a269427955 = 13;
    	a1335229626 = 11;
    	a1053530639 = 10; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((a1335229626 == 12 && (a1438665870 == 7 && ((a950417444 == 6 &&  cf==1 ) && (input == 6))))) {
    	cf = 0;
    	a1851906186 = 33 ;
    	a1335229626 = 9;
    	a1383458586 = 6; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a1438665870 == 7 && ((a950417444 == 6 &&  cf==1 ) && (input == 12))) && a1335229626 == 12)) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 11;
    	a1959734605 = 7; 
    	 printf("%d\n", 17); fflush(stdout); 
    } 
}
 void calculate_outputm288(int input) {
    if(((a950417444 == 6 && (a1335229626 == 12 && ((input == 2) &&  cf==1 ))) && a1438665870 == 11)) {
    	cf = 0;
    	a950417444 = 12;
    	a1255937088 = 8; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a1438665870 == 11 && ((( cf==1  && a1335229626 == 12) && (input == 12)) && a950417444 == 6))) {
    	cf = 0;
    	a1851906186 = 36 ;
    	a1335229626 = 9;
    	a2015844410 = 13; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((a1438665870 == 11 && ((input == 13) && (a950417444 == 6 && ( cf==1  && a1335229626 == 12))))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 9;
    	a1237428760 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm289(int input) {
    if(((input == 11) && ((( cf==1  && a950417444 == 6) && a1438665870 == 13) && a1335229626 == 12))) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1438665870 == 13 && ((input == 13) &&  cf==1 )) && a950417444 == 6) && a1335229626 == 12)) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 32 ;
    	a1074841212 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((a1335229626 == 12 && (a1438665870 == 13 && ((input == 15) &&  cf==1 ))) && a950417444 == 6)) {
    	cf = 0;
    	 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm48(int input) {
    if(( cf==1  && a1438665870 == 6)) {
    	calculate_outputm285(input);
    } 
    if((a1438665870 == 7 &&  cf==1 )) {
    	calculate_outputm286(input);
    } 
    if(( cf==1  && a1438665870 == 11)) {
    	calculate_outputm288(input);
    } 
    if(( cf==1  && a1438665870 == 13)) {
    	calculate_outputm289(input);
    } 
}
 void calculate_outputm290(int input) {
    if(((input == 1) && (a1478065937 == 32 && ((a950417444 == 7 &&  cf==1 ) && a1335229626 == 12)))) {
    	cf = 0;
    	a1851906186 = 35 ;
    	a1149219151 = 32 ;
    	a1335229626 = 9; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a950417444 == 7 && ((input == 4) && (a1335229626 == 12 && ( cf==1  && a1478065937 == 32))))) {
    	cf = 0;
    	a1602107789 = 32 ;
    	a1335229626 = 6;
    	a1959734605 = 5; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a1335229626 == 12 && ((input == 6) && ( cf==1  && a950417444 == 7))) && a1478065937 == 32)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1498174835 = 34 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm291(int input) {
    if((((a1478065937 == 33 && ( cf==1  && a950417444 == 7)) && a1335229626 == 12) && (input == 8))) {
    	cf = 0;
    	a880642005 = 36 ;
    	a1273086420 = 33 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a950417444 == 7 && (( cf==1  && (input == 15)) && a1478065937 == 33)) && a1335229626 == 12)) {
    	cf = 0;
    	a1498174835 = 34 ;
    	a1335229626 = 7;
    	a1510817746 = 12; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm49(int input) {
    if((a1478065937 == 32 &&  cf==1 )) {
    	calculate_outputm290(input);
    } 
    if(( cf==1  && a1478065937 == 33)) {
    	calculate_outputm291(input);
    } 
}
 void calculate_outputm294(int input) {
    if(((((a1335229626 == 12 &&  cf==1 ) && a950417444 == 8) && a389949481 == 32) && (input == 4))) {
    	cf = 0;
    	a1851906186 = 32 ;
    	a1335229626 = 9;
    	a365147679 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((( cf==1  && (input == 6)) && a389949481 == 32) && a1335229626 == 12) && a950417444 == 8)) {
    	cf = 0;
    	a1259748523 = 35 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((((a950417444 == 8 && ((input == 8) &&  cf==1 )) && a389949481 == 32) && a1335229626 == 12)) {
    	cf = 0;
    	a1602107789 = 35 ;
    	a1335229626 = 6;
    	a1959734605 = 5; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if(((a1335229626 == 12 && (( cf==1  && (input == 13)) && a389949481 == 32)) && a950417444 == 8)) {
    	cf = 0;
    	a950417444 = 9;
    	a565249046 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm295(int input) {
    if(((((a389949481 == 34 &&  cf==1 ) && a1335229626 == 12) && (input == 10)) && a950417444 == 8)) {
    	cf = 0;
    	a950417444 = 10;
    	a1760493561 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm296(int input) {
    if(((a1335229626 == 12 && ((a389949481 == 35 &&  cf==1 ) && (input == 2))) && a950417444 == 8)) {
    	cf = 0;
    	a384913899 = 35 ;
    	a1335229626 = 5;
    	a583612627 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a950417444 == 8 && (a389949481 == 35 && (a1335229626 == 12 && ( cf==1  && (input == 7)))))) {
    	cf = 0;
    	a1273086420 = 34 ;
    	a1259748523 = 35 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a950417444 == 8 && (((a1335229626 == 12 &&  cf==1 ) && a389949481 == 35) && (input == 11)))) {
    	cf = 0;
    	a1273086420 = 35 ;
    	a1335229626 = 8;
    	a1383458586 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm297(int input) {
    if((((a389949481 == 36 && ( cf==1  && a1335229626 == 12)) && (input == 4)) && a950417444 == 8)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 7;
    	a940472710 = 11; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a950417444 == 8 && (( cf==1  && (input == 6)) && a1335229626 == 12)) && a389949481 == 36)) {
    	cf = 0;
    	a1959734605 = 3;
    	a1335229626 = 6;
    	a1210809645 = 12; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((a1335229626 == 12 && ((((input == 7) &&  cf==1 ) && a950417444 == 8) && a389949481 == 36))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 32 ;
    	a1074841212 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 8) && ((a389949481 == 36 &&  cf==1 ) && a950417444 == 8)) && a1335229626 == 12)) {
    	cf = 0;
    	a880660927 = 10;
    	a1335229626 = 10;
    	a200918022 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a1335229626 == 12 && (a950417444 == 8 &&  cf==1 )) && (input == 2)) && a389949481 == 36)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 11;
    	a654409942 = 11; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm50(int input) {
    if((a389949481 == 32 &&  cf==1 )) {
    	calculate_outputm294(input);
    } 
    if((a389949481 == 34 &&  cf==1 )) {
    	calculate_outputm295(input);
    } 
    if((a389949481 == 35 &&  cf==1 )) {
    	calculate_outputm296(input);
    } 
    if(( cf==1  && a389949481 == 36)) {
    	calculate_outputm297(input);
    } 
}
 void calculate_outputm298(int input) {
    if(((a1335229626 == 12 && (( cf==1  && a565249046 == 5) && a950417444 == 9)) && (input == 8))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 32 ;
    	a365147679 = 13; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a1335229626 == 12 && (a950417444 == 9 && (a565249046 == 5 &&  cf==1 ))) && (input == 10))) {
    	cf = 0;
    	a880660927 = 13;
    	a1335229626 = 10;
    	a1249410904 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((a950417444 == 9 && (a565249046 == 5 &&  cf==1 )) && a1335229626 == 12) && (input == 15))) {
    	cf = 0;
    	a307029135 = 35 ;
    	a384913899 = 33 ;
    	a1335229626 = 5; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm299(int input) {
    if(((input == 1) && ((a950417444 == 9 && ( cf==1  && a565249046 == 6)) && a1335229626 == 12))) {
    	cf = 0;
    	a1335229626 = 11;
    	a269427955 = 11;
    	a1959734605 = 9; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a1335229626 == 12 && (a950417444 == 9 && (( cf==1  && a565249046 == 6) && (input == 8))))) {
    	cf = 0;
    	a1335229626 = 11;
    	a338143956 = 35 ;
    	a269427955 = 12; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((( cf==1  && a1335229626 == 12) && a950417444 == 9) && a565249046 == 6) && (input == 13))) {
    	cf = 0;
    	a880660927 = 13;
    	a1335229626 = 10;
    	a1249410904 = 7; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm300(int input) {
    if(((a1335229626 == 12 && (a565249046 == 7 && ((input == 1) &&  cf==1 ))) && a950417444 == 9)) {
    	cf = 0;
    	a1851906186 = 36 ;
    	a1335229626 = 9;
    	a2015844410 = 11; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a565249046 == 7 && (a950417444 == 9 && ( cf==1  && (input == 8)))) && a1335229626 == 12)) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((input == 12) && (a950417444 == 9 && ((a565249046 == 7 &&  cf==1 ) && a1335229626 == 12)))) {
    	cf = 0;
    	a1259748523 = 32 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((a950417444 == 9 && (((a1335229626 == 12 &&  cf==1 ) && a565249046 == 7) && (input == 15)))) {
    	cf = 0;
    	a1851906186 = 36 ;
    	a1335229626 = 9;
    	a2015844410 = 9; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm51(int input) {
    if((a565249046 == 5 &&  cf==1 )) {
    	calculate_outputm298(input);
    } 
    if(( cf==1  && a565249046 == 6)) {
    	calculate_outputm299(input);
    } 
    if(( cf==1  && a565249046 == 7)) {
    	calculate_outputm300(input);
    } 
}
 void calculate_outputm302(int input) {
    if((a1760493561 == 9 && ((a1335229626 == 12 && ( cf==1  && a950417444 == 10)) && (input == 4)))) {
    	cf = 0;
    	a1273086420 = 35 ;
    	a1335229626 = 8;
    	a1383458586 = 2; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((a1760493561 == 9 && ((input == 7) &&  cf==1 )) && a1335229626 == 12) && a950417444 == 10)) {
    	cf = 0;
    	a1510817746 = 8;
    	a1335229626 = 7;
    	a782039646 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1760493561 == 9 && (((a1335229626 == 12 &&  cf==1 ) && a950417444 == 10) && (input == 12)))) {
    	cf = 0;
    	a1335229626 = 10;
    	a1664587146 = 32 ;
    	a880660927 = 14; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((((a1335229626 == 12 && (a950417444 == 10 &&  cf==1 )) && a1760493561 == 9) && (input == 15))) {
    	cf = 0;
    	a1335229626 = 7;
    	a307029135 = 36 ;
    	a1510817746 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } 
}
 void calculate_outputm303(int input) {
    if(((input == 11) && (a1335229626 == 12 && ((a950417444 == 10 &&  cf==1 ) && a1760493561 == 10)))) {
    	cf = 0;
    	a389949481 = 36 ;
    	a950417444 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm304(int input) {
    if(((input == 2) && ((( cf==1  && a1760493561 == 11) && a1335229626 == 12) && a950417444 == 10))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1335229626 == 12 && (a1760493561 == 11 && (a950417444 == 10 && ((input == 7) &&  cf==1 ))))) {
    	cf = 0;
    	a1510817746 = 13;
    	a1335229626 = 7;
    	a932751092 = 5; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm307(int input) {
    if(((((input == 4) && (a1760493561 == 15 &&  cf==1 )) && a1335229626 == 12) && a950417444 == 10)) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 11;
    	a1837110425 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((input == 7) && (((a950417444 == 10 &&  cf==1 ) && a1335229626 == 12) && a1760493561 == 15))) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 32 ;
    	a365147679 = 9; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((a1335229626 == 12 && (a950417444 == 10 &&  cf==1 )) && (input == 11)) && a1760493561 == 15)) {
    	cf = 0;
    	a269427955 = 13;
    	a1335229626 = 11;
    	a1053530639 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm308(int input) {
    if((((a950417444 == 10 && ((input == 2) &&  cf==1 )) && a1335229626 == 12) && a1760493561 == 16)) {
    	cf = 0;
    	a1335229626 = 7;
    	a1510817746 = 10;
    	a866603139 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((input == 3) && (a950417444 == 10 && (a1760493561 == 16 &&  cf==1 ))) && a1335229626 == 12)) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 12;
    	a2045918669 = 8; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((a1760493561 == 16 && ((( cf==1  && a950417444 == 10) && (input == 8)) && a1335229626 == 12))) {
    	cf = 0;
    	a1959734605 = 6;
    	a1335229626 = 6;
    	a1210809645 = 10; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((a950417444 == 10 && ((a1335229626 == 12 &&  cf==1 ) && (input == 10))) && a1760493561 == 16)) {
    	cf = 0;
    	a1510817746 = 11;
    	a1335229626 = 7;
    	a654409942 = 13; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if((a1335229626 == 12 && (a1760493561 == 16 && ((input == 1) && (a950417444 == 10 &&  cf==1 ))))) {
    	cf = 0;
    	a1335229626 = 7;
    	a1498174835 = 36 ;
    	a1510817746 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm52(int input) {
    if(( cf==1  && a1760493561 == 9)) {
    	calculate_outputm302(input);
    } 
    if((a1760493561 == 10 &&  cf==1 )) {
    	calculate_outputm303(input);
    } 
    if((a1760493561 == 11 &&  cf==1 )) {
    	calculate_outputm304(input);
    } 
    if(( cf==1  && a1760493561 == 15)) {
    	calculate_outputm307(input);
    } 
    if(( cf==1  && a1760493561 == 16)) {
    	calculate_outputm308(input);
    } 
}
 void calculate_outputm309(int input) {
    if(((input == 2) && (a950417444 == 11 && (a1335229626 == 12 && (a2135239265 == 32 &&  cf==1 ))))) {
    	cf = 0;
    	a1602107789 = 32 ;
    	a1335229626 = 6;
    	a1959734605 = 5; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a2135239265 == 32 && ((( cf==1  && a950417444 == 11) && (input == 6)) && a1335229626 == 12))) {
    	cf = 0;
    	a269427955 = 11;
    	a1335229626 = 11;
    	a1959734605 = 9; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((a2135239265 == 32 && (((input == 12) &&  cf==1 ) && a950417444 == 11)) && a1335229626 == 12)) {
    	cf = 0;
    	a1335229626 = 10;
    	a1664587146 = 35 ;
    	a880660927 = 14; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((((( cf==1  && a2135239265 == 32) && (input == 13)) && a950417444 == 11) && a1335229626 == 12)) {
    	cf = 0;
    	a1664587146 = 35 ;
    	a1335229626 = 10;
    	a880660927 = 14; 
    	 printf("%d\n", 21); fflush(stdout); 
    } 
}
 void calculate_outputm53(int input) {
    if(( cf==1  && a2135239265 == 32)) {
    	calculate_outputm309(input);
    } 
}
 void calculate_outputm314(int input) {
    if((((input == 1) && ((a1335229626 == 12 &&  cf==1 ) && a950417444 == 12)) && a1255937088 == 8)) {
    	cf = 0;
    	a1335229626 = 9;
    	a1851906186 = 33 ;
    	a1383458586 = 7; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a950417444 == 12 && (( cf==1  && a1255937088 == 8) && (input == 2))) && a1335229626 == 12)) {
    	cf = 0;
    	 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm315(int input) {
    if((((( cf==1  && (input == 3)) && a1255937088 == 10) && a1335229626 == 12) && a950417444 == 12)) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 13;
    	a1249410904 = 5; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((a1255937088 == 10 && ((a1335229626 == 12 && ( cf==1  && a950417444 == 12)) && (input == 8)))) {
    	cf = 0;
    	a1602107789 = 36 ;
    	a1335229626 = 6;
    	a1959734605 = 5; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm316(int input) {
    if((a950417444 == 12 && ((a1335229626 == 12 && ( cf==1  && (input == 3))) && a1255937088 == 11))) {
    	cf = 0;
    	a950417444 = 10;
    	a1760493561 = 11; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a1255937088 == 11 && (((a1335229626 == 12 &&  cf==1 ) && a950417444 == 12) && (input == 6)))) {
    	cf = 0;
    	a1259748523 = 33 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if(((a1255937088 == 11 && (a950417444 == 12 && ( cf==1  && a1335229626 == 12))) && (input == 10))) {
    	cf = 0;
    	a1273086420 = 35 ;
    	a1335229626 = 8;
    	a1383458586 = 7; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm317(int input) {
    if((a1335229626 == 12 && (((input == 6) && (a1255937088 == 12 &&  cf==1 )) && a950417444 == 12))) {
    	cf = 0;
    	a269427955 = 8;
    	a1335229626 = 11;
    	a1746137894 = 12; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((a1335229626 == 12 && ((( cf==1  && a950417444 == 12) && (input == 8)) && a1255937088 == 12))) {
    	cf = 0;
    	a950417444 = 10;
    	a1760493561 = 16; 
    	 printf("%d\n", 17); fflush(stdout); 
    } if((a950417444 == 12 && ((( cf==1  && (input == 10)) && a1335229626 == 12) && a1255937088 == 12))) {
    	cf = 0;
    	a1149219151 = 32 ;
    	a1851906186 = 35 ;
    	a1335229626 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a950417444 == 12 && (a1335229626 == 12 && ((input == 13) && ( cf==1  && a1255937088 == 12))))) {
    	cf = 0;
    	a1335229626 = 11;
    	a338143956 = 32 ;
    	a269427955 = 12; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm54(int input) {
    if((a1255937088 == 8 &&  cf==1 )) {
    	calculate_outputm314(input);
    } 
    if(( cf==1  && a1255937088 == 10)) {
    	calculate_outputm315(input);
    } 
    if((a1255937088 == 11 &&  cf==1 )) {
    	calculate_outputm316(input);
    } 
    if((a1255937088 == 12 &&  cf==1 )) {
    	calculate_outputm317(input);
    } 
}
 void calculate_outputm318(int input) {
    if(((a950417444 == 13 && (a962095080 == 3 && (a1335229626 == 12 &&  cf==1 ))) && (input == 3))) {
    	cf = 0;
    	a1510817746 = 10;
    	a1335229626 = 7;
    	a866603139 = 9; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a950417444 == 13 && (((input == 8) && (a962095080 == 3 &&  cf==1 )) && a1335229626 == 12))) {
    	cf = 0;
    	a1335229626 = 8;
    	a1273086420 = 36 ;
    	a864013224 = 13; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((a950417444 == 13 && ((input == 12) && (a962095080 == 3 &&  cf==1 ))) && a1335229626 == 12)) {
    	cf = 0;
    	a384913899 = 35 ;
    	a1335229626 = 5;
    	a583612627 = 13; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm319(int input) {
    if((((( cf==1  && a962095080 == 5) && a950417444 == 13) && a1335229626 == 12) && (input == 10))) {
    	cf = 0;
    	a1335229626 = 10;
    	a880660927 = 15;
    	a1736640332 = 9; 
    	 printf("%d\n", 19); fflush(stdout); 
    } if((((( cf==1  && a1335229626 == 12) && (input == 13)) && a950417444 == 13) && a962095080 == 5)) {
    	cf = 0;
    	a113972147 = 34 ;
    	a1335229626 = 11;
    	a269427955 = 10; 
    	 printf("%d\n", 19); fflush(stdout); 
    } 
}
 void calculate_outputm320(int input) {
    if(((a950417444 == 13 && (( cf==1  && (input == 2)) && a962095080 == 6)) && a1335229626 == 12)) {
    	cf = 0;
    	a880660927 = 13;
    	a1335229626 = 10;
    	a1249410904 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if(((((a1335229626 == 12 &&  cf==1 ) && a950417444 == 13) && a962095080 == 6) && (input == 8))) {
    	cf = 0;
    	 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm321(int input) {
    if(((((a962095080 == 7 &&  cf==1 ) && (input == 6)) && a950417444 == 13) && a1335229626 == 12)) {
    	cf = 0;
    	a1259748523 = 32 ;
    	a1273086420 = 34 ;
    	a1335229626 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm55(int input) {
    if((a962095080 == 3 &&  cf==1 )) {
    	calculate_outputm318(input);
    } 
    if(( cf==1  && a962095080 == 5)) {
    	calculate_outputm319(input);
    } 
    if(( cf==1  && a962095080 == 6)) {
    	calculate_outputm320(input);
    } 
    if((a962095080 == 7 &&  cf==1 )) {
    	calculate_outputm321(input);
    } 
}

 void calculate_output(int input) {
        cf = 1;

    if((a1335229626 == 5 &&  cf==1 )) {
    	if(( cf==1  && a384913899 == 32)) {
    		calculate_outputm1(input);
    	} 
    	if((a384913899 == 33 &&  cf==1 )) {
    		calculate_outputm2(input);
    	} 
    	if(( cf==1  && a384913899 == 34)) {
    		calculate_outputm3(input);
    	} 
    	if(( cf==1  && a384913899 == 35)) {
    		calculate_outputm4(input);
    	} 
    	if(( cf==1  && a384913899 == 36)) {
    		calculate_outputm5(input);
    	} 
    } 
    if(( cf==1  && a1335229626 == 6)) {
    	if((a1959734605 == 2 &&  cf==1 )) {
    		calculate_outputm6(input);
    	} 
    	if(( cf==1  && a1959734605 == 3)) {
    		calculate_outputm7(input);
    	} 
    	if((a1959734605 == 4 &&  cf==1 )) {
    		calculate_outputm8(input);
    	} 
    	if((a1959734605 == 5 &&  cf==1 )) {
    		calculate_outputm9(input);
    	} 
    	if((a1959734605 == 6 &&  cf==1 )) {
    		calculate_outputm10(input);
    	} 
    	if(( cf==1  && a1959734605 == 7)) {
    		calculate_outputm11(input);
    	} 
    	if((a1959734605 == 8 &&  cf==1 )) {
    		calculate_outputm12(input);
    	} 
    	if((a1959734605 == 9 &&  cf==1 )) {
    		calculate_outputm13(input);
    	} 
    } 
    if((a1335229626 == 7 &&  cf==1 )) {
    	if(( cf==1  && a1510817746 == 7)) {
    		calculate_outputm14(input);
    	} 
    	if(( cf==1  && a1510817746 == 8)) {
    		calculate_outputm15(input);
    	} 
    	if((a1510817746 == 9 &&  cf==1 )) {
    		calculate_outputm16(input);
    	} 
    	if((a1510817746 == 10 &&  cf==1 )) {
    		calculate_outputm17(input);
    	} 
    	if((a1510817746 == 11 &&  cf==1 )) {
    		calculate_outputm18(input);
    	} 
    	if(( cf==1  && a1510817746 == 12)) {
    		calculate_outputm19(input);
    	} 
    	if(( cf==1  && a1510817746 == 13)) {
    		calculate_outputm20(input);
    	} 
    	if((a1510817746 == 14 &&  cf==1 )) {
    		calculate_outputm21(input);
    	} 
    } 
    if(( cf==1  && a1335229626 == 8)) {
    	if(( cf==1  && a1273086420 == 32)) {
    		calculate_outputm22(input);
    	} 
    	if(( cf==1  && a1273086420 == 33)) {
    		calculate_outputm23(input);
    	} 
    	if(( cf==1  && a1273086420 == 34)) {
    		calculate_outputm24(input);
    	} 
    	if(( cf==1  && a1273086420 == 35)) {
    		calculate_outputm25(input);
    	} 
    	if(( cf==1  && a1273086420 == 36)) {
    		calculate_outputm26(input);
    	} 
    } 
    if((a1335229626 == 9 &&  cf==1 )) {
    	if((a1851906186 == 32 &&  cf==1 )) {
    		calculate_outputm27(input);
    	} 
    	if((a1851906186 == 33 &&  cf==1 )) {
    		calculate_outputm28(input);
    	} 
    	if((a1851906186 == 34 &&  cf==1 )) {
    		calculate_outputm29(input);
    	} 
    	if(( cf==1  && a1851906186 == 35)) {
    		calculate_outputm30(input);
    	} 
    	if(( cf==1  && a1851906186 == 36)) {
    		calculate_outputm31(input);
    	} 
    } 
    if((a1335229626 == 10 &&  cf==1 )) {
    	if((a880660927 == 9 &&  cf==1 )) {
    		calculate_outputm32(input);
    	} 
    	if((a880660927 == 10 &&  cf==1 )) {
    		calculate_outputm33(input);
    	} 
    	if((a880660927 == 11 &&  cf==1 )) {
    		calculate_outputm34(input);
    	} 
    	if(( cf==1  && a880660927 == 12)) {
    		calculate_outputm35(input);
    	} 
    	if((a880660927 == 13 &&  cf==1 )) {
    		calculate_outputm36(input);
    	} 
    	if((a880660927 == 14 &&  cf==1 )) {
    		calculate_outputm37(input);
    	} 
    	if((a880660927 == 15 &&  cf==1 )) {
    		calculate_outputm38(input);
    	} 
    	if(( cf==1  && a880660927 == 16)) {
    		calculate_outputm39(input);
    	} 
    } 
    if((a1335229626 == 11 &&  cf==1 )) {
    	if(( cf==1  && a269427955 == 8)) {
    		calculate_outputm41(input);
    	} 
    	if(( cf==1  && a269427955 == 9)) {
    		calculate_outputm42(input);
    	} 
    	if(( cf==1  && a269427955 == 10)) {
    		calculate_outputm43(input);
    	} 
    	if(( cf==1  && a269427955 == 11)) {
    		calculate_outputm44(input);
    	} 
    	if(( cf==1  && a269427955 == 12)) {
    		calculate_outputm45(input);
    	} 
    	if((a269427955 == 13 &&  cf==1 )) {
    		calculate_outputm46(input);
    	} 
    	if((a269427955 == 14 &&  cf==1 )) {
    		calculate_outputm47(input);
    	} 
    } 
    if((a1335229626 == 12 &&  cf==1 )) {
    	if(( cf==1  && a950417444 == 6)) {
    		calculate_outputm48(input);
    	} 
    	if((a950417444 == 7 &&  cf==1 )) {
    		calculate_outputm49(input);
    	} 
    	if(( cf==1  && a950417444 == 8)) {
    		calculate_outputm50(input);
    	} 
    	if(( cf==1  && a950417444 == 9)) {
    		calculate_outputm51(input);
    	} 
    	if(( cf==1  && a950417444 == 10)) {
    		calculate_outputm52(input);
    	} 
    	if((a950417444 == 11 &&  cf==1 )) {
    		calculate_outputm53(input);
    	} 
    	if(( cf==1  && a950417444 == 12)) {
    		calculate_outputm54(input);
    	} 
    	if((a950417444 == 13 &&  cf==1 )) {
    		calculate_outputm55(input);
    	} 
    } 
    errorCheck();

    if( cf==1 ) 
    	fprintf(stderr, "Invalid input: %d\n", input); 
}

int main()
{
    // main i/o-loop
    while(1)
    {
        // read input
		int input = 0;
		int ret = scanf("%d", &input);
		if (ret != 1) return 0;        
        // operate eca engine
        if((input != 7) && (input != 2) && (input != 10) && (input != 15) && (input != 5) && (input != 4) && (input != 6) && (input != 11) && (input != 9) && (input != 1) && (input != 12) && (input != 8) && (input != 3) && (input != 14) && (input != 13))
          return -2;
        calculate_output(input);
    }
}