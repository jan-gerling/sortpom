#include <stdio.h> 
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <klee/klee.h>

void __VERIFIER_error(int i) {
    fprintf(stderr, "error_%d ", i);
    assert(0);
}
	// inputs
	int inputs[] = {5,3,8,9,6,7,2,4,10,1};

	void errorCheck();
	void calculate_output(int);
	void calculate_outputm1(int);
	void calculate_outputm2(int);
	void calculate_outputm3(int);
	void calculate_outputm4(int);
	void calculate_outputm5(int);
	void calculate_outputm6(int);
	void calculate_outputm7(int);
	void calculate_outputm8(int);
	void calculate_outputm9(int);
	void calculate_outputm10(int);
	void calculate_outputm11(int);
	void calculate_outputm12(int);
	void calculate_outputm13(int);
	void calculate_outputm14(int);
	void calculate_outputm15(int);
	void calculate_outputm16(int);
	void calculate_outputm17(int);
	void calculate_outputm18(int);
	void calculate_outputm19(int);
	void calculate_outputm20(int);
	void calculate_outputm21(int);
	void calculate_outputm22(int);
	void calculate_outputm23(int);
	void calculate_outputm24(int);
	void calculate_outputm25(int);
	void calculate_outputm26(int);
	void calculate_outputm27(int);
	void calculate_outputm28(int);
	void calculate_outputm29(int);
	void calculate_outputm30(int);
	void calculate_outputm31(int);
	void calculate_outputm32(int);
	void calculate_outputm33(int);
	void calculate_outputm34(int);
	void calculate_outputm35(int);
	void calculate_outputm36(int);
	void calculate_outputm37(int);
	void calculate_outputm38(int);
	void calculate_outputm39(int);
	void calculate_outputm40(int);
	void calculate_outputm41(int);
	void calculate_outputm42(int);
	void calculate_outputm43(int);
	void calculate_outputm44(int);
	void calculate_outputm45(int);
	void calculate_outputm46(int);
	void calculate_outputm47(int);
	void calculate_outputm48(int);
	void calculate_outputm49(int);
	void calculate_outputm50(int);
	void calculate_outputm51(int);
	void calculate_outputm52(int);
	void calculate_outputm53(int);
	void calculate_outputm54(int);
	void calculate_outputm55(int);
	void calculate_outputm56(int);
	void calculate_outputm57(int);
	void calculate_outputm58(int);
	void calculate_outputm59(int);
	void calculate_outputm60(int);
	void calculate_outputm61(int);
	void calculate_outputm62(int);
	void calculate_outputm63(int);
	void calculate_outputm64(int);
	void calculate_outputm65(int);
	void calculate_outputm66(int);
	void calculate_outputm67(int);
	void calculate_outputm68(int);
	void calculate_outputm69(int);
	void calculate_outputm70(int);
	void calculate_outputm71(int);
	void calculate_outputm72(int);
	void calculate_outputm73(int);
	void calculate_outputm74(int);
	void calculate_outputm75(int);
	void calculate_outputm76(int);
	void calculate_outputm77(int);
	void calculate_outputm78(int);
	void calculate_outputm79(int);
	void calculate_outputm80(int);
	void calculate_outputm81(int);
	void calculate_outputm82(int);
	void calculate_outputm83(int);
	void calculate_outputm84(int);
	void calculate_outputm85(int);
	void calculate_outputm86(int);
	void calculate_outputm87(int);
	void calculate_outputm88(int);
	void calculate_outputm89(int);
	void calculate_outputm90(int);
	void calculate_outputm91(int);
	void calculate_outputm92(int);
	void calculate_outputm93(int);
	void calculate_outputm94(int);
	void calculate_outputm95(int);
	void calculate_outputm96(int);
	void calculate_outputm97(int);
	void calculate_outputm98(int);
	void calculate_outputm99(int);
	void calculate_outputm100(int);
	void calculate_outputm101(int);
	void calculate_outputm102(int);
	void calculate_outputm103(int);
	void calculate_outputm104(int);
	void calculate_outputm105(int);
	void calculate_outputm106(int);
	void calculate_outputm107(int);
	void calculate_outputm108(int);
	void calculate_outputm109(int);
	void calculate_outputm110(int);
	void calculate_outputm111(int);
	void calculate_outputm112(int);
	void calculate_outputm113(int);
	void calculate_outputm114(int);
	void calculate_outputm115(int);
	void calculate_outputm116(int);
	void calculate_outputm117(int);
	void calculate_outputm118(int);
	void calculate_outputm119(int);
	void calculate_outputm120(int);
	void calculate_outputm121(int);
	void calculate_outputm122(int);
	void calculate_outputm123(int);
	void calculate_outputm124(int);
	void calculate_outputm125(int);
	void calculate_outputm126(int);
	void calculate_outputm127(int);
	void calculate_outputm128(int);
	void calculate_outputm129(int);
	void calculate_outputm130(int);
	void calculate_outputm131(int);
	void calculate_outputm132(int);
	void calculate_outputm133(int);
	void calculate_outputm134(int);
	void calculate_outputm135(int);
	void calculate_outputm136(int);
	void calculate_outputm137(int);
	void calculate_outputm138(int);
	void calculate_outputm139(int);
	void calculate_outputm140(int);
	void calculate_outputm141(int);
	void calculate_outputm142(int);
	void calculate_outputm143(int);
	void calculate_outputm144(int);
	void calculate_outputm145(int);
	void calculate_outputm146(int);
	void calculate_outputm147(int);
	void calculate_outputm148(int);
	void calculate_outputm149(int);

	 int a1807599127  = 35;
	 int a1129397725  = 35;
	 int a1728472415 = 10;
	 int a1514301173  = 34;
	 int a1240478154 = 15;
	 int a1241946815 = 11;
	 int a363016538  = 36;
	 int a2099614420 = 10;
	 int a1334900752  = 32;
	 int a856341416  = 34;
	 int a2014936070  = 33;
	 int a1488095747 = 12;
	 int a1618049448  = 34;
	 int a1586444362 = 1;
	 int a1880323056  = 32;
	 int a1725246725  = 35;
	 int a350412290  = 33;
	 int a1975051863  = 35;
	 int a535900205 = 6;
	 int cf = 1;
	 int a1837354890 = 17;
	 int a688344934 = 6;
	 int a1429043309  = 36;
	 int a1154495715 = 10;
	 int a516636747  = 34;


	void errorCheck() {
	    if(((a1129397725 == 33 && a535900205 == 4) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(0);
	    }
	    if(((a2099614420 == 7 && a535900205 == 9) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(1);
	    }
	    if(((a1618049448 == 34 && a535900205 == 7) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(2);
	    }
	    if(((a1837354890 == 16 && a363016538 == 33) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(3);
	    }
	    if(((a1837354890 == 13 && a535900205 == 10) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(4);
	    }
	    if(((a1240478154 == 13 && a1334900752 == 36) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(5);
	    }
	    if(((a1154495715 == 11 && a363016538 == 35) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(6);
	    }
	    if(((a1837354890 == 14 && a363016538 == 33) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(7);
	    }
	    if(((a1154495715 == 10 && a363016538 == 35) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(8);
	    }
	    if(((a688344934 == 6 && a516636747 == 32) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(9);
	    }
	    if(((a1429043309 == 35 && a535900205 == 6) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(10);
	    }
	    if(((a2099614420 == 14 && a363016538 == 34) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(11);
	    }
	    if(((a688344934 == 10 && a363016538 == 32) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(12);
	    }
	    if(((a2099614420 == 8 && a363016538 == 34) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(13);
	    }
	    if(((a1241946815 == 12 && a535900205 == 3) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(14);
	    }
	    if(((a1240478154 == 16 && a363016538 == 33) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(15);
	    }
	    if(((a1725246725 == 32 && a1334900752 == 35) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(16);
	    }
	    if(((a1880323056 == 36 && a1334900752 == 34) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(17);
	    }
	    if(((a1129397725 == 36 && a535900205 == 4) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(18);
	    }
	    if(((a1488095747 == 11 && a535900205 == 5) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(19);
	    }
	    if(((a688344934 == 8 && a516636747 == 32) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(20);
	    }
	    if(((a1240478154 == 12 && a363016538 == 33) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(21);
	    }
	    if(((a1837354890 == 16 && a535900205 == 10) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(22);
	    }
	    if(((a1129397725 == 35 && a535900205 == 4) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(23);
	    }
	    if(((a1807599127 == 34 && a363016538 == 36) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(24);
	    }
	    if(((a1586444362 == 7 && a363016538 == 32) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(25);
	    }
	    if(((a1514301173 == 36 && a363016538 == 36) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(26);
	    }
	    if(((a1837354890 == 11 && a363016538 == 33) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(27);
	    }
	    if(((a1240478154 == 11 && a363016538 == 33) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(28);
	    }
	    if(((a1154495715 == 13 && a363016538 == 35) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(29);
	    }
	    if(((a1728472415 == 12 && a363016538 == 35) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(30);
	    }
	    if(((a1837354890 == 17 && a363016538 == 33) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(31);
	    }
	    if(((a688344934 == 9 && a363016538 == 32) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(32);
	    }
	    if(((a1728472415 == 16 && a363016538 == 35) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(33);
	    }
	    if(((a363016538 == 32 && a1334900752 == 33) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(34);
	    }
	    if(((a1618049448 == 35 && a535900205 == 7) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(35);
	    }
	    if(((a2099614420 == 13 && a363016538 == 34) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(36);
	    }
	    if(((a1241946815 == 14 && a516636747 == 33) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(37);
	    }
	    if(((a1241946815 == 7 && a516636747 == 33) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(38);
	    }
	    if(((a1586444362 == 6 && a516636747 == 36) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(39);
	    }
	    if(((a350412290 == 36 && a1334900752 == 32) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(40);
	    }
	    if(((a1807599127 == 35 && a535900205 == 8) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(41);
	    }
	    if(((a688344934 == 9 && a516636747 == 32) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(42);
	    }
	    if(((a1807599127 == 33 && a535900205 == 8) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(43);
	    }
	    if(((a1807599127 == 35 && a363016538 == 36) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(44);
	    }
	    if(((a1807599127 == 36 && a535900205 == 8) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(45);
	    }
	    if(((a1837354890 == 17 && a535900205 == 10) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(46);
	    }
	    if(((a1618049448 == 36 && a535900205 == 7) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(47);
	    }
	    if(((a1586444362 == 4 && a363016538 == 32) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(48);
	    }
	    if(((a1975051863 == 33 && a363016538 == 34) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(49);
	    }
	    if(((a1240478154 == 12 && a1334900752 == 36) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(50);
	    }
	    if(((a1618049448 == 33 && a535900205 == 7) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(51);
	    }
	    if(((a1241946815 == 10 && a516636747 == 33) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(52);
	    }
	    if(((a1586444362 == 4 && a516636747 == 36) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(53);
	    }
	    if(((a1837354890 == 10 && a363016538 == 33) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(54);
	    }
	    if(((a688344934 == 6 && a363016538 == 32) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(55);
	    }
	    if(((a1807599127 == 34 && a535900205 == 8) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(56);
	    }
	    if(((a1728472415 == 13 && a516636747 == 34) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(57);
	    }
	    if(((a2099614420 == 9 && a363016538 == 34) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(58);
	    }
	    if(((a1241946815 == 11 && a516636747 == 33) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(59);
	    }
	    if(((a1241946815 == 11 && a535900205 == 3) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(60);
	    }
	    if(((a2099614420 == 12 && a363016538 == 34) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(61);
	    }
	    if(((a1241946815 == 10 && a535900205 == 3) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(62);
	    }
	    if(((a1586444362 == 3 && a516636747 == 36) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(63);
	    }
	    if(((a1728472415 == 14 && a516636747 == 34) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(64);
	    }
	    if(((a1725246725 == 35 && a1334900752 == 35) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(65);
	    }
	    if(((a1837354890 == 11 && a535900205 == 10) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(66);
	    }
	    if(((a1728472415 == 13 && a363016538 == 35) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(67);
	    }
	    if(((a1728472415 == 10 && a363016538 == 35) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(68);
	    }
	    if(((a1728472415 == 15 && a363016538 == 35) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(69);
	    }
	    if(((a2099614420 == 12 && a535900205 == 9) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(70);
	    }
	    if(((a363016538 == 36 && a1334900752 == 33) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(71);
	    }
	    if(((a363016538 == 35 && a1334900752 == 33) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(72);
	    }
	    if(((a1514301173 == 32 && a363016538 == 36) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(73);
	    }
	    if(((a1240478154 == 16 && a1334900752 == 36) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(74);
	    }
	    if(((a2099614420 == 9 && a535900205 == 9) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(75);
	    }
	    if(((a1514301173 == 33 && a363016538 == 36) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(76);
	    }
	    if(((a2099614420 == 8 && a535900205 == 9) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(77);
	    }
	    if(((a1586444362 == 1 && a363016538 == 32) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(78);
	    }
	    if(((a1241946815 == 13 && a535900205 == 3) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(79);
	    }
	    if(((a1240478154 == 9 && a363016538 == 33) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(80);
	    }
	    if(((a1514301173 == 34 && a363016538 == 36) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(81);
	    }
	    if(((a1837354890 == 15 && a535900205 == 10) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(82);
	    }
	    if(((a1837354890 == 13 && a363016538 == 33) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(83);
	    }
	    if(((a1837354890 == 14 && a535900205 == 10) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(84);
	    }
	    if(((a1240478154 == 15 && a1334900752 == 36) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(85);
	    }
	    if(((a1725246725 == 36 && a1334900752 == 35) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(86);
	    }
	    if(((a1241946815 == 8 && a516636747 == 33) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(87);
	    }
	    if(((a688344934 == 5 && a516636747 == 32) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(88);
	    }
	    if(((a1837354890 == 12 && a535900205 == 10) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(89);
	    }
	    if(((a1488095747 == 9 && a535900205 == 5) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(90);
	    }
	    if(((a1429043309 == 34 && a535900205 == 6) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(91);
	    }
	    if(((a1728472415 == 16 && a516636747 == 34) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(92);
	    }
	    if(((a1880323056 == 35 && a1334900752 == 34) && a856341416 == 32)){
	    cf = 0;
	    __VERIFIER_error(93);
	    }
	    if(((a688344934 == 7 && a363016538 == 32) && a856341416 == 36)){
	    cf = 0;
	    __VERIFIER_error(94);
	    }
	    if(((a2014936070 == 35 && a516636747 == 35) && a856341416 == 34)){
	    cf = 0;
	    __VERIFIER_error(95);
	    }
	    if(((a1586444362 == 5 && a363016538 == 32) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(96);
	    }
	    if(((a1488095747 == 6 && a535900205 == 5) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(97);
	    }
	    if(((a1241946815 == 14 && a535900205 == 3) && a856341416 == 33)){
	    cf = 0;
	    __VERIFIER_error(98);
	    }
	    if(((a1586444362 == 2 && a363016538 == 32) && a856341416 == 35)){
	    cf = 0;
	    __VERIFIER_error(99);
	    }
	}
 void calculate_outputm31(int input) {
    if((a363016538 == 34 && ((input == 6) && (a1334900752 == 33 && (a856341416 == 32 &&  cf==1 ))))) {
    	cf = 0;
    	a856341416 = 34 ;
    	a516636747 = 35 ;
    	a2014936070 = 32 ; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((a1334900752 == 33 && ( cf==1  && a856341416 == 32)) && (input == 8)) && a363016538 == 34)) {
    	cf = 0;
    	a516636747 = 32 ;
    	a856341416 = 34 ;
    	a688344934 = 5; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm2(int input) {
    if(( cf==1  && a363016538 == 34)) {
    	calculate_outputm31(input);
    } 
}
 void calculate_outputm34(int input) {
    if(((a856341416 == 32 && (a1880323056 == 32 && (a1334900752 == 34 &&  cf==1 ))) && (input == 5))) {
    	cf = 0;
    	a363016538 = 35 ;
    	a856341416 = 35 ;
    	a1728472415 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a1880323056 == 32 && (((input == 7) && (a1334900752 == 34 &&  cf==1 )) && a856341416 == 32))) {
    	cf = 0;
    	a516636747 = 35 ;
    	a856341416 = 34 ;
    	a2014936070 = 32 ; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((a1334900752 == 34 && (a856341416 == 32 && (( cf==1  && (input == 9)) && a1880323056 == 32)))) {
    	cf = 0;
    	 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1880323056 == 32 && (a1334900752 == 34 && (a856341416 == 32 && ( cf==1  && (input == 1)))))) {
    	cf = 0;
    	a1618049448 = 33 ;
    	a856341416 = 33 ;
    	a535900205 = 7; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm3(int input) {
    if((a1880323056 == 32 &&  cf==1 )) {
    	calculate_outputm34(input);
    } 
}
 void calculate_outputm49(int input) {
    if((a535900205 == 4 && (a1129397725 == 32 && (a856341416 == 33 && ((input == 9) &&  cf==1 ))))) {
    	cf = 0;
    	a363016538 = 34 ;
    	a856341416 = 35 ;
    	a1975051863 = 35 ; 
    	 printf("%d\n", 25); fflush(stdout); 
    } if((a1129397725 == 32 && (a856341416 == 33 && (( cf==1  && a535900205 == 4) && (input == 6))))) {
    	cf = 0;
    	a535900205 = 10;
    	a1837354890 = 17; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm7(int input) {
    if((a1129397725 == 32 &&  cf==1 )) {
    	calculate_outputm49(input);
    } 
}
 void calculate_outputm56(int input) {
    if((((( cf==1  && a535900205 == 6) && (input == 6)) && a856341416 == 33) && a1429043309 == 33)) {
    	cf = 0;
    	 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a535900205 == 6 && (( cf==1  && (input == 7)) && a856341416 == 33)) && a1429043309 == 33)) {
    	cf = 0;
    	a856341416 = 35 ;
    	a363016538 = 32 ;
    	a1586444362 = 7; 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm9(int input) {
    if(( cf==1  && a1429043309 == 33)) {
    	calculate_outputm56(input);
    } 
}
 void calculate_outputm59(int input) {
    if((((input == 6) && ((a535900205 == 7 &&  cf==1 ) && a1618049448 == 32)) && a856341416 == 33)) {
    	cf = 0;
    	a856341416 = 35 ;
    	a363016538 = 35 ;
    	a1728472415 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a535900205 == 7 && (( cf==1  && a1618049448 == 32) && (input == 9))) && a856341416 == 33)) {
    	cf = 0;
    	a856341416 = 34 ;
    	a516636747 = 32 ;
    	a688344934 = 12; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a535900205 == 7 && ((input == 1) && (( cf==1  && a1618049448 == 32) && a856341416 == 33)))) {
    	cf = 0;
    	a856341416 = 36 ;
    	a363016538 = 33 ;
    	a1240478154 = 12; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm10(int input) {
    if(( cf==1  && a1618049448 == 32)) {
    	calculate_outputm59(input);
    } 
}
 void calculate_outputm71(int input) {
    if(((((input == 7) && ( cf==1  && a2099614420 == 11)) && a535900205 == 9) && a856341416 == 33)) {
    	cf = 0;
    	a1429043309 = 33 ;
    	a535900205 = 6; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((( cf==1  && a535900205 == 9) && a856341416 == 33) && a2099614420 == 11) && (input == 9))) {
    	cf = 0;
    	a1334900752 = 34 ;
    	a856341416 = 32 ;
    	a1880323056 = 32 ; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a535900205 == 9 && ( cf==1  && a2099614420 == 11)) && (input == 4)) && a856341416 == 33)) {
    	cf = 0;
    	a535900205 = 3;
    	a1241946815 = 11; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm12(int input) {
    if((a2099614420 == 11 &&  cf==1 )) {
    	calculate_outputm71(input);
    } 
}
 void calculate_outputm84(int input) {
    if((a856341416 == 34 && ((input == 1) && (a688344934 == 12 && ( cf==1  && a516636747 == 32))))) {
    	cf = 0;
    	a363016538 = 35 ;
    	a856341416 = 36 ;
    	a1154495715 = 14; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((input == 7) && ((( cf==1  && a856341416 == 34) && a688344934 == 12) && a516636747 == 32))) {
    	cf = 0;
    	a516636747 = 36 ;
    	a1586444362 = 6; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm14(int input) {
    if((a688344934 == 12 &&  cf==1 )) {
    	calculate_outputm84(input);
    } 
}
 void calculate_outputm89(int input) {
    if((a516636747 == 33 && (a856341416 == 34 && (a1241946815 == 12 && ((input == 2) &&  cf==1 ))))) {
    	cf = 0;
    	a516636747 = 36 ;
    	a1586444362 = 2; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((a516636747 == 33 && ((input == 10) && ((a1241946815 == 12 &&  cf==1 ) && a856341416 == 34)))) {
    	cf = 0;
    	a856341416 = 33 ;
    	a535900205 = 10;
    	a1837354890 = 14; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm15(int input) {
    if(( cf==1  && a1241946815 == 12)) {
    	calculate_outputm89(input);
    } 
}
 void calculate_outputm91(int input) {
    if((a1728472415 == 10 && (a516636747 == 34 && (a856341416 == 34 && ((input == 3) &&  cf==1 ))))) {
    	cf = 0;
    	a516636747 = 33 ;
    	a1241946815 = 12; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a516636747 == 34 && ((a1728472415 == 10 && ((input == 4) &&  cf==1 )) && a856341416 == 34))) {
    	cf = 0;
    	a1334900752 = 33 ;
    	a856341416 = 32 ;
    	a363016538 = 34 ; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm92(int input) {
    if((a516636747 == 34 && (a1728472415 == 11 && (a856341416 == 34 && ((input == 10) &&  cf==1 ))))) {
    	cf = 0;
    	a363016538 = 33 ;
    	a856341416 = 36 ;
    	a1240478154 = 15; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a1728472415 == 11 && (a516636747 == 34 && (( cf==1  && (input == 8)) && a856341416 == 34)))) {
    	cf = 0;
    	a516636747 = 33 ;
    	a1241946815 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm16(int input) {
    if((a1728472415 == 10 &&  cf==1 )) {
    	calculate_outputm91(input);
    } 
    if(( cf==1  && a1728472415 == 11)) {
    	calculate_outputm92(input);
    } 
}
 void calculate_outputm96(int input) {
    if(((a2014936070 == 32 && (( cf==1  && a516636747 == 35) && (input == 5))) && a856341416 == 34)) {
    	cf = 0;
    	a1129397725 = 32 ;
    	a856341416 = 33 ;
    	a535900205 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if((a2014936070 == 32 && (((input == 7) && ( cf==1  && a516636747 == 35)) && a856341416 == 34))) {
    	cf = 0;
    	a856341416 = 33 ;
    	a535900205 = 9;
    	a2099614420 = 11; 
    	 printf("%d\n", 16); fflush(stdout); 
    } if(((a516636747 == 35 && (( cf==1  && a856341416 == 34) && (input == 10))) && a2014936070 == 32)) {
    	cf = 0;
    	a1334900752 = 34 ;
    	a856341416 = 32 ;
    	a1880323056 = 35 ; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm17(int input) {
    if(( cf==1  && a2014936070 == 32)) {
    	calculate_outputm96(input);
    } 
}
 void calculate_outputm98(int input) {
    if(((((a516636747 == 36 &&  cf==1 ) && (input == 1)) && a856341416 == 34) && a1586444362 == 2)) {
    	cf = 0;
    	a856341416 = 36 ;
    	a363016538 = 33 ;
    	a1240478154 = 15; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((((a856341416 == 34 && (a516636747 == 36 &&  cf==1 )) && a1586444362 == 2) && (input == 3))) {
    	cf = 0;
    	a856341416 = 33 ;
    	a1618049448 = 32 ;
    	a535900205 = 7; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a1586444362 == 2 && (((input == 9) && (a856341416 == 34 &&  cf==1 )) && a516636747 == 36))) {
    	cf = 0;
    	a1586444362 = 7; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if((a1586444362 == 2 && ((a856341416 == 34 && ( cf==1  && (input == 10))) && a516636747 == 36))) {
    	cf = 0;
    	a516636747 = 34 ;
    	a1728472415 = 14; 
    	 printf("%d\n", 16); fflush(stdout); 
    } 
}
 void calculate_outputm102(int input) {
    if((((input == 3) && (( cf==1  && a856341416 == 34) && a1586444362 == 7)) && a516636747 == 36)) {
    	cf = 0;
    	a363016538 = 32 ;
    	a856341416 = 35 ;
    	a1586444362 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((((input == 2) &&  cf==1 ) && a1586444362 == 7) && a516636747 == 36) && a856341416 == 34)) {
    	cf = 0;
    	a1334900752 = 35 ;
    	a856341416 = 32 ;
    	a1725246725 = 32 ; 
    	 printf("%d\n", 23); fflush(stdout); 
    } 
}
 void calculate_outputm18(int input) {
    if((a1586444362 == 2 &&  cf==1 )) {
    	calculate_outputm98(input);
    } 
    if(( cf==1  && a1586444362 == 7)) {
    	calculate_outputm102(input);
    } 
}
 void calculate_outputm105(int input) {
    if(((((a856341416 == 35 &&  cf==1 ) && a1586444362 == 3) && (input == 1)) && a363016538 == 32)) {
    	cf = 0;
    	 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a856341416 == 35 && ((input == 2) && (a1586444362 == 3 && ( cf==1  && a363016538 == 32))))) {
    	cf = 0;
    	a856341416 = 36 ;
    	a688344934 = 8; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((((a856341416 == 35 &&  cf==1 ) && a1586444362 == 3) && (input == 3)) && a363016538 == 32)) {
    	cf = 0;
    	a856341416 = 36 ;
    	a363016538 = 34 ;
    	a2099614420 = 12; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm19(int input) {
    if(( cf==1  && a1586444362 == 3)) {
    	calculate_outputm105(input);
    } 
}
 void calculate_outputm115(int input) {
    if(((input == 8) && ((( cf==1  && a1975051863 == 32) && a856341416 == 35) && a363016538 == 34))) {
    	cf = 0;
    	a363016538 = 32 ;
    	a1586444362 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((((a1975051863 == 32 && ((input == 1) &&  cf==1 )) && a363016538 == 34) && a856341416 == 35)) {
    	cf = 0;
    	a856341416 = 33 ;
    	a535900205 = 9;
    	a2099614420 = 9; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm117(int input) {
    if((((( cf==1  && (input == 2)) && a363016538 == 34) && a1975051863 == 35) && a856341416 == 35)) {
    	cf = 0;
    	a1129397725 = 32 ;
    	a856341416 = 33 ;
    	a535900205 = 4; 
    	 printf("%d\n", 22); fflush(stdout); 
    } if(((a363016538 == 34 && ((a856341416 == 35 &&  cf==1 ) && a1975051863 == 35)) && (input == 5))) {
    	cf = 0;
    	a516636747 = 32 ;
    	a856341416 = 34 ;
    	a688344934 = 8; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm21(int input) {
    if(( cf==1  && a1975051863 == 32)) {
    	calculate_outputm115(input);
    } 
    if(( cf==1  && a1975051863 == 35)) {
    	calculate_outputm117(input);
    } 
}
 void calculate_outputm119(int input) {
    if(((((input == 3) && ( cf==1  && a856341416 == 35)) && a363016538 == 35) && a1728472415 == 11)) {
    	cf = 0;
    	a856341416 = 34 ;
    	a516636747 = 36 ;
    	a1586444362 = 2; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if((((( cf==1  && a856341416 == 35) && a1728472415 == 11) && (input == 4)) && a363016538 == 35)) {
    	cf = 0;
    	a363016538 = 32 ;
    	a1586444362 = 3; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if(((((input == 5) && ( cf==1  && a363016538 == 35)) && a1728472415 == 11) && a856341416 == 35)) {
    	cf = 0;
    	a363016538 = 34 ;
    	a1975051863 = 32 ; 
    	 printf("%d\n", 26); fflush(stdout); 
    } if(((input == 6) && (a1728472415 == 11 && (( cf==1  && a856341416 == 35) && a363016538 == 35)))) {
    	cf = 0;
    	a856341416 = 32 ;
    	a1334900752 = 36 ;
    	a1240478154 = 12; 
    	 printf("%d\n", 18); fflush(stdout); 
    } 
}
 void calculate_outputm22(int input) {
    if(( cf==1  && a1728472415 == 11)) {
    	calculate_outputm119(input);
    } 
}
 void calculate_outputm128(int input) {
    if((a688344934 == 8 && ((a856341416 == 36 && ((input == 2) &&  cf==1 )) && a363016538 == 32))) {
    	cf = 0;
    	a856341416 = 35 ;
    	a363016538 = 34 ;
    	a1975051863 = 32 ; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if((((a363016538 == 32 && ((input == 7) &&  cf==1 )) && a856341416 == 36) && a688344934 == 8)) {
    	cf = 0;
    	a688344934 = 11; 
    	 printf("%d\n", 23); fflush(stdout); 
    } if((a688344934 == 8 && (a856341416 == 36 && (( cf==1  && (input == 10)) && a363016538 == 32)))) {
    	cf = 0;
    	a856341416 = 33 ;
    	a1807599127 = 36 ;
    	a535900205 = 8; 
    	 printf("%d\n", 20); fflush(stdout); 
    } 
}
 void calculate_outputm131(int input) {
    if(((input == 7) && (a688344934 == 11 && ((a363016538 == 32 &&  cf==1 ) && a856341416 == 36)))) {
    	cf = 0;
    	a856341416 = 35 ;
    	a1586444362 = 3; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((a856341416 == 36 && (a363016538 == 32 && ((input == 10) && ( cf==1  && a688344934 == 11))))) {
    	cf = 0;
    	a856341416 = 34 ;
    	a516636747 = 36 ;
    	a1586444362 = 2; 
    	 printf("%d\n", 20); fflush(stdout); 
    } if(((input == 6) && (((a856341416 == 36 &&  cf==1 ) && a363016538 == 32) && a688344934 == 11))) {
    	cf = 0;
    	a363016538 = 35 ;
    	a1154495715 = 10; 
    	 printf("%d\n", 24); fflush(stdout); 
    } 
}
 void calculate_outputm24(int input) {
    if((a688344934 == 8 &&  cf==1 )) {
    	calculate_outputm128(input);
    } 
    if((a688344934 == 11 &&  cf==1 )) {
    	calculate_outputm131(input);
    } 
}
 void calculate_outputm135(int input) {
    if((a856341416 == 36 && ((a363016538 == 33 && ( cf==1  && (input == 6))) && a1240478154 == 15))) {
    	cf = 0;
    	a516636747 = 34 ;
    	a856341416 = 34 ;
    	a1728472415 = 11; 
    	 printf("%d\n", 18); fflush(stdout); 
    } if(((((input == 8) && ( cf==1  && a363016538 == 33)) && a856341416 == 36) && a1240478154 == 15)) {
    	cf = 0;
    	a856341416 = 35 ;
    	a1837354890 = 16; 
    	 printf("%d\n", 22); fflush(stdout); 
    } 
}
 void calculate_outputm25(int input) {
    if((a1240478154 == 15 &&  cf==1 )) {
    	calculate_outputm135(input);
    } 
}
 void calculate_outputm145(int input) {
    if((a856341416 == 36 && (((input == 1) && (a1154495715 == 14 &&  cf==1 )) && a363016538 == 35))) {
    	cf = 0;
    	a856341416 = 35 ;
    	a1728472415 = 11; 
    	 printf("%d\n", 24); fflush(stdout); 
    } if((((input == 2) && (a363016538 == 35 && (a1154495715 == 14 &&  cf==1 ))) && a856341416 == 36)) {
    	cf = 0;
    	 
    	 printf("%d\n", 19); fflush(stdout); 
    } if(((a1154495715 == 14 && (( cf==1  && (input == 5)) && a856341416 == 36)) && a363016538 == 35)) {
    	cf = 0;
    	a363016538 = 33 ;
    	a1240478154 = 15; 
    	 printf("%d\n", 21); fflush(stdout); 
    } if((a856341416 == 36 && (a1154495715 == 14 && (a363016538 == 35 && ((input == 8) &&  cf==1 ))))) {
    	cf = 0;
    	a856341416 = 33 ;
    	a1129397725 = 36 ;
    	a535900205 = 4; 
    	 printf("%d\n", 26); fflush(stdout); 
    } 
}
 void calculate_outputm27(int input) {
    if(( cf==1  && a1154495715 == 14)) {
    	calculate_outputm145(input);
    } 
}

 void calculate_output(int input) {
        cf = 1;

    if(( cf==1  && a856341416 == 32)) {
    	if((a1334900752 == 33 &&  cf==1 )) {
    		calculate_outputm2(input);
    	} 
    	if(( cf==1  && a1334900752 == 34)) {
    		calculate_outputm3(input);
    	} 
    } 
    if(( cf==1  && a856341416 == 33)) {
    	if(( cf==1  && a535900205 == 4)) {
    		calculate_outputm7(input);
    	} 
    	if((a535900205 == 6 &&  cf==1 )) {
    		calculate_outputm9(input);
    	} 
    	if(( cf==1  && a535900205 == 7)) {
    		calculate_outputm10(input);
    	} 
    	if(( cf==1  && a535900205 == 9)) {
    		calculate_outputm12(input);
    	} 
    } 
    if(( cf==1  && a856341416 == 34)) {
    	if((a516636747 == 32 &&  cf==1 )) {
    		calculate_outputm14(input);
    	} 
    	if(( cf==1  && a516636747 == 33)) {
    		calculate_outputm15(input);
    	} 
    	if((a516636747 == 34 &&  cf==1 )) {
    		calculate_outputm16(input);
    	} 
    	if((a516636747 == 35 &&  cf==1 )) {
    		calculate_outputm17(input);
    	} 
    	if((a516636747 == 36 &&  cf==1 )) {
    		calculate_outputm18(input);
    	} 
    } 
    if((a856341416 == 35 &&  cf==1 )) {
    	if((a363016538 == 32 &&  cf==1 )) {
    		calculate_outputm19(input);
    	} 
    	if(( cf==1  && a363016538 == 34)) {
    		calculate_outputm21(input);
    	} 
    	if(( cf==1  && a363016538 == 35)) {
    		calculate_outputm22(input);
    	} 
    } 
    if((a856341416 == 36 &&  cf==1 )) {
    	if((a363016538 == 32 &&  cf==1 )) {
    		calculate_outputm24(input);
    	} 
    	if(( cf==1  && a363016538 == 33)) {
    		calculate_outputm25(input);
    	} 
    	if(( cf==1  && a363016538 == 35)) {
    		calculate_outputm27(input);
    	} 
    } 
    errorCheck();

    if( cf==1 ) 
    	fprintf(stderr, "Invalid input: %d\n", input); 
}

int main()
{
    int length = 20;
    int program[length];
    klee_make_symbolic(program, sizeof(program), "program");

    // main i/o-loop
    for (int i = 0; i < length; ++i) {
        // read input
        int input = program[i];
        if((input != 5) && (input != 3) && (input != 8) && (input != 9) && (input != 6) && (input != 7) && (input != 2) && (input != 4) && (input != 10) && (input != 1))
          return 0;
        calculate_output(input);
    }
}